from pathlib import Path
import json,os,time,sys
sys.path.insert(0,'/Users/sasha/math_gkm')
from machinery.study_common import ROOT,PYTHON,read,sha,write
from machinery.process import run
ops=ROOT/'.bootstrap/construction-v3-20261018'
manifest_path=ROOT/'evidence/harness-v3-install/20261018-006/INSTALLED_SOURCE_MANIFEST.json'
assert sha(manifest_path)=='2b141d4faf49da9ad082f6dea0f7694730723e725121e4528484a01de942a4fd'
files=read(manifest_path)['files_sha256']
def mismatches():return [n for n,h in files.items() if sha(ROOT/n)!=h]
assert not mismatches(),'installed sources changed before preflight'
parent=ROOT/'.scratch/installed006-preflight-parent'
parent.mkdir(parents=True,exist_ok=False)
started=time.monotonic()
write(ops/'INSTALLED_PREFLIGHT_006_INTENT.json',dict(manifest_sha256=sha(manifest_path),profile='config/darwin-memory-profile-006.json',out=str(parent/'check'),scope='actual installed full-Mathlib positive/negative/completion controls; no LLM calls',seconds=1800))
result=run([PYTHON,'-m','machinery.study_deployment','--out',str(parent/'check'),'--seconds','1800'],cwd=ROOT,env={**os.environ,'PATH':'/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin','TMPDIR':str(parent),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','PYTHONDONTWRITEBYTECODE':'1'},timeout=1800,output_bytes=1048576,scope=parent,tree_only=True,log_path=ops/'installed-preflight006.log')
write(ops/'INSTALLED_PREFLIGHT_006_RUN.json',dict(**result,source_mismatches_after=mismatches(),wall_seconds=time.monotonic()-started))
report=read(parent/'check/result.json') if (parent/'check/result.json').exists() else {}
print(json.dumps(dict(returncode=result.get('returncode'),termination=result.get('termination'),ready=report.get('ready'),failure=report.get('failure'),seconds=report.get('elapsed_seconds'),source_mismatches=mismatches()),indent=2))
raise SystemExit(0 if result.get('returncode')==0 and not result.get('termination') and report.get('ready') is True and not mismatches() else 1)
