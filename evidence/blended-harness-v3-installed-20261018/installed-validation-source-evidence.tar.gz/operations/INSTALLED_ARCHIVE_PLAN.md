Installed006 source-only evidence archive; source prepared and AST-checked only. No archive execution by reviewer.

Script SHA256155cfff21b3924a9709526fd93ef38f09e8df58bfb992d463255e583a7ed58fc.

From /Users/sasha/math_gkm, after completed portable record:

    /opt/homebrew/bin/python3 .bootstrap/construction-v3-20261018/archive_installed_evidence.py --execute --archive evidence/blended-harness-v3-installed-20261018/installed-validation-source-evidence.tar.gz --inventory evidence/blended-harness-v3-installed-20261018/installed-validation-source-evidence.manifest.json

The script checks completed installed preflight ready=true and rc0/noabort, installed Construction pass with unchanged sources, and isolated seven-module portable pass. It preserves the exact118 tested installed source files in the separate immutable snapshot, so later README/docs curation cannot alter test provenance. It also preserves the tested seven-module repro manifest/runner/README. Source/pin hashes, original raw receipt bytes, complete premise artifacts, commands/profiles/reviews, installed Construction proof workspace, all installed positive/negative/completion control sources and portable run report are retained. Existing package binaries used by portable testing are NOT copied and that test is explicitly not called a cold bootstrap.

Archive prefixes operations/, installation/, installed-preflight/, installed-construction/job/, installed-construction/proofs/, portable-construction/, independent-review/ preserve original role paths without rewriting hashed receipts. The manifest maps original absolute host paths. Installed manifest SHA2b141d4faf49da9ad082f6dea0f7694730723e725121e4528484a01de942a4fd; portable manifest SHA48146125c4e8a81271b7dfae30d3e3d9809230d22930eb36a078334dd32ae589; unchanged profile SHAfeada5a82c264d2ad98824a2ecd884b0b8242c7a6b6effb2b37c52228488abd4. Prior candidate archive SHA3ab351726d1b625831817043412a8e13d878436b5bac8d85b08fa86d5fb8e110 is referenced, not duplicated.

All hashes are streamed, every source is checked for modification before/during tar writing, max128MiB per member/512MiB total/6000 files. No .lake/package/Git/pycache trees or Lean/native compiled objects are retained, including olean private/server variants. No deletion, compilation, model call, cache update or publication is performed. Existing outputs are never overwritten. Root independently verifies members and publishes.
