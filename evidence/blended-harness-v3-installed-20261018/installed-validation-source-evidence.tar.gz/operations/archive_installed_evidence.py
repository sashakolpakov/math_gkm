#!/usr/bin/env python3
"""Source-only installed006 evidence archive. Never build, delete, or publish.
Run --execute only after the recorded portable test has completed. No package
or compiled-object tree is read into the archive. Original raw bytes retained.
"""
import argparse,codecs,gzip,hashlib,io,json,os,re,tarfile
from pathlib import Path
ROOT=Path('/Users/sasha/math_gkm')
OPS=ROOT/'.bootstrap/construction-v3-20261018'
SNAPSHOT=OPS/'installed006-tested-sources'
INSTALLATION=ROOT/'evidence/harness-v3-install/20261018-006'
PREFLIGHT=ROOT/'.scratch/installed006-preflight-parent/check'
CONSTRUCTION_JOB=ROOT/'.scratch/v3-validation/installed006-construction'
CONSTRUCTION_PROOFS=ROOT/'.scratch/v3-nwl8sy1f'
PORTABLE=ROOT/'.scratch/repro-construction-v3-20261018'
INSTALLED_MANIFEST_SHA='2b141d4faf49da9ad082f6dea0f7694730723e725121e4528484a01de942a4fd'
PORTABLE_MANIFEST_SHA='48146125c4e8a81271b7dfae30d3e3d9809230d22930eb36a078334dd32ae589'
PROFILE_SHA='feada5a82c264d2ad98824a2ecd884b0b8242c7a6b6effb2b37c52228488abd4'
CANDIDATE_ARCHIVE_SHA='3ab351726d1b625831817043412a8e13d878436b5bac8d85b08fa86d5fb8e110'
MAX_FILES=6000
MAX_MEMBER=128*1024**2
MAX_TOTAL=512*1024**2
PRUNE={'.git','.lake','__pycache__'}
BINARY_SUFFIXES={'.olean','.ilean','.o','.a','.so','.dylib','.dll','.exe','.bin','.zip','.pyc','.png','.jpg','.pdf','.c','.bc','.ll','.trace','.hash'}
REVIEWS=('math_gkm_v3_installed006_preflight_scope_audit.md','math_gkm_resource_repro_frozen006_review_20261018.md')
MAPPINGS=((OPS,'operations'),(INSTALLATION,'installation'),(PREFLIGHT,'installed-preflight'),
 (CONSTRUCTION_JOB,'installed-construction/job'),(CONSTRUCTION_PROOFS,'installed-construction/proofs'),
 (PORTABLE,'portable-construction'))

def fail(message): raise RuntimeError(message)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as source:
  for block in iter(lambda:source.read(1048576),b''):h.update(block)
 return h.hexdigest()
def stable(st): return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
def name_for(path):
 for base,prefix in MAPPINGS:
  if path.is_relative_to(base):return prefix+'/'+path.relative_to(base).as_posix()
 if path.parent==Path('/private/tmp') and path.name in REVIEWS:return 'independent-review/'+path.name
 if path.is_relative_to(ROOT):return 'repository-prerequisites/'+path.relative_to(ROOT).as_posix()
 fail('unapproved source root: '+str(path))
def excluded_by_name(path):
 return (any(path.name.endswith(s) for s in ('.olean.private','.olean.server','.tar.gz','.tar'))
         or path.suffix in BINARY_SUFFIXES)

def text_or_json_gzip(path):
 # Gzip is allowed ONLY for complete premise JSON, never a generic binary archive.
 if path.name.endswith('.json.gz'):return True
 if excluded_by_name(path):return False
 decoder=codecs.getincrementaldecoder('utf-8')('strict')
 try:
  with path.open('rb') as source:
   for block in iter(lambda:source.read(1048576),b''):
    if b'\0' in block:return False
    decoder.decode(block)
  decoder.decode(b'',final=True)
 except UnicodeDecodeError:return False
 return True



def sources(extra):
 selected={};skipped=[];scanned=0
 def add(path,required=False):
  nonlocal scanned
  path=Path(os.path.abspath(path))
  if not path.exists():
   if required:fail('required evidence missing: '+str(path))
   return
  if path.is_symlink():skipped.append({'path':name_for(path),'reason':'symlink; dependencies restored from pins'});return
  if not path.is_file():fail('explicit evidence is not a regular file: '+str(path))
  scanned+=1
  if scanned>MAX_FILES:fail('bounded evidence count')
  before=path.stat()
  if excluded_by_name(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'compiled or derived nonsource output'});return
  if before.st_size>MAX_MEMBER:fail('bounded member size: '+str(path))
  if not text_or_json_gzip(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'nonsource binary'});return
  sha=digest(path)
  if stable(path.stat())!=stable(before):fail('source changed during inventory: '+str(path))
  selected[name_for(path)]={'source_path':str(path),'bytes':before.st_size,'sha256':sha,'stat_identity':stable(before)}
 def tree(path):
  if not path.is_dir():fail('required bounded evidence tree missing: '+str(path))
  for directory,dirs,files in os.walk(path,followlinks=False,onerror=lambda e:fail(str(e))):
   dirs[:]=sorted(d for d in dirs if d not in PRUNE and not (Path(directory)/d).is_symlink())
   for filename in sorted(files):add(Path(directory)/filename)
 # Require completed actual records; no partial run is represented as success.
 installed_run=json.loads((OPS/'INSTALLED_PREFLIGHT_006_RUN.json').read_text())
 assert installed_run['returncode']==0 and not installed_run.get('termination') and installed_run['source_mismatches_after']==[]
 assert json.loads((PREFLIGHT/'result.json').read_text())['ready'] is True
 construction=json.loads((CONSTRUCTION_JOB/'result.json').read_text())
 assert construction['returncode']==0 and not construction.get('termination') and construction['source_mismatches_after']==[]
 portable_run=json.loads((OPS/'PORTABLE_CONSTRUCTION_V3_RUN.json').read_text())
 assert portable_run['returncode']==0 and not portable_run.get('termination')
 portable_report=Path(portable_run['stdout'].strip())
 assert portable_report.is_relative_to(PORTABLE)
 assert json.loads(portable_report.read_text())['status']=='passed_declared_profile_checks'
 marker=json.loads((PORTABLE/'.repro-workspace.json').read_text())
 assert marker['manifest_sha256']==PORTABLE_MANIFEST_SHA
 # Preserve tested source bytes independently of subsequent documentation edits.
 manifest=SNAPSHOT/'INSTALLED_SOURCE_MANIFEST.json'
 assert digest(manifest)==INSTALLED_MANIFEST_SHA
 installed=json.loads(manifest.read_text())
 assert len(installed['files_sha256'])==118
 for name,expected in installed['files_sha256'].items():
  assert digest(SNAPSHOT/'sources'/name)==expected,name
 assert digest(SNAPSHOT/'sources/config/darwin-memory-profile-006.json')==PROFILE_SHA
 assert digest(SNAPSHOT/'repro/manifest-construction-v3.json')==PORTABLE_MANIFEST_SHA
 tree(SNAPSHOT);tree(INSTALLATION);tree(PREFLIGHT);tree(CONSTRUCTION_JOB);tree(CONSTRUCTION_PROOFS);tree(PORTABLE)
 for path in sorted(OPS.iterdir()):
  if path.is_file() and path.name.startswith(('INSTALLED_','PORTABLE_','installed-','portable-','run_installed_','archive_installed_')):add(path)
 for name in REVIEWS:add(Path('/private/tmp')/name,True)
 for name in extra:
  path=Path(name)
  if not path.is_absolute():path=ROOT/path
  if not path.is_relative_to(ROOT):fail('--extra must be an explicitly named repository file')
  add(path,True)
 if sum(row['bytes'] for row in selected.values())>MAX_TOTAL:fail('aggregate512MiB bound')
 return selected,skipped,[str(PREFLIGHT),str(CONSTRUCTION_JOB),str(PORTABLE)],['v3-nwl8sy1f']


def metadata(selected,skipped,jobs,fixtures):
 return {'schema':'math-gkm.installed-source-validation-evidence.v1',
  'scope':'Exact installed006 and isolated seven-module reconstruction source/receipt preservation; no new theorem inferred',
  'installed_manifest_sha256':INSTALLED_MANIFEST_SHA,'portable_manifest_sha256':PORTABLE_MANIFEST_SHA,
  'approved_resource_profile_sha256':PROFILE_SHA,'prior_candidate_archive_sha256':CANDIDATE_ARCHIVE_SHA,
  'path_mapping':{prefix:str(base) for base,prefix in MAPPINGS},
  'independent_review_mapping':'/private/tmp named memos only',
  'reproduction_note':'Keep original receipt bytes/absolute paths as provenance. Restore source snapshots and pins into a NEW workspace. Portable test reused existing pinned dependency binaries and was not a cold network bootstrap; its report records7 fresh module compiles and7 kernel replays. Preserved historical repro profile remains separate.',
  'job_roots':jobs,'fixture_roots':fixtures,'excluded_directory_names':sorted(PRUNE),'members':selected,'excluded':skipped}


class HashedReader:
 def __init__(self,source):self.source=source;self.hash=hashlib.sha256()
 def read(self,n=-1):
  data=self.source.read(n);self.hash.update(data);return data

def write_archive(path,record):
 if path.exists():fail('archive already exists; never overwrite evidence')
 path.parent.mkdir(parents=True,exist_ok=True)
 try:
  with path.open('xb') as raw:
   with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
    with tarfile.open(fileobj=compressed,mode='w|') as archive:
     for name,member in sorted(record['members'].items()):
      source=Path(member['source_path'])
      if source.is_symlink() or stable(source.stat())!=tuple(member['stat_identity']):fail('source changed before archiving: '+str(source))
      info=tarfile.TarInfo(name);info.size=member['bytes'];info.mode=0o644;info.mtime=0
      with source.open('rb') as stream:
       reader=HashedReader(stream);archive.addfile(info,reader)
       if reader.hash.hexdigest()!=member['sha256'] or stable(os.fstat(stream.fileno()))!=tuple(member['stat_identity']):fail('source changed during archiving: '+str(source))
     body=(json.dumps(record,sort_keys=True,indent=2)+'\n').encode()
     info=tarfile.TarInfo('ARCHIVE_MANIFEST.json');info.size=len(body);info.mode=0o644;info.mtime=0
     archive.addfile(info,io.BytesIO(body))
 except BaseException:
  # Preserve a partial artifact for debugging, clearly distinguishable by the
  # absence of a success sidecar; never delete or replace any source evidence.
  raise
 return digest(path)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--inventory',type=Path,required=True)
 parser.add_argument('--execute',action='store_true')
 parser.add_argument('--archive',type=Path)
 parser.add_argument('--extra',action='append',default=[])
 args=parser.parse_args()
 if args.inventory.exists():fail('inventory already exists; choose a new finalization label')
 if args.execute and not args.archive:fail('--execute requires a NEW --archive path')
 selected,skipped,jobs,fixtures=sources(args.extra)
 record=metadata(selected,skipped,jobs,fixtures)
 record['archiver_source_sha256']=digest(Path(__file__))
 if args.execute:record['archive_sha256']=write_archive(args.archive,record)
 args.inventory.parent.mkdir(parents=True,exist_ok=True)
 with args.inventory.open('x') as out:json.dump(record,out,indent=2,sort_keys=True);out.write('\n')
 print(json.dumps({'members':len(selected),'source_bytes':sum(m['bytes'] for m in selected.values()),'excluded':len(skipped),'jobs':len(jobs),'inventory':str(args.inventory),'archive_sha256':record.get('archive_sha256')}))

if __name__=='__main__':main()
