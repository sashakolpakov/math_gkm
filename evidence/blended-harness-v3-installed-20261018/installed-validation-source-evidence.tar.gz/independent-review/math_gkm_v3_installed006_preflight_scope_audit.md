# Actual installed006 full-Mathlib preflight: independent scope audit

UTC 2026-10-18T18:53:29.122940+00:00

Read-only review of finished sources, operations, declaration closures and receipt hashes; no builds/tests/source changes by reviewer.

**Finding:** Actual installed preflight returned ready=true after519.726834seconds. It used the real sandbox, pinned full Mathlib import, Lean compiler, independent leanchecker and trusted premise inspector. Current installed machinery still matches the recorded source hashes. The operator wrapper returned0 with no termination or source mismatch. This is genuine neutral deployed-path evidence, not a Markov proof or whole-host continuation certificate.

## Mathematical positive

The staged source imports ResearchSemantics and **Mathlib** (full import). It defines Root as `∀ n : Nat, n+0=n` and proves identity by Nat.add_zero. English: every natural number, including zero, is unchanged by addition of zero. There are no logical hypotheses, positivity restrictions or finite index limits.

The positive runs four actual sandboxed project/wrapper compilations, four independent kernel replays and actual trusted premise inspection, all returning0 without termination. Its mandatory MathGKM.DeploymentRoot.identity constant occurs in the actual checked declaration closure. StudyObligation, StudyInterface and StudyTransport all have empty axiom closures. Interface/transport here are neutral True placeholders, not an additional gluing theorem.

## Controls: actual failures, not infrastructure substitutes

- **Wrong target:** the same identity proof is offered for a captured False target. The final StudyCheck compilation returns1 with actual Lean `error: Type mismatch`: the supplied theorem has type `∀ n, n+0=n`, while the captured Goal is required. No successful proof/admission is recorded.
- **Missing mandatory dependency:** compilation and all four kernel replays pass for the correct identity proposition. The actual trusted inspector then returns1 with `consumer does not use MathGKM.DeploymentRoot.Root`. This control intentionally requires that exact Root declaration in the dependency closure; it is a dependency-use condition, not a logical premise needed for the arithmetic theorem. The negative is not merely a warning, timeout or modeled failure.
- **Completion separation:** the real completion adapter compiles three modules, independently replays three and inspects the exact ControllerRootCheck successfully. lean_exact_root_checked=true and axiom closure empty, but resolved=false. Rejection is exactly `independent source/English correspondence audit required for this exact bundle`. Thus a checked neutral Lean root does not silently grant independent correspondence approval or campaign resolution.
- Real wrapper startup echo and Lean-version probes return0. Deliberately prohibited external read/write probes return1. These finite controls establish their observed behavior only.

## Receipt integrity

- Result: `/Users/sasha/math_gkm/.scratch/installed006-preflight-parent/check/result.json`.
  SHA256 `99d5d73e8d4348564ef1bcbdc26aab1bbd43b42ae516a8529b7d537db52446cf`.
- Deployment receipt: `/Users/sasha/math_gkm/.scratch/installed006-preflight-parent/check/receipt.json`.
  SHA256 `137c6f6a16e49713adcc153f04e9889c526dd20c57b0efc3a07bbc8ed657fd62`.
  All63 retained file hashes match and receipt.result_sha256 matches the actual result.
- Outer operator receipt: `/Users/sasha/math_gkm/.bootstrap/construction-v3-20261018/INSTALLED_PREFLIGHT_006_RUN.json`.
  SHA256 `00864df66907fe2074581eec67727d63dc46ec68714b8b7e1d22531392dad9f2`.
  returncode0, termination=null, source_mismatches_after=[].
- Positive retained source: `/Users/sasha/math_gkm/.scratch/installed006-preflight-parent/check/positive/source/MathGKM/DeploymentRoot.lean`.
  It matches the preflight workspace source and recorded neutral-source hash.

The preflight reports hosted_model_calls=0. It validates this installed environment's proof/control path, not model research ability, mathematical novelty, Markov log-concavity or exploration performance. Full-Mathlib validation now completes on006; prior005 startup refusal remains separate evidence. Resource observations remain sampled; no hard OOM guarantee follows. D1–D3 remain open for actual autonomous researcher self-changes.
