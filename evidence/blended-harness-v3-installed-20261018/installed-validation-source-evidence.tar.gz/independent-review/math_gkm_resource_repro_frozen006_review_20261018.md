Independent resource/reproducibility review — final checkpoint006

SCOPED CLEARANCE: the five affected numeric/headroom/resource checks and one small actual hidden-premise rejection may run sequentially under exact approved outerwatch6c. After final source installation/identity binding, one representative installed full-Mathlib preflight may run under that same fixed profile. A pass is not presumed; no automatic further threshold increase is authorized.

Exact binding independently checked:
- SOURCE_MANIFEST.json SHA25647757e16d92b964d58af75538e83c40d7956f6d3a94832a6feb37075dd983c8f.
- All294 live member hashes match, zero mismatches.
- machinery/resources.py SHA2564e57d4251a821ccf5ef4b41a6e16a3426a4b9bfd23c98bf492ee5387b68759ee.
- config/darwin-memory-profile-006.json SHA256feada5a82c264d2ad98824a2ecd884b0b8242c7a6b6effb2b37c52228488abd4.
- Exact outerwatch6c SHA256494346d7504f257162ae8224b14c03c1987cd6037c32b95495bd32e00645351b.

The substantive diff from005 is narrow and consistent with root's prospective decision: separate memory_admit_free becomes7GiB on Darwin and remains8GiB on Linux; disk admission stays8GiB. The existing5GiB dynamic memory/disk floor, native footprint4GiB sustained/5GiB hard, absolute aggregate RSS8GiB and all ownership/cleanup/output/process/time rules are unchanged. The independent outer watcher retains OS30%/25% checks; the core still reports its byte estimate separately. The available-memory estimator itself was not replaced with an unverified cache formula. Profile005 remains immutable provenance for005 receipts.

The active override validator now rejects bool, NaN and infinity before comparisons. It handles large integers without float conversion, preserves legitimate finite tightening, and rejects lowering memory/disk headroom floors. Tests exercise all limit keys, Darwin/Linux distinctions and exact floor boundaries. No mathematical Lean module, root/premise predicate, or parser changed in006.

The earlier005 representative preflight genuinely passed4 compiles and4 independent kernel replays, then refused the premise inspector's new admission below8GiB. Thus it admitted no theorem. Peak successful leaf native charge was887524680B versus observedRSS5790777344B. The root-approved7GiB admission leaves a2GiB margin above the existing dynamic stop, exceeding the observed leaf charge. This is a reasonable bounded operational trial, not an absolute memory-safety guarantee or a proof of final preflight success.

Previous preserved scope findings remain: final installed sources need their own manifest and implementation authorization; original historical MathGKM.lean must be preserved. The full32MiB bounded premise artifact must be parsed, with no catalog truncation or skipped root/premise checks. Generated Lean sources, receipts, pins, commands, failed runs, exact watcher versions and calibration measurements must be preserved publicly. No compiled-object or package-cache publication is necessary for source reproduction.

No candidate edits, builds, tests, cache changes or process termination were performed by this reviewer for006 clearance.
