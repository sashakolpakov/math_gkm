import MathGKM.Construction
import MathGKM.NeutralV3Root
def MathGKM.Target2f12f9e713650a4f035f2e2e.Interface :=
  (
    True
  )
def MathGKM.Target2f12f9e713650a4f035f2e2e.Transport (StudyInterface : MathGKM.Target2f12f9e713650a4f035f2e2e.Interface) : Prop :=
  (
    True
  )
def MathGKM.Target2f12f9e713650a4f035f2e2e.Goal (StudyInterface : MathGKM.Target2f12f9e713650a4f035f2e2e.Interface) : Prop :=
  (
    ∀ (n : Nat) (s : MathGKM.Continuation.State) (r : MathGKM.Continuation.Result)
              (env : MathGKM.Continuation.Environment) (reward : List MathGKM.Continuation.View → Int),
              MathGKM.Continuation.tryChange s = some r →
              MathGKM.Continuation.Execution env (n + 1) s (MathGKM.Continuation.run (n + 1) s env).state (MathGKM.Continuation.run (n + 1) s env).cost ∧
              (∃ continuationCost, MathGKM.Continuation.Execution env (n + 1) r.state (MathGKM.Continuation.afterChange (n + 1) r env).state continuationCost ∧
                (MathGKM.Continuation.afterChange (n + 1) r env).cost = r.cost + continuationCost) ∧
              (MathGKM.Continuation.afterChange (n + 1) r env).observations = (MathGKM.Continuation.run (n + 1) s env).observations ∧
              MathGKM.Continuation.utility reward (MathGKM.Continuation.run (n + 1) s env) <
                MathGKM.Continuation.utility reward (MathGKM.Continuation.afterChange (n + 1) r env)
  )
