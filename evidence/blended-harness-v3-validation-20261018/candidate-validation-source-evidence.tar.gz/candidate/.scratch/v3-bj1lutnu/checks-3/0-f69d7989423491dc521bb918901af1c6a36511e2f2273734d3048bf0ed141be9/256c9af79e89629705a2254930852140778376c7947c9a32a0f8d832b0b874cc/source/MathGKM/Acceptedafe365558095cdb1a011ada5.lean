import MathGKM.Target05c41b25d327382d56753566
import MathGKM.Accepted0c0c62cb492ed4920bdd7e6d
import Lean
def Acceptedafe365558095cdb1a011ada5.interface : MathGKM.Target05c41b25d327382d56753566.Interface :=
  (
    {
      forget := (
        fun e => by
          exact e.1
      )
      extend := (
        fun b => by
          exact (b, ())
      )
      forget_extend := (
        fun _ => by
          rfl
      )
    }
  )
theorem Acceptedafe365558095cdb1a011ada5.transport : MathGKM.Target05c41b25d327382d56753566.Transport Acceptedafe365558095cdb1a011ada5.interface :=
  (
    Acceptedafe365558095cdb1a011ada5.interface.forget_extend
  )
theorem Acceptedafe365558095cdb1a011ada5.obligation : MathGKM.Target05c41b25d327382d56753566.Goal Acceptedafe365558095cdb1a011ada5.interface :=
  (
    MathGKM.ResearchSemantics.ConservativeExtension.preserves Acceptedafe365558095cdb1a011ada5.interface (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) (fun b => Accepted0c0c62cb492ed4920bdd7e6d.obligation b.1 b.2)
  )
