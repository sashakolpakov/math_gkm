import MathGKM.Acceptedafe365558095cdb1a011ada5
import MathGKM.ResearchSemantics
import MathGKM.NeutralV3Root
def MathGKM.Target601b4bd33602e6611f56a6b8.Residual0 : Prop :=
  (
    ∀ e : ((Nat × Nat) × Unit), (fun e : (Nat × Nat) × Unit => e.1.1 + e.1.2 = e.1.2 + e.1.1) e
  )
def MathGKM.Target601b4bd33602e6611f56a6b8.Interface :=
  (
    MathGKM.ResearchSemantics.Representation (Nat × Nat) ((Nat × Nat) × Unit) (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) (fun e : (Nat × Nat) × Unit => e.1.1 + e.1.2 = e.1.2 + e.1.1)
  )
def MathGKM.Target601b4bd33602e6611f56a6b8.Transport (StudyInterface : MathGKM.Target601b4bd33602e6611f56a6b8.Interface) : Prop :=
  (
    ∀ b : (Nat × Nat), (fun e : (Nat × Nat) × Unit => e.1.1 + e.1.2 = e.1.2 + e.1.1) (StudyInterface.forward b) ↔ (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) b
  )
def MathGKM.Target601b4bd33602e6611f56a6b8.Goal (StudyInterface : MathGKM.Target601b4bd33602e6611f56a6b8.Interface) : Prop :=
  (
    (∀ e : ((Nat × Nat) × Unit), (fun e : (Nat × Nat) × Unit => e.1.1 + e.1.2 = e.1.2 + e.1.1) e) → ∀ b : (Nat × Nat), (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) b
  )
