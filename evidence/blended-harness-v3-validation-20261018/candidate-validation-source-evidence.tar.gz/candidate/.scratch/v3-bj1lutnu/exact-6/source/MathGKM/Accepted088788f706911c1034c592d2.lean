import MathGKM.Targetb71fbd293ff1c39f567d3bd8
import MathGKM.NeutralConsumer
import Lean
def Accepted088788f706911c1034c592d2.interface : MathGKM.Targetb71fbd293ff1c39f567d3bd8.Interface :=
  (
    True.intro
  )
theorem Accepted088788f706911c1034c592d2.transport : MathGKM.Targetb71fbd293ff1c39f567d3bd8.Transport Accepted088788f706911c1034c592d2.interface :=
  (
    True.intro
  )
theorem Accepted088788f706911c1034c592d2.obligation : MathGKM.Targetb71fbd293ff1c39f567d3bd8.Goal Accepted088788f706911c1034c592d2.interface :=
  (
    MathGKM.NeutralConsumer.finish
  )
