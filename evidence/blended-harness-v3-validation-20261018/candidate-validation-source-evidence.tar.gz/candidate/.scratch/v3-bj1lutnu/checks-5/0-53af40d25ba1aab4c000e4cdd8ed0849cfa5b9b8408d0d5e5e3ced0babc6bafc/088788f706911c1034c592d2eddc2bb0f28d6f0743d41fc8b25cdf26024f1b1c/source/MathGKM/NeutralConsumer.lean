import MathGKM.Accepted256c9af79e89629705a22549
import MathGKM.Acceptedafe365558095cdb1a011ada5
import MathGKM.Accepted6671fb7b70e9dda1d3f14764
theorem MathGKM.NeutralConsumer.finish : MathGKM.NeutralV3.Root := by
  intro n m
  let k := MathGKM.ResearchSemantics.pushLift (f := fun n : Nat => n) (F := fun _ : Nat => Nat) (G := fun _ : Nat => Nat) (fun n m : Nat => n + m)
  have hk : k = Accepted6671fb7b70e9dda1d3f14764.interface := Accepted6671fb7b70e9dda1d3f14764.obligation k (fun _ _ => rfl)
  let p := MathGKM.ResearchSemantics.pushUnit (fun n : Nat => n) (fun _ : Nat => Nat) n m
  have use : Accepted6671fb7b70e9dda1d3f14764.interface n p = n + m := (congrArg (fun z => z n p) hk).symm.trans rfl
  exact use.symm.trans ((Accepted6671fb7b70e9dda1d3f14764.transport n m).trans (Accepted256c9af79e89629705a22549.obligation Acceptedafe365558095cdb1a011ada5.obligation (n,m)))
