import MathGKM.Target601b4bd33602e6611f56a6b8
import MathGKM.Acceptedafe365558095cdb1a011ada5
import Lean
def Accepted256c9af79e89629705a22549.interface : MathGKM.Target601b4bd33602e6611f56a6b8.Interface :=
  (
    {
      forward := (
        Acceptedafe365558095cdb1a011ada5.interface.extend
      )
      law := (
        fun b => by
          change ((fun x : Nat × Nat => x.1 + x.2 = x.2 + x.1) (Acceptedafe365558095cdb1a011ada5.interface.forget (Acceptedafe365558095cdb1a011ada5.interface.extend b))) ↔ _
          exact Iff.of_eq (congrArg (fun x : Nat × Nat => x.1 + x.2 = x.2 + x.1) (Acceptedafe365558095cdb1a011ada5.transport b))
      )
    }
  )
theorem Accepted256c9af79e89629705a22549.transport : MathGKM.Target601b4bd33602e6611f56a6b8.Transport Accepted256c9af79e89629705a22549.interface :=
  (
    Accepted256c9af79e89629705a22549.interface.law
  )
theorem Accepted256c9af79e89629705a22549.obligation : MathGKM.Target601b4bd33602e6611f56a6b8.Goal Accepted256c9af79e89629705a22549.interface :=
  (
    MathGKM.ResearchSemantics.Representation.consume Accepted256c9af79e89629705a22549.interface
  )
