import MathGKM.Target033bbb9bdf1b12c0f946c8aa
import MathGKM.NeutralV3Root
import Lean
def Accepted0c0c62cb492ed4920bdd7e6d.interface : MathGKM.Target033bbb9bdf1b12c0f946c8aa.Interface :=
  (
    True.intro
  )
theorem Accepted0c0c62cb492ed4920bdd7e6d.transport : MathGKM.Target033bbb9bdf1b12c0f946c8aa.Transport Accepted0c0c62cb492ed4920bdd7e6d.interface :=
  (
    True.intro
  )
theorem Accepted0c0c62cb492ed4920bdd7e6d.obligation : MathGKM.Target033bbb9bdf1b12c0f946c8aa.Goal Accepted0c0c62cb492ed4920bdd7e6d.interface :=
  (
    Nat.add_comm
  )
