import MathGKM.Accepted0c0c62cb492ed4920bdd7e6d
import MathGKM.ResearchSemantics
import MathGKM.NeutralV3Root
def MathGKM.Target05c41b25d327382d56753566.Interface :=
  (
    MathGKM.ResearchSemantics.ConservativeExtension (Nat × Nat) ((Nat × Nat) × Unit)
  )
def MathGKM.Target05c41b25d327382d56753566.Transport (StudyInterface : MathGKM.Target05c41b25d327382d56753566.Interface) : Prop :=
  (
    ∀ b : (Nat × Nat), StudyInterface.forget (StudyInterface.extend b) = b
  )
def MathGKM.Target05c41b25d327382d56753566.Goal (StudyInterface : MathGKM.Target05c41b25d327382d56753566.Interface) : Prop :=
  (
    ∀ e : ((Nat × Nat) × Unit), (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) (StudyInterface.forget e)
  )
