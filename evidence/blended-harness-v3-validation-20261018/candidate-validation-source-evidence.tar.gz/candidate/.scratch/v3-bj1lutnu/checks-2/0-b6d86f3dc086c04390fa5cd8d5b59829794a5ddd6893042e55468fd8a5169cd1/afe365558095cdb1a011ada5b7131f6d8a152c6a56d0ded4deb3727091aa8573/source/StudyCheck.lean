import MathGKM.Target05c41b25d327382d56753566
import MathGKM.Accepted0c0c62cb492ed4920bdd7e6d
import Lean
def StudyInterface : MathGKM.Target05c41b25d327382d56753566.Interface :=
  (
    {
      forget := (
        fun e => by
          exact e.1
      )
      extend := (
        fun b => by
          exact (b, ())
      )
      forget_extend := (
        fun _ => by
          rfl
      )
    }
  )
theorem StudyTransport : MathGKM.Target05c41b25d327382d56753566.Transport StudyInterface :=
  (
    StudyInterface.forget_extend
  )
theorem StudyObligation : MathGKM.Target05c41b25d327382d56753566.Goal StudyInterface :=
  (
    MathGKM.ResearchSemantics.ConservativeExtension.preserves StudyInterface (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) (fun b => Accepted0c0c62cb492ed4920bdd7e6d.obligation b.1 b.2)
  )
