import MathGKM.Target1f9c269a652db5c37b89c715
import MathGKM.ResearchSemantics
import Lean
def StudyInterface : MathGKM.Target1f9c269a652db5c37b89c715.Interface :=
  (
    MathGKM.ResearchSemantics.pushLift (f := (fun n : Nat => n)) (F := (fun _ : Nat => Nat)) (G := (fun _ : Nat => Nat)) (fun n m : Nat => n + m)
  )
theorem StudyTransport : MathGKM.Target1f9c269a652db5c37b89c715.Transport StudyInterface :=
  (
    MathGKM.ResearchSemantics.push_beta (f := (fun n : Nat => n)) (F := (fun _ : Nat => Nat)) (G := (fun _ : Nat => Nat)) (fun n m : Nat => n + m)
  )
theorem StudyObligation : MathGKM.Target1f9c269a652db5c37b89c715.Goal StudyInterface :=
  (
    MathGKM.ResearchSemantics.push_unique (f := (fun n : Nat => n)) (F := (fun _ : Nat => Nat)) (G := (fun _ : Nat => Nat)) (fun n m : Nat => n + m)
  )
