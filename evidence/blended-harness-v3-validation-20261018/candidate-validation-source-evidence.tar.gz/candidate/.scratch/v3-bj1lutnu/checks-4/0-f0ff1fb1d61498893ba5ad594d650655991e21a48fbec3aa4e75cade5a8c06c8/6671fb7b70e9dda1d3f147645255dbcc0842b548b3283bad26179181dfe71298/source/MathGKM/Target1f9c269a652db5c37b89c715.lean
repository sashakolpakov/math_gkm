import MathGKM.ResearchSemantics
import MathGKM.NeutralV3Root
def MathGKM.Target1f9c269a652db5c37b89c715.Interface :=
  (
    ∀ j : (Nat), MathGKM.ResearchSemantics.Push (fun n : Nat => n) (fun _ : Nat => Nat) j → (fun _ : Nat => Nat) j
  )
def MathGKM.Target1f9c269a652db5c37b89c715.Transport (StudyInterface : MathGKM.Target1f9c269a652db5c37b89c715.Interface) : Prop :=
  (
    ∀ (i : (Nat)) (x : (fun _ : Nat => Nat) i), StudyInterface ((fun n : Nat => n) i) (MathGKM.ResearchSemantics.pushUnit (fun n : Nat => n) (fun _ : Nat => Nat) i x) = (fun n m : Nat => n + m) i x
  )
def MathGKM.Target1f9c269a652db5c37b89c715.Goal (StudyInterface : MathGKM.Target1f9c269a652db5c37b89c715.Interface) : Prop :=
  (
    ∀ k : (∀ j : (Nat), MathGKM.ResearchSemantics.Push (fun n : Nat => n) (fun _ : Nat => Nat) j → (fun _ : Nat => Nat) j), (∀ (i : (Nat)) (x : (fun _ : Nat => Nat) i), k ((fun n : Nat => n) i) (MathGKM.ResearchSemantics.pushUnit (fun n : Nat => n) (fun _ : Nat => Nat) i x) = (fun n m : Nat => n + m) i x) → k = StudyInterface
  )
