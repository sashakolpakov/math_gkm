import MathGKM.Target8a60f20193f4965330cf5a9d
import MathGKM.NeutralV3Root
import Lean
def Acceptede85572672bcfe4eaee41cd82.interface : MathGKM.Target8a60f20193f4965330cf5a9d.Interface :=
  (
    True.intro
  )
theorem Acceptede85572672bcfe4eaee41cd82.transport : MathGKM.Target8a60f20193f4965330cf5a9d.Transport Acceptede85572672bcfe4eaee41cd82.interface :=
  (
    True.intro
  )
theorem Acceptede85572672bcfe4eaee41cd82.obligation : MathGKM.Target8a60f20193f4965330cf5a9d.Goal Acceptede85572672bcfe4eaee41cd82.interface :=
  (
    Nat.add_comm
  )
