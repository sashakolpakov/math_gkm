import MathGKM.NeutralV3Root
def MathGKM.Target8a60f20193f4965330cf5a9d.Interface :=
  (
    True
  )
def MathGKM.Target8a60f20193f4965330cf5a9d.Transport (StudyInterface : MathGKM.Target8a60f20193f4965330cf5a9d.Interface) : Prop :=
  (
    True
  )
def MathGKM.Target8a60f20193f4965330cf5a9d.Goal (StudyInterface : MathGKM.Target8a60f20193f4965330cf5a9d.Interface) : Prop :=
  (
    ∀ n m : Nat, n + m = m + n
  )
