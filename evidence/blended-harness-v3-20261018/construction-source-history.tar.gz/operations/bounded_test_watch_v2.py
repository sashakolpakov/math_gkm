"""Supervisor-only operational bounds around one independent constructor invocation.
No mathematical research or harness implementation. RSS is summed per-process
resident memory and can double-count shared pages; this is a conservative guard.
"""
from pathlib import Path
import argparse, ctypes, json, os, re, shutil, signal, subprocess, sys, time

# Darwin identity layout from Apple XNU bsd/sys/proc_info.h (PROC_PIDTBSDINFO).
# https://github.com/apple-oss-distributions/xnu/blob/main/bsd/sys/proc_info.h
class BSDInfo(ctypes.Structure):
 _fields_=[(name,ctypes.c_uint32) for name in ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','reserved')]+[('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[(name,ctypes.c_uint32) for name in ('nfiles','pgid','pjobc','e_tdev','e_tpgid')]+[('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]
LIBPROC=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
LIBPROC.proc_pidinfo.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int]
LIBPROC.proc_pidinfo.restype=ctypes.c_int

def process_info(pid):
 info=BSDInfo()
 ctypes.set_errno(0)
 n=LIBPROC.proc_pidinfo(pid,3,0,ctypes.byref(info),ctypes.sizeof(info))
 if n!=ctypes.sizeof(info):
  if ctypes.get_errno() in (3,):return None
  raise RuntimeError('native process birth monitor unavailable: '+str(ctypes.get_errno()))
 if info.pid!=pid:return None
 return {'birth':(int(info.start_sec),int(info.start_usec)),'ppid':int(info.ppid),'pgid':int(info.pgid),'status':int(info.status)}

def identity(pid):
 info=process_info(pid)
 return info['birth'] if info else None

GIB=1024**3
ROOT=Path('/Users/sasha/math_gkm')
CANDIDATE=ROOT/'.scratch/strategy-v3-blended-20261018'
OPS=ROOT/'.bootstrap/construction-v3-20261018'

def processes():
 r=subprocess.run(['/bin/ps','-axo','pid=,ppid=,rss='],capture_output=True,text=True,timeout=3)
 if r.returncode: raise RuntimeError('process monitor unavailable: '+r.stderr[:200])
 table={}
 for line in r.stdout.splitlines():
  x=line.split()
  if len(x)==3: table[int(x[0])]=(int(x[1]),int(x[2])*1024)
 if not table or os.getpid() not in table:raise RuntimeError('empty/incomplete process observation')
 return table

def discover(table, seen, known_groups):
 # ps provides candidate PIDs/RSS only. Ancestry is admitted using a CURRENT
 # native PPID plus birth-confirmed parent; never overwrite a prior birth.
 owned={}
 for pid,birth in seen.items():
  info=process_info(pid)
  if info and info['birth']==birth:owned[pid]=info
 for _ in range(len(table)+1):
  added=False
  for pid in table:
   if pid in owned or pid in seen or table[pid][0] not in owned:continue
   info=process_info(pid)
   if not info or info['ppid'] not in owned:continue
   parent=process_info(info['ppid'])
   if not parent or parent['birth']!=seen[info['ppid']]:continue
   seen[pid]=info['birth'];owned[pid]=info;known_groups.add(info['pgid']);added=True
  if not added:break
 return owned

def bytes_used():
 size=0
 def scan_error(error):raise error
 for directory, dirs, files in os.walk(CANDIDATE,followlinks=False,onerror=scan_error):
  dirs[:]=[d for d in dirs if not (Path(directory)/d).is_symlink()]
  for name in files:
   p=Path(directory)/name
   if not p.is_symlink():
    try:size+=p.stat().st_size
    except FileNotFoundError:pass
 return size

def memory_free_percent():
 r=subprocess.run(['/usr/bin/memory_pressure','-Q'],capture_output=True,text=True,timeout=3)
 if r.returncode:raise RuntimeError('system memory-pressure monitor unavailable')
 m=re.search(r'System-wide memory free percentage:\s*(\d+)%',r.stdout)
 if not m:raise RuntimeError('unrecognized memory-pressure output')
 return int(m.group(1))

def main():
 a=argparse.ArgumentParser(); a.add_argument('--label',required=True); a.add_argument('--seconds',type=int,default=1800); a.add_argument('command',nargs=argparse.REMAINDER); args=a.parse_args()
 if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',args.label):raise ValueError('simple unique label required')
 if not 1<=args.seconds<=3600:raise ValueError('bounded wall allowance1..3600s required')
 if args.command[:1]==['--']:args.command=args.command[1:]
 if not args.command:raise ValueError('explicit bounded test command required')
 log=OPS/f'testwatch-{args.label}.jsonl'; summary=OPS/f'testwatch-{args.label}.json'
 if log.exists() or summary.exists(): raise RuntimeError('operational receipt exists; choose new round')
 if (OPS/'RESOURCE_CLEANUP_HOLD.json').exists():raise RuntimeError('unresolved prior cleanup hold; independent inspection required')
 if shutil.disk_usage(ROOT).free<8*GIB:raise RuntimeError('constructor refused: less than8GiB free')
 if memory_free_percent()<30:raise RuntimeError('constructor refused: less than30% system memory free')
 if identity(os.getpid()) is None:raise RuntimeError('constructor refused: own native birth identity unavailable')
 initial=bytes_used(); started=time.monotonic(); seen={}; root_birth=None; known_groups=set(); p=None; error=None; cleanup_errors=[]; peak=0; peak_count=0; low_samples=0; soft_samples=0; max_growth=0
 try:
  command=args.command
  with (OPS/f'testwatch-{args.label}.stdout').open('xb') as out:
   env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
   p=subprocess.Popen(command,cwd=CANDIDATE,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
   known_groups.add(p.pid)
   root_birth=identity(p.pid)
   if root_birth is None:raise RuntimeError('constructor root vanished before birth identity capture')
   seen[p.pid]=root_birth
   os.set_blocking(p.stdout.fileno(),False)
   written=0
   with log.open('x') as stream:
    while True:
     # Stream with pipe backpressure and a fixed retained-output cap.
     while True:
      try:data=os.read(p.stdout.fileno(),65536)
      except BlockingIOError:break
      if not data:break
      if written+len(data)>8*1024*1024:raise RuntimeError('outer retained-output8MiB limit')
      out.write(data);out.flush();written+=len(data)
     # Do not reap the direct child before group cleanup: its reserved PID
     # then keeps the original private PGID valid even if its parent exits
     # before the first sample, leaving an ordinary orphan in that group.
     leader=process_info(p.pid)
     if leader is None:raise RuntimeError('unreaped child identity unexpectedly unavailable')
     if leader['birth']!=root_birth:raise RuntimeError('unreaped child identity changed')
     if leader['status']==5:break  # Darwin SZOMB; p.wait only after cleanup.
     table=processes()
     owned=discover(table,seen,known_groups)
     rss=sum(table[x][1] for x in owned if x in table);peak=max(peak,rss);peak_count=max(peak_count,len(owned))
     free=shutil.disk_usage(ROOT).free; growth=bytes_used()-initial;max_growth=max(max_growth,growth); memfree=memory_free_percent()
     sample={'elapsed':round(time.monotonic()-started,2),'owned':len(owned),'tree_rss':rss,'free_disk':free,'candidate_growth':growth,'system_memory_free_percent':memfree}
     stream.write(json.dumps(sample)+'\n');stream.flush()
     soft_samples=soft_samples+1 if rss>4*GIB else 0;low_samples=low_samples+1 if memfree<25 else 0
     if rss>5*GIB or soft_samples>=3:raise RuntimeError('owned constructor RSS limit')
     if len(owned)>24:raise RuntimeError('owned constructor process-count limit')
     if free<5*GIB:raise RuntimeError('minimum-free-disk limit')
     if growth>GIB:raise RuntimeError('candidate1GiB growth limit')
     if low_samples>=3:raise RuntimeError('system available-memory headroom limit')
     if time.monotonic()-started>args.seconds+15:raise TimeoutError('constructor outer wall limit')
     time.sleep(2)
 except BaseException as exc:error=type(exc).__name__+': '+str(exc)
 finally:
  if p:
   # A failed broad ps observation does not bypass birth-checked cleanup.
   # libproc provides an independent per-process birth identity for fallback.
   try:
    table=processes()
    discover(table,seen,known_groups)
   except BaseException as exc:cleanup_errors.append('process-table cleanup fallback: '+str(exc))
   for sig in (signal.SIGTERM,signal.SIGKILL):
    live_groups=set()
    for pid,birth in list(seen.items()):
     try:
      info=process_info(pid)
      if not info or info['birth']!=birth:continue
      pgid=info['pgid']
      if pgid in known_groups and pgid!=os.getpgrp():live_groups.add(pgid)
     except ProcessLookupError:pass
     except BaseException as exc:cleanup_errors.append('identity confirmation failed: '+str(exc))
    # Signal a process group only while a birth-confirmed owned member still
    # belongs to its previously recorded private group. This also reaps unseen
    # descendants in that group; no unrelated repository process is selected.
    for pgid in live_groups:
     try:os.killpg(pgid,sig)
     except ProcessLookupError:pass
     except BaseException as exc:cleanup_errors.append('owned group cleanup failed: '+str(exc))
    for pid,birth in reversed(list(seen.items())):
     try:
      if identity(pid)==birth:os.kill(pid,sig)
     except ProcessLookupError:pass
     except BaseException as exc:cleanup_errors.append('owned process cleanup failed: '+str(exc))
    if sig==signal.SIGTERM:time.sleep(1)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:
    # p is our unreaped child: its PID cannot have been reused.
    p.kill();p.wait()
   if cleanup_errors:
    error=error or 'cleanup observation incomplete; refuse next launch pending review'
    (OPS/'RESOURCE_CLEANUP_HOLD.json').write_text(json.dumps({'label':args.label,'errors':cleanup_errors,'seen_births':seen,'action':'Independent owned-process inspection required before removing this hold'},indent=2)+'\n')
  result={'error':error,'exit_code':p.returncode if p else None,'elapsed':round(time.monotonic()-started,3),'peak_owned_rss':peak,'peak_owned_processes':peak_count,'max_candidate_growth':max_growth,'free_disk_final':shutil.disk_usage(ROOT).free,'cleanup_errors':cleanup_errors,'ownership':'observed descendants bound to native birth seconds+microseconds; verified private groups; observation and signal are not atomic','rss_scope':'sum of owned process resident sets; shared pages may be counted twice','command':command,'scope':str(CANDIDATE),'label':args.label,'monitor_failures':'fail closed; no hard OOM guarantee if OS monitoring unavailable'}
  summary.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 return 0 if not error and p and p.returncode==0 else 1
if __name__=='__main__':sys.exit(main())
