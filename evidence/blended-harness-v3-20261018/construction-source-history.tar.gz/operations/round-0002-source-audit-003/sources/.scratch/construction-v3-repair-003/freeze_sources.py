"""Source reading/hashing/copying only. No candidate import, parser or execution.

Records repair invocation 003 without changing prior checkpoints or receipts.
"""
from pathlib import Path
import hashlib
import json
import shutil
from datetime import datetime,timezone

root=Path.cwd()
out=root/'evidence/construction-v3/source-audit-003'
prior=root/'evidence/construction-v3/source-audit-002/SOURCE_MANIFEST.json'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1048576),b''): h.update(block)
    return h.hexdigest()
def put(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

old=json.loads((root/'CONSTRUCTION_V3_AUDIT.json').read_text())
oldmanifest=json.loads(prior.read_text())
touched='''machinery/resources.py machinery/process.py machinery/study_worker.py
machinery/v3_validate.py machinery/neutral_validate.py machinery/study_common.py
machinery/study.py machinery/validation_receipts.py machinery/study_transfer.py
machinery/study_knowledge.py machinery/residual_dag.py machinery/study_policy.py
machinery/study_curate.py machinery/study_deployment.py machinery/retention.py
machinery/study_audit.py machinery/completion.py machinery/study_completion.py
machinery/worker.py tests/test_construction_v3.py tests/test_construction_v3_resources.py
tests/test_construction_v3_repair.py tests/test_sol_deployment.py docs/STUDY_V3.md
docs/CONSTRUCTION_V3.md docs/HARNESS_CHECKPOINT.md docs/REGRESSION.md
docs/STUDY_V2.md docs/REQUIREMENT_MAP.md'''.split()
disposition=dict(schema='math-gkm.installation-source-disposition.v1',installation_performed=False,
    candidate_only_exclusions={'MathGKM.lean':dict(sha256=sha(root/'MathGKM.lean'),
        action='EXCLUDE FROM INSTALLATION. Preserve installed MathGKM.lean byte-for-byte, including all historical Agoh imports. This candidate-only workaround is not an API migration.'),
        'MathGKM/NeutralV3Root.lean':dict(sha256=sha(root/'MathGKM/NeutralV3Root.lean'),action='Acceptance fixture; no installed research result.')},
    additive_entrypoint={'MathGKM/Construction.lean':sha(root/'MathGKM/Construction.lean')},
    historical_agoh='Historical Agoh modules absent from candidate. Do not delete or overwrite installed modules/imports. Historical recompilation remains OPEN at installation review.',
    runtime_and_acceptance_overlay=[n for n in touched if n.startswith(('machinery/','tests/','docs/'))],
    excluded_from_overlay=['MathGKM.lean','.bootstrap/','.scratch/','evidence/'],
    protected_sources={n:sha(root/n) for n in old['protected']},
    meaning='Source disposition only; no installation, execution or approval claim.')
put(root/'INSTALLATION_SOURCE_DISPOSITION.json',disposition)

manifest_name='evidence/construction-v3/source-audit-003/SOURCE_MANIFEST.json'
prefix='/opt/homebrew/bin/python3 -m machinery.v3_validate --manifest '+manifest_name+' --label '
selectors=[
 ('repair-pure','tests.test_construction_v3.Pure tests.test_construction_v3_repair.PureRepair'),
 ('repair-resources','tests.test_construction_v3_resources.Resources tests.test_construction_v3_repair.ResourceRepair'),
 ('repair-fresh-consumer','tests.test_construction_v3.CheckedMath.test_successive_admission_fresh_consumer_exact_root'),
 ('repair-partial','tests.test_construction_v3.CheckedMath.test_valid_math_invalid_optional_metadata_later_bad_item_recovery'),
 ('repair-original-dag','tests.test_construction_v3.CheckedMath.test_checked_dag_actual_composition_and_unconnected_true'),
 ('repair-negatives','tests.test_construction_v3.CheckedMath.test_negative_math_boundaries_representation_section_premises_and_axiom'),
 ('repair-context','tests.test_context_revision.ContextRevision.test_residual_same_text_different_context_and_positive_discharge tests.test_context_revision.ContextRevision.test_canonical_root_and_foundation_cannot_be_substituted tests.test_context_revision.ContextRevision.test_task_absent_before_cannot_acquire_adapter_meaning'),
 ('repair-existing','tests.test_construction_v3_repair.CheckedRepair.test_existing_nodes_multilevel_composition_and_required_inspector_closure'),
 ('repair-representation','tests.test_construction_v3_repair.CheckedRepair.test_representation_residual_actual_composition'),
 ('repair-crash','tests.test_construction_v3_repair.CheckedRepair.test_crash_receipt_export_state_snapshot_idempotent_recovery'),
 ('repair-incomplete','tests.test_construction_v3_repair.CheckedRepair.test_incomplete_receipt_and_changed_dependency_rejected_without_free_replay'),
 ('repair-and-or','tests.test_construction_v3_repair.CheckedRepair.test_checked_and_or_routes_cycles_false_open_and_unconnected_true'),
 ('repair-construction','tests.test_construction_v3_repair.CheckedRepair.test_clean_construction_closure_actual_verified_change_consumer'),
 ('repair-matched','tests.test_construction_v3.MatchedContinuation')]
commands=[prefix+label+' '+selection for label,selection in selectors]
commands.append('/opt/homebrew/bin/python3 -m machinery.study_deployment --out .scratch/v3-deployment-003-FRESH --seconds 1800')
audit=dict(phase='construction',schema='math-gkm.construction-v3.source-audit',
    model='gpt-6.1-sol',invocation='source-repair-003',reasoning='high',
    invocation_record='.scratch/construction-v3-repair-003/INVOCATION.json',
    status='STOPPED FOR INDEPENDENT SOURCE AUDIT; ALL CURRENT TESTS NOT RUN',
    tests_run=False,compilers_run=False,preflights_run=False,probes_run=False,campaigns_launched=False,
    syntax_check='Source inspection only. No ast.parse, py_compile, compiler, test collection or behavioral probe.',
    checkpoint=manifest_name,prior_checkpoint=dict(manifest=str(prior.relative_to(root)),sha256=sha(prior),
        disposition='Immutable prior invocation and receipts retained; this is a new bounded repair.'),
    changed_files_sha256={n:sha(root/n) for n in touched},
    protected={n:dict(before=v['after'],after=sha(root/n),unchanged=v['after']==sha(root/n)) for n,v in old['protected'].items()},
    limits=old['limits'],open_obligations=old['open_obligations'],
    source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',
    dispositions=[
      'Exact named premises referenced without recreated residual definitions; generated dependencies reach mandatory inspector; DAG/schema in next request.',
      'Representation antecedents are exact nodes; AND leaves retained, OR closed routes preserved, cycles rejected; actual checked composition remains mandatory.',
      'Per-item durable journal, atomic exports, finished exact validator bundles and source/binary/pin/receipt verification; partial/uncertain checks never replay silently.',
      'Birth-bound immutable ownership, current-parent discovery, worker counts excluding Lake, cleanup fallback/hold, common job disk scope, durable lease release.',
      'Independent bounded source copies without hardlink aliases, source allowlist, bounded retention, exact pins/recipes/receipts before output retirement.',
      'Neutral runners guarded without outer heavy lease; explicit curator model/provenance; full-Mathlib actual deployment positive prepared.',
      'Concrete existing typed consumer preserved and clean Construction/verified_change consumer prepared; installed aggregate excluded from candidate overlay.',
      'Report theorem admission, independent scope and checked root path separately; audit metrics remain one-way.'],
    planned_commands=commands,
    execution_environment='env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null PYTHONDONTWRITEBYTECODE=1 TMPDIR='+str(root/'.scratch'),
    execution_gate='Supervisor independent review binds exact manifest in .bootstrap/construction-v3-review.json before test runner. Run sequentially, retain every result and interruption. No automatic resource escalation.',
    trial_authorization='User already authorizes root fresh matched Markov trials AFTER combined harness passes independent audit and actual tests; same own gpt-6.1-sol, unchanged root, original clean seed, identical budgets and no inherited case proofs or math hints. Constructor launches none.',
    remaining=[
      'Independent source audit and every prepared test/compile/replay/premise/preflight outcome remain unknown.',
      'Actual full Mathlib sandbox capacity, libproc layout/monitor behavior and exhaustive crash/platform matrix need observed tests.',
      'Polling is not arbitrary hostile-daemon containment; host OS isolation remains required. Darwin RSS may double count shared pages.',
      'Historical installed aggregate and Agoh modules cannot be recompiled in this curated candidate; preserve them on installation.',
      'D1/D2/D3 OPEN; matched empirical selection cannot certify the whole live continuation.'],
    manifest_rule='Frozen manifest binds audit plus all current source/docs/tests/scripts/pins and invocation helpers; audit excludes its own hash.')
put(root/'CONSTRUCTION_V3_AUDIT.json',audit)
names=set(oldmanifest['files_sha256'])
for folder,pattern in [('machinery','*.py'),('tests','*.py'),('MathGKM','*.lean'),('docs','*.md'),('contracts','*.json'),('studies','*.json')]:
    names.update(str(p.relative_to(root)) for p in (root/folder).rglob(pattern) if p.is_file() and not p.is_symlink())
names.update(touched)
names.update(['CONSTRUCTION_V3_AUDIT.json','INSTALLATION_SOURCE_DISPOSITION.json','MathGKM.lean',
    '.scratch/construction-v3-repair-003/INVOCATION.json','.scratch/construction-v3-repair-003/freeze_sources.py',
    '.bootstrap/queued-source-review.md','.bootstrap/resource-repro-audit.md','.bootstrap/architecture-audit-updated.md'])
names.update(old['protected'])
hashes={n:sha(root/n) for n in sorted(names)}
out.mkdir(parents=True,exist_ok=False)
for n in sorted(names):
    target=out/'sources'/n
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/n,target)
    target.chmod(0o444)
manifest=dict(schema='math-gkm.frozen-source-audit.v3',created_utc=datetime.now(timezone.utc).isoformat(),
    invocation='source-repair-003',files_sha256=hashes,source_count=len(hashes),
    tests_run=False,compilers_run=False,preflights_run=False,syntax_check='inspection only; not parsed or executed',
    prior_checkpoint=audit['prior_checkpoint'],installation_disposition_sha256=sha(root/'INSTALLATION_SOURCE_DISPOSITION.json'),
    gaps=audit['remaining'],planned_commands=commands)
put(out/'SOURCE_MANIFEST.json',manifest)
(out/'SOURCE_MANIFEST.json').chmod(0o444)
(out/'SOURCE_MANIFEST.sha256').write_text(sha(out/'SOURCE_MANIFEST.json')+'  SOURCE_MANIFEST.json\n')
(out/'SOURCE_MANIFEST.sha256').chmod(0o444)
print(json.dumps(dict(checkpoint=manifest_name,sha256=sha(out/'SOURCE_MANIFEST.json'),sources=len(hashes),
    tests_run=False,syntax_check='inspection only',protected_unchanged=all(v['unchanged'] for v in audit['protected'].values()))))
