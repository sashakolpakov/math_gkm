"""Shared host admission and ownership-scoped observation, never proof evidence.

One heavy lease covers validators, replay, inspectors and external proposers.
Limits can only be lowered by callers. Darwin RSS sums can double-count shared
pages; vm_stat gives a conservative available-memory estimate, not physical
ownership. Missing required observations fail closed, with an explicit reason.
"""
import contextlib
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import selectors
import time

GiB = 1024**3
ROOT = Path(__file__).resolve().parents[1]
LIMITS = dict(rss_sustained=4*GiB, rss_hard=5*GiB, sustained_seconds=3,
              admit_free=8*GiB, hard_free=5*GiB, growth=GiB,
              processes=24, poll_seconds=1, timeout=1800, output_bytes=GiB)

class ResourceFailure(RuntimeError):
    pass

def cleanup_hold(reason, owned=None):
    """A supervisor must reconcile this durable hold before another launch."""
    from .study_common import write
    base=ROOT/'.scratch/resources'
    base.mkdir(parents=True,exist_ok=True)
    write(base/'UNRESOLVED_CLEANUP.json',dict(reason=str(reason),owned=owned or {},
        created=time.time(),status='unresolved; no automatic release'))

def limits(overrides=None):
    out = dict(LIMITS)
    for k,v in (overrides or {}).items():
        if k not in out or not isinstance(v, (int,float)) or v <= 0:
            raise ResourceFailure('invalid resource limit')
        # Headroom floors may be raised, all other caps may only be reduced.
        if (k in ('admit_free','hard_free') and v < out[k]) or (k not in ('admit_free','hard_free') and v > out[k]):
            raise ResourceFailure('resource override increases immutable global bound')
        out[k] = v
    return out

def observation(argv):
    """Small, bounded OS observer, deliberately outside the guarded launcher."""
    p = None
    try:
        p = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        data=bytearray(); start=time.monotonic()
        with selectors.DefaultSelector() as selector:
            for stream in (p.stdout,p.stderr):
                os.set_blocking(stream.fileno(),False)
                selector.register(stream,selectors.EVENT_READ)
            while selector.get_map():
                if time.monotonic()-start>2: raise ResourceFailure('observer timeout')
                for key,_ in selector.select(.02):
                    block=os.read(key.fd,8192)
                    if not block: selector.unregister(key.fileobj); continue
                    if len(data)+len(block)>2**20: raise ResourceFailure('observer output bound')
                    data.extend(block)
            p.wait(timeout=max(.01,2-(time.monotonic()-start)))
        if p.returncode: raise ResourceFailure('observer nonzero exit')
        return data.decode(errors='strict')
    except (OSError,ValueError,UnicodeError,subprocess.TimeoutExpired,ResourceFailure) as exc:
        raise ResourceFailure('monitor_unavailable: '+str(argv[0])+': '+str(exc)) from exc
    finally:
        if p:
            if p.poll() is None: p.kill()
            p.wait()
            p.stdout.close(); p.stderr.close()

def current_process(pid):
    """Current birth and parent from the OS, independent of stale ps ancestry.

    Darwin start time includes microseconds; Linux uses kernel start ticks.
    This is observational ownership, not containment of arbitrary hostile code.
    """
    try:
        if os.uname().sysname == 'Darwin':
            import ctypes
            class BSDInfo(ctypes.Structure):
                _fields_=[(n,ctypes.c_uint32) for n in
                    ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','rfu')]+[
                    ('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[
                    (n,ctypes.c_uint32) for n in ('nfiles','pgid','pjobc','e_tdev','e_tpgid')]+[
                    ('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]
            lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
            info=BSDInfo()
            size=lib.proc_pidinfo(int(pid),3,0,ctypes.byref(info),ctypes.sizeof(info))
            if size==0 and ctypes.get_errno() in (0,3): return None
            if size!=ctypes.sizeof(info) or info.pid!=pid: raise ResourceFailure('proc_pidinfo unavailable')
            if info.status==5: return None  # exited zombie; cannot spawn descendants
            return dict(identity=str(info.start_sec)+':'+str(info.start_usec),ppid=info.ppid)
        with open('/proc/'+str(pid)+'/stat') as f: raw=f.read(8192)
        fields=raw[raw.rindex(')')+2:].split()
        if fields[0]=='Z': return None
        return dict(identity=fields[19],ppid=int(fields[1]))
    except FileNotFoundError: return None
    except (OSError,ValueError,IndexError) as exc:
        raise ResourceFailure('monitor_unavailable: birth/parent identity') from exc

def available_memory():
    if os.uname().sysname == 'Darwin':
        import re
        text = observation(['/usr/bin/vm_stat'])
        page = re.search(r'page size of (\d+) bytes',text)
        counts = dict(re.findall(r'^(Pages [^:]+):\s+(\d+)\.',text,re.M))
        if not page or not all(k in counts for k in ('Pages free','Pages inactive','Pages speculative')):
            raise ResourceFailure('monitor_unavailable: Darwin vm_stat format')
        return sum(int(counts[k]) for k in ('Pages free','Pages inactive','Pages speculative'))*int(page[1])
    try:
        with open('/proc/meminfo') as f:
            for line in f:
                if line.startswith('MemAvailable:'): return int(line.split()[1])*1024
    except OSError as exc:
        raise ResourceFailure('monitor_unavailable: available memory') from exc
    raise ResourceFailure('monitor_unavailable: available memory')

def process_table():
    table = {}
    for line in observation(['/bin/ps','-axo','pid=,ppid=,rss=,lstart=,comm=']).splitlines():
        fields = line.split(None,8)
        if len(fields) < 9: continue
        try: pid,ppid,rss = map(int,fields[:3])
        except ValueError as exc: raise ResourceFailure('monitor_unavailable: malformed ps row') from exc
        table[pid] = dict(ppid=ppid,rss=rss*1024,identity=' '.join(fields[3:8]),command=fields[8])
    if not table: raise ResourceFailure('monitor_unavailable: process table')
    return table

def disk_bytes(root):
    total=count=0
    def failed(exc): raise ResourceFailure('monitor_unavailable: disk scan: '+str(exc))
    for directory,dirs,files in os.walk(root,followlinks=False,onerror=failed):
        dirs[:] = [d for d in dirs if d not in ('.git','__pycache__') and not
            (d=='packages' and Path(directory).name=='.lake') and not (Path(directory)/d).is_symlink()]
        for name in files:
            p=Path(directory)/name
            if p.is_symlink(): continue
            try: total += p.stat().st_size
            except FileNotFoundError: continue
            count+=1
            if count>100000: raise ResourceFailure('monitor_unavailable: disk scan bound')
    return total

@contextlib.contextmanager
def admission(kind='validator', overrides=None):
    cap=limits(overrides)
    base=ROOT/'.scratch/resources'
    base.mkdir(parents=True,exist_ok=True)
    with (base/'heavy.lock').open('a') as f:
        try: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise ResourceFailure('shared_heavy_reservation_busy')
        if (base/'UNRESOLVED_CLEANUP.json').exists(): raise ResourceFailure('unresolved_owned_cleanup_hold')
        try:
            if shutil.disk_usage(ROOT).free<cap['admit_free']: raise ResourceFailure('admission_disk_headroom')
            if available_memory()<cap['admit_free']: raise ResourceFailure('admission_memory_headroom')
        except (OSError,ValueError) as exc: raise ResourceFailure('monitor_unavailable: admission: '+str(exc)) from exc
        # Reservation is not measured RSS, elapsed time, or provider usage.
        receipt=base/(str(os.getpid())+'-'+str(time.time_ns())+'.json')
        from .study_common import write
        start=time.monotonic()
        record=dict(kind=kind,pid=os.getpid(),allocated_caps=cap,status='reserved',time=time.time())
        write(receipt,record)
        try:
            yield cap
        except BaseException as exc:
            record.update(status='released_after_failure',failure=type(exc).__name__+': '+str(exc))
            raise
        else: record['status']='released'
        finally:
            record.update(released=time.time(),lease_elapsed_seconds=time.monotonic()-start,
                cleanup_hold=(base/'UNRESOLVED_CLEANUP.json').exists())
            write(receipt,record)
            fcntl.flock(f,fcntl.LOCK_UN)

class Guard:
    def __init__(self,pid,scope,cap=None):
        self.pid=0; self.scope=Path(scope); self.cap=limits(cap)
        self.owned={}; self.last=0; self.over_since=None
        self.samples=[]; self.peak_rss=0; self.bound=False
        self.baseline=disk_bytes(self.scope)
        if pid: self.bind(pid)
    def bind(self,pid):
        if self.bound: raise ResourceFailure('root identity is immutable')
        self.bound=True; self.pid=pid
        info=current_process(pid)
        if info is not None: self.owned[pid]=info['identity']
        # A missing root is never adopted later, even if its PID reappears.
    def check(self,force=False):
        try: return self._check(force)
        except ResourceFailure as exc:
            if 'monitor_unavailable' in str(exc): cleanup_hold(exc,self.owned)
            raise
        except (OSError,ValueError) as exc:
            cleanup_hold(exc,self.owned)
            raise ResourceFailure('monitor_unavailable: '+str(exc)) from exc
    def _check(self,force=False):
        now=time.monotonic()
        if not force and now-self.last<self.cap['poll_seconds']: return
        self.last=now
        try: table=process_table()
        except (OSError,ValueError) as exc: raise ResourceFailure('monitor_unavailable: process table') from exc
        owned=set()
        for p,identity in self.owned.items():
            now_info=current_process(p)
            if p in table and now_info and now_info['identity']==identity: owned.add(p)
        changed=True
        while changed:
            changed=False
            for p,v in table.items():
                if p in self.owned or v['ppid'] not in owned: continue
                child=current_process(p)
                if not child or child['ppid']!=v['ppid']: continue
                parent=current_process(child['ppid'])
                if not parent or parent['identity']!=self.owned[child['ppid']]: continue
                # Confirm the child again after the parent; never replace a seen birth.
                if current_process(p)!=child: continue
                self.owned[p]=child['identity']; owned.add(p); changed=True
        rss=sum(table[p]['rss'] for p in owned)
        available=available_memory(); free=shutil.disk_usage(self.scope).free
        growth=disk_bytes(self.scope)-self.baseline
        compilers=sum(Path(table[p]['command']).name in ('lean','leanchecker') for p in owned)
        sample=dict(rss_sum=rss,available_memory_estimate=available,free_disk=free,growth=growth,owned_processes=len(owned),compilers=compilers)
        self.samples=(self.samples+[sample])[-8:]
        self.peak_rss=max(self.peak_rss,rss)
        if rss>self.cap['rss_sustained']:
            self.over_since=self.over_since or now
        else: self.over_since=None
        reason = ('rss_hard' if rss>self.cap['rss_hard'] else
                  'rss_sustained' if self.over_since and now-self.over_since>=self.cap['sustained_seconds'] else
                  'disk_headroom' if free<self.cap['hard_free'] else
                  'memory_pressure_or_low_available' if available<self.cap['hard_free'] else
                  'disk_growth' if growth>self.cap['growth'] else
                  'process_limit' if len(owned)>self.cap['processes'] else
                  'compiler_concurrency' if compilers>1 else None)
        if reason: raise ResourceFailure(reason)
    def cleanup(self):
        # Recheck start identity: never signal a recycled or unrelated PID.
        errors=[]
        for pid,identity in reversed(list(self.owned.items())):
            try:
                info=current_process(pid)
                if pid!=os.getpid() and info and info['identity']==identity:
                    try: os.kill(pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                    deadline=time.monotonic()+1
                    while time.monotonic()<deadline:
                        after=current_process(pid)
                        if not after or after['identity']!=identity: break
                        time.sleep(.01)
                    else: errors.append('owned identity still live after SIGKILL: '+str(pid))
            except (ResourceFailure,OSError,ValueError) as exc: errors.append(str(exc))
        if errors:
            cleanup_hold('; '.join(errors),self.owned)
            raise ResourceFailure('unresolved cleanup: '+'; '.join(errors))
    def receipt(self):
        return dict(limits=self.cap,last_samples=self.samples,peak_rss_observed=self.peak_rss,
            owned_identities=self.owned,scope=str(self.scope),monitor='RSS sum may count shared pages twice; available memory estimate; OS pressure level unavailable',ownership='current parent plus immutable birth identity; hostile unobserved daemon escape requires OS sandbox')
