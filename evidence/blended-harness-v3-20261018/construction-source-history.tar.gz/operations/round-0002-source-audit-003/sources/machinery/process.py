"""Codex/Astra: bounded process observations, never proof admission.
Process groups cover ordinary descendants; hostile setsid escape requires the
supervisor's OS containment. Output is capped jointly across stdout and stderr.
"""
import os
import selectors
import signal
import subprocess
import time
from .resources import admission, Guard, ResourceFailure, cleanup_hold, limits


def run(argv, *, cwd, env, timeout=30, output_bytes=65536, resource_limits=None,
        scope=None, tree_only=False, log_path=None):
    start = time.monotonic_ns()
    try:
        if tree_only:
            # Outer test observer owns no heavy lease. Leaf validators reserve it.
            from .resources import ROOT
            if (ROOT/'.scratch/resources/UNRESOLVED_CLEANUP.json').exists():
                raise ResourceFailure('unresolved_owned_cleanup_hold')
            return _run(argv, cwd=cwd, env=env, timeout=timeout,
                        output_bytes=output_bytes, cap=limits(resource_limits), scope=scope,log_path=log_path)
        with admission('validator-or-tool', resource_limits) as cap:
            return _run(argv,cwd=cwd,env=env,timeout=timeout,output_bytes=output_bytes,
                        cap=cap,scope=scope,log_path=log_path)
    except (ResourceFailure,OSError,ValueError) as exc:
        return dict(argv=list(map(str,argv)), returncode=-1, stdout='', stderr=str(exc),
                    termination='resource_guard: '+str(exc), captured_bytes=0,
                    elapsed_ns=time.monotonic_ns()-start, operationally_incomplete=True)

def _run(argv, *, cwd, env, timeout, output_bytes, cap,scope=None,log_path=None):
    if not 0 < timeout <= cap['timeout'] or not 0 < output_bytes <= cap['output_bytes']:
        raise ValueError('invalid process limits')
    start = time.monotonic_ns()
    guard = Guard(0, scope or env.get('TMPDIR', cwd), cap)
    p=None; selector=None; log=None
    captured = {'stdout': bytearray(), 'stderr': bytearray()}
    total = 0
    reason = None
    def kill_child():
        # Popen retains the unreaped child handle. Never signal a numeric group
        # after exit, where PGID reuse could target unrelated processes.
        if p and p.poll() is None: p.kill()
    try:
        if log_path is not None: log=log_path.open('xb')
        p = subprocess.Popen(argv, cwd=cwd, env=env, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, start_new_session=True)
        guard.bind(p.pid)  # First operation after Popen: no late root adoption.
        selector = selectors.DefaultSelector()
        for stream, name in [(p.stdout, 'stdout'), (p.stderr, 'stderr')]:
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, name)
        while selector.get_map() or p.poll() is None:
            try:
                guard.check()
            except ResourceFailure as exc:
                reason = 'resource_guard: '+str(exc)
                break
            if (time.monotonic_ns() - start) / 1e9 >= timeout:
                reason = 'timeout'
                break
            for key, _ in selector.select(0.02):
                data = os.read(key.fileobj.fileno(), 8192)
                if not data:
                    selector.unregister(key.fileobj)
                    continue
                available = output_bytes - total
                captured[key.data].extend(data[:available])
                if log:
                    log.write(data[:available]); log.flush()
                total += min(len(data), available)
                if len(data) > available:
                    reason = 'output_limit'
                    break
            if reason:
                break
        if reason:
            guard.cleanup(); kill_child()
        remaining = max(0.01, timeout - (time.monotonic_ns() - start) / 1e9)
        try:
            p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            reason = 'timeout'
            guard.cleanup(); kill_child()
            p.wait()
    except (OSError,ValueError,ResourceFailure) as exc:
        reason='operationally_incomplete: '+type(exc).__name__+': '+str(exc)
        if p: cleanup_hold(reason,guard.owned)
    finally:
        # This covers binding, selector and logging failures after spawn too.
        try:
            try: guard.cleanup()
            except (ResourceFailure,OSError,ValueError) as exc:
                reason = reason or 'cleanup_monitor_unavailable: '+str(exc)
        finally:
            # Cleanup-observer/hold-write failure must not skip child reaping.
            kill_child()
            if p:
                p.wait(); p.stdout.close(); p.stderr.close()
            if selector: selector.close()
            if log: log.close()
    return {'argv': list(map(str, argv)), 'returncode': p.returncode if p else -1,
            **{k: bytes(v).decode('utf-8', errors='replace') for k, v in captured.items()},
            'termination': reason, 'captured_bytes': total,
            'resources': guard.receipt(),
            'operationally_incomplete': bool(reason),
            'elapsed_ns': time.monotonic_ns() - start}
