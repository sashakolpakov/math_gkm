# Repair invocation 003: source audit hold

This is a new bounded source-only repair invocation by gpt-6.1-sol, started
2026-10-18 15:59:35 UTC with a 1200-second limit. It does not amend invocation
001/002 prompts, checkpoints, failures or receipts. `CONSTRUCTION_V3_AUDIT.json`
and `evidence/construction-v3/source-audit-003/SOURCE_MANIFEST.json` bind the new
checkpoint. **Tests, compilers, examples, preflights, probes and campaigns remain
NOT RUN.** Syntax was inspected as source; no parser/compiler was executed.

The user has authorized root to orchestrate fresh matched Markov trials after
the combined harness passes independent source audit and actual tests. A second
later user permission is not required. The protected supervisor activation
binding must record that existing authorization and the actual audit/test
evidence. This constructor launches no campaign. Root must use the machine's own
gpt-6.1-sol proposer consistently for curation, both arms and independent roles,
the exact unchanged root, a clean original seed, identical global correctness
and resource budgets, and sequential arms. No inherited case proofs or
supervisor mathematical strategy enter either arm. An empty independent suite
is allowed and establishes no heldout transfer.

Remaining source repairs made here:

- Existing named DAG premises are references to their original qualified
  constants, modules and context bindings. No new residual declaration is
  generated for them. Representation antecedents become explicit nodes; an
  explicit checked edge must connect them. AND edges retain all leaves, OR
  alternatives admit a closed route even beside a newer open route, and cycles
  are rejected. Selected routes are recorded. Generated proof dependencies go
  to inspector `required=`, and the next actual request includes exact DAG and
  submission schemas. Reachability alone admits no theorem or root completion.
- Each validator writes a finished bundle binding task, solution, mandatory
  declarations, source/artifacts, binaries and pins after durable output
  retirement. An intermediate `checked=True` result cannot be reused. Exports
  replace complete files atomically; each item has its own durable state
  transaction before the round snapshot. Interrupted exact finished checks may
  finish export/admission idempotently; uncertain checks require a new charged
  identity. Changed accepted source/dependency/receipt versions reject reuse.
  Raw results and failures stay retained. Optional report errors and later bad
  items cannot erase independently admitted mathematics.
- Root ownership binds birth immediately after Popen. Darwin uses libproc birth
  microseconds and current parent; Linux uses kernel start ticks. Numeric PID
  reuse never replaces a seen identity, and stale ps ancestry cannot adopt a
  child's new unrelated identity. Only actual Lean/checker workers count as
  compilers. Setup/observer failures clean the live Popen child and confirmed
  owned descendants. Uncertain observation or cleanup writes a durable
  `UNRESOLVED_CLEANUP.json` launch hold, requiring supervisor reconciliation.
  There is no automatic hold reset or cap escalation. Ordinary polling cannot
  prove containment of an unobserved hostile daemon; this remains an OS concern.
- Job disk observation uses the common TMPDIR/declared job scope, including
  sibling build outputs and `.lake/build`, excluding pinned package trees.
  Snapshot/history views have independent copied inodes, without hardlinks to
  a writable cache. Explicit text-source formats, binary screening and bounded
  inventories exclude object variants and archives. Aggregate retention stops
  before exceeding 1 GiB of retained source/history per owning arm/common view.
  Only attempt-owned rebuildable objects are retired, after exact source,
  inspector artifacts, pins, recipes and receipts are retained. Evidence is
  preserved on retention failure. Leases record release/failure durably.
- Both neutral runners use bounded shared tree execution and streamed capped
  logs. The outer observer holds no heavy lease; leaf validators reserve it.
  The broad historical `worker.execute` entrypoint is disabled in V3; its pure
  `inline` and argv helpers remain available. Supported research uses isolated
  `study_worker`. Audit compression streams with explicit bounds and remains
  one-way; it cannot change requests, selection, mathematical admission or caps.
- Curation has an explicit supported CLI `--model` and provenance. A live suite's
  curator must match the frozen arm model and high reasoning setting. The full
  deployment positive imports **Mathlib**, proves a neutral universally
  quantified identity and runs the actual sandbox compile → independent
  leanchecker → premise inspector with unmocked dependency identity. The default
  total reservation remains 1200 seconds (hard maximum 1800); RSS/disk caps are
  unchanged. Peak observed RSS and timings remain in process receipts. A
  Nat.Basic-only or mocked positive does not establish this deployment path.

Review and then run the commands recorded in the audit, sequentially through
`machinery.v3_validate`; it requires a protected independent review binding the
exact manifest hash. New failures require retained receipts and another source
checkpoint before changed code is tested. The prepared tests include concrete
positive Lean consumers, the original exact-context/fake-root negatives,
interruption windows, actual mandatory declaration closure, resource faults,
and multi-round fixture strategy selection affecting the next actual request.
Fixture selection tests are empirical harness evidence, never live discovery.

Report three statuses separately for every result: (1) fresh compile/kernel/
premise-admitted exact theorem; (2) independently reviewed English/source scope
and relationship to the supplied family; (3) actual checked use/path toward the
unchanged log-concavity root. An indexing/representation theorem is real
intermediate mathematics; without a checked connection it supplies no
log-concavity inequality or root advancement. There is no theorem-count or
general-coverage reward. A conditional path leaves premises open. Independently
checked exact root and correspondence are still required for root completion.

The actual `Gluing` → `Continuation.main` → `verified_change` producer/consumer
chain and `ResearchSemantics` interfaces remain unchanged. A prepared fresh
`MathGKM.Construction` consumer restates the exact quantified `verified_change`
theorem, including its accepted-installation hypothesis, and requires its real
transitive declarations. This is a declared mathematical model, not a live host
certificate. D1 whole live continuation utility, D2 Python/OS refinement, and D3
concrete environment/time/installation obligations remain **OPEN**.

Installation is not performed. `INSTALLATION_SOURCE_DISPOSITION.json` excludes
the candidate-only `MathGKM.lean` workaround from installation. Install new
construction code via `MathGKM.Construction`; preserve the installed aggregate
byte-for-byte and retain historical Agoh modules/imports. This candidate lacks
those historical modules and cannot validate their recompilation here. That
installation-side check remains OPEN; no API migration or removal is implied.
