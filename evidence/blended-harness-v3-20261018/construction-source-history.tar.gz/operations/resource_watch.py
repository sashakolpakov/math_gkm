"""Supervisor-only operational bounds around one independent constructor invocation.
No mathematical research or harness implementation. RSS is summed per-process
resident memory and can double-count shared pages; this is a conservative guard.
"""
from pathlib import Path
import argparse, json, os, re, shutil, signal, subprocess, sys, time

GIB=1024**3
ROOT=Path('/Users/sasha/math_gkm')
CANDIDATE=ROOT/'.scratch/strategy-v3-blended-20261018'
OPS=ROOT/'.bootstrap/construction-v3-20261018'

def processes():
 r=subprocess.run(['/bin/ps','-axo','pid=,ppid=,rss='],capture_output=True,text=True,timeout=3)
 if r.returncode: raise RuntimeError('process monitor unavailable: '+r.stderr[:200])
 table={}
 for line in r.stdout.splitlines():
  x=line.split()
  if len(x)==3: table[int(x[0])]=(int(x[1]),int(x[2])*1024)
 return table

def descend(table, roots):
 owned=set(roots)
 for _ in range(len(table)+1):
  added={pid for pid,(ppid,_) in table.items() if ppid in owned and pid not in owned}
  if not added: break
  owned.update(added)
 return owned

def bytes_used():
 size=0
 for directory, dirs, files in os.walk(CANDIDATE,followlinks=False):
  dirs[:]=[d for d in dirs if not (Path(directory)/d).is_symlink()]
  for name in files:
   p=Path(directory)/name
   if not p.is_symlink():
    try:size+=p.stat().st_size
    except FileNotFoundError:pass
 return size

def memory_free_percent():
 r=subprocess.run(['/usr/bin/memory_pressure','-Q'],capture_output=True,text=True,timeout=3)
 if r.returncode:raise RuntimeError('system memory-pressure monitor unavailable')
 m=re.search(r'System-wide memory free percentage:\s*(\d+)%',r.stdout)
 if not m:raise RuntimeError('unrecognized memory-pressure output')
 return int(m.group(1))

def main():
 a=argparse.ArgumentParser(); a.add_argument('--round',type=int,required=True); a.add_argument('--seconds',type=int,default=1500); args=a.parse_args()
 log=OPS/f'watch-round-{args.round:04d}.jsonl'; summary=OPS/f'watch-round-{args.round:04d}.json'
 if log.exists() or summary.exists(): raise RuntimeError('operational receipt exists; choose new round')
 if shutil.disk_usage(ROOT).free<8*GIB:raise RuntimeError('constructor refused: less than8GiB free')
 if memory_free_percent()<30:raise RuntimeError('constructor refused: less than30% system memory free')
 initial=bytes_used(); started=time.monotonic(); seen=set(); p=None; error=None; peak=0; peak_count=0; low_samples=0; soft_samples=0; max_growth=0
 try:
  command=['/opt/homebrew/bin/python3',str(OPS/'external_launcher_sol.py'),'--round',str(args.round),'--seconds',str(args.seconds),'--task-prompt',str(OPS/'task-blend-construction.md')]
  with (OPS/f'launcher-round-{args.round:04d}.log').open('x') as out:
   env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
   p=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
   with log.open('x') as stream:
    while p.poll() is None:
     table=processes(); owned=descend(table,{p.pid}|{x for x in seen if x in table});seen.update(owned)
     rss=sum(table[x][1] for x in owned if x in table);peak=max(peak,rss);peak_count=max(peak_count,len(owned))
     free=shutil.disk_usage(ROOT).free; growth=bytes_used()-initial;max_growth=max(max_growth,growth); memfree=memory_free_percent()
     sample={'elapsed':round(time.monotonic()-started,2),'owned':len(owned),'tree_rss':rss,'free_disk':free,'candidate_growth':growth,'system_memory_free_percent':memfree}
     stream.write(json.dumps(sample)+'\n');stream.flush()
     soft_samples=soft_samples+1 if rss>4*GIB else 0;low_samples=low_samples+1 if memfree<25 else 0
     if rss>5*GIB or soft_samples>=3:raise RuntimeError('owned constructor RSS limit')
     if len(owned)>24:raise RuntimeError('owned constructor process-count limit')
     if free<5*GIB:raise RuntimeError('minimum-free-disk limit')
     if growth>GIB:raise RuntimeError('candidate1GiB growth limit')
     if low_samples>=3:raise RuntimeError('system available-memory headroom limit')
     if time.monotonic()-started>args.seconds+15:raise TimeoutError('constructor outer wall limit')
     time.sleep(2)
 except BaseException as exc:error=type(exc).__name__+': '+str(exc)
 finally:
  if p:
   try:
    table=processes();owned=descend(table,{p.pid}|{x for x in seen if x in table})
    for sig in (signal.SIGTERM,signal.SIGKILL):
     for pid in sorted(owned,reverse=True):
      try:os.kill(pid,sig)
      except ProcessLookupError:pass
     if sig==signal.SIGTERM:time.sleep(1)
   except BaseException as exc:
    error=error or ('cleanup monitor failure: '+str(exc))
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  result={'error':error,'exit_code':p.returncode if p else None,'elapsed':round(time.monotonic()-started,3),'peak_owned_rss':peak,'peak_owned_processes':peak_count,'max_candidate_growth':max_growth,'free_disk_final':shutil.disk_usage(ROOT).free,'rss_scope':'sum of owned process resident sets; shared pages may be counted twice','monitor_failures':'fail closed; no hard OOM guarantee if OS monitoring unavailable'}
  summary.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 return 0 if not error and p and p.returncode==0 else 1
if __name__=='__main__':sys.exit(main())
