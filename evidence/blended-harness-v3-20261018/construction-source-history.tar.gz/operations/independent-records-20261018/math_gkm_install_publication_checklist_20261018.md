# Installation/publication checklist — independent read-only review

Candidate `/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018`; installed repository `/Users/sasha/math_gkm`. This is an actionable provisional inventory while external repair runs; regenerate exact hashes from the final accepted checkpoint. No candidate/tracked files edited, no package tree hashed, no historical tree enumerated.

## 1. Exact installation overlay

Current changed existing machinery files: `completion.py`, `gate.py`, `neutral_validate.py`, `process.py`, `study.py`, `study_audit.py`, `study_common.py`, `study_completion.py`, `study_curate.py`, `study_deployment.py`, `study_fixture.py`, `study_knowledge.py`, `study_policy.py`, `study_program.py`, `study_transfer.py`, `study_worker.py`, `trust.py`, `worker.py`.

New machinery files: `event_stream.py`, `residual_dag.py`, `resources.py`, `retention.py`, `study_reports.py`, `v3_validate.py`, `validation_receipts.py`.

New Lean sources: `MathGKM/Construction.lean`, `MathGKM/NeutralV3Root.lean`. Both are needed: Construction is the concrete formal-framework consumer, while NeutralV3Root is the unbounded neutral acceptance contract/fixture dependency. Preserve all existing formal sources, including ResearchSemantics, Gluing, Continuation, and historical Agoh/Markov modules.

New tests: `tests/test_construction_v3.py`, `test_construction_v3_repair.py`, `test_construction_v3_resources.py`; changed existing `tests/test_sol_deployment.py`. Include the final repaired tests, not only the oldest checkpoint's test list. Changed docs currently HARNESS_CHECKPOINT, REGRESSION, REQUIREMENT_MAP and STUDY_V2; new docs CONSTRUCTION_V3 and STUDY_V3. Include final installation disposition and any new source-audit helper/templates required by actual commands.

**Preserve installed `MathGKM.lean` byte-for-byte.** It imports historical AgohConsequences. The candidate aggregate deliberately omits that missing historical module and is a construction-only workaround, excluded by INSTALLATION_SOURCE_DISPOSITION.json. Do not overwrite the installed aggregate or delete historical modules to fit the candidate.

## 2. Installed manifest and checks

Retain each original candidate SOURCE_MANIFEST and failed checkpoint unchanged. A candidate manifest includes its different MathGKM.lean; it cannot authorize the installed tree. Produce a separate installation manifest binding exact accepted overlay hashes, the retained installed aggregate, dependency pins, relevant unchanged framework files, and explicit source disposition. Bind the installed review to this new manifest.

`implementation()` enumerates all installed Lean files, including historical modules absent from the clean candidate. Compute implementation()/activation binding **after installation and installed verification**. Never copy candidate study seal, authorization, state, or incomplete receipts into a newly launched installed study. Start new studies against the installed implementation.

Run installed neutral Construction and full Mathlib positive paths sequentially with compile→independent leanchecker→premise inspection, under the tested resource guard and exact model/config identity. State separately: accepted mathematical result; English/model scope; actual root-use relationship. Keep D1–D3 open unless actually discharged.

## 3. Complete source-only evidence

Curate source-only archives, not whole .scratch/.control/cache trees. Include:

- Accepted construction source checkpoint(s), all listed sources/tests/docs/contracts/configs and exact hash manifests; preserve earlier failed checkpoints and launch receipts for debugging.
- Actual generated neutral theorem/adapter/consumer `.lean` files, exact root/context contracts, admitted export modules and source-hash bindings.
- Finished validation bundles/receipts, mandatory declaration/premise artifacts, result JSON, captured bounded logs, exact binary identities, copied pins, REBUILD.json and retired-object hash lists. Preserve failures and operationally incomplete status.
- Actual matched fixture inputs/receipts/selection outputs needed to reproduce the connected strategy loop; label deterministic fixtures explicitly, separate from live mathematical discovery.
- Tested operational watcher version and prior failed versions with raw results; Darwin lifecycle/ps probes and hold reconciliations/clearance records.
- Existing `evidence/disk-maintenance-20261018` summary and compact provenance archive.

Reject compiled objects/cache payloads from publication archives (`.olean`, `.olean.private`, `.olean.server`, `.olean.tmp.*`, `.ilean`, native objects, pycache, package caches). A retired-object hash list is evidence, not an object payload. Archive member manifest must bind bytes/hash, and archive extraction/reproduction must preserve relative paths. Inspect archive entries for source/pin/config completeness before local cleanup. Never delete unique proof/failure evidence merely because its extension is unfamiliar.

## 4. Pin/path portability and commands

Pinned Lean is `leanprover/lean4:v4.32.2`; Mathlib revision `905b95818eb32af7874a58b427f50c1711a5e96c`. Retain lean-toolchain, lakefile.toml and lake-manifest.json unchanged. Current package symlinks resolve into a shared cache under the Collatz tree; publish pins and setup instructions, not those host-specific links or caches. A fresh clone reconstructs packages from the lock/pins without updating the requested revisions.

Current trust.py/Python CLI paths are host-specific (`/Users/sasha/.elan/...`, `/opt/homebrew/bin/python3`). Document a path mapping/setup step or audited environment configuration; do not claim turnkey portability on another host. Preserve exact tested paths/hashes in historical receipts, and regenerate runtime paths/receipts for a fresh deployment.

Supported commands need `.bootstrap/base-permissions.json`, protected review binding, and possibly supervisor-review requirements. Provide reproducible templates/setup from retained evidence; do not silently require ignored local files missing on GitHub. An old review token/seal is historical evidence, not fresh authorization. No live model call is needed for deterministic reproduction tests.

## 5. Historical API and compatibility

Static comparison found no removed/changed public class-method signatures in existing machinery. Existing process.run callers remain syntactically compatible (new optional keyword arguments); curator adds optional keyword-only model; deployment default timeout increases. This is not a behavioral compatibility test.

The broad historical worker.execute path is intentionally disabled in V3. Document that supported entrypoint and migration boundary explicitly; retaining a signature does not imply old controllers can run. Preserve historical state/read-only evidence, but do not resume old runs under changed code. Perform focused installed checks of supported old helper/argv APIs and preserved aggregate import coverage; no broad historical suite or parallel heavy builds unless newly justified.

## 6. Publication and cleanup

Use explicit Git add paths for the accepted overlay and curated evidence. Keep no accidental .scratch/.control/live authorization or compiled cache staging. Follow the repository's existing filtered publication process, then verify public commit/tree and archive hashes. Necessary proof sources, exact pins and working reproduction suite must be present in the public tree before further local cleanup. Separate measured physical free space from APFS duplicated logical bytes.
