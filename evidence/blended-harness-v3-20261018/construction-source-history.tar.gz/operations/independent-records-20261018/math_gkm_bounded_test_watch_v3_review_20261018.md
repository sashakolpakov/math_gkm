# Bounded neutral-test watcher v3 — source review

Reviewer: independent resource auditor. Source `.bootstrap/construction-v3-20261018/bounded_test_watch_v3.py`, SHA-256 `752794beab59c2a5720e0416107c6a6ac864cf2385ecf5daa27a42f20b9756e9`.

**Statically approved for small sequential neutral tests.** This approval concerns the outer operational wrapper only; it does not approve a still-unreviewed frozen mathematical harness. No execution, imports, tests or builds were performed.

The native Darwin ABI remains the previously checked136-byte proc_bsdinfo layout. Native identity includes current PPID, PGID and birth seconds/microseconds; observed descendants are not rebound to reused PIDs. errno is reset before each call. Empty/incomplete ps observations and disk-scan errors fail operationally.

The direct Popen child remains waitable: SIGCHLD is reset to default and no poll/wait occurs before cleanup. Native SZOMB is checked without reaping. Finally always signals the original private process group before releasing the direct child's reserved PID with wait. This covers an ordinary unseen child in that group when its parent exits before the first process sample, including native-observer failure. Observed separate groups use birth-confirmed members. A cleanup-observation failure leaves a durable hold checked before another launch.

Combined output is streamed through a pipe with backpressure and an8MiB retained cap; it no longer writes an unlimited file outside the measured candidate scope. Candidate growth is capped at1GiB; RSS limits4GiB sustained/5GiB hard, process cap24, admission8GiB disk headroom and30% reported system memory free, hard5GiB disk floor. Polling/ordinary observation races and RSS shared-page double counting remain explicit operational limitations.

This is not complete containment for a separate-session descendant never observed while its parent was alive. No such absolute claim is needed for the reviewed small neutral tests. Run one watcher at a time; no cross-watcher lock is installed. Optional nonblocking hardening: set TMPDIR to candidate/.scratch explicitly and close the child's stdout pipe in finally. The inner supported validators/runner must still pass their own frozen source review and subsequent real acceptance tests.
