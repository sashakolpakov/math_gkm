# Operational constructor watcher v2 — independent source review

Scope: static review only; watcher v2 was not imported/executed/tested. v1 preserved. Review against `/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk/usr/include/{libproc.h,sys/proc_info.h,sys/param.h,sys/_types.h}`.

**ABI accepted.** SDK `libproc.h:96` declares `int proc_pidinfo(int,int,uint64_t,void*,int)`. `proc_info.h:59–82` matches all ctypes fields, and uid/gid typedefs are uint32. MAXCOMLEN is16, PIDTBSDINFO is3 (`proc_info.h:723–724`). For current arm64 ABI: pid offset12, ppid16, pgid100, start seconds120, start microseconds128, total136 bytes/alignment8. The exact returned-size check is appropriate.

**Not approved unchanged for next constructor launch.** Fix the following before execution:

1. At lines88–91 and116–119, ancestry comes from a prior `ps` snapshot; current native `identity(pid)` is then adopted unconditionally. If a child vanished and its PID was reused, this records the unrelated process's new birth as owned. `seen[pid]` can overwrite an earlier birth. Fetch current native PPID/PGID/birth together and require a current parent edge to a birth-confirmed owned parent before first adoption. Existing numeric PID with changed birth must not be rebound merely because a stale ps edge exists. Group membership should be bound to the same verified process identity.
2. On cleanup observer failure, the result says 'refuse next launch pending review', but no durable hold is written/read by the next invocation. Record unresolved cleanup as a protected hold; a new round must refuse until an operator independently verifies/reconciles it. Otherwise a surviving detached descendant can overlap the next launch.
3. A successful but empty process-table observation currently returns `{}`, giving zero RSS instead of a monitor failure. Reject empty/invalid required observations. Treat `os.walk` scan errors explicitly rather than default silent skipping if its result is used as the growth measurement.

Useful improvements: clear ctypes errno before each native query so stale ESRCH cannot mask a short/failed observation; validate argument bounds before creating launch files; bind a shared constructor lease to prevent simultaneous different-round watchers. Ordinary polling cannot eliminate every observation/signal race, and native-observer failure may leave descendants unobservable. Keep that limitation explicit and ensure the unresolved-cleanup hold is enforced.

Positive aspects: root birth is captured before normal monitoring; observed descendants are retained for ordinary orphan cleanup; broad ps failure does not skip all native birth checks; group signaling requires a birth-confirmed member; fallback p.kill targets its still-unreaped direct child; raw evidence/version labels are retained. The remaining ownership adoption issue is practical and separate from the disclosed irreducible non-atomic observation/signal limitation.
