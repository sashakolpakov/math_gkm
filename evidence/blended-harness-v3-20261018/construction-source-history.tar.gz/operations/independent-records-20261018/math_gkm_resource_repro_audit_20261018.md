# Independent resource and reproduction review — provisional source review

Reviewer role: resource auditor (agent `/root/disk_cleanup`, reassigned after verified cleanup). Candidate: `/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018`. Sources are under active construction; these are provisional findings for the next charged constructor repair. No tests, builds, or candidate edits performed by reviewer.

## Completed cleanup

Publishable record: `evidence/disk-maintenance-20261018/`. Removed 9,466 untracked derived files, 151,749,943,784 logical bytes (~141.3 GiB). Final observed free space ~75 GiB versus ~20 GiB initially; APFS shared extents and concurrent activity explain the different physical/logical changes. `.control`:96 GiB→2.6 GiB; `evidence`:48 GiB→451 MiB. All 7,602 distinct preserved source/build-receipt files rehashed after cleanup. Exact source and successful-receipt Git blob identities matched local HEAD and published fc2d620b. Worker/object duplicate SHA-256 checks passed. No tracked deletion, source deletion, process termination or build. Ambiguous cases preserved. The prior OOM cause is not established.

## Blocking source findings in current construction

1. **Monitoring omits actual compiler output directory.** `study_transfer.check_task` calls `process.run(...,cwd=directory/source)` while Lean writes `.olean` to sibling `directory/build`. `Guard(scope=cwd)` scans source only. The 1 GiB growth limit therefore does not cover the very compiled outputs that previously filled disk; global disk headroom is the only fallback. Scope must include the actual declared write roots/validation directory, including artifacts written outside cwd; test with a small simulated cap and sibling output, not a multi-GiB allocation.

2. **Post-spawn setup failure can leave a child running.** `process._run` creates `Popen`, then calls `Guard(...)` and selector setup before its try/finally. `Guard.__init__` scans disk and can fail. Setup failures must always terminate/reap the already-created owned child; required observer errors need normalization. The worker path has a broader outer finally, but verify the fallback when its observer itself fails.

3. **Original process identity is not pinned.** `Guard.check` always starts ownership with numeric `self.pid` if present, regardless of its initial birth identity. A recycled root PID can be adopted. The initial identity must be captured once and never replaced. `os.killpg(p.pid,...)` also relies on group reuse assumptions after child exit. Stable owned identities and correctly scoped fallback termination are needed. Constructor's supervisor-only `resource_watch.py` has the same already-reported stale-PID issue.

4. **Compiler count includes wrappers.** `('lean','leanchecker','lake')` rejects a normal single-worker `lake → lean` chain as two compilers. Distinguish wrappers from concurrent elaborator/checker workers. Actual host acceptance should exercise the supported path, not mock only an invented process table.

5. **Snapshot immutability has a writable alias.** `study_common.snapshot` stores immutable-source objects in `workspace/.scratch/source-objects/<hash>` and hard-links them into frozen snapshots. The live researcher owns and can write workspace `.scratch`; chmod(0444) is not an immutable protection against its owner. Accidental cache edits could mutate multiple preserved snapshots and lose the sole preserved contents. Place shared immutable objects outside the live writer's grant; verify source hashes and protect aliases. A later hash mismatch detects damage but does not restore lost proof contents.

6. **Inventory is an output-extension denylist, not source-only retention.** Current `inventory` excludes suffix `.olean` but admits `.olean.private`, `.olean.server`, `.olean.tmp.<pid>`, archives, and arbitrary large binary artifacts. Those can be snapshotted or copied into every role. Use an explicit source/evidence retention policy with bounds and an exact source+recipe requirement before derived-output cleanup. Preserve unique evidence; large outputs should be explicitly sealed/classified rather than copied by default.

7. **No bounded lifecycle for validation object artifacts.** `study_transfer` retains each fresh `build` tree after source/premise checking. Per-call admission and source snapshots do not establish a campaign-wide disk bound. Keep sources, target/context, pins, replay/premise receipts and rebuild recipes durable, then reclaim/reuse derived outputs according to an explicit policy. Must not repeat the previous 140 GiB of retained compiled clones. Account for role-history copies and `.scratch/source-objects` as well.

8. **Test-runner path bypasses new watchdog.** `neutral_validate.py` still uses a direct `subprocess.run` with an uncapped log and timeout limited to its immediate child. Descendants can outlive timeout; log hashing uses `read_bytes`. Ensure the actual sequential acceptance runner, not only leaf validators, has owned-tree RSS/process/disk/output bounds and cleanup. Legacy `worker.py` paths likewise lack the new guard; either explicitly exclude/disable obsolete entrypoints in this version or bound supported consumers.

## Additional review requirements

- Admission receipts currently remain `reserved` and accumulate; record release/failure and keep actual elapsed/observed resources distinct from reservations. No need to discard historical receipts.
- Verify non-reentrant shared heavy lease does not obstruct the actual legitimate nested paths. A proposer worker may own a lease while launching its own Lean tool; root validation should start after release. One live model and one compiler maximum, sequential matched arms, identical caps.
- Observer subprocesses currently use `communicate` then check length after allocation. Current fixed OS commands are small, but monitoring should still bound observation and fail operationally if unavailable.
- Controller-side inventory, archive and snapshot copying are outside worker guard; final campaign aggregate source/history growth needs a bound and safe stop. A worker-local growth baseline resets each invocation.
- `archive_sources` and `role_workspace` still copy history/source material independently; snapshot dedup alone does not remove all repeated copies.
- Audit-only `study_audit.measure/collect` still read entire artifacts/bundles and compress them in memory. One-way isolation from strategy is good, but memory/disk bounds also apply to the observer; stream/bound retained data.
- Preserve pinned cached dependencies read-only, no per-arm copies or downloads. Content hashing is now streamed, good; full dependency-tree rescans need explicit setup accounting and should not occur repeatedly per inference.
- `study_deployment.preflight` retains 10..180s total bound and transfer run min(180,remaining) in WIP; confirm the representative actual Mathlib compile→independent replay→premise-inspection path gets an adequate bounded reservation in final revision.
- Public Git must retain all new source/test/doc/config/pin/protocol/evidence artifacts. Generated object caches are rebuildable only when their exact input/pins/commands remain retained. Reproduction commands must refer to actually shipped paths, not missing `.bootstrap` files.

## Acceptance evidence expected

Small controlled fixtures for RSS/output/process/disk thresholds and owned-descendant cleanup, no real OOM-sized allocation; no unrelated process termination. Missing monitor and post-spawn failure leave no running descendants. Sources survive cleanup and are rebuilt under exact pins. Actual representative Mathlib positive and intended mathematical negatives complete the whole unmocked validator. Test runner itself is guarded. Two matched arms execute sequentially without changing global caps or copying cached dependencies. Frozen source hashes bind all tested bytes; no campaign starts before acceptance.
