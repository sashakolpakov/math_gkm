# Independent resource/reproduction source review — frozen002

Reviewer role: resource auditor. Candidate `/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018`. Source manifest `evidence/construction-v3/source-audit-002/SOURCE_MANIFEST.json`, SHA-256 `69b3ff8f741736325cc50ee12630b9b569bd05c8aa04142468e4d9fee9daa088`. All115 listed files match. Static review only: no imports, tests, compilers or behavioral probes.

**Do not approve tests/campaign on002.** A bounded independent constructor repair can proceed under the separately approved supervisor watcher.

## Blocking operational issues

- `resources.py:116–122` re-adopts numeric root PID and overwrites ownership identities; second-resolution `ps lstart` is weaker than approved native microsecond birth/current-parent checks. Actual validator/worker/runner guard must use stable initial process identity and validate current ancestry. A fake cleanup-only PID-reuse test does not cover adoption. Monitor-unavailable cleanup needs a distinct fallback and persistent unresolved-cleanup hold checked before another heavy launch.
- `process.py:39–41` refuses group cleanup once the leader has exited. An ordinary parent can spawn a child and exit before the first process sample; that child can keep pipes open or allocate memory while its parent is already reaped. Guard has no observed child and kill_group becomes a no-op at timeout. Test the immediate-parent-exit case and assert the descendant is gone, not just that a timeout receipt exists. Selector/nonblocking setup after spawn is still outside try/finally (`32–35`), so setup failures must also reap the child.
- `v3_validate.py:40–52` watches the tree but its monitor-failure fallback kills only the unittest parent. The same orphan/observer-failure limits apply. It also skips pre-launch8GiB memory/free-disk admission. Ensure the actual runner has safe ownership cleanup and headroom observation without holding a conflicting nested heavy lease. Its direct file log is covered only by aggregate growth, not an independent output cap.
- `study_common.inventory:104` still admits `.olean.private`, `.olean.server`, `.olean.tmp.*` and arbitrary archives because it examines only the final suffix. These can again enter snapshots/history/role copies. Define/classify retained sources and unique evidence separately from rebuildable outputs; bound large evidence without deleting it blindly.
- `resources.py:126` counts a `lake` wrapper and its sole `lean` child as two compilers; count actual compiler/checker workers. Existing test does not exercise a real normal lake→lean chain.

## Reproduction/retention cautions

- `retention.retire_build` now creates durable result, exact source hashes, copied pins, binary identities and recorded commands before deleting attempt-owned build directory: good. But an already-existing REBUILD.json is trusted without checking it describes current sources/pins/commands. Require matching recipe before deletion/recovery. Reject symlinks/unexpected unique artifacts rather than recursively deleting them as compiled output. Prove the preserved source/pins/recipe rebuilds a positive example after retirement.
- Freeze/publish all generated acceptance theorem sources, consumers, full validation receipts, premise inspection artifacts and rebuild recipes. Keeping only a test's success string is insufficient. Git publication must include authority/config templates otherwise hidden in `.bootstrap`, or give exact reproducible setup from retained evidence.
- `study_audit.collect` iterates every child of snapshots and requires a manifest. New `snapshots/source-objects` directory has no manifest and will break collection. Filter sealed snapshot entries or store CAS outside snapshot enumeration.
- Audit-only `study_audit.measure/collect` still load and zlib-compress whole artifacts in memory; put a bounded/streaming observation path in place. The legacy neutral_validate entrypoint remains uncapped; document it as unsupported or delegate to the new guarded runner.
- Admission receipts still show status=reserved forever; record release/failure separately from actual measured wall/RSS and provider usage. Entire campaign/source/history growth needs explicit accounting; resetting each worker baseline alone is not a total storage budget.
- Two comparative arms must run sequentially with identical immutable resource caps and shared pinned dependency links; no duplicate package tree or simultaneous external model/compiler jobs. Do not infer source/general theorem admission from fixture-only policy simulation.

## Verified improvements over WIP

- `process._run` constructs disk baseline before spawn and scopes it to TMPDIR; actual transfer TMPDIR is the whole validation directory, covering sibling build outputs. The earlier cwd-only omission is fixed.
- Snapshot source CAS moved to controller-side target.parent/source-objects, outside the live research workspace write grant; hardlinks no longer originate in live `.scratch`.
- Source history views now link retained immutable entries instead of recursively copying entire history trees.
- Validator and completion paths call retirement after retained receipts; hashes are streamed. New guarded v3 runner binds independent source-review manifest. Validation bounds now allow1800s; actual representative Mathlib complete-path calibration still requires later execution.

## Separate outer watcher verdict

Supervisor-only resource_watch_v2.py SHA `d23823a15db258b8d8ac1dfe20ba7ef55a884cfc1a5303342850182531911309` is statically approved for one bounded constructor invocation after prior invocation stops. Native proc_bsdinfo layout/signature matches installed SDK, with136 bytes and birth fields at120/128. Revised discover checks current native PPID + confirmed parent birth and never rebinds a prior seen PID; persistent cleanup hold blocks the next launch after incomplete cleanup. No execution was performed. Residual ordinary non-atomic observation/signal limitation is explicit. Optional hardening remains errno reset, scan-error handling, and a sole-constructor lease.
