# Read-only blended harness source audit

Examined current sources in /Users/sasha/math_gkm; no builds, edits, research, or large scans. This is a construction audit, not mathematical advice on the Markov problem.

## Existing formal producer → artifact → consumer connections

| Producer | Checked artifact | Actual consumer | Scope |
|---|---|---|---|
| MathGKM/Gluing.lean Boundary, Pushout, square | Quotient pushout of types and functions; descend and its universal property | Continuation.gluedView, gluedTick | Boundary compatibility is substantive; necessary and conflicting_binding expose incompatibility |
| Gluing.descend, unique | Glued transition and its uniqueness | Continuation.gluedTrace and run_glued_left/right | Actually identifies states with equal observable views, not arbitrary source declarations |
| run_glued_left/right + glue_bridge | continuation_observations, Continuation.lean:289 | main:342 → installed_main:375 → verified_change:385 | Equality of observable traces for every positive finite continuation; future engine changes remain part of the modeled run |
| tick_simulation and continuation_first_gain | Continuation.main / accepted_change | tryChange → afterChange → installed_main / verified_change | Strict utility improvement after installation cost under the explicit padding profitability condition, in the declared cost/environment model |
| ResearchSemantics.ConservativeExtension | forget/extend with section law; preserves/reflects/compose | study_knowledge.task_for attachments builds StudyInterface, StudyTransport, StudyObligation | Retract condition supplies every old model with an extension; no arbitrary attachment automatically conservative |
| ResearchSemantics.Representation | forward plus exact predicate iff | Representation.consume; study_knowledge representation wrapper | Exact predicate transport, not equal symbol names; target premise remains open until proved |
| ResearchSemantics.Push, pushUnit, pushLift | Dependent-sum cocartesian extension, beta and unique factorization | study_knowledge fiber_gluings generated wrappers | Real dependent transport. No model-category cofibration or arbitrary source-edit claim |
| study_transfer.check_task + wrapper | Fresh rebuild, independent replay, declaration and premise closure receipt | study_knowledge.ingest accepted exports; next request includes accepted library | Actual used declarations must include declared attachment dependencies, source hashes frozen |
| study_policy.request | Accepted knowledge, components, exact residuals and delayed-use links | External researcher and study_program.execute | A real reusable library path already exists |
| study.py policy_trial:645–764 | Same frozen state, equal-budget incumbent and candidate multi-round continuations | Independent comparison/reviewer/selector and later selected program | Empirical finite-horizon selection; not whole-continuation host certification |
| study_bridge.event | Executed Lean epoch guard and hash-bound host transition records | Arm state protocol bookkeeping | D1 whole-continuation, D2 Python/OS refinement, D3 time/environment/install obligations remain explicitly open |

The cofiber-related foundations were not removed by V2. The improvement must preserve these actual consumers and make them useful in ordinary research. ResearchSemantics.Compatible/glue is separately a pullback of interpretations; do not call it the same construction as Gluing.Pushout.

## Exact integration defects and required repairs

1. **Report prose can suppress valid mathematics.** study.py:529–537 calls policy.record before ingest; any Invalid/KeyError/TypeError resets the full update to staged. Identical rollback exists for experimental branches:735–743. Validate/admit independent mathematical submissions per item through the unchanged exact checker. Invalid optional report metadata receives its own rejection receipt; it must not undo an independently checked theorem. Root completion still has its separate strict correspondence and premise gate. A later bad item must not erase earlier accepted items.
2. **No bounded proposal repair.** policy.commit at study.py:520 can raise Invalid and halt the entire arm. Add bounded, charged repair with a new logical request identity and explicit previous invalid receipt/errors. Preserve old bytes, account all attempts, and never replay an uncertain mathematical action silently. Failure after repair budget is exhausted is a recorded pause/failure, not a mathematical refutation.
3. **Exploration is too rigid for routine work.** study_policy requires two initial hypotheses, exact text reproduction of selected/alternative uncertainty and outcomes, and one portfolio trial even for routine proof exploitation. Use ordinary autonomous theorem work as the default. Invoke competing hypotheses and prospective consequential outcomes only for meaningful exploration/strategy trials. Commit immutable hypothesis versions/references; post-action findings and updated uncertainties are separate records. Changed claims create explicit descendants rather than rewriting history.
4. **Residual ledger is too shallow.** Present reductions target only the fixed root and include a conjunction of residuals; representations produce antecedents; ordinary facts are marked relevance-not-asserted. Extend to a checked named proposition/context DAG: exact residual-to-residual edges and their composed path to the unchanged root. Record context/source bindings, premises, used exports, and open leaves. A conditional theorem does not close its antecedents; an unconnected useful theorem can be retained without fabricated root progress. Prohibit circular closure and unknown premises.
5. **Strategy language is cosmetic.** study_program.py:25–34 currently permits only agenda/portfolio reverse, rotate, observation truncation, and conditional-on-open-obligations. Add bounded declarative choices that actually affect obligation selection, library reuse, branch allocation, tool/validation time, exploration/exploitation, and reassessment. Preserve root, premise policy, retained checked facts/history and global resource bounds. Keep broad LLM mathematical actions; do not replace them with a fixed recipe.
6. **Delayed benefit needs checked reuse.** An accepted component is true but not thereby relevant, novel or useful. Require actual later consumers to import and use its exported declarations; preserve its exact representation/section/boundary proof. Compare equal-budget continuations from a frozen state while permitting later strategy changes on both sides. A policy selection is empirical until D1–D3 are proved for the actual host.
7. **Validation capacity must match the real pipeline.** Existing whole-task timeout includes compile, independent replay and closure inspection. Host preflight must run representative Mathlib use through the actual deployment path with adequate reserved time, not infer success from a fixture or compiler-only result. Capture timeout/setup failure separately from theorem failure, retain receipts, and support explicitly charged new attempts where safe.
8. **Complexity remains one-way audit.** study_burden is not imported by controller and preserves unknown conditional minimum complexity. Keep that boundary. Count new definitions/adapters/composition overhead in any witness bundle; mere reusable lemma count or source shortening is not a measured drop in the fixed goal proof burden. Missing observations stay missing; no invented sawtooth. Changes to audit data must not affect requests, choices or theorem admission.

## Resource/OOM defects to fix before new launches

- study_worker has bounded streamed stdout/stderr and wall time, but no process-tree RSS, memory pressure, disk growth or minimum-free-space guard. Add shared global budgets before launch and periodic ownership-scoped checks; terminate only owned descendants on breach, preserving source/receipt checkpoint. Do not stop unrelated repositories/processes.
- study_common.sha currently does Path.read_bytes(), allocating each complete object in RAM. check_task hashes every compiled object with sha; large .olean files can create large avoidable transient RAM spikes. Hash in fixed-size chunks. Likewise stream events.jsonl parsing rather than read_text().splitlines().
- Snapshot/archive_sources duplicates full retained source collections each round; branch setup copies full history. Use content-addressed immutable source storage or bounded source-only views; retain exact manifests and dependencies. Never include compiled outputs in source archives.
- Each validator keeps compiled outputs. Remove rebuildable outputs only after exact source, toolchain/dependency pins, receipts and rebuild recipe are retained. Bound simultaneous Lean jobs, external model calls, output sizes and temporary build directories. A sequential -j1 compile does not by itself bound all descendant resources.
- Mandatory acceptance checks cover low-free-disk refusal, disk-growth and RSS termination, descendant cleanup, bounded hashing/output parsing, retained source recovery and no collateral process termination. Tests should themselves be resource-bounded and sequential for Lean-heavy paths.

## Acceptance evidence for the blend

Use a neutral universal theorem with unbounded indices, independent of Markov, proved in successive admitted components. A later fresh consumer must actually import earlier accepted exports and use exact representation plus conservative/dependent gluing; independently replay and inspect premise closure, then close the fixed neutral root. Include incompatible boundary, lossy representation, missing section, altered premise/false conclusion/unapproved axiom failures. Test bad optional prose and bad later submissions without rollback; immutable commitment plus changed findings; charged proposal repair and next actual call; exact residual composition without closing open leaves; real strategy candidate selection affecting subsequent requests; crash/timeout accounting; audit isolation; resource limits. Audit frozen implementation before tests, retain failures, and do not launch Markov research without the user's later approval.


## Addendum: exact contexts, partial admission and residual composition (2026-10-18T15:40:26.471272+00:00)

Read-only follow-up; no tests/builds or repository edits.

### Existing invariants and tests to preserve

- `bind_task` freezes context source contents before generating a target module; `target_source` captures each residual once as a qualified constant and the reduction itself uses those exact constants. The adapter must not decide a target's meaning afterward. `check_task` rebuilds all project imports, independently replays them, and traverses actual checked declarations' types AND values for allowed premise closure. Printed axioms are diagnostic only.
- `tests/test_context_revision.py::test_residual_same_text_different_context_and_positive_discharge` is essential: original `Neutral.P := False` cannot be replaced by a different module's `Neutral.P := True`, while exact `Neutral.Q` succeeds. A local `Goal := False` must not be confused with the pinned root. Preserve fake canonical root/foundation rejection and a task name absent before adapter elaboration.
- `tests/test_revision_static_checkpoint.py` includes missing section, lossy representation, dependent-family map type mismatch, hidden premise inspection and a connected delayed-use consumer fixture. Its so-called connected cycle is a controller round cycle, not an adversarial dependency-DAG cycle.
- `tests/test_study_v2.py` intentionally separates mathematical correctness from component-use credit: a task's `required_constants` metadata alone may produce `checked=True, component_use_checked=False`; mandatory consumer use is enforced only when the declaration names are also supplied to inspector `required=`. Do not accidentally treat metadata or a successfully imported module as proof of actual use.
- `study_knowledge.ingest` currently checks declared component dependencies against the actual consumer constant closure, and checks all accepted source hashes. Keep both checks after partial admission changes. Presence establishes syntactic/transitive checked use, not causal indispensability; declarations occurring in types count, so documentation must not claim the component was necessary.

### Additional acceptance cases

1. **Exact-context edge identity.** Store node proposition as its frozen target constant with context/source/dependency bindings, not only displayed text. Two nodes with identical English or Lean text in distinct contexts cannot be merged. A changed import, notation environment, namespace, definition body or dependency version requires a new bound version. A root-like name in an adapter must not shadow the unchanged root. An accepted semantic equivalence bridge may relate two contexts, but string equality cannot.
2. **Actual premise transport.** A proposed DAG edge `(A ∧ B) → C` must be checked against the frozen A/B/C constants, not new definitions with matching labels. Unknown or rejected attachment dependencies are invalid. Explicitly test a declared dependency whose export is absent from actual closure, and a changed source behind the same accepted ID. Accepted constants must be rebuilt from exact retained source in the later consumer.
3. **Hyperedges and cycles.** A conjunction requires every antecedent; alternate derivations are alternatives, not extra conjuncts. Cyclic A→B and B→A cannot close either without a checked seed fact. Identity root→root and root→A→root with root still open cannot establish root. A true conditional implication from False remains a checked conditional theorem with open False; do not mark it unconditional, satisfied, useful or a reduction in difficulty.
4. **Partial ingestion durability.** Check a valid item followed by malformed and invalid items, and then another valid independent item. Earlier admissions remain durable, unrelated later items can continue within bounded budget, dependent items on failed parents are rejected/skipped accurately. Each item gets a receipt/status; no optional prose error may erase it. Preserve aggregate per-round resource envelope; partial ingestion must not turn over-limit reports into unbounded checks.
5. **Atomic export and recovery.** Inject interruption after checked receipt but before reusable export, after export but before state admission, and after state admission before the next snapshot. Resume must either finish an exact idempotent admission or retain explicit interrupted status without silent re-execution. Never admit a partially written export. Existing receipts require finished marker plus exact task/solution/source/tool bindings, not merely `checked=True` in a partial file. Recovered source mutations invalidate cached acceptance.
6. **Reservations and reuse.** Already accepted identical identity is idempotent and cannot donate reserved budget; altered identity under the same name is rejected. Independently checked artifacts in different protected branch pools are separately charged. A reservation without completed validator receipt does not authorize free replay; a new attempt must have a new charged identity. Cached finished receipt reuses only its exact immutable bundle.
7. **Root remains stricter.** Newly checked DAG closure is a mathematical witness, not automatic source/English correspondence approval. Do not let fixture output, optional report prose, a synthetic root resolution object, or independent-review text bypass `study_completion` / exact root premise and correspondence checks. A false conclusion or omitted quantified hypothesis must fail through actual Lean checking.
8. **Negative proof audit.** Preserve detection of hidden axiom/sorry in transitive types/values, missing body, missing used declaration, traversal exhaustion and oversized/malformed inspector artifact. Limit hits are incomplete validation, not mathematical falsity or permission to skip premise closure.

Root-DAG closure should retain an explicit checked composed witness and the selected edge route. A numeric ledger status or graph reachability without such a witness is inadequate, especially when there are multiple conditional routes.


## WIP candidate review (2026-10-18T15:46:22.813826+00:00)

NOT a frozen-checkpoint approval; external builder is still editing. No builds. Observed source hashes:

```
machinery/residual_dag.py 4b4c1fa019d1d0b1078f10f0d3cd5d494e0977bd84cd1e7c105411463d6f4c28
machinery/study_reports.py a1f3a7b51475ced9a0d62a66097ffdfa9c85196ce27ad317ae29e691b574cbe5
machinery/study_knowledge.py 1f0287572fbd13dd9eb59b0c0df06cd46cb691584dc27b2dd1db46668f863278
machinery/study_policy.py 20d8e80f163f4bf4c1936fb8a9be88e4124d85fb695f927b1133cfb8808fcab0
```

Current partial-ingestion design separates mathematical checking from optional metadata and preserves individually staged admissions. Exact root, fresh replay and premise gates appear retained at this WIP stage. Concrete blockers sent to builder:

- Existing reduction premises are converted to derived residuals, then the admission loop tries to recreate their ledger entries with changed statements (`P` versus the old qualified residual constant), target modules and context bindings. This rejects valid multi-level reuse after files have been written. Reuse the original named nodes unchanged; create records only for genuinely new residual IDs.
- Generated compositions place required edge constants in `task.required_constants`, but `check_task(required=...)` still receives the original submission item's list. Forward the generated mandatory constants to the trusted inspector. Retain downstream actual dependency-closure checks.
- `study_policy.request` does not yet expose the DAG, and reduction schema does not explain `target_id` or existing `premises`. The researcher cannot reliably use the new capability without a projected exact DAG and schema/prompt connection.
- Representations create remaining-obligation ledger entries but do not add corresponding graph nodes; this leaves their antecedents unavailable to the new composition planner unless explicitly integrated.
- DAG composition picks the latest edge only. This is a selection heuristic, not proof of absence of another closed derivation; record selected route and do not inflate a failed route to impossibility. Preserve cycles, open conjunction antecedents and exact contexts.
- Need final durability tests for interrupted source export and cached checked receipt reuse; current full export writes are not atomic and unfinished cached result is not explicitly rejected by finished-marker logic. No mathematical root resolution follows merely from `proposition_dag.root.status`.


## Frozen checkpoint 002 mathematical-admission review (2026-10-18T16:01:10.197905+00:00)

Reviewed `evidence/construction-v3/source-audit-002/sources/` rather than mutable working files. Manifest SHA256: `69b3ff8f741736325cc50ee12630b9b569bd05c8aa04142468e4d9fee9daa088`. All 115 snapshot files match manifest entries. Checkpoint001 is retained prior syntax-finding evidence, not the final002 source basis. No builds or tests executed by this reviewer.

**Disposition:** From the mathematical admission/context/root perspective, safe for bounded neutral test execution under the independent resource/process watcher. No proof-soundness, exact-context or root-resolution bypass found. Remaining functional and coverage gaps are not reasons for indefinite source-only review: exercise them with bounded tests, preserve failures, and repair before live campaign deployment. Resource/process execution safety is a separate review. This is not Markov-deployment approval.

### Previously reported defects corrected in002

- Existing named reduction premises are now skipped when creating newly introduced residual ledger entries; original exact constants/contexts are preserved.
- Generated composition required constants now reach `check_task(required=...)` and thus actual premise/dependency inspector.
- `study_policy.request` includes the proposition DAG for the independent researcher.
- Routine work no longer requires invented alternatives. Consequential hypotheses have immutable version references, separate findings and charged bounded proposal repair.
- Partial mathematical ingestion precedes optional metadata processing and stages each item independently. Both main and comparison branches use that consumer.

### Remaining corrections / focused tests before campaign

1. Representations still create open antecedents only in `remaining_obligations`, not DAG nodes. Register their exact captured constants/contexts in the DAG and add an actual later reduction/composition consumer. Do not infer that the represented target is proved from the existence of transport alone.
2. Document `target_id`, existing `premises`, and `compositions` in the researcher-facing schemas/prompt. Current reduction schema describes only new residuals to root. This is an API connection gap, not a proof checker bypass.
3. Cached accepted receipts currently check task hash but do not explicitly require `finished` or exact expected solution binding. Exports use non-atomic `write_text`. Add interruption tests around completed receipt/export/state/snapshot; retain exact source versions, refuse unfinished validation as acceptance, and recover exact completed admission idempotently without an uncharged new check. A mismatch must remain an operational rejection.
4. Newly planned negatives should include the existing same-text/different-context residual and absent-before-adapter target regressions. Add declared dependency with no actual export use and an accepted source changed under the same ID. The current trusted checker logic retains these protections; verify regression rather than assuming it.
5. The new boundary negative `∀ a : Unit, false = true` is an ordinary false equation, not a test of incompatible maps into an actual pushout. Use Gluing.necessary/conflicting_binding or a deliberately incompatible descend witness; retain a genuine positive compatible construction.
6. A literal `axiom` source negative tests the lexical screen only. Retain `tests/test_revision_static_checkpoint.py::test_hidden_premise_with_spoofed_empty_reports_rejected`, whose generated missing proof is rejected by the actual post-replay inspector, and require inspection to have run.
7. Add a conjunction route with two genuinely distinct residuals, the missing-one-leaf case, existing-premise reuse, and attempted cycle. Current real DAG test uses successive definitionally equal commutativity propositions with one open leaf; that tests mechanics but not the conjunction/cycle/context boundaries thoroughly.
8. `select_obligation` raises on a closed residual. A successful proof can therefore make a previously accepted strategy halt the next round. Add explicit bounded autonomous reassessment/fallback for stale strategy focus, keeping root/premise/library constraints. Test the actual next request after closing the selected leaf. No theorem checker rule changes.

The neutral consumer does genuinely reference accepted conservative extension, exact representation and dependent-pushforward exports; it is not merely an import list. Existing Continuation still genuinely consumes Gluing and remains unchanged, with D1–D3 explicitly open for the actual host. Empirical matched continuation selection is consistently labeled uncertified. Preserve root MathGKM.lean aggregate during installation and use the separate Construction entry point.
