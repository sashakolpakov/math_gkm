"""Shared host admission and ownership-scoped observation, never proof evidence.

One heavy lease covers validators, replay, inspectors and external proposers.
Limits can only be lowered by callers. Darwin RSS sums can double-count shared
pages; vm_stat gives a conservative available-memory estimate, not physical
ownership. Missing required observations fail closed, with an explicit reason.
"""
import contextlib
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

GiB = 1024**3
ROOT = Path(__file__).resolve().parents[1]
LIMITS = dict(rss_sustained=4*GiB, rss_hard=5*GiB, sustained_seconds=3,
              admit_free=8*GiB, hard_free=5*GiB, growth=GiB,
              processes=24, poll_seconds=1, timeout=1800, output_bytes=GiB)

class ResourceFailure(RuntimeError):
    pass

def limits(overrides=None):
    out = dict(LIMITS)
    for k,v in (overrides or {}).items():
        if k not in out or not isinstance(v, (int,float)) or v <= 0:
            raise ResourceFailure('invalid resource limit')
        # Headroom floors may be raised, all other caps may only be reduced.
        if (k in ('admit_free','hard_free') and v < out[k]) or (k not in ('admit_free','hard_free') and v > out[k]):
            raise ResourceFailure('resource override increases immutable global bound')
        out[k] = v
    return out

def observation(argv):
    """Small, bounded OS observer, deliberately outside the guarded launcher."""
    p = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        out,err = p.communicate(timeout=2)
    except subprocess.TimeoutExpired:
        p.kill(); p.communicate()
        raise ResourceFailure('monitor_unavailable: observer timeout')
    if p.returncode or len(out)+len(err)>2**20:
        raise ResourceFailure('monitor_unavailable: '+str(argv[0]))
    return out.decode(errors='replace')

def available_memory():
    if os.uname().sysname == 'Darwin':
        import re
        text = observation(['/usr/bin/vm_stat'])
        page = re.search(r'page size of (\d+) bytes',text)
        counts = dict(re.findall(r'^(Pages [^:]+):\s+(\d+)\.',text,re.M))
        if not page or not all(k in counts for k in ('Pages free','Pages inactive','Pages speculative')):
            raise ResourceFailure('monitor_unavailable: Darwin vm_stat format')
        return sum(int(counts[k]) for k in ('Pages free','Pages inactive','Pages speculative'))*int(page[1])
    try:
        with open('/proc/meminfo') as f:
            for line in f:
                if line.startswith('MemAvailable:'): return int(line.split()[1])*1024
    except OSError as exc:
        raise ResourceFailure('monitor_unavailable: available memory') from exc
    raise ResourceFailure('monitor_unavailable: available memory')

def process_table():
    table = {}
    for line in observation(['/bin/ps','-axo','pid=,ppid=,rss=,lstart=,comm=']).splitlines():
        fields = line.split(None,8)
        if len(fields) < 9: continue
        pid,ppid,rss = map(int,fields[:3])
        table[pid] = dict(ppid=ppid,rss=rss*1024,identity=' '.join(fields[3:8]),command=fields[8])
    if not table: raise ResourceFailure('monitor_unavailable: process table')
    return table

def disk_bytes(root):
    total=count=0
    for directory,dirs,files in os.walk(root,followlinks=False):
        dirs[:] = [d for d in dirs if d not in ('.git','.lake','__pycache__') and not (Path(directory)/d).is_symlink()]
        for name in files:
            p=Path(directory)/name
            if p.is_symlink(): continue
            try: total += p.stat().st_size
            except FileNotFoundError: continue
            count+=1
            if count>100000: raise ResourceFailure('monitor_unavailable: disk scan bound')
    return total

@contextlib.contextmanager
def admission(kind='validator', overrides=None):
    cap=limits(overrides)
    base=ROOT/'.scratch/resources'
    base.mkdir(parents=True,exist_ok=True)
    with (base/'heavy.lock').open('a') as f:
        try: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise ResourceFailure('shared_heavy_reservation_busy')
        if shutil.disk_usage(ROOT).free<cap['admit_free']: raise ResourceFailure('admission_disk_headroom')
        if available_memory()<cap['admit_free']: raise ResourceFailure('admission_memory_headroom')
        # Reservation is not measured RSS, elapsed time, or provider usage.
        receipt=base/(str(os.getpid())+'-'+str(time.time_ns())+'.json')
        with receipt.open('x') as out:
            json.dump(dict(kind=kind,pid=os.getpid(),allocated_caps=cap,status='reserved',time=time.time()),out)
        yield cap

class Guard:
    def __init__(self,pid,scope,cap=None):
        self.pid=pid; self.scope=Path(scope); self.cap=limits(cap)
        self.owned={}; self.last=0; self.over_since=None
        self.baseline=disk_bytes(self.scope); self.samples=[]
    def check(self,force=False):
        now=time.monotonic()
        if not force and now-self.last<self.cap['poll_seconds']: return
        self.last=now
        table=process_table()
        owned={self.pid} if self.pid in table else set()
        owned.update(p for p,i in self.owned.items() if p in table and table[p]['identity']==i)
        changed=True
        while changed:
            extra={p for p,v in table.items() if v['ppid'] in owned}
            changed=not extra<=owned; owned.update(extra)
        self.owned.update({p:table[p]['identity'] for p in owned})
        rss=sum(table[p]['rss'] for p in owned)
        available=available_memory(); free=shutil.disk_usage(self.scope).free
        growth=disk_bytes(self.scope)-self.baseline
        compilers=sum(Path(table[p]['command']).name in ('lean','leanchecker','lake') for p in owned)
        sample=dict(rss_sum=rss,available_memory_estimate=available,free_disk=free,growth=growth,owned_processes=len(owned),compilers=compilers)
        self.samples=(self.samples+[sample])[-8:]
        if rss>self.cap['rss_sustained']:
            self.over_since=self.over_since or now
        else: self.over_since=None
        reason = ('rss_hard' if rss>self.cap['rss_hard'] else
                  'rss_sustained' if self.over_since and now-self.over_since>=self.cap['sustained_seconds'] else
                  'disk_headroom' if free<self.cap['hard_free'] else
                  'memory_pressure_or_low_available' if available<self.cap['hard_free'] else
                  'disk_growth' if growth>self.cap['growth'] else
                  'process_limit' if len(owned)>self.cap['processes'] else
                  'compiler_concurrency' if compilers>1 else None)
        if reason: raise ResourceFailure(reason)
    def cleanup(self):
        # Recheck start identity: never signal a recycled or unrelated PID.
        table=process_table()
        for pid,identity in reversed(list(self.owned.items())):
            if pid!=os.getpid() and pid in table and table[pid]['identity']==identity:
                try: os.kill(pid,signal.SIGKILL)
                except ProcessLookupError: pass
    def receipt(self):
        return dict(limits=self.cap,last_samples=self.samples,monitor='RSS sum may count shared pages twice; available memory estimate; OS pressure level unavailable',ownership='observed descendant PID plus start identity; hostile unobserved daemon escape requires OS sandbox')
