"""Mathematics and optional report metadata are independent transactions."""
import copy
from .study_common import Invalid, digest, write

def accept_report(arm,state,report,workspace,directory,round_index,protocol,commitment):
    from . import study_policy
    from .study_knowledge import ingest
    # Every item is independently checked, even if optional prose is invalid.
    ingest(arm,state,report,workspace,directory/'math')
    metadata=copy.deepcopy(state)
    try:
        study_policy.record(metadata,report,workspace,round_index,protocol,prospective=commitment)
    except (Invalid,KeyError,TypeError,ValueError) as exc:
        receipt={'report_hash':digest(report),'status':'optional_metadata_rejected',
                 'error_class':type(exc).__name__, 'reason':str(exc), 'math_rollback':False}
        path=directory/('metadata-'+digest(receipt)+'.json')
        if not path.exists(): write(path,receipt)
        state.setdefault('metadata_failures',[]).append(receipt)
        return False
    state.clear(); state.update(metadata)
    return True
