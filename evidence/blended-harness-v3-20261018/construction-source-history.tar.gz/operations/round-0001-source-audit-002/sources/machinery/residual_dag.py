"""Named exact proposition DAG. Edges are only installed after Lean admission.
Graph closure is a planning aid; only a separately checked composition is math.
"""
from .study_common import Invalid,digest

def graph(state,contract):
    root=dict(constant=contract['root_declaration'],module=contract['root_file'][:-5].replace('/','.'),
              context=contract['root_sha256'],status='open')
    dag=state.setdefault('proposition_dag',dict(root='root',nodes={'root':root},edges={}))
    if dag['nodes']['root']['constant']!=root['constant'] or dag['nodes']['root']['context']!=root['context']:
        raise Invalid('immutable root/context changed')
    return dag

def prepare(dag,item):
    target=item.get('target_id','root')
    if target not in dag['nodes']: raise Invalid('unknown exact reduction target')
    residuals=item.get('residuals',[])
    known=item.get('premises',[])
    if len(set(known))!=len(known) or any(k not in dag['nodes'] for k in known):
        raise Invalid('unknown or duplicate premise')
    if any(r['id'] in dag['nodes'] for r in residuals):
        raise Invalid('named propositions are immutable; reference existing premises explicitly')
    ids=known+[r['id'] for r in residuals]
    if not ids or len(set(ids))!=len(ids): raise Invalid('distinct nonempty premises required')
    adjacency={k:[p for e in v for p in e['premises']] for k,v in dag['edges'].items()}
    adjacency.setdefault(target,[]).extend(ids)
    def visit(k,path):
        if k in path: raise Invalid('residual cycle')
        for p in adjacency.get(k,[]): visit(p,path|{k})
    visit(target,set())
    return target,ids,[{'id':k,'statement':dag['nodes'][k]['constant']} for k in known]+residuals

def conjunction(xs):
    return xs[0] if len(xs)==1 else '⟨'+', '.join(xs)+'⟩'

def projection(term,index,count):
    return '('+term+')'+'.2'*index+('.1' if index<count-1 else '')

def composition(dag,state,target='root'):
    leaves=[]; used=[]; imports=[]
    def plan(k,path):
        if k in path: raise Invalid('residual cycle')
        node=dag['nodes'][k]
        if node.get('proof'):
            used.append(node['proof_id']); imports.append(node['proof_module'])
            return node['proof']
        edges=dag['edges'].get(k,[])
        if edges:
            edge=edges[-1]
            used.append(edge['id']); imports.append(edge['module'])
            return '('+edge['proof']+' '+conjunction([plan(p,path|{k}) for p in edge['premises']])+')'
        if k not in leaves: leaves.append(k)
        return '@@'+k+'@@'
    if target not in dag['nodes']: raise Invalid('unknown composition target')
    term=plan(target,set())
    if not used: raise Invalid('unconnected proposition has no checked composition path')
    for n,k in enumerate(leaves):
        term=term.replace('@@'+k+'@@',projection('h',n,len(leaves)))
        imports.append(dag['nodes'][k]['module'])
    goal=dag['nodes'][target]['constant']; imports.append(dag['nodes'][target]['module'])
    if leaves:
        goal='('+' ∧ '.join(dag['nodes'][k]['constant'] for k in leaves)+') → '+goal
        term='fun h => '+term
    return dict(statement=goal,term=term,open_leaves=leaves,
                dependencies=sorted(set(used)),modules=sorted(set(imports)),target=target)
