"""Recoverable, attempt-owned compiled artifact retirement; never source GC."""
import shutil
from .study_common import ROOT,sha,write

def retire_build(directory,result):
    build=directory/'build'
    if not build.exists(): return
    source=directory/'source'
    pins={}
    for name in ('lean-toolchain','lakefile.toml','lake-manifest.json'):
        dest=directory/'rebuild-pins'/name
        dest.parent.mkdir(exist_ok=True)
        if not dest.exists(): shutil.copyfile(ROOT/name,dest)
        pins[name]=sha(dest)
    recipe=dict(source_files={str(p.relative_to(source)):sha(p) for p in source.rglob('*.lean')},
        pins=pins,result_sha256=sha(directory/'result.json'),
        binaries=result.get('binary_hashes'),dependency_paths=result.get('dependency_paths'),
        environment=result.get('launch_environment'),commands=[{k:r[k] for k in ('operation','argv') if k in r} for r in result['checks']],
        rebuild='Recreate build directory, preserve module order and pinned LEAN_PATH, rerun recorded compile/replay/inspector argv under a new charged attempt. Never reuse an uncertain attempt ID.')
    path=directory/'REBUILD.json'
    if not path.exists(): write(path,recipe)
    if build.is_symlink() or not build.resolve().is_relative_to(directory.resolve()):
        raise ValueError('compiled cleanup escaped owned attempt')
    objects={str(p.relative_to(build)):sha(p) for p in build.rglob('*') if p.is_file()}
    write(directory/'retired-objects.json',dict(objects=objects,recipe_sha256=sha(path)))
    shutil.rmtree(build)
