"""Post-review sequential runner. Never called during construction.

The supervisor must supply a protected review binding the exact source manifest.
The runner bounds its owned test tree; child validators obtain the shared heavy
lease themselves, so the outer observer does not reserve a second compiler.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time
from .study_common import ROOT,PYTHON,Invalid,read,sha,write
from .resources import Guard,ResourceFailure

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--label',required=True)
    p.add_argument('--seconds',type=int,default=1800)
    p.add_argument('tests',nargs='+')
    a=p.parse_args()
    if not 1<=a.seconds<=1800 or not a.label.replace('-','').isalnum(): raise Invalid('invalid bounded run label/time')
    manifest=read(a.manifest)
    review=read(ROOT/'.bootstrap/construction-v3-review.json')
    if review.get('accepted') is not True or review.get('manifest_sha256')!=sha(a.manifest):
        raise Invalid('independent source review does not bind these bytes')
    def changed(): return [n for n,h in manifest['files_sha256'].items() if sha(ROOT/n)!=h]
    if changed(): raise Invalid('source mismatch before validation')
    out=ROOT/'.scratch/v3-validation'/a.label
    out.mkdir(parents=True,exist_ok=False)
    argv=[PYTHON,'-m','unittest','-v',*a.tests]
    write(out/'intent.json',dict(argv=argv,manifest_sha256=sha(a.manifest),allocated_seconds=a.seconds))
    start=time.monotonic(); reason=None; child=None; guard=None
    try:
        with (out/'run.log').open('xb') as log:
            env={**os.environ,'PATH':'/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin',
                'TMPDIR':str(ROOT/'.scratch'),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','PYTHONDONTWRITEBYTECODE':'1'}
            child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=log,stderr=log,start_new_session=True)
            guard=Guard(child.pid,ROOT/'.scratch')
            while child.poll() is None:
                guard.check()
                if time.monotonic()-start>a.seconds: raise ResourceFailure('runner_timeout')
                time.sleep(.1)
    except (ResourceFailure,KeyboardInterrupt) as exc:
        reason=type(exc).__name__+': '+str(exc)
    finally:
        if guard:
            try: guard.cleanup()
            except ResourceFailure as exc: reason=reason or str(exc)
        if child and child.poll() is None: child.kill()
        if child: child.wait()
        write(out/'result.json',dict(returncode=child.returncode if child else None,termination=reason,
            worker_tree_wall_seconds=time.monotonic()-start,allocated_seconds=a.seconds,
            controller_wall_overlaps=True,provider_usage='raw receipts only; no normalization',
            log_sha256=sha(out/'run.log'),source_mismatches_after=changed(),
            scope='finite neutral evidence; never campaign activation or D1-D3 proof'))
    return 1 if reason or changed() else child.returncode

if __name__=='__main__': raise SystemExit(main())
