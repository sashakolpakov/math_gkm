"""Source editing/inspection and hashing only; never import candidate code."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
from datetime import datetime,timezone

root=Path.cwd()
p=root/'machinery/worker.py';s=p.read_text()
s=s.replace('def execute(directory):\n', '''def execute(directory):
    from .resources import admission,ResourceFailure
    try:
        with admission('legacy-external-worker') as cap:
            return _execute(directory,cap)
    except ResourceFailure as exc:
        request=json.loads((directory/'request.json').read_text())
        atomic(directory/'receipt.json',dict(outcome='resource_guard: '+str(exc),
            request_id=request['id'],elapsed_seconds=0,report=None,mathematical_resolution=False))

def _execute(directory,cap):
''')
s=s.replace('    error, p = None, None','    from .resources import Guard,ResourceFailure\n    guard=Guard(0,ROOT/\'.scratch\',cap)\n    error, p = None, None')
s=s.replace("        atomic(directory/'process.json'", "        guard.pid=p.pid\n        atomic(directory/'process.json'")
s=s.replace('                now = time.time()', '                guard.check()\n                now = time.time()')
s=s.replace('        if p is not None:\n            try:', '        if p is not None:\n            try: guard.cleanup()\n            except ResourceFailure as exc: error=error or str(exc)\n            try:')
s=s.replace("                if not path.is_symlink() and path.is_file():", "                if not path.is_symlink() and path.is_file() and path.suffix not in ('.olean','.ilean','.o','.so','.dylib','.pyc'):")
s=s.replace("            target.write_bytes((ROOT/name).read_bytes())", "            __import__('shutil').copyfile(ROOT/name,target)")
p.write_text(s)
p=root/'machinery/study.py';s=p.read_text().replace("'model': 'gpt-6-astra'", "'model': 'gpt-6.1-sol'");p.write_text(s)
p=root/'machinery/study_policy.py';s=p.read_text().replace('Never invoke another LLM, Codex, controllers or background processes.', 'Use at most one Lean compiler at a time. Never invoke another LLM, Codex, controllers or background processes.');p.write_text(s)

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
before=json.loads((root/'.scratch/construction-v3/before.json').read_text())
paths=[]
for folder in ('machinery','tests','MathGKM','docs','contracts','studies'):
    paths.extend(p for p in (root/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.lean','.md','.json'))
paths.extend(root/n for n in ('MathGKM.lean','MISSION.md','lakefile.toml','lake-manifest.json','lean-toolchain'))
paths.extend(p for p in (root/'.scratch/construction-v3').iterdir() if p.is_file())
paths.append(root/'.bootstrap/architecture-source-review.md')
hashes={str(p.relative_to(root)):sha(p) for p in sorted(set(paths))}
changed={n:h for n,h in hashes.items() if before.get(n)!=h}
errors=[]
for name in hashes:
    if name.endswith('.py'):
        try: ast.parse((root/name).read_text(),filename=name)
        except SyntaxError as exc: errors.append(str(exc))
protected=['MISSION.md','docs/DESIGN.md','MathGKM/Markov.lean','MathGKM/Protocol.lean','MathGKM/Gluing.lean','MathGKM/Continuation.lean','MathGKM/ResearchSemantics.lean','lakefile.toml','lake-manifest.json','lean-toolchain','contracts/markov-goal.json']
fixed={n:dict(before=before[n],after=hashes[n],unchanged=before[n]==hashes[n]) for n in protected}
checkpoint='evidence/construction-v3/source-audit-001/SOURCE_MANIFEST.json'
commands=[
 '/opt/homebrew/bin/python3 -m machinery.v3_validate --manifest '+checkpoint+' --label v3-pure tests.test_construction_v3.Pure',
 '/opt/homebrew/bin/python3 -m machinery.v3_validate --manifest '+checkpoint+' --label v3-resources tests.test_construction_v3_resources.Resources',
]
for test in ('test_successive_admission_fresh_consumer_exact_root','test_valid_math_invalid_optional_metadata_later_bad_item_recovery','test_checked_dag_actual_composition_and_unconnected_true','test_negative_math_boundaries_representation_section_premises_and_axiom'):
 commands.append('/opt/homebrew/bin/python3 -m machinery.v3_validate --manifest '+checkpoint+' --label v3-'+test.replace('_','-')+' tests.test_construction_v3.CheckedMath.'+test)
commands.append('/opt/homebrew/bin/python3 -m machinery.v3_validate --manifest '+checkpoint+' --label v3-matched tests.test_construction_v3.MatchedContinuation')
commands.append('/opt/homebrew/bin/python3 -m machinery.study_deployment --out .scratch/v3-deployment-UNUSED --seconds 1800')
audit=dict(phase='construction',schema='math-gkm.construction-v3.source-audit',model='gpt-6.1-sol',reasoning='high',
    status='STOPPED FOR INDEPENDENT SOURCE AUDIT; NO TESTS HAVE YET RUN',tests_run=False,compilers_run=False,preflights_run=False,
    checkpoint=checkpoint,changed_files_sha256=changed,protected= fixed,static_parse_findings=errors,
    producer_artifact_consumer=[
      ['Gluing quotient pushout + boundary','descend/universal and glued traces','Continuation.main/verified_change; existing source unchanged'],
      ['checked section/representation/dependent Push','renamed admitted modules and declaration closure receipts','fresh neutral consumer; next researcher request'],
      ['checked named reductions','immutable proposition DAG + actual composed Lean terms','root implication with open leaves; exact completion still separate'],
      ['ordinary plans/versioned exploration','immutable hypothesis refs; separate findings','researcher; charged repair uses new logical ID'],
      ['per-item checker','accepted exports independent of optional metadata rejection','ordinary and both matched continuation branches'],
      ['strategy interpreter','obligation/reuse/allocation/time/reassessment directives','actual request, timeouts and empirical matched selection'],
      ['shared admission + owned tree monitor','resource/termination receipts; retained rebuild recipes','all process.run validators and external workers'],
      ['audit-only burden observer','dictionary/adapter/composition witnesses with unknown minima','standalone audit; no research decision consumer']],
    planned_commands=commands,expected_scope='Sequential neutral finite evidence only; deployment must use real sandbox, pinned Mathlib, compile + leanchecker + inspector, no mocked identity. Prefix Lean/Lake commands with env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null.',
    limits=dict(external_proposers=1,lean_compilers=1,heavy_jobs=1,rss_sustained_GiB=4,rss_hard_GiB=5,admission_free_GiB=8,hard_free_GiB=5,output_and_growth_GiB=1,poll_seconds=1,owned_processes=24,validation_attempt_seconds_max=1800,repair_attempts_default=1,repair_attempts_max=2),
    open_obligations={'D1':'OPEN: whole live continuation utility','D2':'OPEN: Python/OS refinement','D3':'OPEN: concrete environment/time/install obligations'},
    remaining=['Independent source audit before ANY execution','All acceptance outcomes and Mathlib deployment calibration unknown','New failure fixes require new checkpoint; preserve prior receipts','OS containment still needed for unobserved hostile daemon escape; Darwin RSS shared-page and available-memory limitations are explicit','Full crash/platform matrix and live provider behavior unvalidated','Agoh/Markov campaigns require later explicit USER OK'],
    self_hash='Audit excludes its own hash; frozen source manifest binds audit and all touched docs/scripts/fixtures.')
auditpath=root/'CONSTRUCTION_V3_AUDIT.json'
if auditpath.exists(): raise RuntimeError('never overwrite prior audit')
auditpath.write_text(json.dumps(audit,indent=2)+'\n')
hashes['CONSTRUCTION_V3_AUDIT.json']=sha(auditpath)
out=root/Path(checkpoint).parent
out.mkdir(parents=True,exist_ok=False)
for name,h in hashes.items():
    target=out/'sources'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,target);target.chmod(0o444)
manifest=dict(phase='construction',status='FROZEN SOURCE AUDIT; TESTS NOT RUN',created_utc=datetime.now(timezone.utc).isoformat(),
    files_sha256=hashes,changed_files=sorted(changed),protected=fixed,static_parse_findings=errors,
    audit='CONSTRUCTION_V3_AUDIT.json',next='Independent supervisor source review; then separate sequential bounded validation invocation')
mp=out/'SOURCE_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');mp.chmod(0o444)
companion=out/'SOURCE_MANIFEST.sha256';companion.write_text(sha(mp)+'  SOURCE_MANIFEST.json\n');companion.chmod(0o444)
print(json.dumps(dict(checkpoint=checkpoint,sha256=sha(mp),changed_files=len(changed),static_parse_findings=errors,tests_run=False)))
