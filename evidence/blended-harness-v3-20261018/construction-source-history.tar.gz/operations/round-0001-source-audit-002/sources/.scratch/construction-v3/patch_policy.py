from pathlib import Path
p=Path('machinery/study_policy.py');s=p.read_text()
a=s.index("    if state['mode'] != 'baseline':\n        alternatives")
b=s.index("    for link in report.get('use_links'",a)
s=s[:a]+'''    # Fixed predictions live under immutable identities; findings are separate.
    fixed=('id','kind','claim','uncertainty','outcomes')
    for h in report.get('hypotheses',[]):
        if not isinstance(h,dict) or any(k not in h for k in fixed):
            raise Invalid('hypothesis identity, claim and predictions required')
        if h['kind'] not in ('obstacle','capability','strategy') or not h['id'] or not h['claim']:
            raise Invalid('invalid hypothesis identity or kind')
        original=state['portfolio'].get(h['id'])
        core={k:h[k] for k in fixed}
        if original:
            if any(original[k]!=core[k] for k in fixed):
                raise Invalid('predictions immutable; create an explicit version descendant')
            if h.get('parent',original['parent'])!=original['parent'] or h.get('revision',original['revision'])!=original['revision']:
                raise Invalid('version ancestry immutable')
        else:
            parent=h.get('parent'); revision=h.get('revision',0)
            ancestors=[v for v in state['portfolio'].values() if v['reference']==parent]
            if (parent is None and revision!=0) or (parent is not None and (len(ancestors)!=1 or revision!=ancestors[0]['revision']+1)):
                raise Invalid('unknown parent or invalid hypothesis revision')
            version={**core,'parent':parent,'revision':revision}
            reference=digest(version)
            if h.get('reference',reference)!=reference: raise Invalid('hypothesis content hash mismatch')
            state['portfolio'][h['id']]={**version,'reference':reference}
        state.setdefault('findings',[]).append(dict(reference=state['portfolio'][h['id']]['reference'],round=round_index,
            status=h.get('status','open'),reason=h.get('reason',''),evidence=h.get('evidence',[])))
    trial=report.get('trial')
    consequential=report.get('work_kind','ordinary') in ('exploration','strategy')
    if consequential or trial:
        if not isinstance(trial,dict) or trial.get('hypothesis') not in state['portfolio']:
            raise Invalid('consequential experiment must select immutable hypothesis')
        selected=state['portfolio'][trial['hypothesis']]
        if not selected['uncertainty'] or len(selected['outcomes'])<2 or not all(
                isinstance(o,dict) and set(o)=={'check','changes_next_choice'} and all(isinstance(v,str) and v for v in o.values()) for o in selected['outcomes']):
            raise Invalid('consequential experiment needs discriminating outcomes and consequences')
        episode=state.get('episode')
        if episode is None or round_index>episode['review_round']:
            if episode: state.setdefault('episode_history',[]).append(episode)
            horizon=min(protocol['episode_rounds'],max(1,protocol['rounds']-round_index))
            episode=dict(start=round_index,review_round=round_index+horizon-1,continuation_rounds=horizon,
                         invention_used=0,hypothesis=selected['id'],status='usefulness_not_demonstrated')
            state['episode']=episode
        if trial.get('invention') and prospective is None:
            if episode['invention_used']>=protocol['invention_rounds']: raise Invalid('invention budget exhausted')
            episode['invention_used']+=1
        state['decisions'].append(dict(round=round_index,trial=trial,reference=selected['reference'],evidence=evidence))
    else:
        state['decisions'].append(dict(round=round_index,work_kind='ordinary',evidence=evidence))
    for finding in report.get('findings',[]):
        if finding.get('reference') not in {h['reference'] for h in state['portfolio'].values()}:
            raise Invalid('finding references unknown immutable hypothesis')
        state.setdefault('findings',[]).append({**finding,'round':round_index})
''' +s[b:]
a=s.index('    candidates = staged[\'portfolio\']');b=s.index("    fixed = ('id'",a)
s=s[:a]+'''    trial=report.get('trial')
    candidates=staged['portfolio']
    selected=candidates[trial['hypothesis']] if trial else None
'''+s[b:]
s=s.replace("'trial': copy.deepcopy(report['trial']),", "'trial': copy.deepcopy(trial), 'work_kind': report.get('work_kind','ordinary'),\n        'selected_reference': selected['reference'] if selected else None,")
s=s.replace("'selected': {k: copy.deepcopy(selected[k]) for k in fixed},", "'selected': {k: copy.deepcopy(selected[k]) for k in fixed} if selected else None,")
s=s.replace("if h['id'] != selected['id']", "if selected and h['id'] != selected['id']")
a=s.index("    hypotheses = {h['id']: h for h in report.get('hypotheses', [])}",s.index('def validate_execution'))
b=s.index("    if report.get('prospective_binding')",a)
s=s[:a]+'''    # A content-addressed reference replaces verbatim prediction prose.
    if commitment.get('selected_reference') and report.get('commitment_ref') != commitment['selected_reference']:
        hypotheses={h['id']:h for h in report.get('hypotheses',[])}
        actual=hypotheses.get(commitment['selected']['id'])
        if actual is None or any(actual.get(k)!=v for k,v in commitment['selected'].items()):
            raise Invalid('changed prediction or missing immutable commitment reference')
'''+s[b:]
s=s.replace("'component_use_checked'", "'component_use_checked'")
s=s.replace("Generate/retain competing explicit obstacle, capability and strategy hypotheses, not a prescribed math recipe. ","Ordinary proof exploitation is the default: trial:null and hypotheses:[] are valid. For consequential exploration/strategy experiments choose work_kind:exploration or strategy and precommit discriminating outcomes. ")
s=s.replace("Baseline keeps a single agenda and need not retain competing hypotheses; still explicitly commit its selected claim and outcome checks. ","Hypothesis identities are immutable versions with parent reference, revision and content hash. Changed predictions require a new descendant. ")
s=s.replace("Return the same trial identity and hypothesis claims, with actual evidence and updated status. A bounded invention round may precede a formal root reduction. ","Return the same trial identity and commitment_ref from commitment.selected_reference, with findings separate from immutable predictions. Routine work needs no artificial hypotheses. ")
s=s.replace('trial:{hypothesis,invention},','trial:null or {hypothesis,invention}, work_kind:ordinary/exploration/strategy, findings:[{reference,observation,uncertainty}], commitment_ref:null or immutable hash,')
s=s.replace('Executable instructions: reverse_agenda,','Executable instructions: select_obligation {id}; reuse_library {ids}; allocate {exploration_percent}; budgets {tool_seconds,validation_seconds}; reassess {after_rounds}; reverse_agenda,')
s=s.replace("'delayed_use_links': state['use_links'],", "'delayed_use_links': state['use_links'],\n        'proposition_dag': state.get('proposition_dag',{}), 'findings': state.get('findings',[]),")
s=s.replace("Aggregate entries across mathematical_claims, reductions, attachments, representations and fiber_gluings", "Aggregate entries across mathematical_claims, reductions, attachments, representations, fiber_gluings and compositions")
s=s.replace('Over-limit reports are rejected in full before checking.', 'Items within the cap are checked independently; later items are retained as not checked.')
p.write_text(s)
