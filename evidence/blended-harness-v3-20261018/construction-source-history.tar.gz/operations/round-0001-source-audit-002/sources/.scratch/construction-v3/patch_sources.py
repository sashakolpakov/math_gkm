from pathlib import Path
def edit(name,old,new):
    p=Path(name); s=p.read_text()
    if old not in s: raise RuntimeError('missing edit anchor '+name+' '+old[:60])
    p.write_text(s.replace(old,new))

edit('machinery/study_knowledge.py'," 'fiber_gluings':", " 'compositions': {'id': 'new identity', 'target_id': 'root or exact named residual; checked composition keeps open leaves'},\n 'fiber_gluings':")
edit('machinery/study_knowledge.py','def ingest(arm, state, report, workspace, directory):','def _ingest_batch(arm, state, report, workspace, directory):')
edit('machinery/study_knowledge.py',"            task, solution = task_for(kind, item, contract)\n            modules = [item['module']]",'''            from . import residual_dag as dag_api
            dag = dag_api.graph(state, contract)
            derived = copy.deepcopy(item)
            target_id = None
            composition = None
            if kind == 'reductions':
                target_id, premise_ids, residuals = dag_api.prepare(dag, item)
                derived['residuals'] = residuals
                local_contract = {**contract, 'root_declaration': dag['nodes'][target_id]['constant']}
                task, solution = task_for(kind, derived, local_contract)
                modules = [item['module'], dag['nodes'][target_id]['module']] + [dag['nodes'][p]['module'] for p in item.get('premises', [])]
            elif kind == 'compositions':
                composition = dag_api.composition(dag, state, item.get('target_id','root'))
                dependencies = composition['dependencies']
                derived.update(module=composition['modules'][0], statement=composition['statement'], term=composition['term'])
                task, solution = task_for('mathematical_claims', derived, contract)
                modules = composition['modules']
                task['required_constants'] = [state['knowledge'].get(d,state['components'].get(d))['exports'][0] for d in dependencies]
            else:
                task, solution = task_for(kind, item, contract)
                modules = [item['module']]''')
edit('machinery/study_knowledge.py',"                task['residuals'] = item['residuals']","                task['residuals'] = derived['residuals']")
edit('machinery/study_knowledge.py',"                for n, residual in enumerate(item['residuals']):","                for n, residual in enumerate(derived['residuals']):")
edit('machinery/study_knowledge.py',"                    state['remaining_obligations'][residual['id']] = old or value",'''                    state['remaining_obligations'][residual['id']] = old or value
                    if residual['id'] not in dag['nodes']:
                        dag['nodes'][residual['id']] = dict(constant=value['target_constant'],module=value['target_module'],context=value['context_binding'],status='open')
                dag['edges'].setdefault(target_id,[]).append(dict(id=identifier,premises=premise_ids,
                    proof=exports[0],module=record['export_module'],receipt_hash=digest(checked)))
            if composition:
                record['composition'] = composition
                record['relevance'] = 'checked composed path; open antecedents retained'
                if not composition['open_leaves']:
                    node=dag['nodes'][composition['target']]
                    node.update(proof=exports[0],proof_id=identifier,proof_module=record['export_module'],status='checked')''')
edit('machinery/study_knowledge.py',"                    state['remaining_obligations'][rid].update(status='checked', discharge=identifier)",'''                    state['remaining_obligations'][rid].update(status='checked', discharge=identifier)
                    if rid in dag['nodes']:
                        index=item['discharges'].index(rid)+1
                        dag['nodes'][rid].update(status='checked', proof=dag_api.projection(exports[0],index,len(item['discharges'])+1),
                            proof_id=identifier,proof_module=record['export_module'])''')
with Path('machinery/study_knowledge.py').open('a') as f:
 f.write('''

def ingest(arm, state, report, workspace, directory):
    """Each item commits independently; bad later items cannot roll back math."""
    failures = state.setdefault('submission_failures', [])
    items=[]
    for kind in SCHEMAS:
        values=report.get(kind,[])
        if not isinstance(values,list):
            failures.append(dict(kind=kind,status='invalid_submission_list')); continue
        items.extend((kind,item) for item in values)
    cap=arm.p.get('knowledge_checks_per_round',6)
    for index,(kind,item) in enumerate(items):
        attempt=dict(kind=kind,index=index,proposal_hash=digest(item))
        dest=directory/(str(index)+'-'+digest(item))
        if index>=cap:
            failure={**attempt,'status':'per_round_cap_exhausted; not checked'}
        else:
            staged=copy.deepcopy(state)
            try:
                if not isinstance(item,dict): raise Invalid('submission must be an object')
                _ingest_batch(arm,staged,{kind:[item]},workspace,dest)
                state.clear(); state.update(staged)
                failures=state.setdefault('submission_failures',[])
                continue
            except (Invalid,KeyError,TypeError,ValueError,OSError) as exc:
                failure={**attempt,'status':'submission_rejected_or_operationally_incomplete',
                         'error_class':type(exc).__name__,'reason':str(exc)}
        receipt=dest/('rejection-'+digest(failure)+'.json')
        if not receipt.exists(): write(receipt,failure)
        if failure not in failures: failures.append(failure)
    return state
''')

edit('machinery/study.py',"'validation_seconds': 120", "'validation_seconds': 600")
edit('machinery/study.py',"'knowledge_checks_per_round': 6}","'knowledge_checks_per_round': 6, 'proposal_repairs': 1}")
edit('machinery/study.py',"p['validation_seconds'] > 180", "p['validation_seconds'] > 1800")
edit('machinery/study.py',"    validate_commitment(p)\n", "    if type(p['proposal_repairs']) is not int or not 0 <= p['proposal_repairs'] <= 2:\n        raise Invalid('proposal repair bound must be 0..2')\n    validate_commitment(p)\n")
edit('machinery/study.py',"count*(2*p['call_seconds'] + (p['knowledge_checks_per_round']+1)*p['validation_seconds']), 2*count, count", "count*((2+p['proposal_repairs'])*p['call_seconds'] + (p['knowledge_checks_per_round']+1)*p['validation_seconds']), (2+p['proposal_repairs'])*count, (1+p['proposal_repairs'])*count")
start="""        planned = self.call(f'plan-{r:04d}', 'proposer', {**req, 'role': 'proposer'}, readonly=True)
        if planned['outcome'] != 'completed':
            raise Invalid('prospective proposer failed within budget; no trial authorized')
        committed = self.root/'jobs'/f'plan-{r:04d}'/'validated-plan.json'
        if committed.exists():
            binding = read(committed)
            if binding['receipt_hash'] != digest(planned):
                raise Invalid('committed prospective plan changed')
            staged, commitment = binding['research'], binding['commitment']
        else:
            staged, commitment = policy.commit(start['research'], planned['payload'], self.workspace, r, self.p)
            write(committed, {'receipt_hash': digest(planned), 'research': staged, 'commitment': commitment})"""
edit('machinery/study.py',start,"""        staged, commitment = self.plan_with_repair(f'plan-{r:04d}', req, start['research'], self.workspace, r, self.p)""")
start="""            try:
                policy.record(updated, result['payload'], self.workspace, r, self.p, prospective=commitment)
                ingest(self, updated, result['payload'], self.workspace, transaction/'checks')
                updated['next_trial'] = result['payload'].get('trial')
            except (Invalid, KeyError, TypeError) as exc:
                updated = copy.deepcopy(staged)
                updated['observations'].append({'round': r, 'validation_failure': str(exc),
                    'status': 'report_rejected; no theorem or refutation established'})"""
edit('machinery/study.py',start,"""            from .study_reports import accept_report
            accept_report(self, updated, result['payload'], self.workspace, transaction/'checks', r, self.p, commitment)""")
start="""                with self.budget(key+'-'+side):
                    plan = self.call(f'{key}-{side}-plan-{n}', 'proposer', {**req, 'role': 'proposer'}, ws, True)
                if plan['outcome'] != 'completed':
                    raise Invalid('branch prospective proposer failed within budget')
                committed = destination/f'{side}-commit-{n}.json'
                if committed.exists():
                    binding = read(committed)
                    if binding['receipt_hash'] != digest(plan):
                        raise Invalid('branch prospective receipt changed')
                    staged, commitment = binding['research'], binding['commitment']
                else:
                    staged, commitment = policy.commit(local, plan['payload'], ws, index, branch_protocol)
                    write(committed, {'receipt_hash': digest(plan), 'research': staged, 'commitment': commitment})"""
edit('machinery/study.py',start,"""                with self.budget(key+'-'+side):
                    staged, commitment = self.plan_with_repair(f'{key}-{side}-plan-{n}', req, local, ws, index, branch_protocol)""")
start="""                    try:
                        local = copy.deepcopy(staged)
                        policy.record(local, result['payload'], ws, index, branch_protocol, prospective=commitment)
                        with self.budget(key+'-'+side):
                            ingest(self, local, result['payload'], ws, destination/f'{side}-checks-{n}')
                    except (Invalid, KeyError, TypeError) as exc:
                        progress['valid'] = False
                        local = copy.deepcopy(staged)
                        local['observations'].append({'status': 'invalid_branch_report', 'reason': str(exc)})"""
edit('machinery/study.py',start,"""                    from .study_reports import accept_report
                    local = copy.deepcopy(staged)
                    with self.budget(key+'-'+side):
                        metadata_ok = accept_report(self, local, result['payload'], ws, destination/f'{side}-checks-{n}', index, branch_protocol, commitment)
                    progress['valid'] = progress['valid'] and metadata_ok
                    # Both continuations can propose and execute later bounded strategies.
                    if local.get('pending_program'):
                        local['program'] = local.pop('pending_program')['program']
                        local['pending_program'] = None
                    if local.get('pending_policy'):
                        local['policy'] = local.pop('pending_policy')['policy']
                        local['pending_policy'] = None""")
edit('machinery/study.py',"        calls = 4*self.p['policy_trial_rounds']", "        calls = 2*(2+self.p['proposal_repairs'])*self.p['policy_trial_rounds']")
edit('machinery/study.py',"(2*self.p['call_seconds'] +\n            self.p['knowledge_checks_per_round']", "((2+self.p['proposal_repairs'])*self.p['call_seconds'] +\n            self.p['knowledge_checks_per_round']")
edit('machinery/study.py',"2*self.p['policy_trial_rounds'] > self.available_calls(meta=True)","2*(1+self.p['proposal_repairs'])*self.p['policy_trial_rounds'] > self.available_calls(meta=True)")
anchor='    def role_workspace(self, key, records, source=None):'
edit('machinery/study.py',anchor,'''    def plan_with_repair(self,key,req,state,workspace,index,protocol):
        """New charged IDs only. Uncertain operational actions are never repaired/replayed."""
        repair=None
        for attempt in range(protocol['proposal_repairs']+1):
            logical=key if attempt==0 else key+'-repair-'+str(attempt)
            request={**req,'role':'proposer'}
            if repair: request['repair']=repair
            receipt=self.call(logical,'proposer',request,workspace,True)
            path=self.root/'jobs'/logical/'validated-plan.json'
            if path.exists():
                binding=read(path)
                if binding['receipt_hash']!=digest(receipt): raise Invalid('immutable plan receipt changed')
                return binding['research'],binding['commitment']
            # Parsing errors from a completed, read-only proposer are safe to repair.
            if receipt['outcome']!='completed' and not receipt['outcome'].startswith('invalid_report:'):
                raise Invalid('operational proposer failure; no uncertain action replay')
            try:
                staged,commitment=policy.commit(state,receipt.get('payload'),workspace,index,protocol)
            except (Invalid,KeyError,TypeError,ValueError) as exc:
                invalid=self.root/'jobs'/logical/'invalid-plan.json'
                record=dict(status='invalid_proposer_payload',receipt_hash=digest(receipt),
                    original_final_sha256=sha(invalid.parent/'final.json') if (invalid.parent/'final.json').exists() else None,
                    error_class=type(exc).__name__,safe_error='Invalid plan schema, identity, artifact binding or prospective commitment. Correct your own retained payload; no action executed.',
                    attempt=attempt,new_request_required=True)
                if not invalid.exists(): write(invalid,record)
                repair=dict(previous_request=logical,receipt_hash=digest(receipt),error=record['safe_error'],
                    previous_payload=receipt.get('payload'),invalid_receipt_sha256=sha(invalid))
                continue
            write(path,dict(receipt_hash=digest(receipt),research=staged,commitment=commitment))
            return staged,commitment
        failure=dict(status='operational_repair_exhausted; root remains open',request=key,attempts=protocol['proposal_repairs']+1)
        path=self.root/'repair-failures'/(key+'.json')
        if not path.exists(): write(path,failure)
        raise Invalid(failure['status'])

'''+anchor)
