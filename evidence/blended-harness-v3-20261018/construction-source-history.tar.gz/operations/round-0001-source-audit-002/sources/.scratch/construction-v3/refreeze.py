"""Final source-only correction checkpoint; retain audit-001 unchanged."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
from datetime import datetime,timezone
root=Path.cwd()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
oldpath=root/'evidence/construction-v3/source-audit-001/SOURCE_MANIFEST.json'
old=json.loads(oldpath.read_text())
auditpath=root/'CONSTRUCTION_V3_AUDIT.json'
audit=json.loads(auditpath.read_text())
newcheckpoint='evidence/construction-v3/source-audit-002/SOURCE_MANIFEST.json'
names=set(old['files_sha256'])|{'.scratch/construction-v3/refreeze.py'}
errors=[]
for n in sorted(names):
    if n.endswith('.py'):
        try: ast.parse((root/n).read_text(),filename=n)
        except SyntaxError as exc: errors.append(str(exc))
audit['checkpoint']=newcheckpoint
audit['planned_commands']=[c.replace('source-audit-001','source-audit-002') for c in audit['planned_commands']]
audit['static_parse_findings']=errors
audit['prior_checkpoint']={'manifest':str(oldpath.relative_to(root)),'sha256':sha(oldpath),'disposition':'Retained static indentation finding; source corrected before final independent review. No execution occurred.'}
audit['changed_files_sha256']['machinery/study_knowledge.py']=sha(root/'machinery/study_knowledge.py')
audit['changed_files_sha256']['.scratch/construction-v3/refreeze.py']=sha(root/'.scratch/construction-v3/refreeze.py')
auditpath.write_text(json.dumps(audit,indent=2)+'\n')
hashes={n:sha(root/n) for n in sorted(names)}
out=root/Path(newcheckpoint).parent;out.mkdir(parents=True,exist_ok=False)
for n in names:
    target=out/'sources'/n;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/n,target);target.chmod(0o444)
record={**old,'created_utc':datetime.now(timezone.utc).isoformat(),'files_sha256':hashes,'static_parse_findings':errors,
    'prior_checkpoint':audit['prior_checkpoint']}
p=out/'SOURCE_MANIFEST.json';p.write_text(json.dumps(record,indent=2)+'\n');p.chmod(0o444)
companion=out/'SOURCE_MANIFEST.sha256';companion.write_text(sha(p)+'  SOURCE_MANIFEST.json\n');companion.chmod(0o444)
print(json.dumps(dict(checkpoint=newcheckpoint,sha256=sha(p),static_parse_findings=errors,tests_run=False)))
