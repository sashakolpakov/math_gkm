from pathlib import Path
import hashlib,json
r=Path.cwd()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
paths=[]
for d in ('machinery','tests','MathGKM','docs','contracts','studies'):
    paths.extend(p for p in (r/d).rglob('*') if p.is_file() and p.suffix in ('.py','.lean','.md','.json'))
paths.extend(r/n for n in ('MathGKM.lean','MISSION.md','lakefile.toml','lake-manifest.json','lean-toolchain'))
with (r/'.scratch/construction-v3/before.json').open('x') as f:
    json.dump({str(p.relative_to(r)):sha(p) for p in paths},f,sort_keys=True,indent=2)
