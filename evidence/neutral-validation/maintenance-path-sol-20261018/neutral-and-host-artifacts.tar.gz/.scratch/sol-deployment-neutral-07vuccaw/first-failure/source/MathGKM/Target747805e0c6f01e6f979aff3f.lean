import MathGKM.HarnessFixture
def MathGKM.Target747805e0c6f01e6f979aff3f.Interface := True
def MathGKM.Target747805e0c6f01e6f979aff3f.Transport (StudyInterface : MathGKM.Target747805e0c6f01e6f979aff3f.Interface) : Prop := True
def MathGKM.Target747805e0c6f01e6f979aff3f.Goal (StudyInterface : MathGKM.Target747805e0c6f01e6f979aff3f.Interface) : Prop := True
