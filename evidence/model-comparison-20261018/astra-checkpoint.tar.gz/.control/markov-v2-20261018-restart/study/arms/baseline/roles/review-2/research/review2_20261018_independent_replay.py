"""Reviewer-authored replay of supplied artifacts only; no new mathematical tasks.
All outputs are durable review evidence, not temporary files.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone

stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
out = Path("research") / ("review2_" + stamp)
out.mkdir()
build = out / "build"
(build / "MathGKM").mkdir(parents=True)
lean = "/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean"
env = os.environ.copy()
env["LEAN_PATH"] = ":".join([str(build.resolve())] + [str(p.resolve()) for p in Path(".lake/packages").glob("*/.lake/build/lib/lean")])
records = json.loads(Path("inbox/records.json").read_text())
expected = {}
for receipt in records["receipts"]:
    expected.update(receipt["after"])
hashes = {p: {"sha256": hashlib.sha256(Path(p).read_bytes()).hexdigest(), "expected": h} for p, h in expected.items()}
report = {"provenance": "independent reviewer review-2", "artifact_hashes": hashes, "LEAN_PATH": env["LEAN_PATH"], "checks": []}

def run(name, argv):
    start = time.monotonic()
    try:
        p = subprocess.run(argv, capture_output=True, text=True, env=env, timeout=60)
        result = {"name": name, "argv": argv, "elapsed_seconds": time.monotonic()-start, "returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    except subprocess.TimeoutExpired as e:
        result = {"name": name, "argv": argv, "elapsed_seconds": time.monotonic()-start, "timeout": True, "stdout": str(e.stdout), "stderr": str(e.stderr)}
    report["checks"].append(result)
    (out / "receipt.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(result), flush=True)
    return result

run("lean_version", [lean, "--version"])
root = run("root_fresh_compile", [lean, "-j", "1", "-o", str(build / "MathGKM/Markov.olean"), "MathGKM/Markov.lean"])
if root.get("returncode") == 0:
    run("coverage_fresh_compile_axioms", [lean, "-j", "1", "-o", str(build / "MathGKM/R0001Coverage_20261018T100704Z.olean"), "MathGKM/R0001Coverage_20261018T100704Z.lean"])
diagnostic = run("existing_diagnostics", ["/opt/homebrew/bin/python3", "research/r0000_h0_20261018T100308Z_diagnostics.py"])
if diagnostic.get("returncode") == 0:
    actual = json.loads(diagnostic["stdout"])
    recorded = json.loads(Path("research/r0000_h0_20261018T100308Z_diagnostics.json").read_text())
    report["diagnostic_json_exact_match"] = actual == recorded
    report["diagnostic_counts"] = [{"label": d["label"], "triples": len(d["valid_triples"]), "all_hold": d["all_diagnostic_inequalities_hold"]} for d in actual["diagnostics"]]
(out / "receipt.json").write_text(json.dumps(report, indent=2) + "\n")
print("REVIEW_RECEIPT=" + str(out / "receipt.json"))
print("REVIEW_RECEIPT_SHA256=" + hashlib.sha256((out / "receipt.json").read_bytes()).hexdigest())
print("DIAGNOSTIC_EXACT_MATCH=" + str(report.get("diagnostic_json_exact_match")))
