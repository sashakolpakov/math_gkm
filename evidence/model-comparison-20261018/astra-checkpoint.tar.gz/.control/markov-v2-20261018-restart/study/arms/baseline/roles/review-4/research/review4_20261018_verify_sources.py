"""Independent review of supplied snapshots only; no source edits or new tasks.

All outputs are durable review evidence. The denied .scratch path is unused.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
out = Path('research') / ('review4_' + stamp)
(out / 'build/MathGKM').mkdir(parents=True)
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join([str((out / 'build').resolve())] +
    [str(p.resolve()) for p in Path('.lake/packages').glob('*/.lake/build/lib/lean')])
lean = '/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean'
receipt = {'provenance': 'Independent review-4 source replay', 'checks': [],
           'lean_path': env['LEAN_PATH'], 'directory': str(out),
           'records_sha256': hashlib.sha256(Path('inbox/records.json').read_bytes()).hexdigest()}
print(str(out), flush=True)
for module in ['Markov', 'R0001Coverage_20261018T100704Z',
               'R0002Homogeneous_20261018T101629Z', 'R0003Support_20261018T102259Z']:
    source = Path('MathGKM') / (module + '.lean')
    argv = [lean, '-j', '1', '-o', str(out / 'build/MathGKM' / (module + '.olean')), str(source)]
    start = time.monotonic()
    check = {'source': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
             'argv': argv, 'timeout_seconds': 120}
    try:
        result = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=120)
        check.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    except subprocess.TimeoutExpired as error:
        check.update(returncode=None, failure='timeout',
                     stdout=str(error.stdout or ''), stderr=str(error.stderr or ''))
    check['elapsed_seconds'] = time.monotonic() - start
    receipt['checks'].append(check)
    (out / (module + '.json')).write_text(json.dumps(check, indent=2) + '\n')
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(check), flush=True)
    if check['returncode'] != 0:
        break
