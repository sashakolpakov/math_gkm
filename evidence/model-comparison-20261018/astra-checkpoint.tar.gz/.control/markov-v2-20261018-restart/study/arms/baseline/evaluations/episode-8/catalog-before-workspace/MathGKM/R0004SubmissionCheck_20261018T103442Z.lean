import MathGKM.R0004SupportRepair_20261018T103442Z

/- Machine-authored exact submission interface checks, round-0004. -/
namespace MathGKM.Markov.R0004SubmissionCheck
theorem claim0 : ∀ path : List Bool, let f := MathGKM.Markov.HomogeneousR0002.frameH path; MathGKM.Markov.HomogeneousR0002.Homogeneous f.lo.p (f.lo.a + f.lo.b - 1) ∧ MathGKM.Markov.HomogeneousR0002.Homogeneous f.mid.p (f.mid.a + f.mid.b - 1) ∧ MathGKM.Markov.HomogeneousR0002.Homogeneous f.hi.p (f.hi.a + f.hi.b - 1) := MathGKM.Markov.HomogeneousR0002.reachable_homogeneous
#print axioms claim0
theorem claim1 : ∀ path : List Bool, let f := MathGKM.Markov.HomogeneousR0002.frameH path; ∀ i j : ℕ, i + j ≤ f.mid.a + f.mid.b - 1 → MathGKM.Markov.coeff (f.mid.p.coeff (f.mid.a + f.mid.b - 1 - i - j)) i j = MathGKM.Markov.coeff (MathGKM.Markov.frame path).mid.p i j := MathGKM.Markov.HomogeneousR0002.universal_transport
#print axioms claim1
end MathGKM.Markov.R0004SubmissionCheck
