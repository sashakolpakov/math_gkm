"""Machine-authored direct pinned Lean replay, round-0004. No Lake or networking."""
from pathlib import Path
import os, subprocess, datetime, sys
root = Path('research/r0004_support_repair_20261018T103442Z')
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join([str(root/'build')] + [str(p) for p in Path('.lake/packages').glob('*/.lake/build/lib/lean')])
(root/'lean_path.txt').write_text(env['LEAN_PATH'])
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S%f')
for module in (['Markov', 'R0002Homogeneous_20261018T101629Z', 'R0004SupportRepair_20261018T103442Z'] if len(sys.argv)==1 else sys.argv[1:]):
    source = Path('MathGKM')/(module+'.lean')
    if module != 'Markov':
        (root/('attempt_'+module+'_'+stamp+'.lean')).write_text(source.read_text())
    result = subprocess.run(['/Users/sasha/.elan/bin/lean', '-o', str(root/'build/MathGKM'/(module+'.olean')), str(source)], env=env, capture_output=True, text=True, timeout=65)
    log = result.stdout+result.stderr+'\nexit='+str(result.returncode)
    (root/(module+'_'+stamp+'.log')).write_text(log)
    print(log, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
