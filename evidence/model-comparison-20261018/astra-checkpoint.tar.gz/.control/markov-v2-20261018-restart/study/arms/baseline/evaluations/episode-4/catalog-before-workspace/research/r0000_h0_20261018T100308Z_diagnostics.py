"""Machine-authored H0 diagnostic, 2026-10-18; exact integer arithmetic.
Manual transcription of pinned definitions; not Lean execution or a proof.
No external packages, normalization, finite support filtering of LC triples,
network access, or subprocesses. Output is a retained experiment record.
"""
import hashlib
import json
import platform
from pathlib import Path


def add(*ps):
    out = {}
    for p in ps:
        for e, c in p.items():
            out[e] = out.get(e, 0) + c
    return {e: c for e, c in out.items() if c}


def neg(p):
    return {e: -c for e, c in p.items()}


def mul(p, q):
    out = {}
    for e, c in p.items():
        for f, d in q.items():
            g = tuple(x + y for x, y in zip(e, f))
            out[g] = out.get(g, 0) + c*d
    return {e: c for e, c in out.items() if c}


def shift(p, e):
    return mul(p, {e: 1})


one = {(0, 0): 1}
u, v = {(1, 0): 1}, {(0, 1): 1}
t = add(u, v)
s = add(t, one)
p12 = add(mul(t, t), u)
left = add(mul(s, p12), neg(mul(v, t)))
right = add(mul(mul(s, t), p12), neg(mul(u, v)))

# Independent Laurent mutation in x,y,z; negative exponents are allowed.
x, y, z = {(1, 0, 0): 1}, {(0, 1, 0): 1}, {(0, 0, 1): 1}
xy = add(mul(x, x), mul(y, y))
k = shift(add(xy, mul(z, z)), (-1, -1, -1))
m01 = x
m11 = shift(xy, (0, 0, -1))
m12 = shift(add(mul(xy, xy), mul(mul(x, x), mul(z, z))), (0, -1, -2))
m13 = add(mul(mul(k, m01), m12), neg(m11))
m23 = add(mul(mul(k, m11), m12), neg(m01))


def in_polygon(a, b, i, j):
    return i >= 0 and j >= 0 and a*b <= b*i+a*j and i+j <= a+b-1


def diagnostic(a, b, p, laurent):
    degree = a+b-1
    numerator_xyz = shift(laurent, (a-1, b-1, degree))
    assert all(all(e >= 0 and e % 2 == 0 for e in es) for es in numerator_xyz)
    numerator_uvw = {tuple(e//2 for e in es): c for es, c in numerator_xyz.items()}
    homogeneous_lift = {(i, j, degree-i-j): c for (i, j), c in p.items()}
    assert numerator_uvw == homogeneous_lift
    assert all(sum(es) == degree for es in numerator_uvw)
    # Dense grid retains zero coefficients, including outside the polygon.
    grid = [{"i": i, "j": j, "coefficient": p.get((i, j), 0),
             "in_polygon": in_polygon(a, b, i, j)}
            for i in range(degree+1) for j in range(degree+1)]
    triples = []
    for i in range(degree+1):
        for j in range(degree+1):
            for direction, points in [
                ("horizontal", [(i,j), (i+1,j), (i+2,j)]),
                ("vertical", [(i,j), (i,j+1), (i,j+2)]),
                ("diagonal", [(i,j+2), (i+1,j+1), (i+2,j)])]:
                if all(in_polygon(a,b,*point) for point in points):
                    cs = [p.get(point, 0) for point in points]
                    triples.append({"direction": direction, "points": points,
                                    "coefficients": cs, "slack": cs[1]**2-cs[0]*cs[2]})
    return {"label": [a,b], "source_laurent_matches_formal_transcription": True,
            "homogeneous_degree": degree, "coefficient_sum": sum(p.values()),
            "terms_uvw": [{"exponents": e, "coefficient": c} for e,c in sorted(numerator_uvw.items())],
            "dense_grid": grid, "valid_triples": triples,
            "all_diagnostic_inequalities_hold": all(t["slack"] >= 0 for t in triples)}


root = Path("MathGKM/Markov.lean")
root_hash = hashlib.sha256(root.read_bytes()).hexdigest()
assert root_hash == "8b8408e5cae9822fe0969afd4a70b408d48e69f750dffb88c253dba8ef167dbe"
results = {"provenance": "machine-authored H0-source-correspondence, round-0000",
           "python": platform.python_version(), "root_path": str(root),
           "root_sha256": root_hash,
           "scope": "Five diagnostic labels only; manual transcription, not a universal proof or Lean replay.",
           "diagnostics": [diagnostic(0,1,one,m01), diagnostic(1,1,t,m11),
                           diagnostic(1,2,p12,m12), diagnostic(1,3,left,m13),
                           diagnostic(2,3,right,m23)]}
print(json.dumps(results, indent=2, sort_keys=True))
