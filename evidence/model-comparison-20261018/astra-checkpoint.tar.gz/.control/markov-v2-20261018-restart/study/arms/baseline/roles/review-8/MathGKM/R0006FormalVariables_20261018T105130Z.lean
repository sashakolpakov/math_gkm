import MathGKM.R0005Bridge_20261018T104106Z

/- Machine-authored round-0006, H6-formal-variable-interpretation.
   Formal rational functions; no rational-label identification asserted. -/
namespace MathGKM.Markov.FormalR0006
open HomogeneousR0002 BridgeR0005
noncomputable section
abbrev P := MvPolynomial (Fin 3) ℚ
abbrev K := FractionRing P
def formalVar (i : Fin 3) : K := algebraMap P K (MvPolynomial.X i)
def x : K := formalVar 0
def y : K := formalVar 1
def z : K := formalVar 2

theorem formalVar_ne_zero (i : Fin 3) : formalVar i ≠ 0 := by
  intro h
  exact MvPolynomial.X_ne_zero i ((IsFractionRing.injective P K) (by simpa [formalVar] using h))

theorem xyz_nonzero : x ≠ 0 ∧ y ≠ 0 ∧ z ≠ 0 :=
  ⟨formalVar_ne_zero 0, formalVar_ne_zero 1, formalVar_ne_zero 2⟩

def v : HLabel → K := value x y z
def c : K := (x^2+y^2+z^2)/(x*y*z)

theorem seed_values : v initialH.lo = x ∧
    v initialH.hi = (x^2+y^2)/z ∧
    v initialH.mid = ((x^2+y^2)^2+x^2*z^2)/(y*z^2) :=
  seeds x y z xyz_nonzero.1 xyz_nonzero.2.1 xyz_nonzero.2.2

theorem denominator (a b : ℕ) (q : K) :
    norm x y z (a+1) (b+1) q = q/(x^a*y^b*z^(a+b+1)) :=
  positive_denominator x y z xyz_nonzero.1 xyz_nonzero.2.1 xyz_nonzero.2.2 a b q

theorem mutation (path : List Bool) (d : Bool) :
    v (advanceH (frameH path) d).mid =
    if d then c * v (frameH path).hi * v (frameH path).mid - v (frameH path).lo
    else c * v (frameH path).lo * v (frameH path).mid - v (frameH path).hi :=
  branch_value x y z xyz_nonzero.1 xyz_nonzero.2.1 xyz_nonzero.2.2 path d

@[ext] structure RFrame where
  lo : K
  mid : K
  hi : K

def initialR : RFrame :=
  ⟨x, ((x^2+y^2)^2+x^2*z^2)/(y*z^2), (x^2+y^2)/z⟩
def advanceR (f : RFrame) (d : Bool) : RFrame :=
  if d then ⟨f.mid, c*f.hi*f.mid-f.lo, f.hi⟩
  else ⟨f.lo, c*f.lo*f.mid-f.hi, f.mid⟩
def frameR (path : List Bool) : RFrame := path.foldl advanceR initialR
def interpret (f : HFrame) : RFrame := ⟨v f.lo, v f.mid, v f.hi⟩

theorem interpret_initial : interpret initialH = initialR := by
  apply RFrame.ext
  · exact seed_values.1
  · exact seed_values.2.2
  · exact seed_values.2.1

theorem interpret_advance (path : List Bool) (d : Bool) :
    interpret (advanceH (frameH path) d) = advanceR (interpret (frameH path)) d := by
  have h := mutation path d
  cases d <;> apply RFrame.ext
  all_goals first | exact h | rfl

theorem all_paths (path : List Bool) : interpret (frameH path) = frameR path := by
  induction path using List.reverseRecOn with
  | nil => exact interpret_initial
  | append_singleton path d ih =>
    simpa only [frameH, frameR, List.foldl_append, List.foldl_cons, List.foldl_nil] using
      (interpret_advance path d).trans (congrArg (fun f => advanceR f d) ih)

#print axioms xyz_nonzero
#print axioms seed_values
#print axioms denominator
#print axioms mutation
#print axioms all_paths
end
end MathGKM.Markov.FormalR0006
