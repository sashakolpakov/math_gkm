import MathGKM.R0006FormalVariables_20261018T105130Z

/- Machine-authored H7 candidate. Existing-dependency checking only;
   fresh replay is blocked by the temporary-storage capability restriction. -/
namespace MathGKM.Markov.FaithfulnessR0007
open HomogeneousR0002 BridgeR0005 FormalR0006
noncomputable section

def embed : TriPoly →+* MvPolynomial (Fin 3) ℤ :=
  Polynomial.eval₂RingHom
    (Polynomial.eval₂RingHom
      (Polynomial.eval₂RingHom MvPolynomial.C (MvPolynomial.X 1))
      (MvPolynomial.X 0)) (MvPolynomial.X 2)

def back : MvPolynomial (Fin 3) ℤ →+* TriPoly :=
  MvPolynomial.eval₂Hom (Int.castRingHom TriPoly) ![u, v, w]

theorem back_embed : back.comp embed = RingHom.id TriPoly := by
  ext <;> simp [back, embed, u, HomogeneousR0002.v, w, U, V]

theorem embed_injective : Function.Injective embed := by
  intro p q h
  have hh := congrArg back h
  simpa only [← RingHom.comp_apply, back_embed, RingHom.id_apply] using hh

theorem square_injective :
    Function.Injective (MvPolynomial.expand 2 (R := ℚ) (σ := Fin 3)) :=
  MvPolynomial.expand_injective (by decide)

def rationalEmbed : TriPoly →+* P :=
  (MvPolynomial.map (Int.castRingHom ℚ)).comp embed

theorem rationalEmbed_injective : Function.Injective rationalEmbed := by
  intro p q h
  apply embed_injective
  ext d
  have hd := congrArg (MvPolynomial.coeff d) h
  simpa [rationalEmbed, MvPolynomial.coeff_map] using hd

theorem factorization : evalSq x y z =
    (algebraMap P K).comp ((MvPolynomial.expand 2).toRingHom.comp rationalEmbed) := by
  ext <;> simp [evalSq, rationalEmbed, embed, x, y, z, formalVar]

theorem evalSq_injective : Function.Injective (evalSq x y z) := by
  rw [factorization]
  exact (IsFractionRing.injective P K).comp
    (square_injective.comp rationalEmbed_injective)

theorem normalization_injective (a b : ℕ) :
    Function.Injective (norm x y z a b) := by
  intro p q h
  have hd : x^a*y^b*z^(a+b) ≠ 0 :=
    mul_ne_zero (mul_ne_zero (pow_ne_zero _ xyz_nonzero.1)
      (pow_ne_zero _ xyz_nonzero.2.1)) (pow_ne_zero _ xyz_nonzero.2.2)
  have hn : x*y*z ≠ 0 :=
    mul_ne_zero (mul_ne_zero xyz_nonzero.1 xyz_nonzero.2.1) xyz_nonzero.2.2
  exact (mul_left_cancel₀ hn) ((div_left_inj' hd).mp h)

theorem numerator_recovery (a b : ℕ) (p q : TriPoly)
    (h : norm x y z a b (evalSq x y z p) = norm x y z a b (evalSq x y z q)) :
    p = q := evalSq_injective (normalization_injective a b h)

theorem coefficient_recovery (a b : ℕ) (p q : TriPoly)
    (h : norm x y z a b (evalSq x y z p) = norm x y z a b (evalSq x y z q)) :
    ∀ i j k, coeff (p.coeff k) i j = coeff (q.coeff k) i j := by
  intro i j k
  rw [numerator_recovery a b p q h]

#print axioms embed_injective
#print axioms square_injective
#print axioms normalization_injective
#print axioms evalSq_injective
#print axioms numerator_recovery
#print axioms coefficient_recovery
end
end MathGKM.Markov.FaithfulnessR0007

-- Exact closed submission interfaces, checked in this source invocation.
example : Function.Injective (MathGKM.Markov.BridgeR0005.evalSq
    MathGKM.Markov.FormalR0006.x MathGKM.Markov.FormalR0006.y
    MathGKM.Markov.FormalR0006.z) :=
  MathGKM.Markov.FaithfulnessR0007.evalSq_injective

example : ∀ (a b : ℕ) (p q : MathGKM.Markov.HomogeneousR0002.TriPoly),
    MathGKM.Markov.BridgeR0005.norm MathGKM.Markov.FormalR0006.x
      MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z a b
      (MathGKM.Markov.BridgeR0005.evalSq MathGKM.Markov.FormalR0006.x
        MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z p) =
    MathGKM.Markov.BridgeR0005.norm MathGKM.Markov.FormalR0006.x
      MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z a b
      (MathGKM.Markov.BridgeR0005.evalSq MathGKM.Markov.FormalR0006.x
        MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z q) → p = q :=
  MathGKM.Markov.FaithfulnessR0007.numerator_recovery

example : ∀ (a b : ℕ) (p q : MathGKM.Markov.HomogeneousR0002.TriPoly),
    MathGKM.Markov.BridgeR0005.norm MathGKM.Markov.FormalR0006.x
      MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z a b
      (MathGKM.Markov.BridgeR0005.evalSq MathGKM.Markov.FormalR0006.x
        MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z p) =
    MathGKM.Markov.BridgeR0005.norm MathGKM.Markov.FormalR0006.x
      MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z a b
      (MathGKM.Markov.BridgeR0005.evalSq MathGKM.Markov.FormalR0006.x
        MathGKM.Markov.FormalR0006.y MathGKM.Markov.FormalR0006.z q) →
    ∀ i j k, MathGKM.Markov.coeff (p.coeff k) i j =
      MathGKM.Markov.coeff (q.coeff k) i j :=
  MathGKM.Markov.FaithfulnessR0007.coefficient_recovery
