# H1-rational-coverage checkpoint

Machine-authored by the researcher for request round-0001 on 2026-10-18.
Trial: {"hypothesis":"H1-rational-coverage","invention":false}.
Prospective binding: 7cad813881e3468299ca24addd0a000bec4e481605a88bad9798bd2173ce8677
Active contract: published-markov-6-3-clean-v2, phase markov.

## Observed result

The exact requested universal coverage statement compiled with exit 0 in
MathGKM/R0001Coverage_20261018T100704Z.lean:

```lean
∀ a b : ℕ, 0 < a → a < b → Nat.Coprime a b →
  ∃ path : List Bool,
    (MathGKM.Markov.frame path).mid.a = a ∧
    (MathGKM.Markov.frame path).mid.b = b
```

Declaration: MathGKM.Markov.CoverageR0001.rational_coverage.
Lean 4.32.2 reported its axiom closure as propext, Classical.choice, Quot.sound.
The successful output is attempt03.log. This is a locally compiled proof
candidate for independent admission, not a report certifying the root.
No new assumptions, admitted terms, or native evaluation were used.

## Mathematical argument and actual reuse

The existing round-zero audit supplied the mediant invariant and proposed
interval descent. The candidate uses the pinned Frame, initial, advance and
frame definitions directly. It strengthens the desired statement to arbitrary
frames whose middle label is the sum of their endpoint labels. For positive
coprime natural numbers x,y, it reaches the target vector x L + y H.

Strong induction is on x+y. If x=y, coprimality forces x=y=1 and the empty
path works. If y<x, advance left; the new endpoints are L,L+H and target
coordinates become x-y,y. If x<y, advance right; the new endpoints are L+H,H
and coordinates become x,y-x. Both branches preserve positivity and
coprimality and strictly decrease the induction parameter. Ring identities
reconstruct the original target. List.foldl_cons connects each step to the
actual frame computation. The initial coordinates b-a,a represent a/b,
and their sum is b. This is a terminating mediant descent proof.

The trial simplified its originally contemplated route: explicit endpoint
determinant and rational bracketing lemmas are unnecessary for this coordinate
formulation. The stronger positive-coordinate statement supplies the needed
bracketing implicitly. No claim about polynomial values is used or proved.

## Retained attempts and execution restriction

All root and dependency source files were kept unchanged. Root source was
freshly compiled directly into this checkpoint's build/MathGKM directory;
root_compile.log records exit 0. lean_path.txt records the pinned dependency
build directories used. replay.py reproduces the direct Lean invocations
without Lake or network access, retaining uniquely named replay logs.

The initial command `lake env printenv LEAN_PATH` unexpectedly attempted to
refresh a dependency and failed on the protected read-only package. The
actual tool error is retained in capability_failure.txt. No retry through
Lake was made; direct Lean subsequently succeeded. This was a capability
failure of that invocation, not a mathematical conclusion. The denied .scratch
directory was not accessed; persistent research artifacts were used instead
of temporary files.

attempt01.lean and attempt01.log retain an invocation that ran before the
fresh root object was available and failed at import. attempt02.lean and
attempt02.log retain the substantive proof's failed base-case simplification:
`simpa using hf` did not unfold Mediant. Its error-recovery axiom output is
not accepted evidence. attempt03.lean explicitly unfolds Mediant, and its
successful compilation has only the permitted axiom dependencies.

## Scope and next choice

The first prospective outcome check is met locally, subject to independent
checking. Submit the exact theorem through the typed mathematical_claims
interface. This addresses coverage for 0<a<b; the separate 0/1 and 1/1
endpoints are already explicit in the pinned root. It does not establish
uniqueness of indexing, agreement of polynomial labels with the source,
homogeneous coefficient reconstruction, the actual Newton polygon, direction
and zero/endpoints correspondence, or Conjecture 6.3. Those remain separate
obligations, including the independent source audit required by the contract.

Next prioritize universal source-family agreement and homogeneous coefficient
reconstruction. Keep the incumbent single revisable agenda. No policy/program
change, root reduction, historical campaign, or completion is submitted.
The trial began at 10:07:04 UTC and its successful proof compilation was
observed before 10:10:00 UTC, within the 300-second invocation cap.
