"""Machine-authored direct Lean replay for H1-rational-coverage, round-0001.
Run from the workspace root with /opt/homebrew/bin/python3.
Uses only installed pinned packages; no Lake invocation or package updates.
"""
from datetime import datetime, timezone
from pathlib import Path
import os
import subprocess

checkpoint = Path("research/r0001_coverage_20261018T100704Z")
build = checkpoint / "build"
(build / "MathGKM").mkdir(parents=True, exist_ok=True)
environment = os.environ.copy()
environment["LEAN_PATH"] = ":".join(
    [str(build)]
    + [str(p) for p in Path(".lake/packages").glob("*/.lake/build/lib/lean")]
)
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
for module in ["Markov", "R0001Coverage_20261018T100704Z"]:
    command = [
        "/Users/sasha/.elan/bin/lean", "-o",
        str(build / "MathGKM" / (module + ".olean")),
        "MathGKM/" + module + ".lean",
    ]
    result = subprocess.run(
        command, env=environment, capture_output=True, text=True, timeout=60
    )
    log = result.stdout + result.stderr + "\nexit=" + str(result.returncode)
    (checkpoint / ("replay_" + stamp + "_" + module + ".log")).write_text(log)
    print(log)
    if result.returncode:
        raise SystemExit(result.returncode)
