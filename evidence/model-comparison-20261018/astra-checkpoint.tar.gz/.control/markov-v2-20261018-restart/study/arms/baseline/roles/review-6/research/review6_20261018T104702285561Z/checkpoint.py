"""Persist independent review findings, with hashes computed from inspected artifacts."""
from pathlib import Path
import hashlib, json, collections
out = Path(__file__).parent
records = json.loads(Path('inbox/records.json').read_text())
replay = json.loads((out/'receipt.json').read_text())
findings = []
def add(path, finding):
    path = str(path)
    findings.append({'path': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(), 'finding': finding})
add('MathGKM/Markov.lean', 'Matches the pinned root hash and freshly compiles. Conjecture63 is a proposition definition, not a proved theorem. It uses raw coefficients, retains zeros, and includes three directions and both endpoints. No proof or exact refutation is supplied.')
add('MathGKM/R0001Coverage_20261018T100704Z.lean', 'Fresh compilation confirms rational_coverage for every coprime natural pair 0<a<b. It establishes coordinate surjectivity, not polynomial-family identification or log-concavity.')
add('MathGKM/R0002Homogeneous_20261018T101629Z.lean', 'Fresh compilation confirms universal evaluation at w=1 and coefficient transport conditional on homogeneous support. R0004 actually consumes this interface; the condition must not be omitted when citing R0002 alone.')
add('MathGKM/R0004SupportRepair_20261018T103442Z.lean', 'Fresh compilation and the supplied exact submission interface succeed. reachable_homogeneous proves support at degree a+b-1 for all three reachable labels. universal_transport discharges the earlier homogeneity premise for middle-label coefficients, retaining i+j<=a+b-1. Printed axiom closures contain only propext, Classical.choice and Quot.sound. This establishes internal coefficient transport, not Newton-polygon equality or published-family correspondence.')
add('MathGKM/R0005Bridge_20261018T104106Z.lean', 'Fresh compilation and the supplied exact submission interface succeed. Seeds, denominator rewriting and both mutation branches are proved over any field with explicit nonzero x,y,z premises; mediant identities are proved for reachable paths. All six printed axiom closures are permitted. This module imports R0002, but does not apply coverage or R0004 coefficient transport. Formal-function interpretation and rational-label source-family identification remain unconnected.')
add('research/r0005_source_family_20261018T104106Z/R0005Bridge_20261018T104106Z_104455100021.log', 'This retained earlier attempt exits 1 with type mismatches and error-recovery sorryAx for branch_value. It establishes no theorem. The final source separately passes fresh compilation without that dependency; failed attempts remain preserved.')
add('research/r0005_source_family_20261018T104106Z/source_notes.md', 'Researcher-authored source comparison is not a primary-source snapshot or independent correspondence proof. The supplied bundle has no retained publisher text/retrieval receipt sufficient to verify these assertions independently. Source-family, polygon and complete direction/zero/endpoint correspondence remain open; this review performs no new source research.')
add('inbox/records.json', 'Episode transfer is invalid_frozen_context and ineligible. Catalog compilation returns -6 after 0.0068195 seconds with empty output; the catalog wrapper lasts 0.015705041 seconds against a 120-second cap. This is a process failure, not demonstrated budget exhaustion or mathematical rejection. Transfer/regression arrays are empty and policy_comparison=false. Rounds 0002, 0003 and 0005 have budget-failure outcomes and null payloads despite wrapper returncode 0. Empty remaining_obligations does not discharge the contract.')
add(out/'receipt.json', 'Independent replay binds commands, source hashes, diagnostics, axiom output and timings. All 101 final snapshot hashes match. Seven project modules freshly compile using pinned Lean 4.32.2 and read-only dependency oleans. Dependency oleans were trusted, not rebuilt; no research source was edited. These checks do not repair the separate failed frozen-context comparison.')
totals = collections.defaultdict(float)
for r in records['receipts']:
    totals[r['role']] += r['elapsed_seconds']
payload = {
 'findings': findings,
 'correctness': 'Accept the replayed coverage, evaluation, repaired homogeneous-support/coefficient-transport and conditional field-mutation lemmas within their exact statements. No proof or refutation of Conjecture63 is established. Failed elaboration and finite-budget failure imply neither falsity nor unprovability.',
 'scope': 'Active Markov phase only. Internal homogeneity and coefficient transport are now checked; source-family identification, Newton-polygon equality, complete independent English/source correspondence and the root remain open. No new research, historical campaign, retrospective holdout or certified controller work was performed.',
 'transfer': 'Formal reuse is visible: R0004 applies R0002 coefficient transport, and R0005 consumes its homogeneous definitions. Independent-task transfer, regression and policy improvement are unmeasured because the supplied comparison is invalid. No certified persistent switch is established.',
 'costs': {'recorded_role_seconds': dict(totals), 'recorded_total_role_seconds': sum(totals.values()), 'this_review_compilation_seconds': sum(c['elapsed_seconds'] for c in replay['checks']), 'failed_catalog_seconds': records['episode_transfer']['catalog_failure']['elapsed_seconds'], 'money': None, 'normalized_tokens': None, 'limitations': 'Role totals are invocation durations, not complete study wall time. Local compilation is additional review work, not a transfer benchmark. Raw provider usage is unverified and absent for timed-out rounds. No complexity or derived proxy informed decisions.'},
 'recommendation': 'Retain the independently replayed partial lemmas and failed attempts. Keep the root and residual correspondence obligations open. Record transfer as invalid, with no improvement or regression conclusion; do not promote partial proofs or wrapper success to campaign completion.'}
(out/'findings.json').write_text(json.dumps(payload, indent=2)+'\n')
print(json.dumps(payload))
