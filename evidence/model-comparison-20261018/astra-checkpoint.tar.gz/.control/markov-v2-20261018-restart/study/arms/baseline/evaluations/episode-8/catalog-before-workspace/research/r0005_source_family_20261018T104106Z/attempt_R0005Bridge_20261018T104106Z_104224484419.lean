import MathGKM.R0002Homogeneous_20261018T101629Z

/- Machine-authored round-0005, H5-source-family-bridge.
   Publisher equations (3), (5), (7), (8). No source assertion is an axiom.
   norm avoids natural-number truncation at the 0/1 endpoint. -/
namespace MathGKM.Markov.BridgeR0005
open HomogeneousR0002
noncomputable section

def norm {K : Type*} [Field K] (x y z : K) (a b : ℕ) (P : K) : K :=
  x*y*z*P / (x^a*y^b*z^(a+b))

theorem scalar_bridge {K : Type*} [Field K] (x y z : K)
    (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (a b c d : ℕ) (O E M : K) :
    norm x y z (a+2*c) (b+2*d)
      ((x^2+y^2+z^2)*E*M-(x^2)^c*(y^2)^d*(z^2)^(c+d)*O) =
    (x^2+y^2+z^2)/(x*y*z)*norm x y z c d E*
      norm x y z (a+c) (b+d) M - norm x y z a b O := by
  simp only [norm, pow_add, pow_mul]
  field_simp
  <;> ring

theorem endpoint {K : Type*} [Field K] (x y z : K)
    (hy : y ≠ 0) (hz : z ≠ 0) : norm x y z 0 1 1 = x := by
  simp [norm, hy, hz]

def Med (f : HFrame) : Prop :=
  f.mid.a = f.lo.a+f.hi.a ∧ f.mid.b = f.lo.b+f.hi.b

theorem med_initial : Med initialH := by constructor <;> rfl

theorem med_advance (f : HFrame) (d : Bool) : Med (advanceH f d) := by
  cases d <;> simp [Med, advanceH, Nat.add_comm]

theorem med_fold (path : List Bool) (f : HFrame) (h : Med f) :
    Med (path.foldl advanceH f) := by
  induction path generalizing f with
  | nil => exact h
  | cons d path ih => exact ih _ (med_advance f d)

theorem reachable_med (path : List Bool) : Med (frameH path) :=
  med_fold path initialH med_initial

theorem branch_indices (path : List Bool) :
    (advanceH (frameH path) false).mid.a = (frameH path).hi.a+2*(frameH path).lo.a ∧
    (advanceH (frameH path) false).mid.b = (frameH path).hi.b+2*(frameH path).lo.b ∧
    (advanceH (frameH path) true).mid.a = (frameH path).lo.a+2*(frameH path).hi.a ∧
    (advanceH (frameH path) true).mid.b = (frameH path).lo.b+2*(frameH path).hi.b := by
  have h := reachable_med path
  simp only [Med] at h
  simp only [advanceH, Bool.false_eq_true, ↓reduceIte]
  omega

#print axioms scalar_bridge
#print axioms endpoint
#print axioms branch_indices
end
end MathGKM.Markov.BridgeR0005
