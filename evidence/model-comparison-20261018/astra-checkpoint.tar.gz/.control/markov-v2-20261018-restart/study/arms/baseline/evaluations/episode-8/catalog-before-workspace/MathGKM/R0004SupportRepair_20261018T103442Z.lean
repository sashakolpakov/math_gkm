import MathGKM.R0002Homogeneous_20261018T101629Z

/- Machine-authored round-0004, H4-support-interface-repair; repaired from retained round-three source. -/
namespace MathGKM.Markov.HomogeneousR0002
noncomputable section

theorem homogeneous_one : Homogeneous 1 0 := by
  intro i j k h
  by_cases hi : i = 0 <;> by_cases hj : j = 0 <;> by_cases hk : k = 0 <;>
    simp_all [u, v, w, U, V, coeff, Polynomial.coeff_C, Polynomial.coeff_X, Polynomial.coeff_one, eq_comm]

theorem homogeneous_u : Homogeneous u 1 := by
  intro i j k h
  by_cases hi : i = 1 <;> by_cases hj : j = 0 <;> by_cases hk : k = 0 <;>
    simp_all [u, v, w, U, V, coeff, Polynomial.coeff_C, Polynomial.coeff_X, Polynomial.coeff_one, eq_comm]

theorem homogeneous_v : Homogeneous v 1 := by
  intro i j k h
  by_cases hi : i = 0 <;> by_cases hj : j = 1 <;> by_cases hk : k = 0 <;>
    simp_all [u, v, w, U, V, coeff, Polynomial.coeff_C, Polynomial.coeff_X, Polynomial.coeff_one, eq_comm]

theorem homogeneous_w : Homogeneous w 1 := by
  intro i j k h
  by_cases hi : i = 0 <;> by_cases hj : j = 0 <;> by_cases hk : k = 1 <;>
    simp_all [u, v, w, U, V, coeff, Polynomial.coeff_C, Polynomial.coeff_X, Polynomial.coeff_one, eq_comm]

theorem homogeneous_add {P Q : TriPoly} {d : ℕ}
    (hp : Homogeneous P d) (hq : Homogeneous Q d) : Homogeneous (P+Q) d := by
  intro i j k h
  by_cases hP : coeff (P.coeff k) i j = 0
  · apply hq i j k
    simp only [coeff] at hP ⊢
    simpa only [coeff, Polynomial.coeff_add, Polynomial.coeff_sub, hP, zero_add, zero_sub, neg_ne_zero] using h
  · exact hp i j k hP

theorem homogeneous_sub {P Q : TriPoly} {d : ℕ}
    (hp : Homogeneous P d) (hq : Homogeneous Q d) : Homogeneous (P-Q) d := by
  intro i j k h
  by_cases hP : coeff (P.coeff k) i j = 0
  · apply hq i j k
    simp only [coeff] at hP ⊢
    simpa only [coeff, Polynomial.coeff_add, Polynomial.coeff_sub, hP, zero_add, zero_sub, neg_ne_zero] using h
  · exact hp i j k hP

theorem homogeneous_mul {P Q : TriPoly} {d e : ℕ}
    (hp : Homogeneous P d) (hq : Homogeneous Q e) : Homogeneous (P*Q) (d+e) := by
  intro i j k h
  by_contra hd
  apply h
  simp only [coeff, Polynomial.coeff_mul, Polynomial.finsetSum_coeff]
  apply Finset.sum_eq_zero
  intro z hz
  apply Finset.sum_eq_zero
  intro x hx
  apply Finset.sum_eq_zero
  intro y hy
  by_cases hP : coeff (P.coeff z.1) x.1 y.1 = 0
  · simp only [coeff] at hP
    rw [hP, zero_mul]
  · have hdP := hp x.1 y.1 z.1 hP
    have hQ : coeff (Q.coeff z.2) x.2 y.2 = 0 := by
      by_contra hn
      have hdQ := hq x.2 y.2 z.2 hn
      have hz' := Finset.HasAntidiagonal.mem_antidiagonal.mp hz
      have hx' := Finset.HasAntidiagonal.mem_antidiagonal.mp hx
      have hy' := Finset.HasAntidiagonal.mem_antidiagonal.mp hy
      omega
    simp only [coeff] at hQ
    rw [hQ, mul_zero]

theorem homogeneous_pow {P : TriPoly} {d : ℕ} (hp : Homogeneous P d) (n : ℕ) :
    Homogeneous (P^n) (d*n) := by
  induction n with
  | zero => simpa using homogeneous_one
  | succ n ih => simpa [pow_succ, Nat.mul_succ] using homogeneous_mul ih hp

#print axioms homogeneous_mul

def GoodLabel (l : HLabel) : Prop :=
  0 < l.a+l.b ∧ Homogeneous l.p (l.a+l.b-1)

def GoodFrame (f : HFrame) : Prop :=
  GoodLabel f.lo ∧ GoodLabel f.mid ∧ GoodLabel f.hi ∧
  f.mid.a+f.mid.b = (f.lo.a+f.lo.b)+(f.hi.a+f.hi.b)

theorem recurrence_homogeneous (E M O : HLabel)
    (he : GoodLabel E) (hm : GoodLabel M) (ho : GoodLabel O)
    (hmed : M.a+M.b = (E.a+E.b)+(O.a+O.b)) :
    Homogeneous ((u+v+w)*E.p*M.p-u^E.a*v^E.b*w^(E.a+E.b)*O.p)
      (E.a+M.a+(E.b+M.b)-1) := by
  apply homogeneous_sub
  · have h := homogeneous_mul (homogeneous_mul
      (homogeneous_add (homogeneous_add homogeneous_u homogeneous_v) homogeneous_w) he.2) hm.2
    convert h using 1 <;> have h1 := he.1 <;> have h2 := ho.1 <;> omega
  · have h := homogeneous_mul (homogeneous_mul (homogeneous_mul
      (homogeneous_pow homogeneous_u E.a) (homogeneous_pow homogeneous_v E.b))
      (homogeneous_pow homogeneous_w (E.a+E.b))) ho.2
    simp only [Nat.one_mul] at h
    convert h using 1 <;> have h1 := he.1 <;> have h2 := ho.1 <;> omega

theorem good_initial : GoodFrame initialH := by
  refine ⟨⟨by decide, homogeneous_one⟩, ⟨by decide, ?_⟩,
    ⟨by decide, homogeneous_add homogeneous_u homogeneous_v⟩, rfl⟩
  exact homogeneous_add (homogeneous_pow (homogeneous_add homogeneous_u homogeneous_v) 2)
    (homogeneous_mul homogeneous_u homogeneous_w)

theorem good_advance (f : HFrame) (h : GoodFrame f) (d : Bool) :
    GoodFrame (advanceH f d) := by
  rcases h with ⟨hl, hm, hh, hmed⟩
  have hlp := hl.1
  have hmp := hm.1
  have hhp := hh.1
  cases d
  · simp only [advanceH, Bool.false_eq_true, ↓reduceIte, GoodFrame]
    refine ⟨hl, ?_, hm, ?_⟩
    · constructor
      · change 0 < (f.lo.a + f.mid.a) + (f.lo.b + f.mid.b)
        omega
      · exact recurrence_homogeneous _ _ _ hl hm hh hmed
    · change (f.lo.a + f.mid.a) + (f.lo.b + f.mid.b) = _
      omega
  · simp only [advanceH, ↓reduceIte, GoodFrame]
    refine ⟨hm, ?_, hh, ?_⟩
    · constructor
      · change 0 < (f.mid.a + f.hi.a) + (f.mid.b + f.hi.b)
        omega
      · have hp := recurrence_homogeneous _ _ _ hh hm hl (by omega)
        dsimp only
        convert hp using 1 <;> congr 1 <;> omega
    · change (f.mid.a + f.hi.a) + (f.mid.b + f.hi.b) = _
      omega

theorem good_fold (path : List Bool) (f : HFrame) (h : GoodFrame f) :
    GoodFrame (path.foldl advanceH f) := by
  induction path generalizing f with
  | nil => exact h
  | cons d path ih => exact ih _ (good_advance f h d)

theorem reachable_homogeneous (path : List Bool) :
    Homogeneous (frameH path).lo.p ((frameH path).lo.a+(frameH path).lo.b-1) ∧
    Homogeneous (frameH path).mid.p ((frameH path).mid.a+(frameH path).mid.b-1) ∧
    Homogeneous (frameH path).hi.p ((frameH path).hi.a+(frameH path).hi.b-1) := by
  have h := good_fold path initialH good_initial
  exact ⟨h.1.2, h.2.1.2, h.2.2.1.2⟩

theorem universal_transport (path : List Bool) :
    ∀ i j, i+j ≤ (frameH path).mid.a+(frameH path).mid.b-1 →
    coeff ((frameH path).mid.p.coeff ((frameH path).mid.a+(frameH path).mid.b-1-i-j)) i j =
      coeff (frame path).mid.p i j :=
  reachable_transport path (reachable_homogeneous path).2.1

#print axioms reachable_homogeneous
#print axioms universal_transport
end
end MathGKM.Markov.HomogeneousR0002
