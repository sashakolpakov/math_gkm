"""Machine-authored direct pinned Lean replay, round-0002. No Lake or networking."""
from pathlib import Path
import os, subprocess, datetime
root = Path('research/r0002_homogeneous_20261018T101629Z')
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join([str(root/'build')] + [str(p) for p in Path('.lake/packages').glob('*/.lake/build/lib/lean')])
(root/'lean_path.txt').write_text(env['LEAN_PATH'])
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S%f')
for module in ['Markov', 'R0002Homogeneous_20261018T101629Z']:
    source = Path('MathGKM')/(module+'.lean')
    if module != 'Markov':
        (root/('attempt_'+stamp+'.lean')).write_text(source.read_text())
    result = subprocess.run(['/Users/sasha/.elan/bin/lean', '-o', str(root/'build/MathGKM'/(module+'.olean')), str(source)], env=env, capture_output=True, text=True, timeout=45)
    log = result.stdout+result.stderr+'\nexit='+str(result.returncode)
    (root/(module+'_'+stamp+'.log')).write_text(log)
    print(log)
    if result.returncode: raise SystemExit(result.returncode)
