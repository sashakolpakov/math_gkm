import MathGKM.Markov

/- Machine-authored for round-0001, H1-rational-coverage, 2026-10-18.
   Positive endpoint coordinates give a subtraction descent. -/
namespace MathGKM.Markov.CoverageR0001

def Mediant (f : Frame) : Prop :=
  f.mid.a = f.lo.a + f.hi.a ∧ f.mid.b = f.lo.b + f.hi.b

theorem initial_mediant : Mediant initial := by
  constructor <;> rfl

theorem advance_mediant (f : Frame) (h : Mediant f) (d : Bool) :
    Mediant (advance f d) := by
  cases d <;> simp [Mediant, advance]

theorem descend (n : ℕ) : ∀ (x y : ℕ), x + y = n →
    0 < x → 0 < y → Nat.Coprime x y → ∀ f : Frame, Mediant f →
    ∃ path : List Bool,
      (path.foldl advance f).mid.a = x * f.lo.a + y * f.hi.a ∧
      (path.foldl advance f).mid.b = x * f.lo.b + y * f.hi.b := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    intro x y hn hx hy hc f hf
    by_cases he : x = y
    · subst y
      have h1 : x = 1 := by simpa [Nat.Coprime] using hc
      subst x
      exact ⟨[], by simpa using hf⟩
    · by_cases hxy : y < x
      · have hc' : Nat.Coprime (x-y) y :=
          (Nat.coprime_sub_self_left (Nat.le_of_lt hxy)).mpr hc
        obtain ⟨p, ha, hb⟩ := ih ((x-y)+y) (by omega) (x-y) y rfl
          (by omega) hy hc' (advance f false) (advance_mediant f hf false)
        refine ⟨false :: p, ?_, ?_⟩
        · simp only [List.foldl_cons]
          rw [ha]
          simp only [advance, Bool.false_eq_true, ↓reduceIte]
          rw [hf.1]
          have heq : x-y+y=x := Nat.sub_add_cancel (by omega)
          calc
            _ = (x-y+y)*f.lo.a+y*f.hi.a := by ring
            _ = _ := by rw [heq]
        · simp only [List.foldl_cons]
          rw [hb]
          simp only [advance, Bool.false_eq_true, ↓reduceIte]
          rw [hf.2]
          have heq : x-y+y=x := Nat.sub_add_cancel (by omega)
          calc
            _ = (x-y+y)*f.lo.b+y*f.hi.b := by ring
            _ = _ := by rw [heq]
      · have hyx : x < y := by omega
        have hc' : Nat.Coprime x (y-x) :=
          (Nat.coprime_sub_self_right (Nat.le_of_lt hyx)).mpr hc
        obtain ⟨p, ha, hb⟩ := ih (x+(y-x)) (by omega) x (y-x) rfl
          hx (by omega) hc' (advance f true) (advance_mediant f hf true)
        refine ⟨true :: p, ?_, ?_⟩
        · simp only [List.foldl_cons]
          rw [ha]
          simp only [advance, ↓reduceIte]
          rw [hf.1]
          have heq : y-x+x=y := Nat.sub_add_cancel (by omega)
          calc
            _ = x*f.lo.a+(y-x+x)*f.hi.a := by ring
            _ = _ := by rw [heq]
        · simp only [List.foldl_cons]
          rw [hb]
          simp only [advance, ↓reduceIte]
          rw [hf.2]
          have heq : y-x+x=y := Nat.sub_add_cancel (by omega)
          calc
            _ = x*f.lo.b+(y-x+x)*f.hi.b := by ring
            _ = _ := by rw [heq]

theorem rational_coverage : ∀ a b : ℕ, 0 < a → a < b → Nat.Coprime a b →
    ∃ path : List Bool, (frame path).mid.a = a ∧ (frame path).mid.b = b := by
  intro a b ha hab hc
  have hc' : Nat.Coprime (b-a) a :=
    (Nat.coprime_sub_self_left (Nat.le_of_lt hab)).mpr hc.symm
  obtain ⟨p, hp⟩ := descend ((b-a)+a) (b-a) a rfl (by omega) ha hc'
    initial initial_mediant
  refine ⟨p, ?_⟩
  simpa [frame, initial, Nat.sub_add_cancel (Nat.le_of_lt hab)] using hp

#print axioms rational_coverage
end MathGKM.Markov.CoverageR0001
