import MathGKM.Markov

/- Machine-authored, round-0002, H2-homogeneous-coefficient-transport.
   The outer variable of TriPoly is w; its coefficients are pinned BiPoly.
   Evaluation is universal; coefficient transport assumes homogeneous support. -/
namespace MathGKM.Markov.HomogeneousR0002
noncomputable section
abbrev TriPoly := Polynomial BiPoly
def u : TriPoly := Polynomial.C U
def v : TriPoly := Polynomial.C V
def w : TriPoly := Polynomial.X

structure HLabel where
  a : ℕ
  b : ℕ
  p : TriPoly
structure HFrame where
  lo : HLabel
  mid : HLabel
  hi : HLabel

def eraseLabel (x : HLabel) : Label := ⟨x.a, x.b, x.p.eval 1⟩
def erase (f : HFrame) : Frame := ⟨eraseLabel f.lo, eraseLabel f.mid, eraseLabel f.hi⟩
def initialH : HFrame :=
  ⟨⟨0, 1, 1⟩, ⟨1, 2, (u+v)^2+u*w⟩, ⟨1, 1, u+v⟩⟩
def advanceH (f : HFrame) (right : Bool) : HFrame :=
  if right then
    ⟨f.mid, ⟨f.mid.a+f.hi.a, f.mid.b+f.hi.b,
      (u+v+w)*f.hi.p*f.mid.p-u^f.hi.a*v^f.hi.b*w^(f.hi.a+f.hi.b)*f.lo.p⟩, f.hi⟩
  else
    ⟨f.lo, ⟨f.lo.a+f.mid.a, f.lo.b+f.mid.b,
      (u+v+w)*f.lo.p*f.mid.p-u^f.lo.a*v^f.lo.b*w^(f.lo.a+f.lo.b)*f.hi.p⟩, f.mid⟩
def frameH (path : List Bool) : HFrame := path.foldl advanceH initialH

theorem erase_initial : erase initialH = initial := by
  simp [erase, eraseLabel, initialH, initial, u, v, w]

theorem erase_advance (f : HFrame) (d : Bool) :
    erase (advanceH f d) = advance (erase f) d := by
  cases d <;> simp [advanceH, advance, erase, eraseLabel, u, v, w, S]

theorem erase_fold (path : List Bool) (f : HFrame) :
    erase (path.foldl advanceH f) = path.foldl advance (erase f) := by
  induction path generalizing f with
  | nil => rfl
  | cons d path ih => simp only [List.foldl_cons, ih, erase_advance]

theorem erase_frame (path : List Bool) : erase (frameH path) = frame path := by
  rw [frameH, erase_fold, erase_initial]
  rfl

theorem mid_eval (path : List Bool) :
    (frameH path).mid.p.eval 1 = (frame path).mid.p := by
  have h := congrArg (fun f : Frame => f.mid.p) (erase_frame path)
  exact h

theorem endpoint_eval (path : List Bool) :
    (frameH path).lo.p.eval 1 = (frame path).lo.p ∧
    (frameH path).hi.p.eval 1 = (frame path).hi.p := by
  exact ⟨congrArg (fun f : Frame => f.lo.p) (erase_frame path),
    congrArg (fun f : Frame => f.hi.p) (erase_frame path)⟩

#print axioms erase_frame
#print axioms mid_eval
#print axioms endpoint_eval

def Homogeneous (P : TriPoly) (d : ℕ) : Prop :=
  ∀ i j k, coeff (P.coeff k) i j ≠ 0 → i+j+k=d

theorem coeff_eval (P : TriPoly) (i j : ℕ) :
    coeff (P.eval 1) i j = ∑ k ∈ P.support, coeff (P.coeff k) i j := by
  simp [Polynomial.eval_eq_sum, Polynomial.sum_def, coeff]

theorem coefficient_transport (P : TriPoly) (d i j : ℕ)
    (h : Homogeneous P d) (hij : i+j ≤ d) :
    coeff (P.coeff (d-i-j)) i j = coeff (P.eval 1) i j := by
  classical
  rw [coeff_eval]
  symm
  apply Finset.sum_eq_single (d-i-j)
  · intro k hk hne
    by_contra hn
    have he := h i j k hn
    omega
  · intro hn
    simp [Polynomial.notMem_support_iff.mp hn, coeff]

theorem outside_degree (P : TriPoly) (d i j : ℕ)
    (h : Homogeneous P d) (hij : d < i+j) : coeff (P.eval 1) i j = 0 := by
  classical
  rw [coeff_eval]
  apply Finset.sum_eq_zero
  intro k hk
  by_contra hn
  have he := h i j k hn
  omega

#print axioms coefficient_transport
#print axioms outside_degree

theorem reachable_transport (path : List Bool)
    (h : Homogeneous (frameH path).mid.p ((frameH path).mid.a+(frameH path).mid.b-1)) :
    ∀ i j, i+j ≤ (frameH path).mid.a+(frameH path).mid.b-1 →
    coeff ((frameH path).mid.p.coeff ((frameH path).mid.a+(frameH path).mid.b-1-i-j)) i j =
      coeff (frame path).mid.p i j := by
  intro i j hij
  rw [coefficient_transport _ _ _ _ h hij, mid_eval]

theorem degree_balance (e o : ℕ) (he : 0 < e) (ho : 0 < o) :
    1+(e-1)+(e+o-1) = 2*e+o-1 ∧ 2*e+(o-1) = 2*e+o-1 := by
  omega

#print axioms reachable_transport
#print axioms degree_balance
end
end MathGKM.Markov.HomogeneousR0002
