import MathGKM.R0006FormalVariables_20261018T105130Z

/- Machine-authored exact submission interface, round-0006. -/

example : MathGKM.Markov.FormalR0006.x ≠ 0 ∧ MathGKM.Markov.FormalR0006.y ≠ 0 ∧ MathGKM.Markov.FormalR0006.z ≠ 0 := MathGKM.Markov.FormalR0006.xyz_nonzero

#print axioms MathGKM.Markov.FormalR0006.xyz_nonzero

example : let x := MathGKM.Markov.FormalR0006.x; let y := MathGKM.Markov.FormalR0006.y; let z := MathGKM.Markov.FormalR0006.z; let v := MathGKM.Markov.FormalR0006.v; let f := MathGKM.Markov.HomogeneousR0002.initialH; v f.lo = x ∧ v f.hi = (x^2+y^2)/z ∧ v f.mid = ((x^2+y^2)^2+x^2*z^2)/(y*z^2) := MathGKM.Markov.FormalR0006.seed_values

#print axioms MathGKM.Markov.FormalR0006.seed_values

example : let x := MathGKM.Markov.FormalR0006.x; let y := MathGKM.Markov.FormalR0006.y; let z := MathGKM.Markov.FormalR0006.z; ∀ (a b : ℕ) (q : MathGKM.Markov.FormalR0006.K), MathGKM.Markov.BridgeR0005.norm x y z (a+1) (b+1) q = q/(x^a*y^b*z^(a+b+1)) := MathGKM.Markov.FormalR0006.denominator

#print axioms MathGKM.Markov.FormalR0006.denominator

example : let v := MathGKM.Markov.FormalR0006.v; let c := MathGKM.Markov.FormalR0006.c; ∀ (path : List Bool) (d : Bool), let f := MathGKM.Markov.HomogeneousR0002.frameH path; v (MathGKM.Markov.HomogeneousR0002.advanceH f d).mid = if d then c*v f.hi*v f.mid-v f.lo else c*v f.lo*v f.mid-v f.hi := MathGKM.Markov.FormalR0006.mutation

#print axioms MathGKM.Markov.FormalR0006.mutation

example : ∀ (path : List Bool), MathGKM.Markov.FormalR0006.interpret (MathGKM.Markov.HomogeneousR0002.frameH path) = MathGKM.Markov.FormalR0006.frameR path := MathGKM.Markov.FormalR0006.all_paths

#print axioms MathGKM.Markov.FormalR0006.all_paths
