Machine-authored checkpoint: round-0005, H5-source-family-bridge, invention=false.
Started 2026-10-18 10:41:06 UTC. Active contract published-markov-6-3-clean-v2.
Prospective binding: 6d0a2f5c90fbfa77fa6817e466e01b2af26aebcc4bc30948482c6a14bcffd6a5.

Primary-source access succeeded through the authorized web tool; see source_notes.md.
The retained recurrence and seeds agree with the inspected source formulas. No mismatch witness was found.

Fresh root and round-two dependency rebuilds returned zero. The new module subsequently returned zero, printing only propext, Classical.choice and Quot.sound for scalar_bridge, endpoint, positive_denominator, seeds, branch_indices and branch_value. Each earlier attempt and diagnostic log is retained. Failed elaborations printed placeholder dependencies; those failed attempts establish no theorem and no such dependency remains in the successful module.

The new module imports the retained homogeneous definitions. It proves both evaluated mutation branches for every reachable path under explicit x,y,z nonzero premises, proves all three seed evaluations, and handles the endpoint separately. Its norm expression is xyz*P/(x^a*y^b*z^(a+b)); positive_denominator proves agreement with the positive-index source denominator. This changes no numerator coefficient. Reachable mediant identities are proved, not assumed.

Outcome: useful partial bridge, source-family identification still incomplete. Remaining work: instantiate the field with independent formal variables and discharge their nonvanishing; connect the source-labelled Conway/Farey family to the reachable path family, including neighbor/reduced-label and uniqueness conditions; connect that interface to coverage and coefficient transport. Neither the coverage theorem nor the repaired coefficient theorem was applied in this module. Their earlier independent comparison failures are not acceptance. No global source correspondence, polygon theorem, log-concavity, root completion, refutation, unprovability, or continuation improvement is claimed.

The incumbent single-agenda policy remains unchanged. Next choice follows the committed conditional/incomplete outcomes: complete the formal-function and rational-label interface before treating these candidates as published-family coefficient results. No episode is active. All new artifacts are durable research checkpoints or Lean sources; the denied .scratch location was not accessed and no temporary-file workaround was used.
