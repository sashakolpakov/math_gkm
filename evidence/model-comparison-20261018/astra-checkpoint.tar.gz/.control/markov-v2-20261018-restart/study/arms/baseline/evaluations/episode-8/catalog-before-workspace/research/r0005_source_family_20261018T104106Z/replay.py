"""Machine-authored bounded foreground replay using pinned dependencies, round-0005."""
from pathlib import Path
import os, subprocess, datetime, sys
root = Path('research/r0005_source_family_20261018T104106Z')
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join([str(root/'build')] + [str(p) for p in Path('.lake/packages').glob('*/.lake/build/lib/lean')])
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S%f')
for module in (['Markov', 'R0002Homogeneous_20261018T101629Z', 'R0005Bridge_20261018T104106Z'] if len(sys.argv)==1 else sys.argv[1:]):
    source = Path('MathGKM')/(module+'.lean')
    (root/('attempt_'+module+'_'+stamp+'.lean')).write_text(source.read_text())
    try:
        result = subprocess.run(['/Users/sasha/.elan/bin/lean', '-o', str(root/'build/MathGKM'/(module+'.olean')), str(source)], env=env, capture_output=True, text=True, timeout=45)
        log = result.stdout+result.stderr+'\nexit='+str(result.returncode)
        code = result.returncode
    except subprocess.TimeoutExpired as exc:
        log = 'timeout=45\n'+str(exc.stdout)+str(exc.stderr)
        code = 124
    (root/(module+'_'+stamp+'.log')).write_text(log)
    print(log, flush=True)
    if code: raise SystemExit(code)
