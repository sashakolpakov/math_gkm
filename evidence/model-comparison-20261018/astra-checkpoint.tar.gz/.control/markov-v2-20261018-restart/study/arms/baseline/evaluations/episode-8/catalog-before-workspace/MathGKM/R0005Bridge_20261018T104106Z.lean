import MathGKM.R0002Homogeneous_20261018T101629Z

/- Machine-authored round-0005, H5-source-family-bridge.
   Publisher equations (3), (5), (7), (8). No source assertion is an axiom.
   norm avoids natural-number truncation at the 0/1 endpoint. -/
namespace MathGKM.Markov.BridgeR0005
open HomogeneousR0002
noncomputable section

def norm {K : Type*} [Field K] (x y z : K) (a b : ℕ) (P : K) : K :=
  x*y*z*P / (x^a*y^b*z^(a+b))

theorem scalar_bridge {K : Type*} [Field K] (x y z : K)
    (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (a b c d : ℕ) (O E M : K) :
    norm x y z (a+2*c) (b+2*d)
      ((x^2+y^2+z^2)*E*M-(x^2)^c*(y^2)^d*(z^2)^(c+d)*O) =
    (x^2+y^2+z^2)/(x*y*z)*norm x y z c d E*
      norm x y z (a+c) (b+d) M - norm x y z a b O := by
  simp only [norm, pow_add, pow_mul]
  field_simp [hx, hy, hz]
  <;> ring

theorem endpoint {K : Type*} [Field K] (x y z : K)
    (hy : y ≠ 0) (hz : z ≠ 0) : norm x y z 0 1 1 = x := by
  simp [norm, hy, hz]
  field_simp [hy, hz]

theorem positive_denominator {K : Type*} [Field K] (x y z : K)
    (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (a b : ℕ) (P : K) :
    norm x y z (a+1) (b+1) P = P/(x^a*y^b*z^(a+b+1)) := by
  simp only [norm, pow_add, pow_one]
  field_simp [hx, hy, hz]
  <;> ring

def evalSq {K : Type*} [Field K] (x y z : K) : TriPoly →+* K :=
  Polynomial.eval₂RingHom
    (Polynomial.eval₂RingHom (Polynomial.eval₂RingHom (Int.castRingHom K) (y^2)) (x^2)) (z^2)

@[simp] theorem eval_u {K : Type*} [Field K] (x y z : K) : evalSq x y z u = x^2 := by
  simp [evalSq, u, U]
@[simp] theorem eval_v {K : Type*} [Field K] (x y z : K) : evalSq x y z v = y^2 := by
  simp [evalSq, v, V]
@[simp] theorem eval_w {K : Type*} [Field K] (x y z : K) : evalSq x y z w = z^2 := by
  simp [evalSq, w]

def value {K : Type*} [Field K] (x y z : K) (l : HLabel) : K :=
  norm x y z l.a l.b (evalSq x y z l.p)

theorem seeds {K : Type*} [Field K] (x y z : K)
    (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0) :
    value x y z initialH.lo = x ∧
    value x y z initialH.hi = (x^2+y^2)/z ∧
    value x y z initialH.mid = ((x^2+y^2)^2+x^2*z^2)/(y*z^2) := by
  simp only [value, initialH]
  try dsimp only
  simp only [map_one, map_add, map_mul, map_pow, eval_u, eval_v, eval_w]
  refine ⟨endpoint x y z hy hz, ?_, ?_⟩
  <;> simp only [norm, pow_add, pow_one]
  <;> field_simp [hx, hy, hz]
  <;> ring

def Med (f : HFrame) : Prop :=
  f.mid.a = f.lo.a+f.hi.a ∧ f.mid.b = f.lo.b+f.hi.b

theorem med_initial : Med initialH := by constructor <;> rfl

theorem med_advance (f : HFrame) (d : Bool) : Med (advanceH f d) := by
  cases d <;> simp [Med, advanceH, Nat.add_comm]

theorem med_fold (path : List Bool) (f : HFrame) (h : Med f) :
    Med (path.foldl advanceH f) := by
  induction path generalizing f with
  | nil => exact h
  | cons d path ih => exact ih _ (med_advance f d)

theorem reachable_med (path : List Bool) : Med (frameH path) :=
  med_fold path initialH med_initial

theorem branch_indices (path : List Bool) :
    (advanceH (frameH path) false).mid.a = (frameH path).hi.a+2*(frameH path).lo.a ∧
    (advanceH (frameH path) false).mid.b = (frameH path).hi.b+2*(frameH path).lo.b ∧
    (advanceH (frameH path) true).mid.a = (frameH path).lo.a+2*(frameH path).hi.a ∧
    (advanceH (frameH path) true).mid.b = (frameH path).lo.b+2*(frameH path).hi.b := by
  have h := reachable_med path
  simp only [Med] at h
  simp only [advanceH, Bool.false_eq_true, ↓reduceIte]
  omega

theorem branch_value {K : Type*} [Field K] (x y z : K)
    (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0) (path : List Bool) (d : Bool) :
    value x y z (advanceH (frameH path) d).mid =
    if d then (x^2+y^2+z^2)/(x*y*z) * value x y z (frameH path).hi *
      value x y z (frameH path).mid - value x y z (frameH path).lo
    else (x^2+y^2+z^2)/(x*y*z) * value x y z (frameH path).lo *
      value x y z (frameH path).mid - value x y z (frameH path).hi := by
  have hm := reachable_med path
  rcases hm with ⟨ha, hb⟩
  cases d
  · simp only [advanceH, Bool.false_eq_true, ↓reduceIte, value,
      map_sub, map_mul, map_add, map_pow, eval_u, eval_v, eval_w]
    try dsimp only
    simp only [norm]
    simp [evalSq, u, v, w, U, V, Polynomial.eval₂_pow]
    simpa [Polynomial.eval₂_pow, norm, evalSq, u, v, w, U, V, ha, hb, two_mul, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using
      scalar_bridge x y z hx hy hz (frameH path).hi.a (frameH path).hi.b
        (frameH path).lo.a (frameH path).lo.b
        (evalSq x y z (frameH path).hi.p) (evalSq x y z (frameH path).lo.p)
        (evalSq x y z (frameH path).mid.p)
  · simp only [advanceH, ↓reduceIte, value,
      map_sub, map_mul, map_add, map_pow, eval_u, eval_v, eval_w]
    try dsimp only
    simp only [norm]
    simp [evalSq, u, v, w, U, V, Polynomial.eval₂_pow]
    simpa [Polynomial.eval₂_pow, norm, evalSq, u, v, w, U, V, ha, hb, two_mul, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using
      scalar_bridge x y z hx hy hz (frameH path).lo.a (frameH path).lo.b
        (frameH path).hi.a (frameH path).hi.b
        (evalSq x y z (frameH path).lo.p) (evalSq x y z (frameH path).hi.p)
        (evalSq x y z (frameH path).mid.p)

#print axioms scalar_bridge
#print axioms endpoint
#print axioms positive_denominator
#print axioms seeds
#print axioms branch_indices
#print axioms branch_value
end
end MathGKM.Markov.BridgeR0005
