"""Independent review-6 replay of supplied sources; no mathematical edits."""
from pathlib import Path
import hashlib, json, os, subprocess, time

out = Path(__file__).parent
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
records = json.loads(Path('inbox/records.json').read_text())
receipt = {'records_sha256': sha('inbox/records.json'), 'bindings': [], 'checks': [],
           'method': 'Fresh project compilation; pinned read-only dependency oleans trusted. No source repair or new theorem.'}
for name, expected in records['receipts'][-1]['after'].items():
    p = Path(name)
    actual = sha(p) if p.is_file() else None
    receipt['bindings'].append({'path': name, 'expected': expected, 'actual': actual, 'match': actual == expected})
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join([str(out/'build')] + [str(p) for p in sorted(Path('.lake/packages').glob('*/.lake/build/lib/lean'))])
receipt['lean_path'] = env['LEAN_PATH']
receipt['replay_sha256'] = sha(__file__)
lean = '/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean'
modules = ['Markov', 'R0001Coverage_20261018T100704Z', 'R0002Homogeneous_20261018T101629Z',
           'R0004SupportRepair_20261018T103442Z', 'R0004SubmissionCheck_20261018T103442Z',
           'R0005Bridge_20261018T104106Z', 'R0005SubmissionCheck_20261018T104106Z']
for module in modules:
    source = Path('MathGKM')/(module+'.lean')
    argv = [lean, '-j', '1', '-o', str(out/'build/MathGKM'/(module+'.olean')), str(source)]
    start = time.monotonic()
    try:
        r = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=60)
        code, stdout, stderr = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        code, stdout, stderr = 124, str(e.stdout), str(e.stderr)
    elapsed = time.monotonic()-start
    log = out/(module+'.log')
    log.write_text(stdout+'\n'+stderr)
    axioms = [line for line in stdout.splitlines() if 'depends on axioms:' in line]
    check = {'source': str(source), 'sha256': sha(source), 'argv': argv, 'returncode': code,
             'elapsed_seconds': elapsed, 'log': str(log), 'log_sha256': sha(log), 'axiom_lines': axioms}
    receipt['checks'].append(check)
    (out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(check), flush=True)
    if code:
        break
print('bindings', len(receipt['bindings']), 'mismatches', [b for b in receipt['bindings'] if not b['match']], flush=True)
