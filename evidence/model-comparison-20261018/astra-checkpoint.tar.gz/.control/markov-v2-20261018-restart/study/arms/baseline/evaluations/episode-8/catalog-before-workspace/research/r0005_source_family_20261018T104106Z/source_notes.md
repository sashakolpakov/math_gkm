Machine-authored source comparison, 2026-10-18, round-0005.

Read through the authorized web tool:
https://armj.math.stonybrook.edu/Articles/250708-Winn/index.html
Sections 2, 3, 6; equations (3), (5), (7)-(11), Definitions 6.1-6.2, Conjecture 6.3.
Also inspected https://arxiv.org/html/2501.14882v1; its numbering differs, so the publisher version controls this comparison.

The publisher seeds match initialH after u=x²,v=y²,w=z². Equation (8) uses the retained numerator recurrence. Its indices assign the stationary endpoint c/d, the opposite endpoint a/b, and their mediant (a+c)/(b+d). Swapping endpoint roles supplies the other branch. Equation (7) supplies denominator exponents; its endpoint convention requires a negative exponent at 0/1. Equations (9)-(11) describe coefficient projection and polygon bounds. Definitions 6.1-6.2 use non-strict inequalities in the three specified directions.

Our algebraic device: norm(a,b,P)=xyz P/(x^a y^b z^(a+b)). This avoids truncated subtraction at the endpoint and agrees with the positive-index denominator. It does not rescale the numerator coefficients. Formal proofs are attempted in MathGKM/R0005Bridge_20261018T104106Z.lean. Scalar nonzero premises describe evaluation in a field; a complete formal-function interpretation must supply them, not assume arbitrary numerical inputs are nonzero.
