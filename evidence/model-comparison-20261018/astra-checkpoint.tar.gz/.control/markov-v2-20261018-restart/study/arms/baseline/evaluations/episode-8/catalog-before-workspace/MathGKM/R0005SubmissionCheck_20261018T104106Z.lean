import MathGKM.R0005Bridge_20261018T104106Z
/- Machine-authored exact submission interface, round-0005. -/
example : ∀ (K : Type) [Field K] (x y z : K), x ≠ 0 → y ≠ 0 → z ≠ 0 →
    ∀ (path : List Bool) (d : Bool),
    let v := MathGKM.Markov.BridgeR0005.value x y z
    let f := MathGKM.Markov.HomogeneousR0002.frameH path
    v (MathGKM.Markov.HomogeneousR0002.advanceH f d).mid =
      if d then (x^2+y^2+z^2)/(x*y*z)*v f.hi*v f.mid-v f.lo
      else (x^2+y^2+z^2)/(x*y*z)*v f.lo*v f.mid-v f.hi :=
  @MathGKM.Markov.BridgeR0005.branch_value

example : ∀ (K : Type) [Field K] (x y z : K), x ≠ 0 → y ≠ 0 → z ≠ 0 →
    let v := MathGKM.Markov.BridgeR0005.value x y z
    let f := MathGKM.Markov.HomogeneousR0002.initialH
    v f.lo = x ∧ v f.hi = (x^2+y^2)/z ∧
      v f.mid = ((x^2+y^2)^2+x^2*z^2)/(y*z^2) :=
  @MathGKM.Markov.BridgeR0005.seeds
