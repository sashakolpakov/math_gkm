# H2 homogeneous coefficient transport checkpoint

Machine-authored for round-0002 on 2026-10-18. Active phase: Markov.
Trial: {"hypothesis":"H2-homogeneous-coefficient-transport","invention":false}.
Prospective binding: 018daaa0aecec01b82d604bdd2958335053a547441133a805f2bda6f63a9941b
Start: 10:16:29 UTC. Budget: 300 seconds. No policy change installed.

Final verification observed by 10:20:29 UTC: exit 0 for both the fresh root
and the final candidate. R0002Homogeneous_20261018T101629Z_102010549035.log
prints only propext, Classical.choice, Quot.sound for erase_frame, mid_eval,
endpoint_eval, coefficient_transport, outside_degree, reachable_transport,
and degree_balance. The final source matches attempt_102010549035.lean.
These are locally compiled proof candidates pending independent checking.

## Construction and exact scope

The module MathGKM/R0002Homogeneous_20261018T101629Z.lean defines
TriPoly = Polynomial BiPoly, with outer variable w and coefficients in the
pinned u,v ring. HLabel and HFrame repeat the label updates, and advanceH
uses precisely the committed monomial u^a v^b w^(a+b). Seeds are 1, u+v,
and (u+v)^2+uw. No normalization is applied.

eraseLabel evaluates w=1; erase preserves the full frame, including labels.
erase_initial and erase_advance prove the seed and both branch identities.
erase_fold and erase_frame give the universal evaluation law for every path.
mid_eval and endpoint_eval extract the middle and endpoint laws.

Homogeneous P d explicitly means every nonzero raw coefficient at (i,j,k)
satisfies i+j+k=d. coefficient_transport assumes this condition and proves
the raw coefficient at k=d-i-j equals the bivariate evaluation coefficient
when i+j<=d. outside_degree proves vanishing when i+j>d under the same
condition. The proof expands evaluation as a finite sum over w exponents;
homogeneity forces all summands except the unique exponent to vanish.
reachable_transport combines this conditional theorem with the proved
evaluation law. Its homogeneous-support premise is NOT discharged here.

## Universal support argument, still awaiting formalization

Reuse the mediant invariant M=E+O from the existing round-zero audit and
round-one coverage candidate. Write e=E.a+E.b and o=O.a+O.b. Reachable
endpoint b coordinates are positive, so e,o>=1. The middle has coordinate
sum e+o; the new middle has sum 2e+o. Assuming homogeneous degrees e-1,
e+o-1, and o-1 for E,M,O, the first recurrence summand has degree
1+(e-1)+(e+o-1)=2e+o-1. The subtracted monomial has total degree 2e,
so the second summand has degree 2e+(o-1)=2e+o-1. Subtraction preserves
homogeneous support even when terms cancel. The seeds have degrees 0,1,2,
including 0/1. The arithmetic equalities are formalized in degree_balance.

This is a written induction argument, not a submitted universal support
theorem. Remaining formal work: support preservation under polynomial
multiplication/addition/subtraction, seed support, positivity of label sums,
and assembly of the reachable-frame invariant. Identification of this family
with the published source, Newton polygon equality, and direction/zero/endpoint
correspondence remain separate. Neither transport nor finite tests prove LC.

## Experiments and reuse

experiment.py performs independent integer-dictionary bivariate and trivariate
recurrences for all 31 paths of length at most four. It tests all three slots
(93 label occurrences), homogeneous support, evaluation equality, and 11,054
dense coefficient comparisons including zeros and entries beyond the degree.
All assertions passed; experiment.json retains the individual path/slot rows.
This is finite experimental evidence from a manual transcription, not Lean
execution, universal proof, source-family identification, or refutation.

The round-zero audit supplied the recurrence comparison and coefficient
uniqueness argument. The round-one candidate's Mediant definition and
advance_mediant supplied the invariant used in the written support induction.
Its independent acceptance is not presumed. No old campaign was rerun.

## Retention, failure classification, and next choice

replay.py directly runs installed pinned Lean and rebuilds the unchanged root
for each attempt, retaining source snapshots and timestamped logs. No Lake,
dependency refresh, network shell, or background process is used. The first
evaluation-only candidate compiled. Two subsequent attempts failed because
the guessed library constants not_mem_support_iff and
coeff_eq_zero_of_not_mem_support do not exist under those names. Their source
snapshots and logs are retained. Compiler error recovery in failed attempts
is not proof evidence; only the final successful compilation is eligible.
The actual installed interface is Polynomial.notMem_support_iff.

One patch failed its exact-line match and made no changes; its text is retained
in editing_failure.txt. This was an editing failure, not a mathematical one.
The managed profile denies .scratch. It was not accessed, and no replacement
temporary directory was used. All created files are persistent trial artifacts.
No capability invocation failed in this round; the restriction is recorded in
capability_boundary.txt without pretending an attempted access occurred.

The bounded trial yields universal evaluation and conditional coefficient
transport, with universal homogeneous support still open. Next prioritize
that precise support invariant; do not claim the full transport obligation
closed. Finite-budget incompleteness is not unprovability. The baseline
single-agenda policy remains unchanged. Root completion is not submitted.
