"""Machine-authored exact H2 experiment. Finite diagnostics, not a proof.
Manual independent bivariate and trivariate recurrence transcriptions.
"""
from pathlib import Path
import json, hashlib, platform

def add(p,q):
    r=p.copy()
    for e,c in q.items(): r[e]=r.get(e,0)+c
    return {e:c for e,c in r.items() if c}
def mul(p,q):
    r={}
    for e,c in p.items():
        for f,d in q.items():
            g=tuple(a+b for a,b in zip(e,f))
            r[g]=r.get(g,0)+c*d
    return {e:c for e,c in r.items() if c}
def sub(p,q): return add(p,{e:-c for e,c in q.items()})
def shift(p,e): return mul(p,{e:1})
def seed(n):
    u={(1,0)+(0,)*(n-2):1}; v={(0,1)+(0,)*(n-2):1}
    one={(0,)*n:1}; t=add(u,v)
    uw=u if n==2 else shift(u,(0,0,1))
    return ((0,1,one),(1,2,add(mul(t,t),uw)),(1,1,t))
def advance(f,right,n):
    lo,mid,hi=f
    e,o=(hi,lo) if right else (lo,hi)
    a,b,p=e; c,d,q=mid
    s={(1,0)+(0,)*(n-2):1,(0,1)+(0,)*(n-2):1}
    s=add(s,{(0,0) if n==2 else (0,0,1):1})
    factor=(a,b) if n==2 else (a,b,a+b)
    new=(a+c,b+d,sub(mul(mul(s,p),q),shift(o[2],factor)))
    return (mid,new,hi) if right else (lo,new,mid)
def evaluate(p):
    q={}
    for (i,j,k),c in p.items(): q[(i,j)]=q.get((i,j),0)+c
    return {e:c for e,c in q.items() if c}

rows=[]; dense_checks=0
queue=[('',seed(2),seed(3))]
while queue:
    path,bf,hf=queue.pop(0)
    assert bf[1][:2]==tuple(x+y for x,y in zip(bf[0][:2],bf[2][:2]))
    for slot,((a,b,p),(aa,bb,q)) in enumerate(zip(bf,hf)):
        assert (a,b)==(aa,bb)
        d=a+b-1
        assert all(sum(e)==d for e in q)
        assert evaluate(q)==p
        assert all(i+j<=d for i,j in p)
        for i in range(d+3):
            for j in range(d+3):
                if i+j<=d: assert q.get((i,j,d-i-j),0)==p.get((i,j),0)
                else: assert p.get((i,j),0)==0
                dense_checks+=1
        rows.append({'path':path,'slot':slot,'label':[a,b],'degree':d,'all_checks':True})
    if len(path)<4:
        for right in (False,True):
            queue.append((path+str(int(right)),advance(bf,right,2),advance(hf,right,3)))
root=Path('MathGKM/Markov.lean')
result={'provenance':'machine-authored round-0002 H2-homogeneous-coefficient-transport',
        'python':platform.python_version(),'root_sha256':hashlib.sha256(root.read_bytes()).hexdigest(),
        'scope':'All 31 paths of length at most 4, all three slots; finite manual transcription.',
        'dense_coefficient_checks':dense_checks,'rows':rows}
Path('research/r0002_homogeneous_20261018T101629Z/experiment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'frames':len(rows)//3,'label_checks':len(rows),'dense_coefficient_checks':dense_checks,'passed':True}))
