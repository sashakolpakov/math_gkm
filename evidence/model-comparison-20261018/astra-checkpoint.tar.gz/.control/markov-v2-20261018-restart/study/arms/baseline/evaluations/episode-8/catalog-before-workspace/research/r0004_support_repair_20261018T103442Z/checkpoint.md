# Round 0004 support repair checkpoint

Machine-authored trial H4-support-interface-repair, invention=false.
Prospective binding: 56df2e1e9ad1b6014bda1de4433851efef1bbf4d19e45858640f4fad2095dfeb
Active contract: published-markov-6-3-clean-v2; phase Markov.
Started 2026-10-18 10:34:42 UTC; final fresh compilation observed by 10:37:40 UTC, within 300 seconds.

## Observed outcome

The unchanged root, unchanged round-two dependency, repaired candidate and exact submission interface module all returned exit zero in the final replay stamped 103722802783. Reachable homogeneity, universal transport and both exact submitted statements print only propext, Classical.choice and Quot.sound. These are local proof candidates pending independent checking, not independent admission or root completion.

The candidate preserves the retained universal statements and representation. For every Boolean path, all three frame slots have homogeneous raw trivariate support of total degree a+b-1. The proof uses seed support, closure under addition/subtraction/multiplication/powers, positivity of label sums and the mediant sum invariant. The multiplication argument expands three nested antidiagonal sums and eliminates terms whose factor degrees cannot sum correctly. No nonnegativity assumption is needed for homogeneous support.

The existing coefficient_transport and reachable_transport are reused to obtain universal_transport with no added homogeneity premise. The explicit condition i+j <= a+b-1 remains: it selects a nonnegative recovered w exponent. This is not a claim that all source correspondence obligations are closed. Source-family identification, polygon correspondence, direction/zero/endpoint audit and log-concavity remain open; no source theorem was assumed.

## Repairs and retained failures

The round-three source remains unchanged. A new module imports the unchanged round-two source. Seed proofs now split each exponent at its monomial value and normalize equality orientation. Add/sub proofs unfold the custom coefficient consistently. Multiplication uses Finset.HasAntidiagonal.mem_antidiagonal, the installed interface. Frame updates expose coordinates explicitly before arithmetic.

All attempted candidate sources and logs remain here. Replay 103511603450 failed on equality orientation in two seeds and simplification making no progress. Replay 103603338646 fixed the seeds but still failed on no-progress simplification. Replay 103623468926 failed due to layout in an inline tactic edit. Replay 103654800598 succeeded. Final replay 103722802783 freshly rebuilt all three mathematical modules and the exact two submitted proposition/term interfaces. Failed elaborations are not theorem evidence; their compiler recovery dependencies do not certify any result. No concrete mathematical obstruction was found.

## Boundary, reuse and next action

Only pinned local Lean/Mathlib and /opt/homebrew/bin/python3 were used. The replay runs Lean sequentially, retaining source snapshots and logs; it performs no Lake refresh, networking or background launch. The managed profile denies .scratch, so it was not accessed. All generated files are persistent research evidence or candidate modules, not temporary substitutes. There was no missing-tool failure in this trial.

The candidate repairs the retained round-three proof and imports the round-two coefficient transport. The submission-check module consumes the final candidate and checks the exact proposed statements. No historical campaign was rerun. The root and contract were not edited. No policy/program change was installed or proposed; the baseline single revisable agenda remains incumbent.

Next investigate source-family identification, retaining these two candidates for independent checks. Do not infer root resolution, independent acceptance, continuation improvement, falsity or unprovability from this report.
