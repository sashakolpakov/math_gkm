import MathGKM.MarkovExchangeRefinement
/- Machine-authored committed H6-unit-specialization-nonvanishing, 2026-10-18. -/
namespace MathGKM.Markov.UnitNonvanishingTrial
open LaurentBridgeTrial HomogeneousTransportTrial ExchangeRefinementTrial
noncomputable section
def Positive (f : SourceFrame ℚ) : Prop := 0 < f.lo ∧ 0 < f.mid ∧ 0 < f.hi
theorem step_positive (f : SourceFrame ℚ)
    (hc : Cubic (((1:ℚ)^2+1^2+1^2)/(1*1*1)) f)
    (hp : Positive f) (r : Bool) : Positive (sourceStep 1 1 1 f r) := by
  obtain ⟨hl, hm, hh⟩ := hp
  obtain ⟨hfalse, htrue⟩ := exchange_quotients (1:ℚ) 1 1 f hc
    (ne_of_gt hl) (ne_of_gt hh)
  cases r
  · exact ⟨hl, hfalse.symm ▸ div_pos (add_pos (sq_pos_of_pos hl) (sq_pos_of_pos hm)) hh, hm⟩
  · exact ⟨hm, htrue.symm ▸ div_pos (add_pos (sq_pos_of_pos hh) (sq_pos_of_pos hm)) hl, hh⟩
theorem unit_positive (path : List Bool) : Positive (sourceFamily (1:ℚ) 1 1 path) := by
  have aux : ∀ (l : List Bool) (f : SourceFrame ℚ),
      Cubic (((1:ℚ)^2+1^2+1^2)/(1*1*1)) f → Positive f →
      Positive (l.foldl (sourceStep 1 1 1) f) := by
    intro l
    induction l with
    | nil => intro f hc hp; exact hp
    | cons r l ih =>
      intro f hc hp
      exact ih _ (step_cubic 1 1 1 f r hc) (step_positive f hc hp r)
  exact aux path _ (start_cubic 1 1 1 one_ne_zero one_ne_zero one_ne_zero)
    (by norm_num [Positive, sourceStart])
theorem numerator_unit_positive (path : List Bool) :
    0 < evaluate (1:ℚ) 1 1 (lifted path).lo.q ∧
    0 < evaluate (1:ℚ) 1 1 (lifted path).mid.q ∧
    0 < evaluate (1:ℚ) 1 1 (lifted path).hi.q := by
  have h := unit_positive path
  rw [← pathwise (1:ℚ) 1 1 one_ne_zero one_ne_zero one_ne_zero path] at h
  simpa [Positive, chart, realize, denominator] using h
theorem positive_eval_nonzero (q : Tri) (h : 0 < evaluate (1:ℚ) 1 1 q) : q ≠ 0 := by
  intro hz
  have hn := ne_of_gt h
  exact hn (by rw [hz, map_zero])
theorem numerator_nonzero (path : List Bool) :
    (lifted path).lo.q ≠ 0 ∧ (lifted path).mid.q ≠ 0 ∧ (lifted path).hi.q ≠ 0 := by
  obtain ⟨hl, hm, hh⟩ := numerator_unit_positive path
  exact ⟨positive_eval_nonzero _ hl, positive_eval_nonzero _ hm, positive_eval_nonzero _ hh⟩
def biUnit : BiPoly →+* ℚ :=
  Polynomial.eval₂RingHom (Polynomial.eval₂RingHom (Int.castRingHom ℚ) 1) 1
theorem dehom_unit (q : Tri) : biUnit (dehom q) = evaluate (1:ℚ) 1 1 q := by
  have he : biUnit.comp dehom = evaluate (1:ℚ) 1 1 := by
    ext n
    · simp [biUnit, dehom, evaluate]
    · fin_cases n <;> norm_num [biUnit, dehom, evaluate, U, V]
  exact DFunLike.congr_fun he q
theorem dehom_nonzero_of_positive (q : Tri) (h : 0 < evaluate (1:ℚ) 1 1 q) :
    dehom q ≠ 0 := by
  intro hz
  have he := dehom_unit q
  rw [hz, map_zero] at he
  linarith
theorem dehom_numerator_nonzero (path : List Bool) :
    dehom (lifted path).lo.q ≠ 0 ∧ dehom (lifted path).mid.q ≠ 0 ∧
    dehom (lifted path).hi.q ≠ 0 := by
  obtain ⟨hl, hm, hh⟩ := numerator_unit_positive path
  exact ⟨dehom_nonzero_of_positive _ hl, dehom_nonzero_of_positive _ hm,
    dehom_nonzero_of_positive _ hh⟩
theorem frame_nonzero (path : List Bool) :
    (frame path).lo.p ≠ 0 ∧ (frame path).mid.p ≠ 0 ∧ (frame path).hi.p ≠ 0 := by
  rw [← evaluation path]
  exact dehom_numerator_nonzero path
#print axioms unit_positive
#print axioms numerator_unit_positive
#print axioms numerator_nonzero
#print axioms dehom_unit
#print axioms dehom_numerator_nonzero
#print axioms frame_nonzero
end
end MathGKM.Markov.UnitNonvanishingTrial
