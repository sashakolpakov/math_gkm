# Machine-authored H7 symbolic quadratic exchange checkpoint

Trial: H7-symbolic-quadratic-exchange; invention: false.
Prospective binding: 8f0844959e65811f06b4956faa194fe18467acb5ed97113fa036c54ca1fe13c7.
Active contract: published-markov-6-3-clean-v2; phase markov.
Bound: 300 seconds, beginning at observed 2026-10-18 13:49:11 UTC.

Observed outcome: first committed outcome supported by successful local rebuilding and importing replay; independent admission remains pending.

Fresh source rebuilds of Markov, MarkovCoverage, MarkovHomogeneousTransport,
MarkovLaurentBridge, MarkovExchangeRefinement and MarkovUnitNonvanishing
all returned zero using a new trial build directory, pinned Lean 4.32.2 and
installed pinned Mathlib. The retained unit-nonvanishing importing client also
returned zero against these fresh artifacts.

The new module MathGKM/MarkovSymbolicExchange.lean defines K = FractionRing Tri,
with x,y,z the images of X 0, X 1, X 2. squareSub sends each X i to (X i)^2.
Its composition with unit evaluation equals unit evaluation. Thus positivity
of the unit evaluation implies squareSub q is nonzero. Injectivity of the
fraction-ring algebra map transports this to symbolic numerator nonvanishing.
Each variable image is nonzero, so every monomial Laurent denominator is
nonzero. The retained pathwise bridge gives nonvanishing of all three
sourceFamily components for every finite path.

quadraticStep is separately defined with middle component
(lo^2+mid^2)/hi in the false branch and (hi^2+mid^2)/lo in the true branch.
quadraticFamily folds it from exactly sourceStart x y z. symbolic_step uses
the retained cubic invariant and exchange_quotients, with its endpoint
nonvanishing discharged by symbolic_nonzero. Reverse-list induction then
proves quadratic_equality for all finite paths.

attempt01 failed due to reserved identifier variable and an incorrectly typed
coefficient homomorphism. Its source and complete failure diagnostics are
retained. Compiler-generated placeholder warnings in this failed elaboration
are rejected diagnostics; no proof or admission uses them. attempt02 replaces
the identifier with symVar and uses Int.castRingHom Tri. It returned zero.
No prohibited proof commands occur in the new candidate or fresh client.

The fresh importing client returned zero and checks universal nonvanishing,
universal family equality, explicit realized-component nonvanishing, and
quadratic-family nonvanishing. It prints all eight new theorem closures:
each contains only propext, Classical.choice, Quot.sound.

Scope: symbolic fraction field only. This does not assert nonvanishing at
arbitrary specializations, coefficient positivity, exact Newton support,
published-source identification, coefficient log-concavity, or the pinned root.
Published-source and polygon correspondence remain open. No completion claimed.
Reports and self-authored runners do not independently certify proofs.

Capability boundary: .scratch is denied. No access or bypass was attempted.
Shell heredoc creation failed because temporary files are unavailable; python -c
was used instead. All generated files are durable trial artifacts, not temporary
files. No network, controller, other model, Git, archive, other workspace or
background process was invoked.

Next single agenda: investigate universal Newton-polygon correspondence.
The incumbent allocation/memory/search/reassessment policy remains installed
unchanged. No policy or executable-program proposal is submitted.
