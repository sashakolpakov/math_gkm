import MathGKM.MarkovIndexScope
import MathGKM.Markov
def MathGKM.Target1ab402ee6bd9e26a6dacbc59.Interface := True
def MathGKM.Target1ab402ee6bd9e26a6dacbc59.Transport (StudyInterface : MathGKM.Target1ab402ee6bd9e26a6dacbc59.Interface) : Prop := True
def MathGKM.Target1ab402ee6bd9e26a6dacbc59.Goal (StudyInterface : MathGKM.Target1ab402ee6bd9e26a6dacbc59.Interface) : Prop := ∀ p q : ℕ, (∃ path : List Bool, (MathGKM.Markov.frame path).mid.a = p ∧ (MathGKM.Markov.frame path).mid.b = q) ↔ 0 < p ∧ p < q ∧ Nat.Coprime p q
