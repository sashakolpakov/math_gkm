import MathGKM.MarkovSymbolicExchange
/- Machine-authored H7 fresh importing client, 2026-10-18. -/
open MathGKM.Markov
open HomogeneousTransportTrial LaurentBridgeTrial SymbolicExchangeTrial
example : ∀ path : List Bool,
    (sourceFamily x y z path).lo ≠ 0 ∧
    (sourceFamily x y z path).mid ≠ 0 ∧
    (sourceFamily x y z path).hi ≠ 0 := symbolic_nonzero
example : ∀ path : List Bool,
    sourceFamily x y z path = quadraticFamily path := quadratic_equality
example (path : List Bool) :
    realize x y z (lifted path).lo ≠ 0 ∧
    realize x y z (lifted path).mid ≠ 0 ∧
    realize x y z (lifted path).hi ≠ 0 := by
  have h := symbolic_nonzero path
  rw [← pathwise x y z (symVar_nonzero 0) (symVar_nonzero 1) (symVar_nonzero 2) path] at h
  exact h
example (path : List Bool) :
    (quadraticFamily path).lo ≠ 0 ∧
    (quadraticFamily path).mid ≠ 0 ∧
    (quadraticFamily path).hi ≠ 0 := by
  rw [← quadratic_equality]
  exact symbolic_nonzero path
#print axioms MathGKM.Markov.SymbolicExchangeTrial.square_unit
#print axioms MathGKM.Markov.SymbolicExchangeTrial.symbolic_evaluate
#print axioms MathGKM.Markov.SymbolicExchangeTrial.symVar_nonzero
#print axioms MathGKM.Markov.SymbolicExchangeTrial.evaluate_nonzero
#print axioms MathGKM.Markov.SymbolicExchangeTrial.realized_nonzero
#print axioms MathGKM.Markov.SymbolicExchangeTrial.symbolic_nonzero
#print axioms MathGKM.Markov.SymbolicExchangeTrial.symbolic_step
#print axioms MathGKM.Markov.SymbolicExchangeTrial.quadratic_equality
