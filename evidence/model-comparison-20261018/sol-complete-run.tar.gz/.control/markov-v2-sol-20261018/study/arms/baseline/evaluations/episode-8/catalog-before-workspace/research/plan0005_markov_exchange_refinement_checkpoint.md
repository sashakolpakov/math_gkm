# H5-exchange-refinement checkpoint

Machine-authored 2026-10-18. Committed trial H5-exchange-refinement,
invention false. Binding:
05741bb4149733229b200a75b9f0bf6e6541cccc5ac611c23324eb3c72fdbef6

Read MISSION.md, full docs/DESIGN.md, contract.json and retained bridge.
Active phase remains markov, contract published-markov-6-3-clean-v2.
Primary-source comparison found agreement of initial frame and mutation
equations; see the source checkpoint and its publisher link.

Freshly rebuilt Markov, MarkovCoverage, MarkovHomogeneousTransport and
MarkovLaurentBridge from sources into a unique research build directory.
The retained H4 importing replay succeeded. An early coverage invocation
failed because it preceded root build completion; the sequential retry passed.

New module MathGKM/MarkovExchangeRefinement.lean proves a cubic invariant
for every sourceFamily path, both product exchange identities, and both
quotient identities under explicit lo/hi nonzero premises. The first attempt
failed on redundant dsimp steps; its source and diagnostics are retained.
Compiler error recovery in that failed attempt produced invalid placeholder
axiom diagnostics, which are rejected evidence for theorem validity. Removing
the redundant tactics gave a successful compile and only propext,
Classical.choice and Quot.sound in the printed closures. No placeholder
or additional axiom was introduced in the candidate source.

The importing replay checks the invariant, products, conditional quotients,
and transport to the retained homogeneous chart using pathwise. Its separate
compile record supplies the final outcome and all six axiom closures.

Positivity was not attempted within the remaining budget. Quotient mutation
therefore remains conditional on nonvanishing of the current endpoints.
The importing replay passed (exit 0), with all six printed closures exactly
propext, Classical.choice and Quot.sound. Select committed outcome 2. Next action:
prove symbolic nonvanishing or polynomial-family uniqueness. Do not claim
unrestricted published-family correspondence, polygon correspondence or
Conjecture 6.3. No root reduction, root resolution, policy installation or
certified continuation improvement is claimed. Finite-budget limits imply
neither refutation nor unprovability.

The nominal setup allocation overran; the overall 300-second bound governs.
At about 246 seconds, the corrected candidate had compiled and client replay
was running; its successful result was recorded by about 269 seconds.
The pinned root hash remains 8b8408e5cae9822fe0969afd4a70b408d48e69f750dffb88c253dba8ef167dbe.
Temporary-file restrictions are separately recorded as capability
failures. All generated retained outputs are durable research artifacts.
