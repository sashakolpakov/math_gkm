import MathGKM.MarkovCoverage
/- Machine-authored committed H3 trial, 2026-10-18. -/
namespace MathGKM.Markov.HomogeneousTransportTrial
open MathGKM.Markov CoverageTrial
noncomputable section
abbrev Tri := MvPolynomial (Fin 3) ℤ
def u : Tri := MvPolynomial.X 0
def v : Tri := MvPolynomial.X 1
def w : Tri := MvPolynomial.X 2
def dehom : Tri →+* BiPoly := MvPolynomial.eval₂Hom (Int.castRingHom BiPoly)
  (fun i => if i = 0 then U else if i = 1 then V else 1)
@[simp] theorem dehom_u : dehom u = U := by simp [dehom, u]
@[simp] theorem dehom_v : dehom v = V := by simp [dehom, v]
@[simp] theorem dehom_w : dehom w = 1 := by simp [dehom, w]
structure LLabel where
  a : ℕ
  b : ℕ
  q : Tri
structure LFrame where
  lo : LLabel
  mid : LLabel
  hi : LLabel
def forgetLabel (l : LLabel) : Label := ⟨l.a, l.b, dehom l.q⟩
def forget (f : LFrame) : Frame :=
  ⟨forgetLabel f.lo, forgetLabel f.mid, forgetLabel f.hi⟩
def start : LFrame :=
  ⟨⟨0, 1, 1⟩, ⟨1, 2, (u+v)^2+u*w⟩, ⟨1, 1, u+v⟩⟩
def step (f : LFrame) (r : Bool) : LFrame :=
  if r then
    ⟨f.mid, ⟨f.mid.a+f.hi.a, f.mid.b+f.hi.b,
      (u+v+w)*f.hi.q*f.mid.q-u^f.hi.a*v^f.hi.b*w^(f.hi.a+f.hi.b)*f.lo.q⟩, f.hi⟩
  else
    ⟨f.lo, ⟨f.lo.a+f.mid.a, f.lo.b+f.mid.b,
      (u+v+w)*f.lo.q*f.mid.q-u^f.lo.a*v^f.lo.b*w^(f.lo.a+f.lo.b)*f.hi.q⟩, f.mid⟩
def lifted (path : List Bool) : LFrame := path.foldl step start
theorem forget_start : forget start = initial := by
  simp [forget, forgetLabel, start, initial]
theorem forget_step (f : LFrame) (r : Bool) :
    forget (step f r) = advance (forget f) r := by
  cases r <;> simp [forget, forgetLabel, step, advance, S]
theorem evaluation (path : List Bool) : forget (lifted path) = frame path := by
  have aux : ∀ (l : List Bool) (f : LFrame),
      forget (l.foldl step f) = l.foldl advance (forget f) := by
    intro l
    induction l with
    | nil => intro f; rfl
    | cons r l ih => intro f; simpa [forget_step] using ih (step f r)
  simpa [lifted, frame, forget_start] using aux path start
def Good (f : LFrame) : Prop :=
  Mediant (forget f) ∧ 0 < f.lo.a+f.lo.b ∧ 0 < f.hi.a+f.hi.b ∧
  f.lo.q.IsHomogeneous (f.lo.a+f.lo.b-1) ∧
  f.mid.q.IsHomogeneous (f.mid.a+f.mid.b-1) ∧
  f.hi.q.IsHomogeneous (f.hi.a+f.hi.b-1)
theorem hu : u.IsHomogeneous 1 := MvPolynomial.isHomogeneous_X _ _
theorem hv : v.IsHomogeneous 1 := MvPolynomial.isHomogeneous_X _ _
theorem hw : w.IsHomogeneous 1 := MvPolynomial.isHomogeneous_X _ _
theorem start_good : Good start := by
  refine ⟨initial_mediant, by decide, by decide, ?_, ?_, ?_⟩
  · exact MvPolynomial.isHomogeneous_one _ _
  · exact ((hu.add hv).pow 2).add (hu.mul hw)
  · exact hu.add hv
theorem step_good (f : LFrame) (r : Bool) (h : Good f) : Good (step f r) := by
  rcases h with ⟨hm, hlp, hrp, hl, hc, hr⟩
  have hma : f.mid.a = f.lo.a+f.hi.a := hm.1
  have hmb : f.mid.b = f.lo.b+f.hi.b := hm.2
  have hs := (hu.add hv).add hw
  have aux (x y z : LLabel) (hx : 0 < x.a+x.b) (hz : 0 < z.a+z.b)
      (ha : y.a = x.a+z.a) (hb : y.b = x.b+z.b)
      (hqx : x.q.IsHomogeneous (x.a+x.b-1))
      (hqy : y.q.IsHomogeneous (y.a+y.b-1))
      (hqz : z.q.IsHomogeneous (z.a+z.b-1)) :
      ((u+v+w)*x.q*y.q-u^x.a*v^x.b*w^(x.a+x.b)*z.q).IsHomogeneous
        (x.a+y.a+(x.b+y.b)-1) := by
    apply MvPolynomial.IsHomogeneous.sub
    · have hd : 1+(x.a+x.b-1)+(y.a+y.b-1) = x.a+y.a+(x.b+y.b)-1 := by omega
      exact hd ▸ (hs.mul hqx).mul hqy
    · have hh := (((hu.pow x.a).mul (hv.pow x.b)).mul (hw.pow (x.a+x.b))).mul hqz
      simp only [Nat.one_mul] at hh
      have hd : x.a+x.b+(x.a+x.b)+(z.a+z.b-1) = x.a+y.a+(x.b+y.b)-1 := by omega
      exact hd ▸ hh
  cases r <;> simp only [Good, step, Bool.false_eq_true, ↓reduceIte]
  · refine ⟨?_, hlp, by omega, hl, ?_, hc⟩
    · exact ⟨rfl, rfl⟩
    · exact aux f.lo f.mid f.hi hlp hrp hma hmb hl hc hr
  · refine ⟨?_, by omega, hrp, hc, ?_, hr⟩
    · exact ⟨rfl, rfl⟩
    · simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using
        aux f.hi f.mid f.lo hrp hlp (by omega) (by omega) hr hc hl
theorem homogeneous_support (path : List Bool) : Good (lifted path) := by
  have aux : ∀ (l : List Bool) (f : LFrame), Good f → Good (l.foldl step f) := by
    intro l
    induction l with
    | nil => intro f h; exact h
    | cons r l ih => intro f h; exact ih _ (step_good f r h)
  exact aux path start start_good
#print axioms evaluation
#print axioms homogeneous_support
end
end MathGKM.Markov.HomogeneousTransportTrial
