# Machine-authored H3-homogeneous-raw-coefficient-transport, 2026-10-18.
# Durable evidence runner; no network, package changes, or background execution.
import os, pathlib, subprocess, sys, time, json
root = pathlib.Path.cwd()
build = root/'research/plan0003_markov_homogeneous_transport_build'
(build/'MathGKM').mkdir(parents=True, exist_ok=True)
paths = [str(build)] + [str(p/'.lake/build/lib/lean') for p in (root/'.lake/packages').iterdir() if p.is_dir()]
env = dict(os.environ, LEAN_PATH=':'.join(paths))
args = ['/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean'] + sys.argv[2:]
start = time.time()
try:
    r = subprocess.run(args, env=env, capture_output=True, text=True, timeout=50)
    out = dict(command=args, returncode=r.returncode, stdout=r.stdout, stderr=r.stderr, elapsed=time.time()-start)
except (subprocess.TimeoutExpired, OSError) as e:
    out = dict(command=args, returncode='execution_failure', detail=str(e), elapsed=time.time()-start)
(root/sys.argv[1]).write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
