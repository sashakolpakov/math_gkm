import MathGKM.MarkovExchangeRefinement
/- Machine-authored H5 importing replay, 2026-10-18. -/
open MathGKM.Markov.LaurentBridgeTrial
open MathGKM.Markov.ExchangeRefinementTrial
example (K : Type) [Field K] (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0)
    (hz : z ≠ 0) (path : List Bool) :
    Cubic ((x^2+y^2+z^2)/(x*y*z)) (sourceFamily x y z path) :=
  family_cubic x y z hx hy hz path
example (K : Type) [Field K] (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0)
    (hz : z ≠ 0) (path : List Bool) :
    let f := sourceFamily x y z path
    f.hi * (sourceStep x y z f false).mid = f.lo^2+f.mid^2 ∧
    f.lo * (sourceStep x y z f true).mid = f.hi^2+f.mid^2 :=
  family_exchange x y z hx hy hz path
example (K : Type) [Field K] (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0)
    (hz : z ≠ 0) (path : List Bool)
    (hl : (sourceFamily x y z path).lo ≠ 0)
    (hr : (sourceFamily x y z path).hi ≠ 0) :
    let f := sourceFamily x y z path
    (sourceStep x y z f false).mid = (f.lo^2+f.mid^2)/f.hi ∧
    (sourceStep x y z f true).mid = (f.hi^2+f.mid^2)/f.lo :=
  exchange_quotients x y z _ (family_cubic x y z hx hy hz path) hl hr
example (K : Type) [Field K] (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0)
    (hz : z ≠ 0) (path : List Bool) :
    Cubic ((x^2+y^2+z^2)/(x*y*z))
      (chart x y z (MathGKM.Markov.HomogeneousTransportTrial.lifted path)) := by
  rw [pathwise x y z hx hy hz path]
  exact family_cubic x y z hx hy hz path
#print axioms MathGKM.Markov.ExchangeRefinementTrial.start_cubic
#print axioms MathGKM.Markov.ExchangeRefinementTrial.step_cubic
#print axioms MathGKM.Markov.ExchangeRefinementTrial.family_cubic
#print axioms MathGKM.Markov.ExchangeRefinementTrial.exchange_products
#print axioms MathGKM.Markov.ExchangeRefinementTrial.exchange_quotients
#print axioms MathGKM.Markov.ExchangeRefinementTrial.family_exchange
