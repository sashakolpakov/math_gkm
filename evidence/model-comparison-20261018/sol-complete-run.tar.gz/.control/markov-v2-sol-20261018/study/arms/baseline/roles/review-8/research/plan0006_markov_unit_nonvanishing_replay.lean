import MathGKM.MarkovUnitNonvanishing
/- Machine-authored fresh importing H6 client, 2026-10-18. -/
open MathGKM.Markov
open LaurentBridgeTrial HomogeneousTransportTrial UnitNonvanishingTrial
example (path : List Bool) :
    0 < (sourceFamily (1:ℚ) 1 1 path).lo ∧
    0 < (sourceFamily (1:ℚ) 1 1 path).mid ∧
    0 < (sourceFamily (1:ℚ) 1 1 path).hi := unit_positive path
example (path : List Bool) :
    (lifted path).lo.q ≠ 0 ∧ (lifted path).mid.q ≠ 0 ∧ (lifted path).hi.q ≠ 0 :=
  numerator_nonzero path
example (path : List Bool) :
    dehom (lifted path).lo.q ≠ 0 ∧ dehom (lifted path).mid.q ≠ 0 ∧
    dehom (lifted path).hi.q ≠ 0 := dehom_numerator_nonzero path
example (path : List Bool) :
    (frame path).lo.p ≠ 0 ∧ (frame path).mid.p ≠ 0 ∧ (frame path).hi.p ≠ 0 :=
  frame_nonzero path
#print axioms MathGKM.Markov.UnitNonvanishingTrial.unit_positive
#print axioms MathGKM.Markov.UnitNonvanishingTrial.numerator_unit_positive
#print axioms MathGKM.Markov.UnitNonvanishingTrial.numerator_nonzero
#print axioms MathGKM.Markov.UnitNonvanishingTrial.dehom_unit
#print axioms MathGKM.Markov.UnitNonvanishingTrial.dehom_numerator_nonzero
#print axioms MathGKM.Markov.UnitNonvanishingTrial.frame_nonzero
