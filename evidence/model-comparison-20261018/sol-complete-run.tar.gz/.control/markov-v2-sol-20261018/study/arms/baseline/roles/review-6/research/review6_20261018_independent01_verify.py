"""Independent replay of supplied sources only; no mathematical search or new tasks.

Machine-authored reviewer checkpoint, 2026-10-18. All outputs are durable
review evidence because the active permission profile denies .scratch reads.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path.cwd()
PREFIX = ROOT / 'research/review6_20261018_independent01'
BUILD = Path(str(PREFIX) + '_build')
RECEIPT = Path(str(PREFIX) + '_receipt.json')
LEAN = Path('/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean')
CHECKER = LEAN.with_name('leanchecker')
MODULES = [
    'Markov', 'MarkovCoverage', 'MarkovIndexScope',
    'MarkovHomogeneousTransport', 'MarkovRawCoefficientTransport',
    'MarkovLaurentBridge', 'MarkovExchangeRefinement',
]
CLIENTS = [
    'research/plan0002_markov_index_scope_replay.lean',
    'research/plan0003_markov_homogeneous_transport_replay.lean',
    'research/plan0004_markov_laurent_bridge_replay.lean',
    'research/plan0005_markov_exchange_refinement_replay.lean',
]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

started = time.monotonic()
records = json.loads((ROOT / 'inbox/records.json').read_text())
manifest = records['receipts'][-1]['after']
bindings = {p: {'expected': h, 'actual': sha(ROOT / p)} for p, h in manifest.items()}
sources = {f'MathGKM/{m}.lean': sha(ROOT / f'MathGKM/{m}.lean') for m in MODULES}
sources.update({p: sha(ROOT / p) for p in CLIENTS})
(BUILD / 'MathGKM').mkdir(parents=True, exist_ok=False)
deps = sorted(str(p / '.lake/build/lib/lean') for p in (ROOT / '.lake/packages').iterdir() if p.is_dir())
env = dict(os.environ, LEAN_PATH=':'.join([str(BUILD)] + deps))
result = {
    'request_id': 'review-6',
    'provenance': 'Independent foreground reviewer replay of the exact supplied artifacts',
    'started_unix': time.time(),
    'input_sha256': {p: sha(ROOT / p) for p in ['inbox/records.json', 'contract.json', 'lean-toolchain', 'lake-manifest.json']},
    'binary_sha256': {str(p): sha(p) for p in [LEAN, CHECKER]},
    'source_sha256': sources,
    'latest_receipt_bindings': bindings,
    'lean_path': env['LEAN_PATH'],
    'checks': [],
    'scope': 'Existing supplied theorem statements and clients only; no root theorem, source-hull theorem or transfer task is invented.',
    'capability_failure': 'The shell here-document temporary-file operation is denied. No .scratch read attempted; review evidence retained directly in research/.',
}

def save():
    result['elapsed_seconds'] = time.monotonic() - started
    RECEIPT.write_text(json.dumps(result, indent=2) + '\n')

def run(label, argv):
    t = time.monotonic()
    entry = {'label': label, 'argv': list(map(str, argv))}
    try:
        r = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, text=True, timeout=55)
        entry.update(returncode=r.returncode, stdout=r.stdout, stderr=r.stderr)
    except (subprocess.TimeoutExpired, OSError) as e:
        entry.update(returncode=None, failure=repr(e))
    entry['elapsed_seconds'] = time.monotonic() - t
    result['checks'].append(entry)
    save()
    print(json.dumps({k: entry[k] for k in ['label', 'returncode', 'elapsed_seconds']}), flush=True)
    return entry['returncode'] == 0

save()
for module in MODULES:
    source = f'MathGKM/{module}.lean'
    if not run('compile:' + module, [LEAN, '-j', '1', '-o', BUILD / f'MathGKM/{module}.olean', source]):
        result['status'] = 'compile_failure'
        save()
        raise SystemExit(1)
for i, client in enumerate(CLIENTS):
    if not run('supplied_client:' + client, [LEAN, '-j', '1', '-o', BUILD / f'SuppliedClient{i}.olean', client]):
        result['status'] = 'client_failure'
        save()
        raise SystemExit(1)
for module in MODULES:
    if not run('kernel_replay:' + module, [CHECKER, 'MathGKM.' + module]):
        result['status'] = 'kernel_replay_failure'
        save()
        raise SystemExit(1)
result['source_unchanged'] = all(sha(ROOT / p) == h for p, h in sources.items())
result['status'] = 'passed' if result['source_unchanged'] else 'source_changed'
save()
print(json.dumps({'status': result['status'], 'receipt': str(RECEIPT), 'elapsed_seconds': result['elapsed_seconds']}), flush=True)
