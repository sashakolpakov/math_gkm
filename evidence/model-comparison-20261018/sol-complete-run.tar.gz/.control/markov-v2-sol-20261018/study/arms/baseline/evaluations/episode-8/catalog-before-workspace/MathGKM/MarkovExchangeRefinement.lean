import MathGKM.MarkovLaurentBridge
/- Machine-authored committed H5-exchange-refinement, 2026-10-18. -/
namespace MathGKM.Markov.ExchangeRefinementTrial
open LaurentBridgeTrial
noncomputable section
variable {K : Type*} [Field K]
def Cubic (k : K) (f : SourceFrame K) : Prop :=
  f.lo^2 + f.mid^2 + f.hi^2 = k*f.lo*f.mid*f.hi
theorem start_cubic (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0) :
    Cubic ((x^2+y^2+z^2)/(x*y*z)) (sourceStart x y z) := by
  unfold Cubic sourceStart
  dsimp
  field_simp [hx, hy, hz]
  <;> ring
theorem step_cubic (x y z : K) (f : SourceFrame K) (r : Bool)
    (h : Cubic ((x^2+y^2+z^2)/(x*y*z)) f) :
    Cubic ((x^2+y^2+z^2)/(x*y*z)) (sourceStep x y z f r) := by
  unfold Cubic at *
  cases r <;> simp only [sourceStep, Bool.false_eq_true, ↓reduceIte]
  <;> linear_combination h
theorem family_cubic (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (path : List Bool) :
    Cubic ((x^2+y^2+z^2)/(x*y*z)) (sourceFamily x y z path) := by
  have aux : ∀ (l : List Bool) (f : SourceFrame K),
      Cubic ((x^2+y^2+z^2)/(x*y*z)) f →
      Cubic ((x^2+y^2+z^2)/(x*y*z)) (l.foldl (sourceStep x y z) f) := by
    intro l
    induction l with
    | nil => intro f h; exact h
    | cons r l ih => intro f h; exact ih _ (step_cubic x y z f r h)
  exact aux path _ (start_cubic x y z hx hy hz)
theorem exchange_products (x y z : K) (f : SourceFrame K)
    (h : Cubic ((x^2+y^2+z^2)/(x*y*z)) f) :
    f.hi * (sourceStep x y z f false).mid = f.lo^2+f.mid^2 ∧
    f.lo * (sourceStep x y z f true).mid = f.hi^2+f.mid^2 := by
  unfold Cubic at h
  constructor <;> simp only [sourceStep, Bool.false_eq_true, ↓reduceIte]
  <;> linear_combination -h
theorem exchange_quotients (x y z : K) (f : SourceFrame K)
    (h : Cubic ((x^2+y^2+z^2)/(x*y*z)) f) (hl : f.lo ≠ 0) (hr : f.hi ≠ 0) :
    (sourceStep x y z f false).mid = (f.lo^2+f.mid^2)/f.hi ∧
    (sourceStep x y z f true).mid = (f.hi^2+f.mid^2)/f.lo := by
  obtain ⟨hfalse, htrue⟩ := exchange_products x y z f h
  constructor
  · apply (eq_div_iff hr).2
    simpa only [mul_comm] using hfalse
  · apply (eq_div_iff hl).2
    simpa only [mul_comm] using htrue
theorem family_exchange (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (path : List Bool) :
    let f := sourceFamily x y z path
    f.hi * (sourceStep x y z f false).mid = f.lo^2+f.mid^2 ∧
    f.lo * (sourceStep x y z f true).mid = f.hi^2+f.mid^2 :=
  exchange_products x y z _ (family_cubic x y z hx hy hz path)
#print axioms family_cubic
#print axioms family_exchange
#print axioms exchange_quotients
end
end MathGKM.Markov.ExchangeRefinementTrial
