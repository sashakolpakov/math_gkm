# Machine-authored H4 evidence runner, 2026-10-18. Foreground bounded Lean calls.
import os, pathlib, subprocess, sys, time, json
root=pathlib.Path.cwd(); build=root/'research/plan0004_markov_laurent_bridge_build'
(build/'MathGKM').mkdir(parents=True,exist_ok=True)
env=dict(os.environ,LEAN_PATH=':'.join([str(build)]+[str(p/'.lake/build/lib/lean') for p in (root/'.lake/packages').iterdir() if p.is_dir()]))
args=['/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean']+sys.argv[2:]
t=time.time()
try:
 r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=35)
 out=dict(command=args,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,elapsed=time.time()-t)
except (subprocess.TimeoutExpired,OSError) as e: out=dict(command=args,returncode='execution_failure',detail=str(e),elapsed=time.time()-t)
(root/sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
