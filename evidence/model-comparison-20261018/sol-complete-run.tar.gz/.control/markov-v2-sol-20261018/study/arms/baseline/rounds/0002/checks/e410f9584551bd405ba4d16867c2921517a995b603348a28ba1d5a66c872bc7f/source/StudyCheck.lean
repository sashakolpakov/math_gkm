import MathGKM.Target1ab402ee6bd9e26a6dacbc59
import MathGKM.MarkovIndexScope
import Lean
def StudyInterface : MathGKM.Target1ab402ee6bd9e26a6dacbc59.Interface := True.intro
theorem StudyTransport : MathGKM.Target1ab402ee6bd9e26a6dacbc59.Transport StudyInterface := True.intro
theorem StudyObligation : MathGKM.Target1ab402ee6bd9e26a6dacbc59.Goal StudyInterface := MathGKM.Markov.IndexScopeTrial.exact_interior_index
