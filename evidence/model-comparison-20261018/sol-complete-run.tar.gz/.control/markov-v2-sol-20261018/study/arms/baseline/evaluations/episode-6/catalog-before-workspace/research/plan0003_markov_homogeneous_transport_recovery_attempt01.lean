import MathGKM.MarkovHomogeneousTransport
/- Machine-authored bounded coefficient recovery attempt, H3, 2026-10-18. -/
namespace MathGKM.Markov.HomogeneousTransportTrial
open MathGKM.Markov
noncomputable section
def exponent (i j k : ℕ) : Fin 3 →₀ ℕ :=
  Finsupp.equivFunOnFinite.symm ![i,j,k]
theorem exponent_degree (d : Fin 3 →₀ ℕ) : d.degree = d 0+d 1+d 2 := by
  simp [Finsupp.degree, Finsupp.sum_fintype, Fin.sum_univ_succ, add_assoc]
theorem monomial_raw (d : Fin 3 →₀ ℕ) (z : ℤ) (i j : ℕ) :
    coeff (dehom (MvPolynomial.monomial d z)) i j =
      if d 0 = i ∧ d 1 = j then z else 0 := by
  simp [dehom, MvPolynomial.eval₂Hom_monomial, Finsupp.prod_fintype,
    Fin.prod_univ_succ, coeff, U, V, Polynomial.coeff_mul_X_pow,
    Polynomial.coeff_C_mul, Polynomial.coeff_X_pow, mul_assoc]
theorem raw_recovery (Q : Tri) (D i j : ℕ) (h : Q.IsHomogeneous D)
    (hij : i+j ≤ D) :
    coeff (dehom Q) i j = MvPolynomial.coeff (exponent i j (D-i-j)) Q := by
  classical
  rw [← Q.support_sum_monomial_coeff, map_sum]
  simp only [coeff, Polynomial.finset_sum_coeff]
  change (∑ d ∈ Q.support, coeff (dehom (MvPolynomial.monomial d (MvPolynomial.coeff d Q))) i j) = _
  simp_rw [monomial_raw]
  apply Finset.sum_eq_single (exponent i j (D-i-j))
  · intro d hd hne
    split_ifs with he
    · exfalso
      apply hne
      have hdg : d.degree = D := by
        simpa only [← Finsupp.degree_eq_weight_one, Pi.one_def] using h (MvPolynomial.mem_support_iff.mp hd)
      rw [exponent_degree] at hdg
      ext n
      fin_cases n <;> simp [exponent, he.1, he.2] <;> omega
    · rfl
  · intro hn
    simp [MvPolynomial.not_mem_support_iff.mp hn]
end
end MathGKM.Markov.HomogeneousTransportTrial
