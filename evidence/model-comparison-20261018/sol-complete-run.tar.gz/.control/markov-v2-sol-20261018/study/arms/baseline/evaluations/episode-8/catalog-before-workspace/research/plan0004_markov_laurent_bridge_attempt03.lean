import MathGKM.MarkovHomogeneousTransport
/- Machine-authored committed H4 trial, 2026-10-18. -/
namespace MathGKM.Markov.LaurentBridgeTrial
open HomogeneousTransportTrial
noncomputable section
variable {K : Type*} [Field K]
def denominator (x y z : K) (a b : ℕ) : K :=
  x ^ ((a : ℤ)-1) * y ^ ((b : ℤ)-1) * z ^ ((a : ℤ)+(b : ℤ)-1)
theorem denominator_formula (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0)
    (hz : z ≠ 0) (a b : ℕ) :
    denominator x y z a b = x^a*y^b*z^(a+b)/(x*y*z) := by
  simp [denominator, zpow_sub₀, zpow_add₀, hx, hy, hz, pow_add]
  ring
def evaluate (x y z : K) : Tri →+* K :=
  MvPolynomial.eval₂Hom (Int.castRingHom K) (fun i => if i=0 then x^2 else if i=1 then y^2 else z^2)
def realize (x y z : K) (l : LLabel) : K :=
  evaluate x y z l.q / denominator x y z l.a l.b
theorem endpoint (x y z : K) (hx : x ≠ 0) :
    realize x y z start.lo = x := by
  simp [realize, start, denominator, hx]
theorem algebra (x y z A B C : K) (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (a b c d : ℕ) :
    ((x^2+y^2+z^2)*A*B-x^(2*a)*y^(2*b)*z^(2*(a+b))*C) /
      denominator x y z (a+(a+c)) (b+(b+d)) =
    ((x^2+y^2+z^2)/(x*y*z))*(A/denominator x y z a b)*
      (B/denominator x y z (a+c) (b+d))-C/denominator x y z c d := by
  simp only [denominator_formula x y z hx hy hz, pow_add, pow_mul]
  field_simp [hx, hy, hz]
  <;> ring
structure SourceFrame (K : Type*) where
  lo : K
  mid : K
  hi : K
def sourceStart (x y z : K) : SourceFrame K :=
  ⟨x, ((x^2+y^2)^2+x^2*z^2)/(y*z^2), (x^2+y^2)/z⟩
def sourceStep (x y z : K) (f : SourceFrame K) (r : Bool) : SourceFrame K :=
  let k := (x^2+y^2+z^2)/(x*y*z)
  if r then ⟨f.mid, k*f.hi*f.mid-f.lo, f.hi⟩
  else ⟨f.lo, k*f.lo*f.mid-f.hi, f.mid⟩
def sourceFamily (x y z : K) (path : List Bool) :=
  path.foldl (sourceStep x y z) (sourceStart x y z)
def chart (x y z : K) (f : LFrame) : SourceFrame K :=
  ⟨realize x y z f.lo, realize x y z f.mid, realize x y z f.hi⟩
theorem initial_values (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0) :
    chart x y z start = sourceStart x y z := by
  unfold chart sourceStart
  congr 1
  · exact endpoint x y z hx
  · simp [chart, realize, start, evaluate, u, v, w, denominator, hx, hy, hz] <;> ring
  · simp [chart, realize, start, evaluate, u, v, w, denominator, hx, hy, hz] <;> ring
theorem branch (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (f : LFrame) (r : Bool) (hm : f.mid.a = f.lo.a+f.hi.a ∧ f.mid.b = f.lo.b+f.hi.b) :
    chart x y z (step f r) = sourceStep x y z (chart x y z f) r := by
  cases r <;> simp only [step, sourceStep, Bool.false_eq_true, ↓reduceIte, chart]
  · congr 1
    simpa [realize, evaluate, u, v, w, hm.1, hm.2, pow_add, pow_mul] using
      algebra x y z (evaluate x y z f.lo.q) (evaluate x y z f.mid.q)
        (evaluate x y z f.hi.q) hx hy hz f.lo.a f.lo.b f.hi.a f.hi.b
  · congr 1
    simpa [realize, evaluate, u, v, w, hm.1, hm.2, pow_add, pow_mul,
      Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using
      algebra x y z (evaluate x y z f.hi.q) (evaluate x y z f.mid.q)
        (evaluate x y z f.lo.q) hx hy hz f.hi.a f.hi.b f.lo.a f.lo.b
theorem pathwise (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0) (hz : z ≠ 0)
    (path : List Bool) : chart x y z (lifted path) = sourceFamily x y z path := by
  have aux : ∀ (l : List Bool) (f : LFrame), Good f →
      chart x y z (l.foldl step f) = l.foldl (sourceStep x y z) (chart x y z f) := by
    intro l
    induction l with
    | nil => intro f h; rfl
    | cons r l ih =>
      intro f h
      simpa only [List.foldl_cons, branch x y z hx hy hz f r h.1] using
        ih (step f r) (step_good f r h)
  simpa only [lifted, sourceFamily, initial_values x y z hx hy hz] using aux path start start_good
abbrev Ambient := FractionRing Tri
#print axioms pathwise
#print axioms branch
#print axioms endpoint
#print axioms denominator_formula
#print axioms algebra
#print axioms initial_values
end
end MathGKM.Markov.LaurentBridgeTrial
