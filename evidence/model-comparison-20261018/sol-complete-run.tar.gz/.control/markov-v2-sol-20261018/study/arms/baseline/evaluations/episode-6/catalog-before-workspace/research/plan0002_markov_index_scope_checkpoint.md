# H2-universal-index-scope checkpoint

Machine-authored 2026-10-18. Invention: false. Contract:
published-markov-6-3-clean-v2, phase markov. Prospective binding:
745e2712da467c5350968c3b328767a354d042aff3c469b36d3e41591b6b025e.
Start 12:53:40 UTC; deadline 12:58:40 UTC (300 seconds).

Committed hypothesis, unchanged:
"A bounded Lean trial reusing the retained mediant and coverage declarations will either establish that every generated middle label is a reduced rational strictly between 0 and 1, and combine this with surjectivity into an exact interior-index characterization, or isolate the specific invariant, arithmetic or execution obstruction that should determine the next action."

## Result and proof scope

Local compilation and client replay succeeded for the new module
MathGKM/MarkovIndexScope.lean, importing the retained MarkovCoverage module.
The submitted candidate statements are:

```
∀ path : List Bool,
  0 < (MathGKM.Markov.frame path).mid.a ∧
  (MathGKM.Markov.frame path).mid.a < (MathGKM.Markov.frame path).mid.b ∧
  Nat.Coprime (MathGKM.Markov.frame path).mid.a
    (MathGKM.Markov.frame path).mid.b
```

and

```
∀ p q : ℕ,
  (∃ path : List Bool, (MathGKM.Markov.frame path).mid.a = p ∧
    (MathGKM.Markov.frame path).mid.b = q) ↔
  0 < p ∧ p < q ∧ Nat.Coprime p q
```

The actual frame is used throughout, with its polynomial fields carried by
advance. The retained frame_mediant supplies M=L+R. New fold invariants are
L.a<L.b, R.a≤R.b, 0<R.a, and L.b*R.a=L.a*R.b+1. Each branch preserves these
using the mediant equations. The first three imply 0<M.a<M.b. The determinant
gives L.b*M.a=L.a*M.b+1. Any prime dividing both middle coordinates would
divide 1, establishing coprimality via Nat.coprime_of_dvd'. The reverse
direction of exact_interior_index calls retained rational_coverage directly.
No coverage reconstruction or finite rational cutoff was used. No uniqueness
of paths, source-family identity, or statement about coefficients is proved.

## Replay and allowed assumptions

Pinned Lean 4.32.2 was invoked by its absolute executable path, with explicit
LEAN_PATH entries for existing pinned package libraries and the unique trial
build directory. No Lake or dependency refresh was used. The root source was
freshly compiled into this directory (27.36 seconds), then retained coverage
source (6.54 seconds), corrected new source (12.94 seconds), and an importing
client with explicit closed examples (5.68 seconds). All exited zero. The
client prints axiom closures for frame_boundsDet, generated_label_valid and
exact_interior_index; each is exactly propext, Classical.choice, Quot.sound.
The coverage rebuild reports the same closure. These local records are
evidence for independent checking; this report does not certify admission.

The root hash was checked after replay and remains
8b8408e5cae9822fe0969afd4a70b408d48e69f750dffb88c253dba8ef167dbe.
Mission, design, contract, coverage and the retained source-correspondence
candidate hashes were also read and computed. No root or retained source was
edited. Only this trial's new module, source snapshots and checkpoints were
created. No historical campaigns were rerun.

## Retained failures and capability boundaries

Attempt01 and its failed compiler JSON are preserved. Its invariants compiled,
but the final divisibility step used the wrong orientation of
Nat.dvd_add_iff_left. Lean reported a type mismatch and error-recovery
dependencies in that failed run; it is not submitted as a proof. Attempt02
uses (Nat.dvd_add_iff_right h2).mpr h1 and compiles without those dependencies.
No admitted term, new axiom or native decision procedure was authored.

The initial zsh heredoc failed because shell temporary files are denied; its
subsequent runner invocation consequently found no file. The managed profile
also denies .scratch. The runner was then created through apply_patch and
all further authored artifacts were durable research checkpoints. This is
recorded as a capability failure without a mathematical inference. A lemma
search also named a nonexistent Mathlib Defs.lean path; the other searched
file and the pinned Lean Nat/Dvd.lean supplied the needed signatures.

## Observed reuse and next choice

The new module actually imports and calls frame_mediant, advance_mediant,
initial_mediant and rational_coverage from MathGKM/MarkovCoverage.lean. The
retained plan0000 correspondence candidate supplied the determinant argument
that was translated here. The client replay imports and applies the new
module's declarations. These are observed uses, pending checked interfaces.

Outcome: locally successful candidate for the committed indexing trial,
pending independent validation. The next single agenda action is homogeneous
source-family and raw coefficient transport, using the resulting exact
interior-index characterization. Source-family identity, homogeneity and
coefficient correspondence, universal Newton polygon, directions/zeros/
endpoints interpretation, final scope audit and Conjecture 6.3 remain open.
The two endpoints remain separate. This result does not prove log-concavity
or resolve the published root. No policy or executable change is proposed or
installed; no certified continuation improvement is claimed. No inference of
unprovability or refutation follows from the failed attempt or any budget.

Successful compilation, client replay and root-hash recheck were complete
before 12:56:20 UTC; checkpoint and evidence bookkeeping are within the
12:58:40 UTC deadline. The trial stopped after completing its bounded target.
