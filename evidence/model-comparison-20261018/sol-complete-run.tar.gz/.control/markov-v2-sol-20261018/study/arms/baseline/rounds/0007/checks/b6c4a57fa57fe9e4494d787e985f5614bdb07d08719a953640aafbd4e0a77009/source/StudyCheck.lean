import MathGKM.Target9a22f8f64c31fef3da1b3759
import MathGKM.MarkovSymbolicExchange
import Lean
def StudyInterface : MathGKM.Target9a22f8f64c31fef3da1b3759.Interface := True.intro
theorem StudyTransport : MathGKM.Target9a22f8f64c31fef3da1b3759.Transport StudyInterface := True.intro
theorem StudyObligation : MathGKM.Target9a22f8f64c31fef3da1b3759.Goal StudyInterface := MathGKM.Markov.SymbolicExchangeTrial.quadratic_equality
