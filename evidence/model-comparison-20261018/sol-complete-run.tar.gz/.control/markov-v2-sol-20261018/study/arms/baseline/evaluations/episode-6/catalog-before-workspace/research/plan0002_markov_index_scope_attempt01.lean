import MathGKM.MarkovCoverage
/- Machine-authored H2-universal-index-scope, 2026-10-18.
   Converse indexing for the actual pinned frame, no polynomial claims. -/
namespace MathGKM.Markov.IndexScopeTrial
open MathGKM.Markov CoverageTrial

def BoundsDet (f : Frame) : Prop :=
  f.lo.a < f.lo.b ∧ f.hi.a ≤ f.hi.b ∧ 0 < f.hi.a ∧
  f.lo.b * f.hi.a = f.lo.a * f.hi.b + 1

theorem initial_boundsDet : BoundsDet initial := by
  norm_num [BoundsDet, initial]

theorem advance_boundsDet (f : Frame) (hm : Mediant f)
    (h : BoundsDet f) (r : Bool) : BoundsDet (advance f r) := by
  rcases hm with ⟨hma, hmb⟩
  rcases h with ⟨hl, hr, hp, hd⟩
  cases r <;> simp only [BoundsDet, advance, Bool.false_eq_true, ↓reduceIte]
  · rw [hma, hmb]
    constructor
    · exact hl
    constructor
    · omega
    constructor
    · omega
    · nlinarith
  · rw [hma, hmb]
    constructor
    · omega
    constructor
    · exact hr
    constructor
    · exact hp
    · nlinarith

theorem frame_boundsDet (path : List Bool) : BoundsDet (frame path) := by
  have aux : ∀ (l : List Bool) (f : Frame), Mediant f → BoundsDet f →
      BoundsDet (l.foldl advance f) := by
    intro l
    induction l with
    | nil => intro f hm hd; exact hd
    | cons r l ih =>
      intro f hm hd
      exact ih _ (advance_mediant f hm r) (advance_boundsDet f hm hd r)
  exact aux path initial initial_mediant initial_boundsDet

theorem generated_label_valid (path : List Bool) :
    0 < (frame path).mid.a ∧ (frame path).mid.a < (frame path).mid.b ∧
    Nat.Coprime (frame path).mid.a (frame path).mid.b := by
  have hm := frame_mediant path
  have hd := frame_boundsDet path
  generalize frame path = f at hm hd ⊢
  rcases hm with ⟨hma, hmb⟩
  rcases hd with ⟨hl, hr, hp, hd⟩
  rw [hma, hmb]
  refine ⟨by omega, by omega, ?_⟩
  apply Nat.coprime_of_dvd'
  intro k hk ha hb
  have h1 : k ∣ f.lo.b * (f.lo.a + f.hi.a) := dvd_mul_of_dvd_right ha _
  have h2 : k ∣ f.lo.a * (f.lo.b + f.hi.b) := dvd_mul_of_dvd_right hb _
  have he : f.lo.b * (f.lo.a + f.hi.a) = f.lo.a * (f.lo.b + f.hi.b) + 1 := by
    nlinarith
  rw [he] at h1
  exact (Nat.dvd_add_iff_left h2).mp h1

theorem exact_interior_index (p q : ℕ) :
    (∃ path : List Bool, (frame path).mid.a = p ∧ (frame path).mid.b = q) ↔
    0 < p ∧ p < q ∧ Nat.Coprime p q := by
  constructor
  · rintro ⟨path, rfl, rfl⟩
    exact generated_label_valid path
  · rintro ⟨hp, hpq, hc⟩
    exact rational_coverage p q hp hpq hc

#print axioms frame_boundsDet
#print axioms generated_label_valid
#print axioms exact_interior_index
end MathGKM.Markov.IndexScopeTrial
