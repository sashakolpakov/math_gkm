import MathGKM.MarkovLaurentBridge
/- Machine-authored importing client, H4, 2026-10-18. -/
open MathGKM.Markov.LaurentBridgeTrial
example (K : Type) [Field K] (x y z : K) (hx : x ≠ 0) (hy : y ≠ 0)
    (hz : z ≠ 0) (path : List Bool) :
    chart x y z (MathGKM.Markov.HomogeneousTransportTrial.lifted path) =
      sourceFamily x y z path := pathwise x y z hx hy hz path
#print axioms MathGKM.Markov.LaurentBridgeTrial.pathwise
#print axioms MathGKM.Markov.LaurentBridgeTrial.branch
#print axioms MathGKM.Markov.LaurentBridgeTrial.initial_values
#print axioms MathGKM.Markov.LaurentBridgeTrial.denominator_formula
#print axioms MathGKM.Markov.LaurentBridgeTrial.endpoint
#print axioms MathGKM.Markov.LaurentBridgeTrial.algebra
