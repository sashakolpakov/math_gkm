import MathGKM.Target0bb8ea26982e3bccdc79ce06
import MathGKM.MarkovIndexScope
import Lean
def StudyInterface : MathGKM.Target0bb8ea26982e3bccdc79ce06.Interface := True.intro
theorem StudyTransport : MathGKM.Target0bb8ea26982e3bccdc79ce06.Transport StudyInterface := True.intro
theorem StudyObligation : MathGKM.Target0bb8ea26982e3bccdc79ce06.Goal StudyInterface := MathGKM.Markov.IndexScopeTrial.generated_label_valid
