import MathGKM.MarkovRawCoefficientTransport
/- Machine-authored H3 importing replay client, 2026-10-18. -/
open MathGKM.Markov MathGKM.Markov.HomogeneousTransportTrial
example : ∀ path : List Bool, forget (lifted path) = frame path := evaluation
example : ∀ path : List Bool, Good (lifted path) := homogeneous_support
example : ∀ (Q : Tri) (D i j : ℕ), Q.IsHomogeneous D → i+j ≤ D →
    coeff (dehom Q) i j = MvPolynomial.coeff (exponent i j (D-i-j)) Q := raw_recovery
example : ∀ (Q : Tri) (D i j : ℕ), Q.IsHomogeneous D → D < i+j →
    coeff (dehom Q) i j = 0 := raw_zero
#print axioms evaluation
#print axioms homogeneous_support
#print axioms raw_recovery
#print axioms raw_zero
