# H1-formal-rational-coverage checkpoint

Machine-authored 2026-10-18. Trial invention: false. Active contract:
published-markov-6-3-clean-v2, phase markov.
Prospective binding: ce2dbf80acc5f4f61b6ae09eb7b3209629af5546ae3d0521b5f695e6e36f41e6.
Trial started 12:38:53 UTC; absolute deadline 12:43:53 UTC.

The committed hypothesis is unchanged: Attempting the retained determinant
invariants and positive-coordinate descent in Lean will produce either a checked
universal coverage lemma for the existing frame definition or a precise
obstruction that determines the next coverage attempt.

## Result and exact scope

`MathGKM/MarkovCoverage.lean` imports the unchanged `MathGKM/Markov.lean` and
proves `MathGKM.Markov.CoverageTrial.rational_coverage`:

```
∀ p q : ℕ, 0 < p → p < q → Nat.Coprime p q →
  ∃ path : List Bool, (MathGKM.Markov.frame path).mid.a = p ∧
    (MathGKM.Markov.frame path).mid.b = q
```

The final compilation exited zero. Its axiom reports for rational_coverage and
frame_mediant list exactly propext, Classical.choice, Quot.sound. Local replay
is recorded separately in plan0001_markov_coverage_replay_compile.json; this
checkpoint is a report, and independent admission must inspect that evidence.

The proof uses the retained positive-coordinate descent. A determinant is not
needed in this direction: any frame with middle coordinates equal to the sum
of its endpoint coordinates suffices for the generalized reach theorem. For
positive coprime x,y, strong induction on x+y reaches the weighted endpoint
vector. If x<y, prepend True and use (x,y-x); if y<x, prepend False and use
(x-y,y). Coprimality is preserved by the existing Nat subtraction lemmas.
When x=y, coprimality implies x=y=1. At the initial frame choose x=q-p,y=p.
The proof manipulates the actual frame fold, not a disconnected label tree.
The frame's polynomial fields are carried by the actual advance function;
no assertion about their coefficients is needed or obtained here.

The module also proves the mediant invariant for all paths. No determinant,
injectivity, denominator positivity, reducedness of all generated labels,
source-family identity or uniqueness theorem is claimed by this submission.

## Preserved execution history

All source attempts and diagnostics are retained. Attempt01 was written but
not compiled; attempt02 corrected arithmetic proof steps before execution.
Attempt02 compilation failed at the initial Mediant proof because `decide`
did not unfold the predicate to obtain its decision procedure. Lean's error
recovery inserted an error placeholder, visible as a disallowed dependency in
that failed run. That run is not submitted as a proof. Replacing the initial
proof by `constructor <;> rfl` removed the error; attempt03 is the final module
snapshot. No admitted declaration or new axiom was written.

`lake env lean --version` unexpectedly attempted a dependency refresh because
it considered the configured package URL changed. The sandbox rejected the
attempt. Subsequent executions used direct pinned Lean with explicit paths to
the existing package build libraries, without Lake or network commands. A
fresh compilation of the unchanged root first exceeded a 35-second timeout,
then succeeded in 24.54 seconds with a 65-second cap. The final coverage
compilation took 6.34 seconds. The intended sub-budgets shifted due to import
startup; the complete trial remains bounded by 300 seconds. Scratch and shell
temporary storage are denied by the managed profile, so all authored files
are durable checkpoints in research/ or the new Lean module.

## Remaining obligations and next choice

Coverage is submitted for independent checking, with no root completion claim.
The next single-agenda action is source-family identification and homogeneous
coefficient transport using this coverage lemma. The independent universal
Newton-polygon/support-hull proof remains explicitly open, together with the
remaining contract correspondence obligations and Conjecture 6.3 itself.
The endpoints remain separate in the root. Coverage alone proves neither the
source correspondence nor any log-concavity inequality. There is no finite
denominator cutoff or extra mathematical premise in the submitted theorem.

The incumbent policy and executable program are unchanged. No historical
campaign, external LLM, background process, archive, Git, or other workspace
was used. No unprovability or refutation inference follows from any timeout
or failed attempt. Reported use links describe actual use of retained artifacts
in the written proof and local compiler/replay files, pending independent checks.
