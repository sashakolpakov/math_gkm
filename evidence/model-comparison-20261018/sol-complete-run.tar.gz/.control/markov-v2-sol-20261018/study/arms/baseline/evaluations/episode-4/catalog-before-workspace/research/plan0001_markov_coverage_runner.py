# Machine-authored 2026-10-18, H1-formal-rational-coverage. No dependency updates.
import os, pathlib, subprocess, sys, time, json
root = pathlib.Path.cwd()
paths = [str(root/'research/plan0001_markov_coverage_build')]
paths += [str(p/'.lake/build/lib/lean') for p in (root/'.lake/packages').iterdir() if p.is_dir()]
env = dict(os.environ, LEAN_PATH=':'.join(paths))
args = ['lean'] + sys.argv[2:]
started = time.time()
try:
    r = subprocess.run(args, env=env, capture_output=True, text=True, timeout=65)
    out = dict(command=args, returncode=r.returncode, stdout=r.stdout, stderr=r.stderr, elapsed=time.time()-started)
except subprocess.TimeoutExpired as e:
    out = dict(command=args, returncode='timeout', stdout=(e.stdout or b'').decode(), stderr=(e.stderr or b'').decode(), elapsed=time.time()-started)
(root/sys.argv[1]).write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
