import MathGKM.MarkovUnitNonvanishing
/- Machine-authored committed H7-symbolic-quadratic-exchange, 2026-10-18. -/
namespace MathGKM.Markov.SymbolicExchangeTrial
open HomogeneousTransportTrial LaurentBridgeTrial ExchangeRefinementTrial UnitNonvanishingTrial
noncomputable section
abbrev K := FractionRing Tri
def variable (i : Fin 3) : K := algebraMap Tri K (MvPolynomial.X i)
abbrev x : K := variable 0
abbrev y : K := variable 1
abbrev z : K := variable 2
def squareSub : Tri →+* Tri :=
  MvPolynomial.eval₂Hom (RingHom.id ℤ) (fun i => (MvPolynomial.X i)^2)
theorem square_unit (q : Tri) :
    evaluate (1:ℚ) 1 1 (squareSub q) = evaluate (1:ℚ) 1 1 q := by
  have he : (evaluate (1:ℚ) 1 1).comp squareSub = evaluate (1:ℚ) 1 1 := by
    ext i
    · simp [squareSub, evaluate]
    · fin_cases i <;> norm_num [squareSub, evaluate]
  exact DFunLike.congr_fun he q
theorem symbolic_evaluate (q : Tri) :
    evaluate x y z q = algebraMap Tri K (squareSub q) := by
  have he : evaluate x y z = (algebraMap Tri K).comp squareSub := by
    ext i
    · simp [squareSub, evaluate]
    · fin_cases i <;> simp [squareSub, evaluate, variable]
  exact DFunLike.congr_fun he q
theorem variable_nonzero (i : Fin 3) : variable i ≠ 0 := by
  exact fun h => MvPolynomial.X_ne_zero i
    ((IsFractionRing.injective Tri K) (by simpa [variable] using h))
theorem evaluate_nonzero (q : Tri) (hp : 0 < evaluate (1:ℚ) 1 1 q) :
    evaluate x y z q ≠ 0 := by
  rw [symbolic_evaluate]
  intro hz
  have hsq : squareSub q = 0 :=
    (IsFractionRing.injective Tri K) (by simpa using hz)
  have he := square_unit q
  rw [hsq, map_zero] at he
  linarith
theorem realized_nonzero (l : LLabel) (hp : 0 < evaluate (1:ℚ) 1 1 l.q) :
    realize x y z l ≠ 0 := by
  apply div_ne_zero (evaluate_nonzero l.q hp)
  exact mul_ne_zero (mul_ne_zero (zpow_ne_zero _ (variable_nonzero 0))
    (zpow_ne_zero _ (variable_nonzero 1))) (zpow_ne_zero _ (variable_nonzero 2))
theorem symbolic_nonzero (path : List Bool) :
    (sourceFamily x y z path).lo ≠ 0 ∧
    (sourceFamily x y z path).mid ≠ 0 ∧
    (sourceFamily x y z path).hi ≠ 0 := by
  rw [← pathwise x y z (variable_nonzero 0) (variable_nonzero 1) (variable_nonzero 2) path]
  obtain ⟨hl, hm, hh⟩ := numerator_unit_positive path
  exact ⟨realized_nonzero _ hl, realized_nonzero _ hm, realized_nonzero _ hh⟩
def quadraticStep (f : SourceFrame K) (r : Bool) : SourceFrame K :=
  if r then ⟨f.mid, (f.hi^2+f.mid^2)/f.lo, f.hi⟩
  else ⟨f.lo, (f.lo^2+f.mid^2)/f.hi, f.mid⟩
def quadraticFamily (path : List Bool) : SourceFrame K :=
  path.foldl quadraticStep (sourceStart x y z)
theorem symbolic_step (path : List Bool) (r : Bool) :
    sourceStep x y z (sourceFamily x y z path) r =
      quadraticStep (sourceFamily x y z path) r := by
  obtain ⟨hl, hm, hh⟩ := symbolic_nonzero path
  obtain ⟨hf, ht⟩ := exchange_quotients x y z _ (family_cubic x y z
    (variable_nonzero 0) (variable_nonzero 1) (variable_nonzero 2) path) hl hh
  cases r
  · simpa only [sourceStep, quadraticStep, Bool.false_eq_true, ↓reduceIte] using
      congrArg (fun m => SourceFrame.mk (sourceFamily x y z path).lo m
        (sourceFamily x y z path).mid) hf
  · simpa only [sourceStep, quadraticStep, ↓reduceIte] using
      congrArg (fun m => SourceFrame.mk (sourceFamily x y z path).mid m
        (sourceFamily x y z path).hi) ht
theorem quadratic_equality (path : List Bool) :
    sourceFamily x y z path = quadraticFamily path := by
  induction path using List.reverseRecOn with
  | nil => rfl
  | append_singleton path r ih =>
    change (path ++ [r]).foldl (sourceStep x y z) (sourceStart x y z) =
      (path ++ [r]).foldl quadraticStep (sourceStart x y z)
    simp only [List.foldl_append, List.foldl_cons, List.foldl_nil]
    change sourceStep x y z (sourceFamily x y z path) r =
      quadraticStep (quadraticFamily path) r
    rw [symbolic_step, ih]
#print axioms symbolic_nonzero
#print axioms quadratic_equality
end
end MathGKM.Markov.SymbolicExchangeTrial
