import MathGKM.MarkovSymbolicExchange
import MathGKM.Markov
def MathGKM.Target9a22f8f64c31fef3da1b3759.Interface := True
def MathGKM.Target9a22f8f64c31fef3da1b3759.Transport (StudyInterface : MathGKM.Target9a22f8f64c31fef3da1b3759.Interface) : Prop := True
def MathGKM.Target9a22f8f64c31fef3da1b3759.Goal (StudyInterface : MathGKM.Target9a22f8f64c31fef3da1b3759.Interface) : Prop := ∀ path : List Bool, MathGKM.Markov.LaurentBridgeTrial.sourceFamily MathGKM.Markov.SymbolicExchangeTrial.x MathGKM.Markov.SymbolicExchangeTrial.y MathGKM.Markov.SymbolicExchangeTrial.z path = MathGKM.Markov.SymbolicExchangeTrial.quadraticFamily path
