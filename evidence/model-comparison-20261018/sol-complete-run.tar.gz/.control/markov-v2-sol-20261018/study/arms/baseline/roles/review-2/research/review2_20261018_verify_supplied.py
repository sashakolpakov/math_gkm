"""Reviewer-authored replay of supplied artifacts only; no new mathematics."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd()
base = root / "research/review2_20261018_build"
base.mkdir(exist_ok=False)
(base / "MathGKM").mkdir()
toolchain = Path("/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2")
lean = toolchain / "bin/lean"
checker = toolchain / "bin/leanchecker"
packages = sorted((root / ".lake/packages").iterdir())
paths = [base, toolchain / "lib/lean"]
paths += [p / ".lake/build/lib/lean" for p in packages if p.is_dir()]
env = dict(os.environ)
env["LEAN_PATH"] = ":".join(map(str, paths))
env["LEAN_SYSROOT"] = str(toolchain)
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
record = {
    "provenance": "review-2 independent supplied-source verification",
    "source_hashes": {p: digest(p) for p in [
        "inbox/records.json", "contract.json", "MathGKM/Markov.lean",
        "MathGKM/MarkovCoverage.lean", "research/plan0001_markov_coverage_replay.lean",
        "research/plan0000_markov_correspondence_checks.py",
        "research/plan0000_markov_correspondence_checks.json"]},
    "binary_hashes": {str(p): digest(p) for p in [lean, checker]},
    "lean_path": env["LEAN_PATH"],
    "checks": [],
}
receipt = root / "research/review2_20261018_verification_receipt.json"
receipt.open("x").close()
commands = [
    [str(lean), "-j", "1", "-o", str(base / "MathGKM/Markov.olean"), "MathGKM/Markov.lean"],
    [str(lean), "-j", "1", "-o", str(base / "MathGKM/MarkovCoverage.olean"), "MathGKM/MarkovCoverage.lean"],
    [str(lean), "-j", "1", "research/plan0001_markov_coverage_replay.lean"],
    [str(checker), "MathGKM.Markov"],
    [str(checker), "MathGKM.MarkovCoverage"],
    ["/opt/homebrew/bin/python3", "research/plan0000_markov_correspondence_checks.py"],
]
for argv in commands:
    started = time.monotonic()
    entry = {"argv": argv, "timeout_seconds": 55}
    try:
        result = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=55)
        entry.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
        if argv == commands[-1] and result.returncode == 0:
            entry["matches_supplied_json"] = json.loads(result.stdout) == json.loads(
                (root / "research/plan0000_markov_correspondence_checks.json").read_text())
    except subprocess.TimeoutExpired as error:
        entry.update(returncode=None, termination="timeout",
                     stdout=(error.stdout or b"").decode(), stderr=(error.stderr or b"").decode())
    except OSError as error:
        entry.update(returncode=None, termination="capability_failure", error=str(error))
    entry["elapsed_seconds"] = time.monotonic() - started
    record["checks"].append(entry)
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(entry), flush=True)
    if entry.get("returncode") != 0:
        break
