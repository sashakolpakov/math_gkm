# H6 unit-specialization nonvanishing checkpoint

Machine-authored 2026-10-18. Trial H6-unit-specialization-nonvanishing;
invention false. Prospective binding:
1e234da72ce60fc31a4393cc9bae91514299e549cdf5614b583d946c49e85da0

Read MISSION.md, all of docs/DESIGN.md, and contract.json. The active contract
is published-markov-6-3-clean-v2 in phase markov. No historical campaign was
rerun. The pinned root source was left unchanged.

The trial began at 13:42:18 UTC. By 13:45:38 UTC the corrected module had
compiled and both importing replays had been launched; both returned exit 0
before this checkpoint. All work, including this checkpoint and evidence
hashing, is bounded by the 300-second deadline, 13:47:18 UTC.

Fresh sequential rebuilds from source succeeded for Markov, MarkovCoverage,
MarkovHomogeneousTransport, MarkovLaurentBridge, and MarkovExchangeRefinement,
using pinned Lean 4.32.2 and installed pinned dependencies. The retained H5
client also replayed successfully using these fresh outputs. Each invocation
and its diagnostics are retained in a separately named JSON file.

New module MathGKM/MarkovUnitNonvanishing.lean establishes positivity of every
sourceFamily frame component at x=y=z=1 over the rationals, for all finite
paths. The induction carries the retained cubic invariant. The retained
exchange_quotients identity writes each new middle component as a positive
sum of squares divided by a positive endpoint. The initial frame evaluates
to (1,5,2).

The retained pathwise chart identity, whose denominator evaluates to 1,
transports positivity to the three homogeneous numerator evaluations.
Consequently all three homogeneous polynomials are nonzero. A nested
polynomial evaluation ring homomorphism biUnit satisfies
biUnit (dehom q) = evaluate 1 1 1 q for every Tri polynomial q; this proves
nonvanishing of the three dehomogenized numerators. The retained evaluation
identity then identifies these polynomials with all three pinned frame
components, proving their nonvanishing.

Attempt 1 failed on a binder name in ring-homomorphism extensionality.
Its complete source snapshot and compiler diagnostics are retained. The
compiler's error recovery printed placeholder-dependent closures for the
failed declarations; these are rejected evidence and do not certify them.
The corrected source compiles with exit 0. A fresh importing client states
the universal positivity and three nonvanishing conclusions explicitly and
replays successfully. Its six printed axiom closures contain exactly
propext, Classical.choice and Quot.sound. No additional assumption was added.

Select committed outcome 1 on this local evidence. These are candidates for
independent checking; this report cannot admit them. No claim of coefficient
positivity, arbitrary-specialization nonvanishing, published-source identity,
Newton polygon correspondence, or root resolution is made. Next target
symbolic realization nonvanishing and quadratic-family uniqueness using the
scoped candidates. No controller or policy change is installed.

The .scratch denial was honored without access or bypass. All generated
sources, build outputs and diagnostics are durable research artifacts, not
temporary files. The storage restriction did not prevent fresh verification.
No network, Git, other workspace, external messaging, or agent was used.
