# Independent reviewer: replay supplied source and supplied clients only.
# No new mathematical targets, experiments, or dependencies.
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd()
stem = 'review4_20261018_independent01'
build = root / 'research' / (stem + '_build')
build.mkdir(exist_ok=False)
lean = Path('/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean')
checker = lean.with_name('leanchecker')
deps = sorted(p / '.lake/build/lib/lean' for p in (root / '.lake/packages').iterdir() if p.is_dir())
env = dict(os.environ, LEAN_PATH=':'.join(map(str, [build] + deps)))
modules = ['MathGKM.Markov', 'MathGKM.MarkovCoverage',
           'MathGKM.MarkovIndexScope', 'MathGKM.MarkovHomogeneousTransport',
           'MathGKM.MarkovRawCoefficientTransport',
           'research.plan0002_markov_index_scope_replay',
           'research.plan0003_markov_homogeneous_transport_replay']
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report = {'purpose': 'independent replay of supplied declarations and clients',
          'binary_hashes': {str(p): sha(p) for p in [lean, checker]},
          'sources': {}, 'checks': [], 'dependency_paths': list(map(str, deps))}
records = json.loads((root / 'inbox/records.json').read_text())
bindings = {}
for receipt in records['receipts']:
    bindings.update(receipt.get('after', {}))
report['snapshot_binding_checks'] = []
for name, expected in bindings.items():
    p = root / name
    actual = sha(p) if p.is_file() else None
    report['snapshot_binding_checks'].append(dict(path=name, expected=expected, actual=actual,
                                                  matches=actual == expected))
def save():
    (root / 'research' / (stem + '_receipt.json')).write_text(json.dumps(report, indent=2) + '\n')
def run(args, operation, module):
    start = time.monotonic()
    try:
        p = subprocess.run(args, cwd=root, env=env, capture_output=True, text=True, timeout=90)
        result = dict(returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)
    except subprocess.TimeoutExpired as e:
        result = dict(returncode=None, termination='timeout', stdout=str(e.stdout), stderr=str(e.stderr))
    result.update(operation=operation, module=module, argv=list(map(str, args)),
                  elapsed_seconds=time.monotonic()-start)
    report['checks'].append(result)
    save()
    print(operation, module, result['returncode'], round(result['elapsed_seconds'], 3), flush=True)
    return result['returncode'] == 0
for module in modules:
    source = root / (module.replace('.', '/') + '.lean')
    report['sources'][str(source.relative_to(root))] = sha(source)
    out = build / (module.replace('.', '/') + '.olean')
    out.parent.mkdir(parents=True, exist_ok=True)
    if not run([str(lean), '-j', '1', '-o', str(out), str(source.relative_to(root))], 'compile', module):
        report['status'] = 'compile_failure'
        save()
        raise SystemExit(1)
for module in modules:
    if not run([str(checker), module], 'kernel_replay', module):
        report['status'] = 'replay_failure'
        save()
        raise SystemExit(1)
report['status'] = 'passed'
report['subprocess_elapsed_seconds'] = sum(c['elapsed_seconds'] for c in report['checks'])
save()
