"""Reviewer-authored foreground replay of supplied sources; no new theorem tasks.

All outputs are retained review evidence, not temporary research artifacts.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path.cwd()
BASE = ROOT / 'research/review8_20261018_validation'
BUILD = BASE / 'build'
LEAN = Path('/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin')
BUILD.joinpath('MathGKM').mkdir(parents=True, exist_ok=True)
PACKAGES = sorted((ROOT / '.lake/packages').iterdir())
ENV = dict(os.environ, LEAN_PATH=':'.join([str(BUILD)] +
    [str(p / '.lake/build/lib/lean') for p in PACKAGES if p.is_dir()]))
RECEIPT = BASE / 'receipts.json'
records = json.loads(RECEIPT.read_text()) if RECEIPT.exists() else []

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for target in sys.argv[2:]:
    mode = sys.argv[1]
    if mode == 'compile':
        source = ROOT / (target.replace('.', '/') + '.lean')
        output = BUILD / (target.replace('.', '/') + '.olean')
        output.parent.mkdir(parents=True, exist_ok=True)
        argv = [str(LEAN / 'lean'), '-o', str(output), str(source)]
    elif mode == 'client':
        source = ROOT / target
        argv = [str(LEAN / 'lean'), str(source)]
    elif mode == 'kernel':
        source = ROOT / (target.replace('.', '/') + '.lean')
        argv = [str(LEAN / 'leanchecker'), target]
    else:
        raise ValueError(mode)
    entry = {'operation': mode, 'target': target, 'source_sha256': digest(source),
             'binary_sha256': digest(Path(argv[0])), 'argv': argv,
             'lean_path': ENV['LEAN_PATH']}
    started = time.monotonic()
    try:
        result = subprocess.run(argv, cwd=ROOT, env=ENV, capture_output=True,
                                text=True, timeout=55)
        entry.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    except (OSError, subprocess.TimeoutExpired) as error:
        entry.update(returncode=None, failure=str(error))
    entry['elapsed_seconds'] = time.monotonic() - started
    records.append(entry)
    RECEIPT.write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps({k: entry[k] for k in ['operation', 'target', 'returncode', 'elapsed_seconds']}), flush=True)
    if entry['returncode'] != 0:
        print(entry.get('stderr', entry.get('failure', '')))
        print(entry.get('stdout', ''))
        sys.exit(1)
