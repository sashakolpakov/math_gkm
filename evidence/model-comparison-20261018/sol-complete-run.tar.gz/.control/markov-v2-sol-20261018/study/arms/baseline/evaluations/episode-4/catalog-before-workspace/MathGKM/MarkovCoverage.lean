import MathGKM.Markov
/- Machine-authored H1-formal-rational-coverage, 2026-10-18. -/
namespace MathGKM.Markov.CoverageTrial
open MathGKM.Markov

def Mediant (f : Frame) : Prop :=
  f.mid.a = f.lo.a + f.hi.a ∧ f.mid.b = f.lo.b + f.hi.b

theorem initial_mediant : Mediant initial := by constructor <;> rfl

theorem advance_mediant (f : Frame) (h : Mediant f) (r : Bool) :
    Mediant (advance f r) := by
  cases r <;> simp_all [Mediant, advance]

theorem frame_mediant (path : List Bool) : Mediant (frame path) := by
  have aux : ∀ (l : List Bool) (f : Frame), Mediant f → Mediant (l.foldl advance f) := by
    intro l
    induction l with
    | nil => intro f h; exact h
    | cons r l ih => intro f h; exact ih _ (advance_mediant f h r)
  exact aux path initial initial_mediant

theorem reach (n : ℕ) : ∀ x y : ℕ, x + y = n → 0 < x → 0 < y →
    Nat.Coprime x y → ∀ f : Frame, Mediant f →
    ∃ path : List Bool,
      (path.foldl advance f).mid.a = x * f.lo.a + y * f.hi.a ∧
      (path.foldl advance f).mid.b = x * f.lo.b + y * f.hi.b := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    intro x y hn hx hy hc f hf
    rcases lt_trichotomy x y with hxy | heq | hyx
    · have hs : x + (y - x) < n := by omega
      have hc' : Nat.Coprime x (y-x) :=
        (Nat.coprime_sub_self_right (Nat.le_of_lt hxy)).mpr hc
      obtain ⟨path, ha, hb⟩ := ih _ hs x (y-x) rfl hx (by omega) hc'
        (advance f true) (advance_mediant f hf true)
      refine ⟨true :: path, ?_, ?_⟩
      · simpa only [List.foldl_cons, advance, ↓reduceIte] using ha.trans (by
          dsimp [advance]
          rcases hf with ⟨hfa, hfb⟩
          rw [hfa]
          calc
            x * (f.lo.a + f.hi.a) + (y-x) * f.hi.a = x * f.lo.a + (x + (y-x)) * f.hi.a := by ring
            _ = x * f.lo.a + y * f.hi.a := by rw [Nat.add_sub_of_le (Nat.le_of_lt hxy)])
      · simpa only [List.foldl_cons, advance, ↓reduceIte] using hb.trans (by
          dsimp [advance]
          rcases hf with ⟨hfa, hfb⟩
          rw [hfb]
          calc
            x * (f.lo.b + f.hi.b) + (y-x) * f.hi.b = x * f.lo.b + (x + (y-x)) * f.hi.b := by ring
            _ = x * f.lo.b + y * f.hi.b := by rw [Nat.add_sub_of_le (Nat.le_of_lt hxy)])
    · have hx1 : x = 1 := by simpa [heq, Nat.Coprime] using hc
      have hy1 : y = 1 := by omega
      refine ⟨[], ?_, ?_⟩
      · simpa [hx1, hy1] using hf.1
      · simpa [hx1, hy1] using hf.2
    · have hs : (x - y) + y < n := by omega
      have hc' : Nat.Coprime (x-y) y :=
        (Nat.coprime_sub_self_left (Nat.le_of_lt hyx)).mpr hc
      obtain ⟨path, ha, hb⟩ := ih _ hs (x-y) y rfl (by omega) hy hc'
        (advance f false) (advance_mediant f hf false)
      refine ⟨false :: path, ?_, ?_⟩
      · simpa only [List.foldl_cons, advance, Bool.false_eq_true, ↓reduceIte] using ha.trans (by
          dsimp [advance]
          rcases hf with ⟨hfa, hfb⟩
          rw [hfa]
          calc
            (x-y) * f.lo.a + y * (f.lo.a + f.hi.a) = ((x-y)+y) * f.lo.a + y * f.hi.a := by ring
            _ = x * f.lo.a + y * f.hi.a := by rw [Nat.sub_add_cancel (Nat.le_of_lt hyx)])
      · simpa only [List.foldl_cons, advance, Bool.false_eq_true, ↓reduceIte] using hb.trans (by
          dsimp [advance]
          rcases hf with ⟨hfa, hfb⟩
          rw [hfb]
          calc
            (x-y) * f.lo.b + y * (f.lo.b + f.hi.b) = ((x-y)+y) * f.lo.b + y * f.hi.b := by ring
            _ = x * f.lo.b + y * f.hi.b := by rw [Nat.sub_add_cancel (Nat.le_of_lt hyx)])

theorem rational_coverage (p q : ℕ) (hp : 0 < p) (hpq : p < q)
    (hc : Nat.Coprime p q) :
    ∃ path : List Bool, (frame path).mid.a = p ∧ (frame path).mid.b = q := by
  have hc' : Nat.Coprime (q-p) p :=
    (Nat.coprime_sub_self_left (Nat.le_of_lt hpq)).mpr hc.symm
  obtain ⟨path, ha, hb⟩ := reach ((q-p)+p) (q-p) p rfl (by omega) hp hc' initial initial_mediant
  refine ⟨path, ?_, ?_⟩
  · simpa [frame, initial] using ha
  · simpa [frame, initial, Nat.sub_add_cancel (Nat.le_of_lt hpq)] using hb

#print axioms rational_coverage
#print axioms frame_mediant
end MathGKM.Markov.CoverageTrial
