import MathGKM.MarkovSymbolicExchange
import MathGKM.Markov
def MathGKM.Target4ad05e3c124286756994b100.Interface := True
def MathGKM.Target4ad05e3c124286756994b100.Transport (StudyInterface : MathGKM.Target4ad05e3c124286756994b100.Interface) : Prop := True
def MathGKM.Target4ad05e3c124286756994b100.Goal (StudyInterface : MathGKM.Target4ad05e3c124286756994b100.Interface) : Prop := ∀ path : List Bool, let f := MathGKM.Markov.LaurentBridgeTrial.sourceFamily MathGKM.Markov.SymbolicExchangeTrial.x MathGKM.Markov.SymbolicExchangeTrial.y MathGKM.Markov.SymbolicExchangeTrial.z path; f.lo ≠ 0 ∧ f.mid ≠ 0 ∧ f.hi ≠ 0
