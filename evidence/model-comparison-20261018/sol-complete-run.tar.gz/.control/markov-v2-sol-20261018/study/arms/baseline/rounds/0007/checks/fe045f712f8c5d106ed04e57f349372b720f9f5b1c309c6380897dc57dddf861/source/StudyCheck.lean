import MathGKM.Target4ad05e3c124286756994b100
import MathGKM.MarkovSymbolicExchange
import Lean
def StudyInterface : MathGKM.Target4ad05e3c124286756994b100.Interface := True.intro
theorem StudyTransport : MathGKM.Target4ad05e3c124286756994b100.Transport StudyInterface := True.intro
theorem StudyObligation : MathGKM.Target4ad05e3c124286756994b100.Goal StudyInterface := MathGKM.Markov.SymbolicExchangeTrial.symbolic_nonzero
