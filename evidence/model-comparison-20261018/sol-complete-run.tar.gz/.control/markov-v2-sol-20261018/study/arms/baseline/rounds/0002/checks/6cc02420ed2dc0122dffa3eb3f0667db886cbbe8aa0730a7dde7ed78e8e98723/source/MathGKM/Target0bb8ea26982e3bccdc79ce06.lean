import MathGKM.MarkovIndexScope
import MathGKM.Markov
def MathGKM.Target0bb8ea26982e3bccdc79ce06.Interface := True
def MathGKM.Target0bb8ea26982e3bccdc79ce06.Transport (StudyInterface : MathGKM.Target0bb8ea26982e3bccdc79ce06.Interface) : Prop := True
def MathGKM.Target0bb8ea26982e3bccdc79ce06.Goal (StudyInterface : MathGKM.Target0bb8ea26982e3bccdc79ce06.Interface) : Prop := ∀ path : List Bool, 0 < (MathGKM.Markov.frame path).mid.a ∧ (MathGKM.Markov.frame path).mid.a < (MathGKM.Markov.frame path).mid.b ∧ Nat.Coprime (MathGKM.Markov.frame path).mid.a (MathGKM.Markov.frame path).mid.b
