# Round 0000: source-correspondence audit

Machine-authored on 2026-10-18. Trial: `H0-source-correspondence`, invention: false.
Binding: `06605f2de1ee1c24e7543c027b4adaf54be5bb34cae8aa88650d64a18691cd24`.
Active contract: `published-markov-6-3-clean-v2`, phase `markov`.
Audit started at 12:32:49 UTC; budget at most 300 seconds. Historical campaigns were not revisited. No controller changes or formal submissions were made.

## Source access and source facts

Read [the publisher's article](https://armj.math.stonybrook.edu/Articles/250708-Winn/index.html) through the permitted `web.run` interface. The requested passages were accessible. Also inspected Section 6 of [arXiv HTML](https://arxiv.org/html/2501.14882), labelled v3, 7 July 2025. Retrieval locators are in `plan0000_markov_source_access.json`; this record is not a full-source snapshot.

Equation (5) supplies the three initial Laurent polynomials. Equations (7)-(9) specify homogeneous numerators in squared variables and their subtractive evolution. Equations (10)-(11) describe the support hull and its inequalities. Definitions 6.1-6.2 impose adjacent non-strict inequalities along the horizontal, vertical and constant-sum directions. Conjecture 6.3 applies this property to the family. Theorem 3.2's proof omits polygon details; those details remain an independent obligation here.

The following calculations and candidate arguments are this audit's own mathematical analysis. They have not been kernel checked or independently certified.

## Initial data and both branches

Write a label as a vector L=(a,b), its numerator as Q_L, and t_L=a+b. Use integer Laurent exponents for

`D_L = x^(a-1) y^(b-1) z^(t_L-1)`.

The initial vectors are L=(0,1), R=(1,1), M=L+R=(1,2). After setting u=x², v=y², w=z², their numerators are respectively

`1`, `u+v`, `(u+v)^2+u*w`.

These yield x, (x²+y²)/z, and ((x²+y²)²+x²z²)/(yz²), so the pinned initial data agree after w=1. The negative x exponent in D_(0,1) is legitimate in a Laurent ring; a future formal translation must not implement it as truncated natural subtraction.

For right=True the new vector is N=M+R=L+2R. Multiplication of the Laurent denominators gives

`xyz*D_R*D_M = D_N`,
`D_N/D_L = x^(2 R.a) y^(2 R.b) z^(2 t_R)`.

Consequently the mutation `k*M_R*M_M-M_L`, with k=(x²+y²+z²)/(xyz), has numerator

`Q_N = (u+v+w)*Q_R*Q_M - u^(R.a)*v^(R.b)*w^t_R*Q_L`.

Setting w=1 is exactly the True branch in `advance`. For right=False interchange the roles of the two endpoints: N=L+M=2L+R, subtract the old R numerator, and the correction factor is `u^(L.a)*v^(L.b)*w^t_L`. This gives exactly the False branch. The False branch uses the same mutation identity with endpoint roles exchanged; numerical orientation of the rational interval does not enter that identity.

As exact initial branch checks the script obtains

`p_(1/3) = (u+v)^3 + 2*u^2 + 2*u*v + u`,

and

`p_(2/3) = (u+v)^4 + 2*u^3 + 5*u^2*v + 4*u*v^2 + v^3 + u^2`.

The latter agrees with the inspected worked example in Section 3.1. These calculations support the translation; universal source identification still needs an explicit source-family definition and an induction theorem linking that definition to Lean's `frame`.

## Rational indexing: a general candidate coverage proof

The following is an unbounded mathematical argument, distinct from the finite experiment.

Maintain ordered endpoint vectors L=(a,b), R=(c,d), determinant `b*c-a*d=1`, and middle vector M=L+R. Both updates preserve the determinant: the new interval is (L,M) on False and (M,R) on True. The initial determinant is one. All denominators are positive. Determinant one makes each endpoint primitive; M is primitive because a common divisor of its coordinates would divide the determinant of L and M. Thus every path gives a reduced rational strictly inside (0,1). Endpoint ordering and strict containment follow from the positive determinant.

Conversely fix any reduced p/q with 0<p<q. Initially set x=q-p and y=p, so `(p,q)=x*L+y*R`, x,y>0, and gcd(x,y)=1. At any step target-minus-middle has the sign of y-x: expanding its cross product gives `(y-x)*(b*c-a*d)`. If x>y, take False and replace the coordinates by (x-y,y), since

`x*L+y*R = (x-y)*L+y*(L+R)`.

If y>x, take True and replace them by (x,y-x), since

`x*L+y*R = x*(L+R)+(y-x)*R`.

The coordinates stay positive and coprime. Their sum strictly decreases until x=y; coprimality then forces x=y=1, so the target vector is precisely the current M. This proves candidate surjectivity onto the interior reduced rationals. Each unequal comparison forces its branch; strict child intervals are disjoint and do not contain their parent middle, giving uniqueness of the address as well. No finite denominator bound enters this argument. This reasoning has not been translated to or checked in Lean. The endpoint rationals 0/1 and 1/1 are handled separately by the root.

## Homogeneity and coefficient recovery

Define homogeneous lifts by the displayed three-variable initial data and branch formulas. Suppose endpoint degrees are t_L-1 and t_R-1 and the middle degree is t_L+t_R-1. On the True branch both summands have total degree

`1 + (t_R-1) + (t_L+t_R-1) = t_L+2*t_R-1`,
`2*t_R + (t_L-1) = t_L+2*t_R-1`.

The False branch follows by exchanging L,R. This proves candidate homogeneous degree bounds by induction, including the degree-zero initial endpoint. A nonzero top-degree coefficient would additionally prove exact degree; it is not needed for unique homogeneous coefficient recovery with the known degree bound.

For any homogeneous lift of prescribed total degree D, the only monomial mapping to u^i v^j under w=1 is `u^i v^j w^(D-i-j)`; none exists if i+j>D. Thus dehomogenization loses no coefficients on this homogeneous component. `Polynomial (Polynomial ℤ)` has outer X=u and constant inner X=v, so `(P.coeff i).coeff j` retrieves the required raw coefficient. There is no factorial or binomial renormalization. This supplies a candidate universal transport argument, conditional on the source-family induction. It does not assert that arbitrary dehomogenization is injective.

## Polygon, directions, zeros, endpoints

For positive a,b, multiplication by ab transforms `i/a+j/b >= 1` to `b*i+a*j >= a*b`. Natural indices implement i,j>=0. For a,b>=1, the natural expression `a+b-1` is ordinary integer subtraction. Therefore the *stated source inequalities* and `InPolygon` agree algebraically. This does not prove that the support hull of every recursively constructed numerator is that polygon. The latter universal Newton-polygon assertion, including absence of boundary cancellation, remains unproved in this audit. The source's Theorem 3.2 is a reported result, not an authorized new Lean assumption. Finite support-containment checks do not establish the hull equality.

Each intersection of the stated convex polygon with a principal lattice line consists of consecutive lattice points. Horizontal triples have coordinates (i,j),(i+1,j),(i+2,j); vertical triples are analogous. Constant-sum triples, oriented in direction (1,-1), are (i,j+2),(i+1,j+1),(i+2,j). Every such triple in the nonnegative quadrant has the corresponding natural parametrization. Reversing a triple preserves its inequality. All three clauses in `WeakLC` consequently use the appropriate non-strict inequality and require every point of the triple to belong to the polygon. The end entries participate whenever there is a triple, but no point outside the line segment is introduced. Lines of one or two points impose no inequalities.

There is no condition that `coeff` be nonzero and no filtering of support. Missing monomials contribute coefficient zero. Thus the root retains interior zeros without assuming saturation. The signs of coefficients are not extra hypotheses of `WeakLC`; proving source-family nonnegativity, if used later, must be a separate result.

For 0/1, do not divide by a=0 in the source inequality: its numerator 1 has singleton support. The pinned inequalities give i+j<=0 and therefore the same singleton. For 1/1 they give i+j=1, the segment joining (1,0),(0,1), matching u+v. Neither endpoint has a principal triple; both endpoint clauses are mathematically vacuous.

## Evidence and outstanding status

Executed `/opt/homebrew/bin/python3 research/plan0000_markov_correspondence_checks.py` with Python 3.14.6. All exact assertions passed. The retained JSON records 15 paths of lengths 0 through 3, checking labels, branch calculations, homogeneous degrees, dehomogenization, nonnegative sample coefficients and polygon containment. It also records successful address recovery for all 489 reduced interior rationals with q<=40. These are calculations under the script's semantics; the script is a manual translation of the Lean definitions, not an execution/refinement proof of Lean.

| Contract obligation | Audit result | Still required |
| --- | --- | --- |
| coverage | General descent argument supplied; bounded checks pass | Formal frame invariants, termination and surjectivity |
| source_family | Initial data and both branches match algebraically | Explicit source-family object and universal induction bridge |
| homogeneity_coefficients | Degree and unique coefficient-recovery arguments supplied | Checked homogeneous lift and coefficient transport |
| polygon | Inequality translation matches; sample containment passes | Independent universal support-hull proof |
| directions_zeros_endpoints | Triple correspondence and endpoint calculations supplied | Checked predicate equivalence with the source interpretation |
| assumptions | No new mathematical assumptions or Lean declarations introduced | Audit dependencies of future proofs under the allowed closure |
| proof_scope | Root quantifies all finite paths and two endpoints | Combine coverage and source correspondence before claiming published-family scope |

No discrepancy in the pinned initial data, branches or conventions was found. The hypothesis is partially supported; all-seven-obligations completion is not claimed. The coverage argument above remains an unchecked proof candidate, and the universal polygon argument is missing. No formal proof attempt was compiled in this audit; the incomplete polygon argument is preserved rather than filled by an assumption. No source-access capability failure occurred. No root proof or refutation follows, and no negative conclusion about provability follows from this bounded trial.

Next choice: retain the single agenda and first formalize rational coverage with the determinant/coordinate descent above, then the homogeneous source-family transport. Keep the independent Newton-polygon proof explicitly open. No policy or executable-program change is proposed or installed. Observed reuse consists of the pinned source definitions in this comparison and the experiment results in this audit; future intended consumers are not reported as use links.

Timing checkpoint: source reading, calculations, the audit draft and input-hash verification were complete by 12:36:04 UTC, 195 seconds after the recorded start. Final checkpoint bookkeeping and reporting remain within the same 300-second invocation cap.
