import MathGKM.MarkovCoverage
/- Machine-authored independent source replay target within the same trial.
   This is local replay, not independent controller admission. -/
example : ∀ p q : ℕ, 0 < p → p < q → Nat.Coprime p q →
    ∃ path : List Bool, (MathGKM.Markov.frame path).mid.a = p ∧
      (MathGKM.Markov.frame path).mid.b = q :=
  MathGKM.Markov.CoverageTrial.rational_coverage

#print axioms MathGKM.Markov.CoverageTrial.rational_coverage
#print axioms MathGKM.Markov.CoverageTrial.frame_mediant
