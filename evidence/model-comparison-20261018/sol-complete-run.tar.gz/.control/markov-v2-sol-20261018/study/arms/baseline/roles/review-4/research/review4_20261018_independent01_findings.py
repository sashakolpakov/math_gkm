# Independent review checkpoint writer. Consumes the actual replay receipts.
import hashlib
import json
from pathlib import Path
import re

base = Path('research/review4_20261018_independent01')
verification_path = Path(str(base) + '_receipt.json')
verification = json.loads(verification_path.read_text())
assert verification['status'] == 'passed'
assert len(verification['checks']) == 14
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
closures = re.findall(r'depends on axioms:\s*\[(.*?)\]',
                      '\n'.join(c['stdout'] for c in verification['checks']), re.S)
assert len(closures) >= 11
assert all(set(a.strip() for a in c.split(',')) <= allowed for c in closures)
records = json.loads(Path('inbox/records.json').read_text())
experiment_path = Path(str(base) + '_experiment_receipt.json')
experiment = json.loads(experiment_path.read_text())
assert experiment['returncode'] == 0 and experiment['output_equals_supplied_json']
def finding(path, message):
    return dict(path=str(path), sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(), finding=message)
costs = {role: sum(r['elapsed_seconds'] for r in records['receipts'] if r['role'] == role)
         for role in ['proposer', 'researcher', 'reviewer', 'selector']}
checks = verification['snapshot_binding_checks']
present = [c for c in checks if c['actual'] is not None]
missing = [c['path'] for c in checks if c['actual'] is None]
assert all(c['matches'] for c in present)
payload = dict(
    findings=[
        finding('MathGKM/MarkovIndexScope.lean',
                'Freshly checked generated_label_valid and exact_interior_index characterize exactly the coprime natural pairs 0<p<q reached by the actual frame. The reverse direction explicitly reuses rational_coverage. This is universal label coverage and validity; it proves neither path uniqueness nor published-polynomial identity.'),
        finding('MathGKM/MarkovHomogeneousTransport.lean',
                'Freshly checked evaluation identifies the entire lifted frame after w=1 with the pinned frame. homogeneous_support supplies homogeneity in prescribed total degree a+b-1 for all three labels and every path. This proves a local recurrence adapter, with no positivity, exact nonzero degree, support-hull or published-family identification theorem.'),
        finding('MathGKM/MarkovRawCoefficientTransport.lean',
                'Freshly checked raw_recovery recovers the raw coefficient at (i,j,D-i-j) of any homogeneous Q when i+j<=D; raw_zero covers i+j>D. The supplied client checks these generic interfaces. No normalization or new mathematical assumption is introduced. Application to published numerators still requires their identification with the lift.'),
        finding(verification_path,
                'Independent fresh compilation and leanchecker replay passed for five supplied mathematical modules and both supplied importing clients (14 successful subprocesses). Printed closures for coverage, indexing and transport contain only propext, Classical.choice and Quot.sound. Executable hashes match the supplied validator record. This evidence validates the checked declarations, not the Python host or the publication correspondence.'),
        finding('MathGKM/Markov.lean',
                'Bytes match the pinned root hash. Conjecture63 remains a proposition definition, with separate endpoints, all paths, three triple directions and unfiltered coefficients. No supplied closed proof or exact negation establishes it. Indexing and coefficient transport do not imply the required log-concavity inequalities.'),
        finding('research/plan0000_markov_source_correspondence.md',
                'The audit offers algebraic source interpretations but explicitly leaves source-family induction and universal polygon equality open. The supplied access record saves locators and interpretations rather than primary article passages. Local homogeneity and indexing are now independently checked; the full hash-bound English/source audit remains incomplete.'),
        finding(experiment_path,
                'Rerunning only the supplied experiment reproduced its JSON exactly: 15 path frames and 489 reduced interior rationals with denominator at most 40. Its translated arithmetic checks do not test log-concavity, prove universal polygon equality, or certify a Python-to-Lean refinement. No new cases or holdout tasks were introduced.'),
        finding('inbox/records.json',
                f'All {len(present)} available latest after-snapshots match their recorded hashes; {len(missing)} earlier reviewer/selector attachments are absent locally, so their reports were not used as proof evidence. Round-0003 has failure_within_time_budget and null payload despite surviving successful compiler receipts. Current independent replay validates surviving bytes without changing that process outcome or establishing completion within its deadline. Role receipts identify gpt-6.1-sol; they do not measure Astra performance.'),
        finding('inbox/records.json',
                'Transfer has status invalid_frozen_context, eligible=false, policy_comparison=false and no task outcomes. The supplied catalog receipt records successful compilations followed by a timeout during StudyCheck kernel replay at the 120-second budget; checked=false. This is an infrastructure/budget failure, not a mathematical rejection, improvement, regression or unprovability result.'),
        finding('MathGKM/ContinuationObligations.lean',
                'The source defines executable model steps and generic simulation obligations, not a concrete favorable switch or Python/OS simulation. The record leaves whole-continuation comparison, host refinement, costs/environment and independent guarded installation open. No certified persistent switch is evidenced.')
    ],
    correctness='Accept the independently compiled, kernel-replayed indexing, homogeneous-lift and raw-coefficient declarations as partial checked mathematics under the permitted axioms. The pinned Conjecture63 and its negation remain unproved.',
    scope='Active Markov contract only. Exact interior-label coverage and local coefficient transport are checked. Published-family identity, universal Newton-polygon identification, the remaining independent English/source correspondence audit, and log-concavity remain open. No historical campaign or new mathematical research was performed.',
    transfer='Not assessable: the supplied frozen-context validation timed out, transfer is ineligible, and no completed task outcomes exist. Observed source reuse is visible in imports and theorem calls; it establishes no policy improvement or cross-task transfer.',
    costs=(f'Supplied role elapsed times total {sum(costs.values()):.6f} seconds: planning {costs["proposer"]:.6f}, research {costs["researcher"]:.6f}, prior review {costs["reviewer"]:.6f}, selection {costs["selector"]:.6f}. '
           f'The separately recorded current catalog failure consumed {records["episode_transfer"]["catalog_failure"]["elapsed_seconds"]:.6f} seconds. '
           f'This review added {verification["subprocess_elapsed_seconds"]:.6f} seconds of fresh Lean compilation/replay and {experiment["elapsed_seconds"]:.6f} seconds reproducing the existing experiment. '
           'Nested compiler times are not added again to role times; these sums are not end-to-end wall time. Money and normalized usage are unknown, raw usage is unverified and absent for timed-out rounds, and total current-review provider cost is unavailable.'),
    recommendation='Retain these checked lemmas as partial progress. Withhold root completion, full source correspondence, transfer and certified-improvement claims. Preserve failed attempts and the original timed-out process outcomes. Checkpoint: research/review4_20261018_independent01_findings.json.'
)
out = Path(str(base) + '_findings.json')
out.write_text(json.dumps(payload, indent=2) + '\n')
print(json.dumps(dict(path=str(out), sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
                     missing_earlier_attachments=missing, payload=payload)))
