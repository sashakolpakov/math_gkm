import MathGKM.MarkovIndexScope
/- Machine-authored independent client replay within H2 trial. -/
example : ∀ path : List Bool,
    0 < (MathGKM.Markov.frame path).mid.a ∧
    (MathGKM.Markov.frame path).mid.a < (MathGKM.Markov.frame path).mid.b ∧
    Nat.Coprime (MathGKM.Markov.frame path).mid.a (MathGKM.Markov.frame path).mid.b :=
  MathGKM.Markov.IndexScopeTrial.generated_label_valid

example : ∀ p q : ℕ,
    (∃ path : List Bool, (MathGKM.Markov.frame path).mid.a = p ∧
      (MathGKM.Markov.frame path).mid.b = q) ↔
    0 < p ∧ p < q ∧ Nat.Coprime p q :=
  MathGKM.Markov.IndexScopeTrial.exact_interior_index

#print axioms MathGKM.Markov.IndexScopeTrial.frame_boundsDet
#print axioms MathGKM.Markov.IndexScopeTrial.generated_label_valid
#print axioms MathGKM.Markov.IndexScopeTrial.exact_interior_index
#check MathGKM.Markov.Conjecture63
