# H5 source comparison

Machine-authored, 2026-10-18. Trial H5-exchange-refinement, invention false.
Primary source inspected through web.run:
https://armj.math.stonybrook.edu/Articles/250708-Winn/index.html

Equations (1)–(3) give quadratic mutation, the cubic relation with
k=(x²+y²+z²)/(xyz), and the subtractive mutation kXY-Z.
Equation (5) agrees with sourceStart: lo=x, hi=(x²+y²)/z,
mid=((x²+y²)²+x²z²)/(yz²). The True branch replaces lo and
the False branch replaces hi, with permutation into the next frame.
The source's exchange relation in Section 2 agrees with both proposed
product identities. No discrepancy was found in these equations.

This is an English comparison, not independent source correspondence
certification. Generic-field quotient statements need explicit nonzero
divisors. Ordered-field positivity, if established, applies only within
that domain and cannot by itself establish symbolic family identity.
Polygon correspondence and Conjecture 6.3 remain separate obligations.
