"""Machine-authored audit calculations, round-0000, 2026-10-18.
Exact integer arithmetic; experiments do not certify Lean propositions.
Run: /opt/homebrew/bin/python3 research/plan0000_markov_correspondence_checks.py
"""
import hashlib
import itertools
import json
import math
import platform
from pathlib import Path


def add(*terms):
    out = {}
    for scale, poly in terms:
        for exponent, coefficient in poly.items():
            out[exponent] = out.get(exponent, 0) + scale * coefficient
    return {e: c for e, c in out.items() if c}


def mul(p, q):
    out = {}
    for e, c in p.items():
        for f, d in q.items():
            g = tuple(x + y for x, y in zip(e, f))
            out[g] = out.get(g, 0) + c * d
    return {e: c for e, c in out.items() if c}


def seeds(n):
    one = {(0,) * n: 1}
    u = {(1, 0) + (0,) * (n - 2): 1}
    v = {(0, 1) + (0,) * (n - 2): 1}
    w = {(0, 0, 1): 1} if n == 3 else one
    uv = add((1, u), (1, v))
    s = add((1, uv), (1, w))
    p12 = add((1, mul(uv, uv)), (1, mul(u, w)))
    return s, ((0, 1, one), (1, 2, p12), (1, 1, uv))


def advance(frame, right, n):
    lo, mid, hi = frame
    endpoint, old = (hi, lo) if right else (lo, hi)
    a, b, p = endpoint
    shift = (a, b, a + b) if n == 3 else (a, b)
    correction = mul({shift: 1}, old[2])
    s, _ = seeds(n)
    new = (a + mid[0], b + mid[1],
           add((1, mul(mul(s, p), mid[2])), (-1, correction)))
    return (mid, new, hi) if right else (lo, new, mid)


def dehom(p):
    out = {}
    for (i, j, k), c in p.items():
        out[i, j] = out.get((i, j), 0) + c
    return {e: c for e, c in out.items() if c}


def rational_path(p, q):
    # Coordinates relative to endpoints 0/1 and 1/1.
    x, y = q - p, p
    path = []
    while x != y:
        assert x > 0 and y > 0
        if y > x:
            path.append(True)
            y -= x
        else:
            path.append(False)
            x -= y
    assert x == y == 1
    return path


def label_frame(path):
    lo, hi = (0, 1), (1, 1)
    for right in path:
        mid = tuple(x + y for x, y in zip(lo, hi))
        if right:
            lo = mid
        else:
            hi = mid
    return lo, tuple(x + y for x, y in zip(lo, hi)), hi


def main():
    checked = 0
    for length in range(4):
        for path in itertools.product((False, True), repeat=length):
            _, f2 = seeds(2)
            _, f3 = seeds(3)
            for right in path:
                f2 = advance(f2, right, 2)
                f3 = advance(f3, right, 3)
            assert tuple((a, b) for a, b, _ in f2) == label_frame(path)
            lo, mid, hi = f2
            assert lo[1] * hi[0] - lo[0] * hi[1] == 1
            for (a, b, p2), (_, _, p3) in zip(f2, f3):
                assert all(sum(e) == a + b - 1 for e in p3)
                assert dehom(p3) == p2
                assert all(c >= 0 for c in p3.values())
                assert all(a * b <= b * i + a * j and i + j <= a + b - 1
                           for i, j in p2)
            checked += 1
    _, initial = seeds(2)
    p13 = advance(initial, False, 2)[1][2]
    p23 = advance(initial, True, 2)[1][2]
    expected13 = {(3, 0): 1, (2, 1): 3, (1, 2): 3, (0, 3): 1,
                  (2, 0): 2, (1, 1): 2, (1, 0): 1}
    expected23 = {(4, 0): 1, (3, 1): 4, (2, 2): 6, (1, 3): 4,
                  (0, 4): 1, (3, 0): 2, (2, 1): 5, (1, 2): 4,
                  (0, 3): 1, (2, 0): 1}
    assert p13 == expected13
    assert p23 == expected23
    rationals = 0
    max_path = 0
    for q in range(2, 41):
        for p in range(1, q):
            if math.gcd(p, q) == 1:
                path = rational_path(p, q)
                assert label_frame(path)[1] == (p, q)
                max_path = max(max_path, len(path))
                rationals += 1
    inputs = ["contract.json", "MathGKM/Markov.lean", "MISSION.md", "docs/DESIGN.md"]
    result = {
        "provenance": "Machine-authored, round-0000, H0-source-correspondence",
        "python": platform.python_version(),
        "pinned_input_hashes": {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in inputs},
        "paths_checked_lengths_0_through_3": checked,
        "checks": ["initial numerator arithmetic", "both branch examples",
                   "P_2/3 matches source Section 3.1 example",
                   "frame label mediants and endpoint determinant",
                   "homogeneous 3-variable recurrence dehomogenizes to 2-variable recurrence",
                   "sample homogeneous degrees, nonnegative coefficients, polygon containment",
                   "subtractive rational-address algorithm"],
        "reduced_interior_rationals_q_at_most_40": rationals,
        "largest_tested_address_length": max_path,
        "p13": [[*e, c] for e, c in sorted(p13.items())],
        "p23": [[*e, c] for e, c in sorted(p23.items())],
        "status": "All exact assertions passed; finite experiment only. No Lean proof or universal polygon theorem."
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
