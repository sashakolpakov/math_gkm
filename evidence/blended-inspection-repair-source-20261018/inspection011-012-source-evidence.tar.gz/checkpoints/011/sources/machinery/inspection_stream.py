"""Trusted generic Lean producer for lossless, shared Expr records (schema 2).

This is validator code, never proposal/proof text. No expression pretty printer
or candidate digest is used. Pointer equality only memoizes the same live Expr.
"""

PRELUDE = r'''
open Lean
private def j (xs : List Json) : Json := toJson xs
private def s (x : String) : Json := toJson x
private partial def nm : Name → Json
  | .anonymous => j [s "anonymous"]
  | .str p v => j [s "str", nm p, toJson v]
  | .num p v => j [s "num", nm p, toJson v]
private partial def lv : Level → Json
  | .zero => j [s "zero"]
  | .succ u => j [s "succ", lv u]
  | .max u v => j [s "max", lv u, lv v]
  | .imax u v => j [s "imax", lv u, lv v]
  | .param n => j [s "param", nm n]
  | .mvar n => j [s "mvar", nm n.name]
private def sub (v : Substring.Raw) : Json :=
  j [toJson v.str, toJson v.startPos.byteIdx, toJson v.stopPos.byteIdx]
private def si : SourceInfo → Json
  | .none => j [s "none"]
  | .original a b c d => j [s "original", sub a, toJson b.byteIdx, sub c, toJson d.byteIdx]
  | .synthetic a b c => j [s "synthetic", toJson a.byteIdx, toJson b.byteIdx, toJson c]
private def pre : Syntax.Preresolved → Json
  | .namespace n => j [s "namespace", nm n]
  | .decl n fs => j [s "decl", nm n, toJson fs]
private partial def syn : Syntax → Json
  | .missing => j [s "missing"]
  | .node i k as => j [s "node", si i, nm k, toJson (as.map syn)]
  | .atom i v => j [s "atom", si i, toJson v]
  | .ident i r v ps => j [s "ident", si i, sub r, nm v, toJson (ps.map pre)]
private def dv : DataValue → Json
  | .ofString v => j [s "string", toJson v]
  | .ofBool v => j [s "bool", toJson v]
  | .ofName v => j [s "name", nm v]
  | .ofNat v => j [s "nat", toJson v]
  | .ofInt v => j [s "int", toJson v]
  | .ofSyntax v => j [s "syntax", syn v]
private def bi : BinderInfo → Json
  | .default => s "default"
  | .implicit => s "implicit"
  | .strictImplicit => s "strictImplicit"
  | .instImplicit => s "instImplicit"
private structure Stream where
  handle : IO.FS.Handle
  bytes : Nat := 0
  nodes : Nat := 0
  decls : Nat := 0
  cache : Std.HashMap Lean.Meta.Sym.ExprPtr Nat := {}
private abbrev M := StateRefT Stream IO
private def fail (category : String) : M α := do
  let st ← get
  let record := j [s "failure", s category, toJson st.nodes, toJson st.decls]
  let text := record.compress ++ "\n"
  if st.bytes + text.utf8ByteSize <= 33554432 then
    st.handle.putStr text
    st.handle.flush
  throw <| IO.userError "trusted inspection did not complete"
private def emit (v : Json) : M Unit := do
  let text := v.compress ++ "\n"
  let st ← get
  if text.utf8ByteSize > 1048576 || st.bytes + text.utf8ByteSize > 33554432 then
    fail "artifact_size_limit"
  st.handle.putStr text
  modify fun st => { st with bytes := st.bytes + text.utf8ByteSize }
private partial def expr (e : Expr) (depth : Nat := 0) : M Nat := do
  if depth > 4096 then fail "expression_depth_limit"
  if let some id := (← get).cache[{expr := e}]? then return id
  let (tag, fields, children) ← match e with
    | .bvar n => pure ("bvar", j [toJson n], #[])
    | .fvar n => pure ("fvar", j [nm n.name], #[])
    | .mvar n => pure ("mvar", j [nm n.name], #[])
    | .sort u => pure ("sort", j [lv u], #[])
    | .const n us => pure ("const", j [nm n, toJson (us.map lv)], #[])
    | .app f a => pure ("app", j [], #[← expr f (depth+1), ← expr a (depth+1)])
    | .lam n t b i => pure ("lam", j [nm n, bi i], #[← expr t (depth+1), ← expr b (depth+1)])
    | .forallE n t b i => pure ("forallE", j [nm n, bi i], #[← expr t (depth+1), ← expr b (depth+1)])
    | .letE n t v b d => pure ("letE", j [nm n, toJson d], #[← expr t (depth+1), ← expr v (depth+1), ← expr b (depth+1)])
    | .lit (.natVal n) => pure ("nat", j [toJson n], #[])
    | .lit (.strVal v) => pure ("string", j [toJson v], #[])
    | .mdata d b => pure ("mdata", toJson (d.entries.map fun (n,v) => j [nm n, dv v]), #[← expr b (depth+1)])
    | .proj n i b => pure ("proj", j [nm n, toJson i], #[← expr b (depth+1)])
  let id := (← get).nodes
  if id >= 1000000 then fail "expression_node_limit"
  emit <| j [s "expr", toJson id, s tag, fields, toJson children]
  modify fun st => { st with nodes := id+1, cache := st.cache.insert {expr := e} id }
  return id
private def kind : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"
private def declaration (env : Environment) (n : Name) : M Unit := do
  let some info := env.checked.get.find? n | fail "unknown_dependency"
  let t ← expr info.type
  let b ← match info.value? (allowOpaque := true) with
    | none => pure Json.null
    | some v => return toJson (← expr v)
  let origin := match env.getModuleIdxFor? n with
    | none => "local"
    | some idx => toString env.header.moduleNames[idx]!
  emit <| j [s "decl", toJson (toString n), toJson origin, s (kind info),
    toJson info.isUnsafe, toJson (info.levelParams.map nm), toJson t, b]
  modify fun st => {st with decls := st.decls+1}
'''


def program(module, declarations, required, catalog_modules):
    names = lambda xs: ', '.join('`'+x for x in xs)
    # Each selected module is enumerated in full, including unused declarations.
    return 'import '+module+'\nimport Lean\nimport Lean.Meta.Sym.ExprPtr\n'+PRELUDE+f'''
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let handle ← IO.FS.Handle.mk "declarations.json" IO.FS.Mode.write
  let action : M Unit := do
    emit <| j [s "header", s "math-gkm.inspection-dag.v2", toJson ([{', '.join('s '+__import__('json').dumps(x) for x in declarations)}] : List Json)]
    let mut emitted : NameHashSet := {{}}
    let mut catalog : Array String := #[]
    for (n, _) in env.constants.toList do
      if let some idx := env.getModuleIdxFor? n then
        if ([{names(catalog_modules)}] : List Name).contains env.header.moduleNames[idx]! then
          if catalog.size >= 200000 then fail "catalog_node_limit"
          declaration env n
          emitted := emitted.insert n
          catalog := catalog.push (toString n)
    emit <| j [s "catalog", toJson catalog]
    for root in ([{names(declarations)}] : List Name) do
      let some ci := env.checked.get.find? root | fail "missing_root"
      if (ci.value? (allowOpaque := true)).isNone then fail "missing_body"
      let mut todo := #[root]
      let mut enqueued : NameHashSet := {{}}
      enqueued := enqueued.insert root
      let mut pos := 0
      let mut edges := 0
      let mut duplicates := 0
      let mut axioms : Array String := #[]
      let mut constants : Array String := #[]
      while pos < todo.size do
        let n := todo[pos]!
        pos := pos+1
        let some info := env.checked.get.find? n | fail "unknown_dependency"
        let mut deps := info.type.getUsedConstants.toList
        if let some body := info.value? (allowOpaque := true) then
          deps := deps ++ body.getUsedConstants.toList
        match info with
        | .axiomInfo _ =>
          unless [``propext, ``Classical.choice, ``Quot.sound].contains n do
            fail "forbidden_axiom"
          axioms := axioms.push (toString n)
        | .inductInfo v => deps := deps ++ v.ctors
        | _ => pure ()
        for dep in deps do
          if edges >= 200000 then fail "dependency_edge_limit"
          edges := edges+1
          if enqueued.contains dep then duplicates := duplicates+1
          else
            if todo.size >= 200000 then fail "dependency_node_limit"
            enqueued := enqueued.insert dep
            todo := todo.push dep
        let origin := match env.getModuleIdxFor? n with
          | none => "local"
          | some idx => toString env.header.moduleNames[idx]!
        if origin.startsWith "MathGKM." || n == root || origin == "StudyCheck" then
          if !emitted.contains n then
            if (← get).decls >= 200000 then fail "catalog_node_limit"
            declaration env n
            emitted := emitted.insert n
          constants := constants.push (toString n)
      if root == `{declarations[0]} then
        for n in ([{names(required)}] : List Name) do
          unless enqueued.contains n do fail "missing_required"
      emit <| j [s "root", toJson (toString root), toJson axioms, toJson constants,
        toJson pos, toJson edges, toJson duplicates]
    let st ← get
    emit <| j [s "end", toJson st.nodes, toJson st.decls, toJson ({len(declarations)} : Nat), toJson catalog.size]
  let _ ← liftIO <| action.run {{handle := handle}}
  liftIO <| handle.flush
  liftIO <| IO.println "GKM_DECLARATIONS_FILE_V2:declarations.json"
'''
