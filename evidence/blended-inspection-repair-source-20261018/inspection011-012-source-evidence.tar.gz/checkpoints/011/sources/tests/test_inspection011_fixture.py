"""Supervisor-input integration selectors. NEVER run during source construction.

Missing fixture is a failure, never a skipped/easier substitute. Inputs are own
engineering cases, not evaluator payloads. Source copies preserve original bytes.
"""
import importlib.util
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from machinery import proof_audit, study_transfer
from machinery.study_common import ROOT, read, sha, write, digest


class Supervisor011(unittest.TestCase):
    def inputs(self):
        path=ROOT/'local.scratch/inspection011-fixture.json'
        expected=os.environ.get('GKM_INSPECTION011_FIXTURE_SHA256')
        self.assertIsNotNone(expected,'Supervisor must supply immutable fixture hash after source review')
        self.assertEqual(sha(path),expected)
        value=read(path)
        self.assertEqual(value['schema'],'math-gkm.inspection011.fixture.v1')
        self.assertEqual(value['supervisor_selected'],True)
        self.assertEqual(value['unchanged_original_claim_context_dependencies'],True)
        self.assertEqual({c['tag'] for c in value['cases']}, {'large_pilot','neutral','full_mathlib'})
        return value

    def run_case(self,case,checker=study_transfer.check_task):
        directory=Path(tempfile.mkdtemp(dir=ROOT/'.scratch',prefix='inspection011-'))
        ws=directory/'workspace'; ws.mkdir()
        origin=ROOT/case['source_directory']
        self.assertTrue(origin.resolve().is_relative_to((ROOT/'local.scratch').resolve()))
        for name,expected in case['files_sha256'].items():
            source=origin/name
            self.assertTrue(source.resolve().is_relative_to(origin.resolve()))
            self.assertFalse(source.is_symlink()); self.assertEqual(sha(source),expected)
            target=ws/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(source,target)
        (ws/'.lake').mkdir()
        (ws/'.lake/packages').symlink_to(ROOT/'.lake/packages',target_is_directory=True)
        self.assertEqual(digest(case['task']),case['task_hash'])
        self.assertEqual(digest(case['solution']),case['solution_hash'])
        self.assertEqual(case['required'],case['task']['required_constants'])
        result=checker(ws,case['task'],case['solution'],directory/'check',case['seconds'],
            live=True,required=case['required'],contract=read(ws/'contract.json'))
        # Record actual status, including infrastructure failures, before asserting.
        checks=result.get('checks',[])
        metrics=dict(tag=case['tag'],fixture_binding=digest(case),checked=result['checked'],
            status=result['status'],elapsed_seconds=result.get('elapsed_seconds'),
            artifact_bytes=(directory/'check/source/declarations.json').stat().st_size
                if (directory/'check/source/declarations.json').is_file() else None,
            traversals=[r.get('traversal') for r in result.get('declarations',[])],
            resources=[c.get('resources') for c in checks],
            finished_sha256=sha(directory/'check/FINISHED.json'),result_sha256=sha(directory/'check/result.json'))
        write(directory/'ENGINEERING_MEASUREMENTS.json',metrics)
        return result

    def test_supervisor_large_neutral_full_mathlib_actual_admission(self):
        for case in self.inputs()['cases']:
            with self.subTest(tag=case['tag']):
                result=self.run_case(case)
                self.assertEqual(result['checked'],case['expected_checked'],result)
                self.assertEqual({c['operation'] for c in result['checks']},
                    {'compile','kernel_replay','trusted_premise_inspection'})
                self.assertEqual(result['inspection_schema'],proof_audit.SCHEMA)

    def test_differential_old_new_complete_closures(self):
        prior=ROOT/'evidence/construction-v3/source-audit-010'
        manifest=read(prior/'SOURCE_MANIFEST.json')
        modules={}
        for name in ('proof_audit','study_transfer'):
            path=prior/'sources/machinery'/(name+'.py')
            self.assertEqual(sha(path),manifest['files_sha256']['machinery/'+name+'.py'])
            spec=importlib.util.spec_from_file_location('machinery._inspection011_old_'+name,path)
            module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); modules[name]=module
        modules['study_transfer'].proof_audit=modules['proof_audit']
        # Supervisor chooses cases whose old complete artifact fits; the large
        # case is separately mandatory and cannot be substituted here.
        for case in self.inputs()['differential_cases']:
            old=self.run_case(case,modules['study_transfer'].check_task)
            new=self.run_case(case)
            self.assertTrue(old['checked'],old); self.assertTrue(new['checked'],new)
            for a,b in zip(old['declarations'],new['declarations']):
                self.assertEqual(a['name'],b['name'])
                self.assertEqual(set(a['axioms']),set(b['axioms']))
                self.assertEqual({c['name'] for c in a['constants']},{c['name'] for c in b['constants']})
                self.assertEqual({c['name'] for c in a['catalog']},{c['name'] for c in b['catalog']})
            self.assertEqual(old['component_use_checked'],new['component_use_checked'])
