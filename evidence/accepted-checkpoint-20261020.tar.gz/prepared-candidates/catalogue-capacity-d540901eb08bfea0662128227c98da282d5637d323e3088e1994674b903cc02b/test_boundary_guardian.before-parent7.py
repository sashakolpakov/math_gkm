"""Pure guardian fixtures: no actual signals, processes, research or installed writes."""
import copy
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('boundary_guardian_fixture',Path(__file__).with_name('boundary_guardian.py'))
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)


class FakeHost:
    def __init__(self,closed=None,requested=False):
        self.calls=[];self.records=[];self.closed=closed;self.requested=requested;self.check_count=0
    def lease(self):return contextlib.nullcontext()
    def prepare(self):self.calls.append('prepare');return 'guardian-birth'
    def announce(self,**value):self.records.append(value);self.calls.append('guardian_ready')
    def paused(self):return True
    def record(self,**value):self.records.append(value);self.calls.append(value.get('phase'))
    def check(self):self.check_count+=1;self.calls.append('check')
    def watcher_signal(self,number):self.calls.append(number)
    def closure(self):return self.closed
    def handoff_requested(self):return self.requested


class GuardFixtures(unittest.TestCase):
    def request(self):return {'authorized_at':100,'hold_deadline_wall':102,'outer_deadline_wall':10000}
    def run_guard(self,host,**kwargs):
        clock=[100.]
        def sleep(seconds):clock[0]+=max(1,seconds)
        return g.guard(host,self.request(),now=lambda:clock[0],sleep=sleep,**kwargs)

    def test_guardian_identity_is_recorded_before_first_pause(self):
        host=FakeHost();self.run_guard(host)
        self.assertLess(host.calls.index('guardian_ready'),host.calls.index(signal.SIGSTOP))
        self.assertEqual(host.records[0]['guardian_birth'],'guardian-birth')

    def test_timeout_automatically_releases_only_supervisor(self):
        host=FakeHost();self.assertEqual(self.run_guard(host),'deadline_released')
        self.assertEqual([v for v in host.calls if isinstance(v,signal.Signals)],[signal.SIGSTOP,signal.SIGCONT])

    def test_short_deadline_and_original_cleanup_ceiling_are_both_enforced(self):
        for delta in [{'hold_deadline_wall':1001},{'outer_deadline_wall':2000},{'hold_deadline_wall':99},{'authorized_at':101}]:
            request={**self.request(),**delta}
            with self.subTest(delta=delta),self.assertRaisesRegex(RuntimeError,'deadline'):g.deadline(request,100)

    def test_wall_rollback_cannot_extend_the_short_monotonic_hold(self):
        host=FakeHost();mono=[100.]
        def sleep(seconds):mono[0]+=1
        self.assertEqual(g.guard(host,self.request(),now=lambda:100,monotonic=lambda:mono[0],sleep=sleep),'deadline_released')
        self.assertEqual(mono[0],102);self.assertEqual(host.calls[-1],signal.SIGCONT)

    def test_term_or_int_cancel_releases_on_independent_guardian_path(self):
        for label in ('TERM','INT'):
            host=FakeHost()
            with self.subTest(label=label),self.assertRaisesRegex(RuntimeError,'guardian signal'):
                self.run_guard(host,cancelled=lambda:signal.SIGSTOP in host.calls)
            self.assertIn(signal.SIGCONT,host.calls);self.assertNotIn(signal.SIGTERM,host.calls)

    def test_stop_hold_keeper_failure_or_observer_error_automatically_release(self):
        for reason in ('STOP','cleanup hold','keeper gone','observer timeout'):
            host=FakeHost();original=host.check
            def check():
                original()
                if host.check_count==2:raise RuntimeError(reason)
            host.check=check
            with self.subTest(reason=reason),self.assertRaisesRegex(RuntimeError,reason):self.run_guard(host)
            self.assertIn(signal.SIGCONT,host.calls);self.assertNotIn(signal.SIGTERM,host.calls)

    def test_live_controller_handoff_is_refused_and_resumed(self):
        host=FakeHost(requested=True)
        with self.assertRaisesRegex(RuntimeError,'live or unverified'):self.run_guard(host)
        self.assertNotIn(signal.SIGTERM,host.calls);self.assertIn(signal.SIGCONT,host.calls)

    def test_exact_rechecked_normal_closure_allows_term_then_continue(self):
        host=FakeHost(closed={'controller_exit_code':0,'state_sha256':'fixed'},requested=True)
        self.assertEqual(self.run_guard(host),'handoff_released')
        signals=[v for v in host.calls if isinstance(v,signal.Signals)]
        self.assertEqual(signals,[signal.SIGSTOP,signal.SIGTERM,signal.SIGCONT])
        self.assertIn('handoff_intent',host.calls)

    def test_changing_closure_never_terminates_supervisor(self):
        host=FakeHost(closed={'zero':True},requested=True);values=iter([{'zero':True},{'changed':True}]);host.closure=lambda:next(values)
        with self.assertRaisesRegex(RuntimeError,'closure changed'):self.run_guard(host)
        self.assertNotIn(signal.SIGTERM,host.calls)

    def test_native_birth_total_failure_is_explicit_unreleased_uncertainty(self):
        host=FakeHost();original=host.watcher_signal
        def signals(number):
            if number==signal.SIGCONT:raise RuntimeError('native birth observer unavailable')
            original(number)
        host.watcher_signal=signals
        with self.assertRaisesRegex(RuntimeError,'release: native birth'):self.run_guard(host,cancelled=lambda:signal.SIGSTOP in host.calls)
        self.assertEqual(host.records[-1]['phase'],'unreleased_needs_reconciliation')

    def test_no_shared_checkpoint_write_occurs_before_pause_or_after_continue(self):
        host=FakeHost();self.run_guard(host)
        first_pause=host.calls.index(signal.SIGSTOP);last_continue=host.calls.index(signal.SIGCONT)
        self.assertNotIn('paused',host.calls[:first_pause])
        self.assertEqual(last_continue,len(host.calls)-1)

    def test_owner_advance_in_prepause_window_is_released_without_shared_write(self):
        host=FakeHost();original=host.check
        def check():
            original()
            if host.check_count==2:raise RuntimeError('owner advanced')
        host.check=check
        with self.assertRaisesRegex(RuntimeError,'owner advanced'):self.run_guard(host)
        self.assertEqual(host.records,[{'guardian_pid':os.getpid(),'guardian_birth':'guardian-birth'}])
        self.assertEqual(host.calls[-1],signal.SIGCONT)

    def test_unavailable_birth_and_journal_cannot_hide_unreleased_status(self):
        host=FakeHost();original_signal=host.watcher_signal;original_record=host.record
        def signals(number):
            if number==signal.SIGCONT:raise RuntimeError('native observer unavailable')
            original_signal(number)
        def record(**value):
            if value.get('phase')=='unreleased_needs_reconciliation':raise RuntimeError('safe journal unavailable')
            original_record(**value)
        host.watcher_signal=signals;host.record=record
        with self.assertRaisesRegex(RuntimeError,'unreleased_needs_reconciliation.*unresolved journal unavailable'):
            self.run_guard(host,cancelled=lambda:signal.SIGSTOP in host.calls)

    def test_mismatched_birth_is_never_signaled(self):
        host=g.Host.__new__(g.Host);host.request={'watcher':{'pid':123,'birth':'old'}}
        host.native=lambda pid:{'birth':'replacement','status':2}
        with patch.object(g.os,'kill') as kill,self.assertRaisesRegex(RuntimeError,'birth changed'):
            host.watcher_signal(signal.SIGCONT)
        kill.assert_not_called()

    def test_native_lookup_failure_never_signals_unknown_pid(self):
        host=g.Host.__new__(g.Host);host.request={'watcher':{'pid':123,'birth':'old'}}
        host.native=lambda pid:(_ for _ in ()).throw(RuntimeError('observer unavailable'))
        with patch.object(g.os,'kill') as kill,self.assertRaisesRegex(RuntimeError,'observer unavailable'):
            host.watcher_signal(signal.SIGCONT)
        kill.assert_not_called()


class ClosureFixtures(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='math-gkm-boundary-fixture-');self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name);self.arm=root/'study/arms/exploration';self.job=self.arm/'jobs/plan-fixture'
        self.job.mkdir(parents=True);self.study=root/'study'
        digest=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        def read(path):return json.loads(Path(path).read_text())
        def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
        self.common=SimpleNamespace(read=read,sha=sha,digest=digest,load_state=read)
        self.receipt={'finished':101,'resources':{'owned_identities':{'123':'worker'}},
            'payload':{'resources':{'owned_identities':{'666':'PRIVATE_PAYLOAD_MUST_NOT_BE_PROJECTED'}}}}
        (self.job/'receipt.json').write_text(json.dumps(self.receipt))
        (self.job/'process.json').write_text(json.dumps({'pid':123,'watchdog_pid':124}))
        result=self.arm/'rounds/0031/checks/math/item/result.json';result.parent.mkdir(parents=True)
        result.write_text(json.dumps({'finished':102,'checks':[{'resources':{'owned_identities':{'789':'validator'}}}],
            'task':{'resources':{'owned_identities':{'999':'PRIVATE_TASK_MUST_NOT_BE_PROJECTED'}}}}))
        self.state={'round':32,'status':'finite_budget_finished; root_open','active':None,'active_intent':None,'resolution':None,
            'receipts':[str(self.job)],'counted_jobs':['plan-fixture'],'receipt_hashes':{str(self.job):digest(self.receipt)}}
        (self.arm/'state.json').write_text(json.dumps(self.state));(self.study/'protocol.json').write_text('{"rounds":32}')
        (self.study/'seal.json').write_text('{}')
        self.host=g.Host.__new__(g.Host);self.host.root=root;self.host.study=self.study;self.host.common=self.common
        self.host.request={'controller':{'pid':7954,'birth':'controller'},'watcher':{'pid':7835,'birth':'watcher'}}
        self.controller={'birth':'controller','ppid':7835,'status':5,'exit_status':0,'pgid':7954}
        self.own={'birth':'guardian','ppid':os.getppid(),'status':2,'pgid':os.getpid()}
        self.host.guardian_birth='guardian'
        self.host.native=lambda pid:self.controller if pid==7954 else self.own if pid==os.getpid() else None
        self.snapshot=f'7954 7835 7954\n{os.getpid()} {os.getppid()} {os.getpid()}\n88888 {os.getpid()} {os.getpid()}\n'
        self.host.resources=SimpleNamespace(observation=lambda argv:self.snapshot,_LAST_OBSERVER=(88888,('/bin/ps','-axo','pid=,ppid=,pgid=')))
        self.host.free=lambda path:True

    def test_mechanical_registry_binds_complete_counted_ledger_and_all_resources(self):
        value=g.closed_ownership(self.common,self.arm,self.state)
        self.assertEqual(value['owners'],{123:['worker'],789:['validator']})
        self.assertEqual(value['unknown_pids'],[124]);self.assertEqual(value['receipt_count'],1)
        self.assertEqual(value['resource_records'],2)
        self.assertNotIn('PRIVATE',json.dumps(value));self.assertNotIn('payload',json.dumps(value))

    def test_activation_singleton_lease_excludes_a_second_guardian(self):
        self.host.ops=self.study
        with self.host.lease():
            with self.assertRaises(BlockingIOError):
                with self.host.lease():pass

    def test_empty_or_truncated_observer_table_cannot_certify_group_absence(self):
        for output in ('','7954 7835 7954\n',self.snapshot.replace('88888','77777')):
            self.host.resources.observation=lambda argv:output
            with self.subTest(output=output),self.assertRaisesRegex(RuntimeError,'incomplete'):
                self.host.closure()

    def test_missing_or_changed_counted_receipt_blocks_handoff(self):
        self.state['counted_jobs'].append('unaccounted')
        with self.assertRaisesRegex(RuntimeError,'inventory differs'):g.closed_ownership(self.common,self.arm,self.state)
        self.state['counted_jobs'].pop();self.state['receipt_hashes'][str(self.job)]='wrong'
        with self.assertRaisesRegex(RuntimeError,'exactly finalized'):g.closed_ownership(self.common,self.arm,self.state)

    def test_zero_exit_zombie_and_complete_ownership_produce_closed_projection(self):
        value=self.host.closure();self.assertEqual(value['controller_exit_code'],0)
        self.assertEqual(value['owned_native_count'],2);self.assertEqual(value['private_group_count'],3)

    def test_live_nonzero_signaled_wrong_birth_or_wrong_parent_cannot_be_normal(self):
        for delta in [{'status':2},{'exit_status':256},{'exit_status':9},{'birth':'replacement'},{'ppid':999}]:
            previous=dict(self.controller);self.controller.update(delta)
            try:
                if delta=={'status':2}:self.assertIsNone(self.host.closure())
                else:
                    with self.subTest(delta=delta),self.assertRaises(RuntimeError):self.host.closure()
            finally:self.controller.clear();self.controller.update(previous)

    def test_owned_native_group_survivors_and_held_lease_block_handoff(self):
        self.host.resources.observation=lambda argv:self.snapshot+'888 1 123\n'
        with self.assertRaisesRegex(RuntimeError,'group survivor'):self.host.closure()
        self.host.resources.observation=lambda argv:self.snapshot;self.host.free=lambda path:False
        with self.assertRaisesRegex(RuntimeError,'lease'):self.host.closure()

    def test_multiple_historical_births_are_preserved_and_new_group_is_distinguished(self):
        result=self.arm/'rounds/0031/checks/math/item/result.json'
        value=json.loads(result.read_text());value['checks'].append({'resources':{'owned_identities':{'123':'second-old-birth'}}})
        result.write_text(json.dumps(value))
        registry=g.closed_ownership(self.common,self.arm,self.state)
        self.assertEqual(registry['owners'][123],['second-old-birth','worker'])
        self.host.native=lambda pid:self.controller if pid==7954 else {'birth':'new-unrelated-birth','status':2,'pgid':123} if pid==123 else self.own if pid==os.getpid() else None
        self.host.resources.observation=lambda argv:self.snapshot+'123 1 123\n888 123 123\n'
        closed=self.host.closure();self.assertEqual(closed['positively_reused_native_pids'],1)
        self.assertEqual(closed['positively_replaced_private_groups'],1)
        self.host.native=lambda pid:self.controller if pid==7954 else {'birth':'worker','status':2,'pgid':123} if pid==123 else self.own if pid==os.getpid() else None
        with self.assertRaisesRegex(RuntimeError,'native owner remains'):self.host.closure()

    def test_unknown_watchdog_birth_is_a_gap_not_an_attestation(self):
        self.host.native=lambda pid:self.controller if pid==7954 else {'birth':'unidentified','status':2} if pid==124 else None
        with self.assertRaisesRegex(RuntimeError,'lacks historical birth'):self.host.closure()

    def test_final_state_still_uncertain_is_never_closed(self):
        self.state['active_intent']={'not_inspected':'present'};(self.arm/'state.json').write_text(json.dumps(self.state))
        with self.assertRaisesRegex(RuntimeError,'incomplete or uncertain'):self.host.closure()


class ExistingExecuteTimingFixtures(unittest.TestCase):
    def test_existing_execute_never_stops_an_already_exited_child_at_loop_boundaries(self):
        path=Path.cwd()/'.bootstrap/concept-driver-20261020/general-continuation/follow.py'
        module=importlib.util.spec_from_file_location('existing_follow_timing_fixture',path);follow=importlib.util.module_from_spec(module);module.loader.exec_module(follow)
        for scenario in ('closed_before_poll','closed_before_controls','closed_before_birth','closed_nonzero','live_negative'):
            with tempfile.TemporaryDirectory(prefix='math-gkm-execute-timing-') as tmp:
                calls={'controls':0,'birth':0};root=Path(tmp);study=root/'study';study.mkdir()
                child=SimpleNamespace(pid=123456,returncode=0 if scenario=='closed_before_poll' else 1 if scenario=='closed_nonzero' else None)
                child.poll=lambda:child.returncode
                def controls():
                    calls['controls']+=1
                    if scenario=='closed_before_controls' and calls['controls']==2:child.returncode=0
                    if calls['controls']>=(3 if scenario=='closed_before_birth' else 2):raise RuntimeError('mock signal')
                def birth(*args):
                    calls['birth']+=1
                    if scenario=='closed_before_birth' and calls['birth']==2:child.returncode=0
                    return 'mock-birth'
                def stop(*args):child.returncode=-15;return True
                with patch.object(follow,'OPS',root),patch.object(follow,'ROOT',root),patch.object(follow,'controls',side_effect=controls),patch.object(follow,'checkpoint'),patch.object(follow.subprocess,'Popen',return_value=child),patch.object(follow.ops,'own_birth',side_effect=birth),patch.object(follow.ops,'stop_child',side_effect=stop) as stopper,patch.object(follow.time,'sleep'):
                    with self.subTest(scenario=scenario),self.assertRaises(RuntimeError):follow.execute(study,1e30)
                    self.assertEqual(stopper.called,scenario=='live_negative')
                    self.assertFalse((study/'STOP.json').exists())


if __name__=='__main__':unittest.main(verbosity=2)
