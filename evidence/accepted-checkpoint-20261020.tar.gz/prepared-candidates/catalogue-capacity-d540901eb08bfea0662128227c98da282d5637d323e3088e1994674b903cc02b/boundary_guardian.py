"""Explicit, bounded supervisor-only boundary hold. Importing never acts.

Activation requires a separately reviewed source pin and an explicit scalar
operator request in argv. FOLLOW is first updated only after observed pause. This code never launches research or changes its
source, authority, protocol, state, budgets, receipts or STOP markers.
"""
import argparse
import contextlib
import errno
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import sys
import time

BASE_IMPLEMENTATION='590648a8eb6c9ee626c63077cbdbd7963aa53d946ceac9cfe3f73e4591b63b7d'
PRIOR_SOURCE='cb6c57cd808e25118baed054fc11b8bb0c971280f41981d2f964b702ee3072b6'
PARENT_SEQUENCE=7
NEXT_SEQUENCE=8
NORMAL_ROUND=36
MAX_HOLD_SECONDS=900
CLEANUP_SECONDS=1900
CANCELLED=False


def deadline(request,now):
    start,end,outer=(request[k] for k in ('authorized_at','hold_deadline_wall','outer_deadline_wall'))
    if (any(type(v) not in (int,float) or not math.isfinite(v) for v in (start,end,outer)) or
        start>now or end<=now or end>start+MAX_HOLD_SECONDS or end>outer-CLEANUP_SECONDS):
        raise RuntimeError('fixed hold deadline invalid; no pause')
    return end


def guard(host,request,**timing):
    with host.lease():return _guard(host,request,**timing)


def _guard(host,request,*,now=time.time,monotonic=time.monotonic,sleep=time.sleep,cancelled=lambda:False):
    """Birth-confirm guardian before pause; shared writes only while stopped."""
    automatic=request.get('handoff_on_verified_close',False)
    if type(automatic) is not bool:raise RuntimeError('handoff_on_verified_close must be a strict boolean')
    wall_start=now();end=deadline(request,wall_start);mono_end=monotonic()+min(MAX_HOLD_SECONDS,end-wall_start)
    expired=lambda:now()>=end or monotonic()>=mono_end
    may_be_paused=confirmed=False;result='released';error=None
    try:
        identity=host.prepare()
        host.announce(guardian_pid=os.getpid(),guardian_birth=identity)  # Bounded stdout, no live FOLLOW RMW.
        host.check()
        if cancelled() or expired():raise RuntimeError('guardian cancelled or expired before pause')
        may_be_paused=True
        host.watcher_signal(signal.SIGSTOP)
        host.check()  # Abort/release if the owner advanced in the pre-pause window.
        if not host.paused():raise RuntimeError('supervisor pause not observed')
        confirmed=True
        host.record(phase='paused',guardian_pid=os.getpid(),guardian_birth=identity,paused_at=now())
        last_closed=None
        while not expired():
            if cancelled():raise RuntimeError('guardian signal; release supervisor')
            host.check()
            closed=host.closure()
            if closed and closed!=last_closed:
                host.record(phase='boundary_ready',closure=closed);last_closed=closed
            if (automatic and closed) or host.handoff_requested():
                if not closed:raise RuntimeError('live or unverified controller; handoff refused')
                host.check()
                if host.closure()!=closed:raise RuntimeError('closure changed before handoff')
                if cancelled() or expired():raise RuntimeError('hold expired before handoff')
                host.record(phase='handoff_intent',closure=closed,automatic_verified_close=automatic)
                host.watcher_signal(signal.SIGTERM)
                result='handoff_released';break
            sleep(min(1,max(0,min(end-now(),mono_end-monotonic()))))
        else:result='deadline_released'
    except BaseException as exc:
        error=type(exc).__name__+': '+str(exc)
    finally:
        if may_be_paused:
            if confirmed:
                try:host.record(phase='release_intent',planned_result=result,error=error,finished=now())
                except BaseException as exc:error=(error or '')+'; journal: '+str(exc)
            try:host.watcher_signal(signal.SIGCONT)
            except BaseException as exc:
                result='unreleased_needs_reconciliation';error=(error or '')+'; release: '+str(exc)
                if confirmed:
                    try:host.record(phase=result,error=error,finished=now())
                    except BaseException as exc:error+='; unresolved journal unavailable: '+str(exc)
        # No shared FOLLOW write after successful CONT: the watcher owns it again.
    if error:raise RuntimeError(result+': '+error)
    return result


def closed_ownership(common,arm,state):
    """Project operational ownership only; never expose role/task/request contents."""
    receipts=state['receipts'];counted=state['counted_jobs'];ledger=state['receipt_hashes']
    if len(receipts)!=len(set(receipts)) or set(ledger)!=set(receipts) or len(counted)!=len(set(counted)):
        raise RuntimeError('closed receipt ledger is incomplete')
    jobs={str(p):p for p in (arm/'jobs').iterdir() if p.is_dir()}
    if set(jobs)!=set(receipts) or {p.name for p in jobs.values()}!=set(counted):
        raise RuntimeError('counted job/receipt inventory differs')
    owners={};unknown=set();files={};resource_records=0
    def project(value):
        nonlocal resource_records
        if not isinstance(value,dict):return
        resource=value.get('resources')
        if isinstance(resource,dict):
            native=resource.get('owned_identities')
            if not isinstance(native,dict):raise RuntimeError('resource ownership schema unavailable')
            resource_records+=1
            for pid,birth in native.items():
                pid=int(pid)
                if pid<=0 or not isinstance(birth,str) or not birth:raise RuntimeError('invalid recorded native identity')
                owners.setdefault(pid,set()).add(birth)
        # Only operational subprocess records are traversed, never payload/answers/tasks.
        for key in ('checks','probes'):
            rows=value.get(key,[])
            if isinstance(rows,list):
                for row in rows:project(row)
    for path in jobs.values():
        receipt=common.read(path/'receipt.json')
        if common.digest(receipt)!=ledger[str(path)] or 'finished' not in receipt:
            raise RuntimeError('counted receipt not exactly finalized')
    total=count=0
    for directory,dirs,names in os.walk(arm,followlinks=False):
        dirs[:]=[name for name in dirs if name not in ('workspace','snapshots','inherited','source','build','.scratch','history','__pycache__') and not (Path(directory)/name).is_symlink()]
        for name in names:
            count+=1
            if count>20000:raise RuntimeError('closed operational inventory bound')
            if name not in ('receipt.json','result.json','process.json','watchdog.json'):continue
            path=Path(directory)/name
            if path.is_symlink():raise RuntimeError('operational metadata symlink')
            total+=path.stat().st_size
            if total>256*1024**2 or path.stat().st_size>64*1024**2:raise RuntimeError('closed operational metadata bound')
            value=common.read(path);relative=str(path.relative_to(arm));files[relative]=common.sha(path)
            if name in ('process.json','watchdog.json'):
                for key in ('pid','watchdog_pid'):
                    if key in value:unknown.add(int(value[key]))
            else:project(value)
    if not resource_records:raise RuntimeError('no complete closed resource registry')
    return {'owners':{pid:sorted(births) for pid,births in owners.items()},'unknown_pids':sorted(unknown-set(owners)),'groups':sorted(set(owners)|unknown),
        'files_binding':common.digest(files),'ledger_binding':common.digest({'receipts':receipts,'counted_jobs':counted,'receipt_hashes':ledger}),
        'receipt_count':len(receipts),'operational_files':len(files),'resource_records':resource_records}


class Host:
    def __init__(self,root,pin,request):
        self.root=Path(root).resolve();self.ops=self.root/'.bootstrap/concept-driver-20261020/general-continuation'
        self.path=self.ops/'FOLLOW.json';sys.path.insert(0,str(self.root))
        from machinery import resources,study_common
        self.resources=resources;self.common=study_common
        self.request=request
        if (hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=pin or self.request.get('source_sha256')!=pin or
            self.request.get('schema')!='math-gkm.boundary-hold.v1' or self.request.get('authorized') is not True):
            raise RuntimeError('exact reviewed guardian request/source pin required')
        self.study=Path(self.request['study'])
        if (self.study!=self.root/'.scratch/concept-driver-20261020-follow-000007' or
            self.request.get('current_sequence')!=PARENT_SEQUENCE or self.request.get('next_sequence')!=NEXT_SEQUENCE):
            raise RuntimeError('exact parent7 to destination8 scope required')
        if type(self.request.get('handoff_on_verified_close',False)) is not bool:
            raise RuntimeError('handoff_on_verified_close must be a strict boolean')

    @contextlib.contextmanager
    def lease(self):
        with (self.ops/'boundary_hold.lock').open('a') as stream:
            fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
            yield

    def read(self):return json.loads(self.path.read_text())

    def announce(self,**fields):
        print(json.dumps({'guardian_ready':True,**fields},sort_keys=True),flush=True)

    def paused(self):return self.same('watcher',live=True)['status']==4

    def record(self,**updates):
        if not self.paused():raise RuntimeError('shared guardian journal requires observed stopped supervisor')
        value=self.read();hold=value.get('boundary_hold')
        if hold is not None and hold.get('request')!=self.request:
            self.verify_prior_hold(hold)
            hold={'request':self.request,'previous_hold_sha256':self.request['prior_hold_sha256'],'previous_hold':hold}
        elif hold is None:hold={'request':self.request}
        hold.update(updates);value['boundary_hold']=hold;self.common.write(self.path,value)

    def native(self,pid):
        # Includes stopped processes and unreaped exit status, never reaps.
        c,lib,BSDInfo,_=self.resources.darwin_api();info=BSDInfo();c.set_errno(0)
        size=lib.proc_pidinfo(pid,3,1,c.byref(info),c.sizeof(info))
        if size==0 and c.get_errno()==errno.ESRCH:return None
        if size!=c.sizeof(info) or info.pid!=pid:raise RuntimeError('native birth observer unavailable')
        return {'birth':str(info.start_sec)+':'+str(info.start_usec),'status':info.status,'ppid':info.ppid,
            'exit_status':info.xstatus,'pgid':info.pgid}

    def same(self,key,*,live=False):
        expected=self.request[key];value=self.native(expected['pid'])
        if value is not None and value['birth']!=expected['birth']:raise RuntimeError(key+' PID birth changed')
        if live and (value is None or value['status']==5):raise RuntimeError(key+' is not live')
        return value

    def watcher_signal(self,number):
        value=self.same('watcher')
        if value is None:return  # Never signal a replacement or an unknown identity.
        os.kill(self.request['watcher']['pid'],number)

    def prepare(self):
        self.check();watcher=self.same('watcher',live=True);self.same('controller',live=True)
        if watcher['status']==4:raise RuntimeError('supervisor already stopped by another owner')
        own=self.native(os.getpid())
        if own is None or own['status']==5:raise RuntimeError('guardian birth unavailable')
        self.guardian_birth=own['birth'];return own['birth']

    def check(self):
        value=self.read()
        prior=value.get('boundary_hold')
        if prior is not None and prior.get('request')!=self.request:self.verify_prior_hold(prior)
        elif prior is not None and 'previous_hold' in prior:
            if prior.get('previous_hold_sha256')!=self.request.get('prior_hold_sha256'):raise RuntimeError('retained prior hold binding changed')
            self.verify_prior_hold(prior['previous_hold'])
        if value.get('current_study')!=str(self.study) or value.get('phase')!='research_running' or value.get('next_sequence')!=PARENT_SEQUENCE:raise RuntimeError('supervisor moved from current owned epoch')
        for role,key in [('operator','watcher'),('controller','controller'),('caffeinate','keeper')]:
            if (value.get(role+'_pid'),value.get(role+'_birth'))!=(self.request[key]['pid'],self.request[key]['birth']):
                raise RuntimeError('current native ownership changed')
        self.same('watcher',live=True);self.same('keeper',live=True)
        if (value.get('current_resume',{}).get('deadline_wall')!=self.request['outer_deadline_wall'] or
            self.common.digest(self.common.implementation())!=BASE_IMPLEMENTATION):raise RuntimeError('original epoch wall/source changed')
        for path in [self.ops/'STOP.json',self.study/'STOP.json',self.root/'.scratch/resources/UNRESOLVED_CLEANUP.json']:
            if path.exists():raise RuntimeError('STOP or cleanup hold; release supervisor')
        if (self.root/'.scratch/concept-driver-20261020-follow-000008').exists():raise RuntimeError('destination already started')

    def verify_prior_hold(self,prior):
        old=prior.get('request',{})
        if (self.common.digest(prior)!=self.request.get('prior_hold_sha256') or
            old.get('source_sha256')!=PRIOR_SOURCE or old.get('study')!=str(self.root/'.scratch/concept-driver-20261020-follow-000006') or
            old.get('watcher')!=self.request.get('watcher') or prior.get('phase')!='release_intent' or
            prior.get('planned_result')!='deadline_released' or prior.get('error') is not None or
            prior.get('handoff_requested') is True or old.get('handoff_on_verified_close',False) is not False or
            type(old.get('hold_deadline_wall')) not in (int,float) or not math.isfinite(old['hold_deadline_wall']) or
            old['hold_deadline_wall']>time.time()):
            raise RuntimeError('exact expired closed parent6 hold reconciliation required')
        for owner in ({'pid':prior.get('guardian_pid'),'birth':prior.get('guardian_birth')},old.get('controller',{})):
            if type(owner.get('pid')) is not int or not owner.get('birth'):raise RuntimeError('prior owner binding incomplete')
            current=self.native(owner['pid'])
            if current is not None and current['birth']==owner['birth']:
                raise RuntimeError('prior guardian/controller is not absent')

    def free(self,path):
        with path.open('rb') as stream:
            try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:return False
        return True

    def handoff_requested(self):return self.read()['boundary_hold'].get('handoff_requested') is True

    def closure(self):
        process=self.same('controller')
        if process is None:raise RuntimeError('controller disappeared without observed zero exit')
        if process['status']!=5:return None
        if process['ppid']!=self.request['watcher']['pid']:raise RuntimeError('controller parent binding changed')
        code=process['exit_status']
        if not os.WIFEXITED(code) or os.WEXITSTATUS(code)!=0:raise RuntimeError('controller did not exit normally with code zero')
        state_path=self.study/'arms/exploration/state.json';state=self.common.load_state(state_path)
        protocol=self.common.read(self.study/'protocol.json')
        if (state.get('status')!='finite_budget_finished; root_open' or state['round']!=NORMAL_ROUND or protocol['rounds']!=NORMAL_ROUND or
            state.get('active') is not None or state.get('active_intent') is not None or state.get('resolution') is not None):
            raise RuntimeError('finite boundary incomplete or uncertain')
        projection={k:self.common.sha(self.study/name) for k,name in [('state_sha256','arms/exploration/state.json'),('seal_sha256','seal.json'),('protocol_sha256','protocol.json')]}
        registry=closed_ownership(self.common,self.study/'arms/exploration',state)
        replaced={}
        for pid,births in registry['owners'].items():
            info=self.native(pid)
            if info is not None and not (pid==self.request['controller']['pid'] and info==process):
                if info['birth'] in births:raise RuntimeError('recorded native owner remains')
                replaced[pid]=info  # Every recorded old birth is positively absent.
        for pid in registry['unknown_pids']:
            if self.native(pid) is not None:raise RuntimeError('watchdog/worker PID lacks historical birth; closure uncertain')
        groups=set(registry['groups'])|{process['pgid']};members={pgid:set() for pgid in groups}
        argv=['/bin/ps','-axo','pid=,ppid=,pgid='];table={}
        for row in self.resources.observation(argv).splitlines():
            pid,ppid,pgid=map(int,row.split())
            if pid in table:raise RuntimeError('duplicate observer row')
            table[pid]=(ppid,pgid)
            if pgid in groups:members[pgid].add(pid)
        observer=self.resources._LAST_OBSERVER;own=self.native(os.getpid())
        if (not own or own['birth']!=self.guardian_birth or table.get(os.getpid())!=(own['ppid'],own['pgid']) or
            table.get(self.request['controller']['pid'])!=(process['ppid'],process['pgid']) or
            not observer or observer[1]!=tuple(argv) or table.get(observer[0])!=(os.getpid(),own['pgid'])):
            raise RuntimeError('incomplete native/controller/observer snapshot')
        replaced_groups=0
        for pgid,pids in members.items():
            if not pids or pids=={self.request['controller']['pid']}:continue
            # An explicitly new birth leading a newly instantiated group proves
            # historical group identity replacement, even if its number recycled.
            if pgid in replaced and replaced[pgid]['pgid']==pgid and pgid in pids:
                replaced_groups+=1;continue
            raise RuntimeError('owned private group survivor or ambiguous group identity')
        if not all(self.free(path) for path in [self.study/'controller.lock',self.root/'.scratch/resources/heavy.lock']):
            raise RuntimeError('controller or heavy lease remains held')
        return {**projection,'round':NORMAL_ROUND,'controller_exit_code':0,**{k:v for k,v in registry.items() if k not in ('owners','unknown_pids','groups')},
            'owned_native_count':sum(len(births) for births in registry['owners'].values()),'private_group_count':len(registry['groups']),
            'positively_reused_native_pids':len(replaced),'positively_replaced_private_groups':replaced_groups}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path.cwd());parser.add_argument('--source-sha256',required=True)
    parser.add_argument('--request-json',required=True,help='Explicit scalar operator request; no live FOLLOW seed write')
    parser.add_argument('--activate',action='store_true');args=parser.parse_args()
    if len(args.request_json)>4096:raise RuntimeError('bounded scalar request required')
    host=Host(args.root,args.source_sha256,json.loads(args.request_json));deadline(host.request,time.time())
    if not args.activate:print('prepared only; explicit reviewed activation required');return
    def stop(signum,frame):
        global CANCELLED
        CANCELLED=True
    for number in (signal.SIGTERM,signal.SIGINT):signal.signal(number,stop)
    print(guard(host,host.request,cancelled=lambda:CANCELLED))


if __name__=='__main__':main()
