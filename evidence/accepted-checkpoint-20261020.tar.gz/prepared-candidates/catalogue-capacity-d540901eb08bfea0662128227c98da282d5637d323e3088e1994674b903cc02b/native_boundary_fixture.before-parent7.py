"""Neutral <=10s Darwin ABI fixture. Signals only this process's own children."""
import errno
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def run():
    sys.path.insert(0,str(Path.cwd()))
    from machinery.resources import darwin_api
    c,lib,BSDInfo,_=darwin_api();start=time.monotonic();children=[];rows=[];cleanup=[]
    def native(pid):
        info=BSDInfo();c.set_errno(0)
        size=lib.proc_pidinfo(pid,3,1,c.byref(info),c.sizeof(info))
        if size==0 and c.get_errno()==errno.ESRCH:return None
        if size!=c.sizeof(info) or info.pid!=pid:raise RuntimeError('fixture native observation failed')
        if info.ppid!=os.getpid():raise RuntimeError('fixture child parent mismatch')
        return {'pid':pid,'birth':str(info.start_sec)+':'+str(info.start_usec),'status':info.status,'xstatus':info.xstatus}
    def wait_for(child,predicate):
        end=min(start+7.5,time.monotonic()+.75)
        while time.monotonic()<end:
            value=native(child.pid)
            if value is not None and predicate(value):return value
            time.sleep(.005)
        raise RuntimeError('fixture native condition timed out')
    def spawn(argv):
        if time.monotonic()-start>6:raise RuntimeError('fixture work budget exhausted')
        child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        children.append(child);return child
    def alarm(signum,frame):raise RuntimeError('fixture hard work deadline')
    previous=signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,8)
    error=None
    try:
        child=spawn(['/bin/sleep','4']);initial=wait_for(child,lambda value:value['status']!=5)
        assert native(child.pid)['birth']==initial['birth'];os.kill(child.pid,signal.SIGSTOP)
        stopped=wait_for(child,lambda value:value['status']==4)
        assert stopped['birth']==initial['birth'];os.kill(child.pid,signal.SIGCONT)
        resumed=wait_for(child,lambda value:value['status'] not in (4,5))
        assert resumed['birth']==initial['birth']
        child.terminate();child.wait(timeout=.75)
        rows.append({'case':'own_child_stop_continue','birth_unchanged':True,'stopped_status':stopped['status'],
            'resumed_status':resumed['status'],'reaped':True})
        for code in (0,7):
            child=spawn(['/bin/sh','-c','exit '+str(code)])
            zombie=wait_for(child,lambda value:value['status']==5)
            assert native(child.pid)['birth']==zombie['birth']
            assert os.WIFEXITED(zombie['xstatus']) and os.WEXITSTATUS(zombie['xstatus'])==code
            actual=child.wait(timeout=.75);assert actual==code
            rows.append({'case':'own_child_exit_'+str(code),'zombie_status':zombie['status'],'raw_xstatus':zombie['xstatus'],
                'decoded_exit':actual,'birth_unchanged':True,'reaped':True})
    except BaseException as exc:error=type(exc).__name__+': '+str(exc)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        end=min(start+10,time.monotonic()+2)
        for child in children:
            # An unreaped direct child cannot be a recycled foreign PID. Popen
            # rechecks/reaps before signaling; no existing process is targeted.
            if child.poll() is None:
                child.send_signal(signal.SIGCONT);child.terminate()
                try:child.wait(timeout=max(.01,min(.5,end-time.monotonic())))
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=max(.01,end-time.monotonic()))
            cleanup.append(child.returncode is not None)
        signal.signal(signal.SIGALRM,previous)
    elapsed=time.monotonic()-start
    return {'passed':error is None and len(rows)==3 and all(cleanup) and elapsed<=10,'error':error,
        'elapsed_seconds':elapsed,'hard_bound_seconds':10,'signals_only_own_throwaway_children':True,
        'all_fixture_children_reaped':all(cleanup),'cases':rows,
        'scope':'native Darwin ABI fixture only; no real guardian/follower/controller signals, models, Lean or harness edits'}


if __name__=='__main__':
    result=run();source=Path(__file__);result['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
    output=source.with_name('NATIVE_BOUNDARY_FIXTURE_RESULT.json')
    output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True,indent=2));raise SystemExit(0 if result['passed'] else 1)
