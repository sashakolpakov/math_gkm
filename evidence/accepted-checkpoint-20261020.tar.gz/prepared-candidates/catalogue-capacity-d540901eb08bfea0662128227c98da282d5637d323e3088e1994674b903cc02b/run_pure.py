"""Temporary namespace overlay for offline candidate controls; no installation."""
import importlib.util
from pathlib import Path
import sys
import unittest

CANDIDATE=Path(__file__).resolve().parent
REPOSITORY=Path.cwd().resolve()
if not (REPOSITORY/'machinery/study_common.py').is_file():
    raise SystemExit('run from the existing math_gkm repository')
sys.path[:0]=[str(CANDIDATE),str(REPOSITORY)]
suite=unittest.defaultTestLoader.discover(str(CANDIDATE/'tests'))
path=CANDIDATE/'.bootstrap/concept-driver-20261020/general-continuation/test_continue_machine.py'
spec=importlib.util.spec_from_file_location('candidate_ops_controls',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
