"""Offline budget/transport controls. No models, compilers or proof attempts."""
import contextlib
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from machinery import study, study_transfer as transfer
from machinery import study_research_feedback as feedback, study_concepts as concepts
from machinery.study_common import Invalid, digest, read, write

CANDIDATE = Path(__file__).resolve().parents[1]
OPSPATH = CANDIDATE/'.bootstrap/concept-driver-20261020/general-continuation/continue_machine.py'
spec = importlib.util.spec_from_file_location('catalogue_candidate_ops', OPSPATH)
ops = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ops)


def protocol(**changes):
    return dict(study.DEFAULT, transport='live', rounds=12, episode_rounds=2,
        call_seconds=1800, adaptation_seconds=1800, validation_seconds=900,
        arm_seconds=180000, max_calls=64, meta_calls=32,
        knowledge_checks_per_round=3, proposal_repairs=1, policy_trials=1,
        policy_trial_rounds=2, **changes)


def comparison():
    return {'status':'valid_finite_budget_comparison', 'eligible':True,
        'all_frozen_declarations_retained':True, 'task_gains':['private-target'],
        'transfer':['private-target'], 'regressions':[],
        'binding':{'adaptation_seconds_each':1800,
            'validation_seconds_each_task':900, 'catalog_seconds_each':1800},
        'sides':{'private':'PRIVATE_CANARY'}, 'catalog_failure':{'private':'PRIVATE_CANARY'}}


class CatalogueCapacity(unittest.TestCase):
    def test_catalogue_derived_cap_and_hard_ceiling(self):
        for ordinary, expected in ((1,2),(90,180),(899,1798),(900,1800),(1200,1800),(1800,1800)):
            with self.subTest(ordinary=ordinary):
                self.assertEqual(transfer.catalogue_seconds({'validation_seconds':ordinary}),expected)

    def test_invalid_cap_basis_rejected(self):
        for value in (0,-1,1801,True,900.0,'900'):
            with self.subTest(value=value), self.assertRaises(Invalid):
                transfer.catalogue_seconds({'validation_seconds':value})

    def test_ordinary_protocol_and_main_validation_unchanged(self):
        p=protocol(); before=copy.deepcopy(p); study.validate_protocol(p)
        self.assertEqual(p,before); self.assertEqual(p['validation_seconds'],900)
        self.assertEqual(set(p),set(study.DEFAULT))
        self.assertEqual(study.episode_envelope(p,2,2)['research'],(18000,6,4))

    def test_symmetric_pair_and_empty_suite_semantics(self):
        p=protocol()
        self.assertEqual(transfer.paired_evaluation_seconds(p,2),10800)
        self.assertEqual(study.episode_envelope(p,2,2)['evaluation'],(10800,2,0))
        self.assertEqual(study.episode_envelope(p,2,0)['evaluation'],(0,0,0))
        self.assertEqual(transfer.paired_evaluation_seconds(p,0),7200)
        for tasks in (False,-1,2.5):
            with self.assertRaises(Invalid): transfer.paired_evaluation_seconds(p,tasks)

    def test_prospective_operator_formula_matches_core_without_loading_api(self):
        with patch.object(ops,'api',side_effect=AssertionError('no old/new runtime import')):
            for ordinary in (1,600,900,1800):
                p=dict(protocol(),validation_seconds=ordinary)
                for tasks in (0,1,2,8):
                    self.assertEqual(ops.prospective_evaluation_seconds(p,tasks),
                        transfer.paired_evaluation_seconds(p,tasks))

    def test_full_research_and_pending_review_fit_existing_arm(self):
        p=protocol(); main=ops.capacity_plan(p,30,'research'); pending=ops.capacity_plan(p,30,'review')
        self.assertEqual(main['protected_seconds'],104400)
        self.assertEqual(main['optional_trial_seconds_each'],46800)
        self.assertEqual(main['required_seconds'],151200)
        self.assertEqual(pending['required_seconds'],165600)
        self.assertEqual(main['required_calls'],46); self.assertEqual(main['required_meta_calls'],26)
        self.assertLessEqual(pending['required_seconds'],180000)
        with self.assertRaisesRegex(RuntimeError,'cannot fund'):
            ops.capacity_plan(dict(p,arm_seconds=165599),30,'review')
        self.assertEqual(ops.epoch_wall_reservation(p),191440)

    def test_valid_caps_survive_feedback_and_concept_finish(self):
        result=comparison(); packet=feedback.build_review_feedback(2,{'outcome':'missing'},False,
            reviewer_scope='own_sources_only',episode_transfer=result)
        self.assertEqual(feedback.validate_feedback(packet),packet)
        self.assertEqual(packet['episode_transfer']['budget_caps_seconds'],result['binding'])
        cfg={'enabled':True}; completed=concepts.finish(concepts.initial(cfg),2,packet,cfg)
        self.assertEqual(completed['review_feedback'][-1]['reference'],packet['reference'])
        self.assertNotIn('PRIVATE_CANARY',json.dumps(packet));self.assertNotIn('private-target',json.dumps(packet))

    def test_legacy_valid_feedback_without_catalogue_cap_remains_loadable(self):
        result=comparison();del result['binding']['catalog_seconds_each']
        packet=feedback.build_review_feedback(2,{'outcome':'missing'},False,
            reviewer_scope='own_sources_only',episode_transfer=result)
        self.assertEqual(feedback.validate_feedback(packet),packet)
        self.assertNotIn('catalog_seconds_each',packet['episode_transfer']['budget_caps_seconds'])

    def test_invalid_catalogue_cap_is_not_substituted_for_elapsed_time(self):
        result=comparison();result['binding']['catalog_seconds_each']=True
        projected=feedback.comparison_feedback(result)
        self.assertNotIn('catalog_seconds_each',projected['budget_caps_seconds'])
        self.assertTrue(all(v is None for v in projected['measured_costs']['before'].values()))

    def test_typed_own_timeout_remains_inconclusive_and_private_data_omitted(self):
        raw={'checked':False,'controller_diagnostic':{
            'schema':'math-gkm.own-check-feedback.v1','category':'timeout',
            'mathematical_conclusion':'none'},'elapsed_seconds':1799.5,'private':'PRIVATE_CANARY'}
        accounted=transfer._catalog_account(raw,reused=False,start=transfer.time.monotonic(),origin=Path('/neutral'))
        result={'status':'invalid_frozen_context','own_context_status':accounted['frozen_context_failure_category'],
            'catalog_failure':raw,'task_gains':['PRIVATE_CANARY'],'regressions':['PRIVATE_CANARY']}
        packet=feedback.build_review_feedback(2,{'outcome':'missing'},False,
            reviewer_scope='own_sources_only',episode_transfer=result)
        public=packet['episode_transfer'];self.assertEqual(public['reason'],'frozen_context_timeout')
        self.assertEqual(public['assessment'],'inconclusive'); self.assertFalse(public['eligible'])
        self.assertTrue(all(public[k] is None for k in ('gains','checked_component_transfer','regressions')))
        feedback.validate_feedback(packet);self.assertNotIn('PRIVATE_CANARY',json.dumps(packet))

    def test_private_task_or_untyped_timeout_text_cannot_classify_context(self):
        for raw in ({'checked':False,'failure':'timeout'},
                {'checked':False,'controller_diagnostic':{'category':'timeout'}},
                {'checked':True,'controller_diagnostic':{'schema':'math-gkm.own-check-feedback.v1',
                    'category':'timeout','mathematical_conclusion':'none'}}):
            out=transfer._catalog_account(raw,reused=False,start=transfer.time.monotonic(),origin=Path('/neutral'))
            self.assertNotIn('frozen_context_failure_category',out)
        out=feedback.comparison_feedback({'status':'invalid_comparison_or_capability_regression',
            'own_context_status':'timeout','catalog_failure':{'failure':'timeout'}})
        self.assertEqual(out['reason'],'invalid_or_capability_regression')

    def test_current_measured_catalogue_cost_is_not_reserved_or_original_cost(self):
        raw={'checked':False,'elapsed_seconds':1700}
        out=transfer._catalog_account(raw,reused=False,start=transfer.time.monotonic(),origin=Path('/neutral'))
        costs=transfer._measured_costs({}, {'before':out})
        self.assertLess(costs['before']['context_validation_seconds'],1)
        self.assertEqual(out['catalog_accounting']['original_validation_seconds'],1700)

    def test_pair_outer_funding_uses_complete_new_cap(self):
        with tempfile.TemporaryDirectory(prefix='catalogue-capacity-pure-') as temp:
            base=Path(temp);arm=SimpleNamespace(study=base,root=base/'arm',p=protocol())
            arm.fund=lambda key,cap: funding.append((key,cap))
            arm.budget=lambda key: contextlib.nullcontext();funding=[]
            with patch.object(transfer,'read',return_value={'tasks':[{},{}]}), \
                    patch.object(transfer,'_evaluate_pair',return_value={'fixture':True}) as inner:
                self.assertEqual(transfer.evaluate_pair(arm,None,None,'neutral'),{'fixture':True})
            self.assertEqual(funding,[('paired-evaluation-neutral',10800)]);inner.assert_called_once()

    def test_new_comparison_binding_never_reinterprets_old_result(self):
        with tempfile.TemporaryDirectory(prefix='catalogue-capacity-binding-') as temp:
            base=Path(temp);studyroot=base/'study';armroot=base/'arm'
            write(studyroot/'evaluation/suite.json',{'tasks':[]})
            p=protocol();arm=SimpleNamespace(study=studyroot,root=armroot,p=p)
            m={'binding':'same','files':{}}
            oldbinding={'before':'same','after':'same','suite':digest({'tasks':[]}),
                'inspection_schema':transfer.proof_audit.SCHEMA,'policy_comparison':False,
                'adaptation_seconds_each':1800,'validation_seconds_each_task':900}
            path=armroot/'evaluations/neutral/result.json';write(path,{'binding':oldbinding,'status':'invalid_frozen_context'})
            before=path.read_bytes()
            with patch.object(transfer,'verify_snapshot',return_value=m), \
                    patch.object(transfer,'check_task',side_effect=AssertionError('no replay')):
                with self.assertRaisesRegex(Invalid,'binding changed'):
                    transfer._evaluate_pair(arm,None,None,'neutral')
            self.assertEqual(path.read_bytes(),before)

    def test_actual_catalogue_dispatch_and_journal_share_cap(self):
        from test_snapshot_catalog_cache import FrozenCatalogCache
        fixture=FrozenCatalogCache('test_measurements_never_substitute_caps_or_invalid_values')
        fixture.setUp()
        try:
            original=fixture.fake_check
            with patch.object(transfer,'check_task',side_effect=original) as check:
                result=fixture.catalog('bounded')
            self.assertTrue(result['checked']);self.assertEqual(check.call_args.args[4],180)
            self.assertEqual(fixture.reservations,{'catalog-bounded-before':180})
            marker=fixture.armroot/'evaluations/bounded/catalog-before.reserved.json'
            self.assertEqual(read(marker)['seconds'],180)
            self.assertEqual(fixture.arm.p['validation_seconds'],90)
        finally: fixture.doCleanups()

    def test_adapter_task_still_reserves_and_receives_ordinary_cap(self):
        with tempfile.TemporaryDirectory(prefix='catalogue-task-cap-') as temp:
            base=Path(temp);reservations=[]
            arm=SimpleNamespace(p=protocol(),stopped=lambda:False,
                reserve=lambda key,seconds:reservations.append((key,seconds)))
            task={'id':'neutral-private-task'}
            with patch.object(transfer,'intake',return_value=(
                    {'solutions':{'neutral-private-task':{'module':'Neutral'}}},{'fixture':True})), \
                    patch.object(transfer,'check_task',return_value={'checked':False}) as check:
                transfer.adapter_checks(arm,{},[task],[task],base,'before',base/'workspace',
                    'neutral',{}, {'files':{}},{'files':{}},{'files':{}})
            self.assertEqual(reservations,[('evaluation-neutral-before-neutral-private-task',900)])
            self.assertEqual(check.call_args.args[4],900)

    def test_existing_failed_catalogue_is_not_replayed_or_relabelled(self):
        from test_snapshot_catalog_cache import FrozenCatalogCache
        fixture=FrozenCatalogCache('test_measurements_never_substitute_caps_or_invalid_values')
        fixture.setUp()
        try:
            directory=fixture.first_directory();directory.mkdir(parents=True)
            historical={'checked':False,'budget_seconds':90,'status':'historical-bounded-failure'}
            write(directory/'result.json',historical);before=(directory/'result.json').read_bytes()
            with patch.object(transfer,'check_task',side_effect=AssertionError('no historical replay')):
                result=fixture.catalog()
            self.assertFalse(result['checked']);self.assertNotIn('frozen_context_failure_category',result)
            self.assertEqual((directory/'result.json').read_bytes(),before)
            self.assertEqual(read(directory/'result.json')['budget_seconds'],90)
        finally: fixture.doCleanups()

    def test_new_empty_suite_binding_records_catalogue_cap_without_work(self):
        with tempfile.TemporaryDirectory(prefix='catalogue-empty-suite-') as temp:
            base=Path(temp);write(base/'study/evaluation/suite.json',{'tasks':[]})
            arm=SimpleNamespace(study=base/'study',root=base/'arm',p=protocol())
            with patch.object(transfer,'verify_snapshot',return_value={'binding':'same','files':{}}), \
                    patch.object(transfer,'catalog_snapshot',side_effect=AssertionError('empty suite')):
                result=transfer._evaluate_pair(arm,None,None,'empty')
            self.assertEqual(result['binding']['catalog_seconds_each'],1800)
            self.assertEqual(result['binding']['validation_seconds_each_task'],900)
            self.assertEqual(result['status'],'no_independent_holdout; transfer_not_demonstrated')


if __name__ == '__main__':
    unittest.main()
