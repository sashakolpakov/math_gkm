Accepted Markov checkpoint: five independently admitted claims; universal conjecture remains open.
Contains the reviewed unchanged harness source, accepted proof registry, pinned protocol/contract, and FINISHED-bound proof sources and rebuild pins.
No compiled caches, unfinished recovery helpers, private launch authority, or unadmitted candidates are included.
Original receipts keep their original provenance; this archive is preservation, not a fresh proof replay.
