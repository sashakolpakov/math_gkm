Accepted Markov checkpoint: eight independently admitted claims; universal conjecture remains open.
Contains the reviewed unchanged harness source, accepted claim registry/root DAG, pinned protocol/contract, and original FINISHED-bound proof source closures and rebuild pins.
Original FINISHED.json and result.json bytes retain their original checked provenance. Additional proofs/<id>/exports/ files are generated exports bound by the accepted registry source_files hashes, not by the original FINISHED.files.
Those generated exports require a fresh consumer rebuild; no independent fresh compilation or replay is asserted by this preservation update.
No compiled caches, unfinished recovery helpers, full runtime state, private evaluation inputs/outputs, launch authority, routing state, or unadmitted candidates are included.
