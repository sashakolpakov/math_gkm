import MathGKM.Target9547e5c68601efb6ce8d0798
import MathGKM.Round19ConvolutionA
import Lean
def StudyInterface : MathGKM.Target9547e5c68601efb6ce8d0798.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Target9547e5c68601efb6ce8d0798.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Target9547e5c68601efb6ce8d0798.Goal StudyInterface :=
  (
    ConvolutionR19.binomial_convolution
  )
