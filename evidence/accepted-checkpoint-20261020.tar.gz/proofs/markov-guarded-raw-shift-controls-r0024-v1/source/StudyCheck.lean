import MathGKM.Target05126537bfd040d474442a5c
import MathGKM.Round24ShiftA
import Lean
def StudyInterface : MathGKM.Target05126537bfd040d474442a5c.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Target05126537bfd040d474442a5c.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Target05126537bfd040d474442a5c.Goal StudyInterface :=
  (
    ⟨RawDeficitR24.raw_shift, RawDeficitR24.controls⟩
  )
