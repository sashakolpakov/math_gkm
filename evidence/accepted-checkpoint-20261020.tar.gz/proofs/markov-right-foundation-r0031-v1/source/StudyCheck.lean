import MathGKM.Targetcd963d41e1b1c35f3730e8bf
import MathGKM.Round31FoundationA
import Lean
def StudyInterface : MathGKM.Targetcd963d41e1b1c35f3730e8bf.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Targetcd963d41e1b1c35f3730e8bf.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Targetcd963d41e1b1c35f3730e8bf.Goal StudyInterface :=
  (
    ⟨⟨RightR30.right_labels,RightR30.right_state,RightR30.right_series,RightR30.right_recurrence⟩,⟨RightR30.coefficient_recovery,RightR30.right_nonnegative⟩⟩
  )
