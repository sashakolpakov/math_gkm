import MathGKM.Target337adf62a9f327d3a1b3ec59
import MathGKM.Round10Support
import Lean
def StudyInterface : MathGKM.Target337adf62a9f327d3a1b3ec59.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Target337adf62a9f327d3a1b3ec59.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Target337adf62a9f327d3a1b3ec59.Goal StudyInterface :=
  (
    SupportR10.actual_support
  )
