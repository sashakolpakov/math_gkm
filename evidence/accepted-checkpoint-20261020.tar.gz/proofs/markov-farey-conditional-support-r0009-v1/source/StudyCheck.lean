import MathGKM.Target41fef3cabe206a24f4f34ffd
import MathGKM.Round9Conditional
import Lean
def StudyInterface : MathGKM.Target41fef3cabe206a24f4f34ffd.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Target41fef3cabe206a24f4f34ffd.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Target41fef3cabe206a24f4f34ffd.Goal StudyInterface :=
  (
    FareyR9.conditional
  )
