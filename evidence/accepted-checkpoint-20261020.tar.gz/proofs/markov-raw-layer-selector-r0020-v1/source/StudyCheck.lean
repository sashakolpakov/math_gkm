import MathGKM.Targetd524f74aea36c34ca7f8318c
import MathGKM.Round20RawA
import Lean
def StudyInterface : MathGKM.Targetd524f74aea36c34ca7f8318c.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Targetd524f74aea36c34ca7f8318c.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Targetd524f74aea36c34ca7f8318c.Goal StudyInterface :=
  (
    ⟨ClearedLayersR20.rawLayer_coeff,ClearedLayersR20.rawLayer_homogeneous⟩
  )
