# Inspection capacity controls

The three checker replacements in `CAPACITY_SOURCE_BINDING.json` remain frozen:
implementation `bac1b8f622077e362fc2d078e87bab3bad4114882700d722b09498f3481878fa`
from baseline `7772dfefd0e76d355edbdcd1a1414a4fcaccb7ec1aa0d298de99b8d7e1f84aa3`.
Only raw per-root edges/duplicates increase to 2,000,000. Distinct dependency
nodes and declarations/catalog remain 200,000; Expr nodes 1,000,000; depth 4096;
artifact 32 MiB and line 1 MiB. Schema, semantic identity, complete traversal,
duplicate counting and all production resource/time/STOP limits are unchanged.
Historical recorded diagnostics retain their original bounds.

## Final relative install layout

Install the following reviewed test sources without changing their bytes:

```text
tests/inspection_capacity/run_pure_capacity_tests.py
tests/inspection_capacity/neutral_producer_controls.py
tests/inspection_capacity/test_inspection_capacity.py
tests/inspection_capacity/controls/MathGKM/InspectionCapacityNeutral.lean
tests/inspection_capacity/README.md                         (this document)
```

The pure runner reuses existing `tests/test_inspection011.py`,
`test_inspection012.py`, `test_deployment_receipt_reuse.py` and
`test_snapshot_catalog_cache.py`. It selects only their pure classes.
The three pinned historical baseline files come from
`evidence/concept-driver-source-20261020/source/machinery/` when a local stage
baseline is absent. All three hashes are checked, including `own_feedback.py`.
No disposable-stage files are needed by the installed layout.

Both runners resolve the repository from `MATH_GKM_CAPACITY_REPO`, or cwd when
unset, requiring `machinery/study_common.py` and `lean-toolchain`. Their default
source is that installed repository. `MATH_GKM_CAPACITY_STAGE` explicitly enables
the reviewed three-file source overlay for staging only. The neutral Lean fixture
is always located relative to its runner, rather than a user home or stage name.

## Pure controls

From the repository root after installation:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 tests/inspection_capacity/run_pure_capacity_tests.py
```

For the existing temporary stage, set `MATH_GKM_CAPACITY_STAGE` to its directory
and run that directory's `run_pure_capacity_tests.py` from the validated repo root.
The 56 pure tests block subprocess creation and cover parser boundaries/counts,
exact producer-source delta, feedback history, nonce/hash/source/FINISHED
bindings, catalog/deployment identity and portable baseline/layout resolution.
They are synthetic engineering controls, not mathematical admissions.

Results/logs go into one fresh `math-gkm-capacity-pure-*` tempfile/TMPDIR child;
fixture scratch is removed. The printed `RESULT_DIRECTORY` identifies the bounded
result files for review. No tracked test directory is used for generated output.
The original pre-portability bootstrap failure occurred before any test because
namespace paths have no `insert`; only the runner overlay was corrected.

## Actual producer controls — not yet executed

Only after the operator confirms parent/keeper/heavy-lease quiescence and approves
execution, run from the repo root:

```sh
GKM_CAPACITY_QUIESCENT=reviewed PYTHONDONTWRITEBYTECODE=1 python3 tests/inspection_capacity/neutral_producer_controls.py --run
```

For staging, add the explicit `MATH_GKM_CAPACITY_STAGE` overlay and invoke the
stage's same runner path. Repository resolution can instead be explicit through
`MATH_GKM_CAPACITY_REPO`. All output goes into one fresh
`math-gkm-capacity-neutral-*` tempfile/TMPDIR child, printed at startup. `STOP` in
that output directory (or the explicit stage) is checked between commands;
already-running commands retain their process guard and timeout.

The runner refuses actual execution without the quiescent flag. It uses official
process admission/resource guards and sandboxing: one neutral-module compile,
one independent replay, eight sequential inspectors, at most one external process
at a time; 120 s/1 MiB per command, at most 1,200 s aggregate command caps. It changes
no resource limits. The negative fixture's axiom is isolated test input and must
never enter a research seed.

Five actual controls compare complete reported old/new closures/catalog identities,
test shared raw-edge/duplicate counts, find a forbidden axiom after a scaled low
cap, reject a required constant absent from root closure, and test nonce,
same-size stream corruption, source and FINISHED bindings. The producer low cap
is 16 versus production 2,000,000: no actual >200,000-edge stress run is claimed.
Real numeric boundaries are tested by the offline parser controls. No actual
producer result, fresh proof replay or mathematical acceptance is claimed yet.
