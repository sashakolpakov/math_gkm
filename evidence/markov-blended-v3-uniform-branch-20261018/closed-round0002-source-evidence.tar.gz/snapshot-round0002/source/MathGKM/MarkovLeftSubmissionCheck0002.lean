import MathGKM.MarkovLeftWeakLC0002

/-! Machine-authored exact submission elaboration, not independent admission. -/

theorem MathGKM.Markov.LeftBranch0001.submission0002_0 :
    ∀ n i j : ℕ, MathGKM.Markov.coeff (MathGKM.Markov.LeftBranch0001.Q n) i j = MathGKM.Markov.LeftBranch0001.rawFormula n i j :=
  MathGKM.Markov.LeftBranch0001.coefficient_bridge
#print axioms MathGKM.Markov.LeftBranch0001.submission0002_0

theorem MathGKM.Markov.LeftBranch0001.submission0002_1 :
    MathGKM.Markov.LeftBranch0001.FormulaWeakLC :=
  MathGKM.Markov.LeftBranch0001.formula_weakLC
#print axioms MathGKM.Markov.LeftBranch0001.submission0002_1

theorem MathGKM.Markov.LeftBranch0001.submission0002_2 :
    ∀ k : ℕ, let m := (MathGKM.Markov.frame (List.replicate k false)).mid; MathGKM.Markov.WeakLC m.a m.b m.p :=
  MathGKM.Markov.LeftBranch0001.all_false_weakLC
#print axioms MathGKM.Markov.LeftBranch0001.submission0002_2
