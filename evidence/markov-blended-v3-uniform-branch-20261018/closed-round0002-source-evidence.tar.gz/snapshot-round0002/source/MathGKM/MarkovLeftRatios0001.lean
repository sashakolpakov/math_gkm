import MathGKM.MarkovLeftBranch0001

/-! Machine-authored monotonicity of the three proposed adjacent coefficient
ratios. The bridge from these rational expressions to coefficients is open. -/
namespace MathGKM.Markov.LeftBranch0001

theorem three_ratio_inequalities :
    (∀ n i j : ℚ, 1 ≤ i → 0 ≤ j → i+j+2 ≤ n →
      ((i+j+2)/(i+2))*((n-i-j-1)/(i+1)) ≤
      ((i+j+1)/(i+1))*((n-i-j)/i)) ∧
    (∀ n i j : ℚ, 1 ≤ i → 0 ≤ j → i+j+2 ≤ n →
      ((i+j+2)/(j+2))*((n-i-j-1)/(n-j-2)) ≤
      ((i+j+1)/(j+1))*((n-i-j)/(n-j-1))) ∧
    (∀ n i j : ℚ, 1 ≤ i → 2 ≤ j → i+j ≤ n →
      ((j-1)/(i+2))*((n-j+1)/(i+1)) ≤
      (j/(i+1))*((n-j)/i)) := by
  refine ⟨?_, ?_, ?_⟩
  · intro n i j hi hj hn
    have h₁ : (i+j+2)/(i+2) ≤ (i+j+1)/(i+1) := by
      apply (div_le_div_iff₀ (by linarith) (by linarith)).2
      nlinarith
    have h₂ : (n-i-j-1)/(i+1) ≤ (n-i-j)/i := by
      apply (div_le_div_iff₀ (by linarith) (by linarith)).2
      nlinarith
    exact mul_le_mul h₁ h₂ (div_nonneg (by linarith) (by linarith))
      (div_nonneg (by linarith) (by linarith))
  · intro n i j hi hj hn
    have h₁ : (i+j+2)/(j+2) ≤ (i+j+1)/(j+1) := by
      apply (div_le_div_iff₀ (by linarith) (by linarith)).2
      nlinarith
    have h₂ : (n-i-j-1)/(n-j-2) ≤ (n-i-j)/(n-j-1) := by
      apply (div_le_div_iff₀ (by linarith) (by linarith)).2
      nlinarith
    exact mul_le_mul h₁ h₂ (div_nonneg (by linarith) (by linarith))
      (div_nonneg (by linarith) (by linarith))
  · intro n i j hi hj hn
    have h₁ : (j-1)/(i+2) ≤ j/(i+1) := by
      apply (div_le_div_iff₀ (by linarith) (by linarith)).2
      nlinarith
    have h₂ : (n-j+1)/(i+1) ≤ (n-j)/i := by
      apply (div_le_div_iff₀ (by linarith) (by linarith)).2
      nlinarith
    exact mul_le_mul h₁ h₂ (div_nonneg (by linarith) (by linarith))
      (div_nonneg (by linarith) (by linarith))

#print axioms three_ratio_inequalities
end MathGKM.Markov.LeftBranch0001
