import MathGKM.Markov

/-! Machine-authored round-0000 witness for the committed slice trial.
This file makes no universal log-concavity or source-correspondence claim.
-/
namespace MathGKM.Markov.SliceTrial0000

theorem witness_polynomial :
    (frame [false]).mid.a = 1 ∧ (frame [false]).mid.b = 3 ∧
    (frame [false]).mid.p =
      U^3 + 3*U^2*V + 3*U*V^2 + V^3 + 2*U^2 + 2*U*V + U := by
  norm_num [frame, advance, initial, S]
  ring

theorem witness_coefficients :
    coeff (frame [false]).mid.p 1 0 = 1 ∧
    coeff (frame [false]).mid.p 1 1 = 2 ∧
    coeff (frame [false]).mid.p 1 2 = 3 := by
  rw [witness_polynomial.2.2]
  norm_num [coeff, U, V, pow_succ, Polynomial.mul_coeff_one]
  simp [Polynomial.coeff_one, Polynomial.coeff_X]

theorem witness_triple_valid :
    InPolygon 1 3 1 0 ∧ InPolygon 1 3 1 1 ∧ InPolygon 1 3 1 2 ∧
    (1 : ℤ)*3 ≤ 2^2 := by
  norm_num [InPolygon]

theorem witness_real_slice_positive :
    ∀ t : ℝ, 0 < 1 + 2*t + 3*t^2 := by
  intro t
  nlinarith [sq_nonneg (3*t+1)]

#print axioms witness_polynomial
#print axioms witness_coefficients
#print axioms witness_triple_valid
#print axioms witness_real_slice_positive

end MathGKM.Markov.SliceTrial0000
