/- Machine-authored local exact proposal interface check. -/
import MathGKM.MarkovLeftBranch0001
import MathGKM.MarkovLeftWeakLC0001
import MathGKM.MarkovLeftRatios0001

example : ∀ k : ℕ, (MathGKM.Markov.frame (List.replicate k false)).mid.a = 1 ∧ (MathGKM.Markov.frame (List.replicate k false)).mid.b = k+2 ∧ (MathGKM.Markov.frame (List.replicate k false)).mid.p = MathGKM.Markov.LeftBranch0001.Q (k+2) := MathGKM.Markov.LeftBranch0001.mid_left

example : MathGKM.Markov.WeakLC (MathGKM.Markov.frame [false]).mid.a (MathGKM.Markov.frame [false]).mid.b (MathGKM.Markov.frame [false]).mid.p := MathGKM.Markov.LeftBranch0001.false_weakLC

example : (∀ n i j : ℚ, 1 ≤ i → 0 ≤ j → i+j+2 ≤ n → ((i+j+2)/(i+2))*((n-i-j-1)/(i+1)) ≤ ((i+j+1)/(i+1))*((n-i-j)/i)) ∧ (∀ n i j : ℚ, 1 ≤ i → 0 ≤ j → i+j+2 ≤ n → ((i+j+2)/(j+2))*((n-i-j-1)/(n-j-2)) ≤ ((i+j+1)/(j+1))*((n-i-j)/(n-j-1))) ∧ (∀ n i j : ℚ, 1 ≤ i → 2 ≤ j → i+j ≤ n → ((j-1)/(i+2))*((n-j+1)/(i+1)) ≤ (j/(i+1))*((n-j)/i)) := MathGKM.Markov.LeftBranch0001.three_ratio_inequalities
