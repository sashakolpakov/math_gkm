"""Machine-authored direct, sequential pinned Lean compiler runner.
No Lake execution, package mutations, network, subprocess concurrency, or shell.
Preserves each compiler invocation output, including failed attempts.
"""
from pathlib import Path
import os
import subprocess
import time
import json

root=Path.cwd()
out=root/"research/plan0000-markov-slices-20261018-build/MathGKM"
out.mkdir(parents=True,exist_ok=True)
packages=json.loads(Path("lake-manifest.json").read_text())["packages"]
env=os.environ.copy()
env["LEAN_PATH"]=":".join([str(out.parent)]+[
    str(root/".lake/packages"/p["name"]/".lake/build/lib/lean") for p in packages])
for module in ["Markov","MarkovSliceTrial0000"]:
    if module == "Markov" and (out/(module+".olean")).exists():
        continue  # reuse this round's successful pinned-root compilation
    log=root/("research/plan0000-markov-slices-20261018-"+module+"-compile-"+str(time.time_ns())+".txt")
    cmd=["lean","-o",str(out/(module+".olean")),"MathGKM/"+module+".lean"]
    start=time.monotonic()
    result=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
    text="Command: "+repr(cmd)+"\nElapsed seconds: "+str(time.monotonic()-start)+"\nReturn code: "+str(result.returncode)+"\n"+result.stdout
    log.write_text(text)
    print(text,flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
