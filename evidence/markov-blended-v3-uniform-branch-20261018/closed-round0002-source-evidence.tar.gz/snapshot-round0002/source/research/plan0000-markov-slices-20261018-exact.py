"""Machine-authored committed experiment, 2026-10-18, round-0000.
Trial markov-slice-realroot-route-v0; reference b4f28ca309ddd3bef79f3327601ff47e32e43c7c723e2255acd5e3203409bed0.
Only standard-library exact arithmetic. No theorem certification is claimed.
Run with /opt/homebrew/bin/python3 from the workspace root.
"""
from collections import defaultdict
from fractions import Fraction
from functools import reduce
from itertools import product
from math import gcd, lcm
from pathlib import Path
import hashlib
import json
import time
import sys

PREFIX = Path("research/plan0000-markov-slices-20261018")
START = time.monotonic()
BUDGET = 600

def budget():
    if time.monotonic() - START > BUDGET:
        raise TimeoutError("600 second exact-experiment horizon")

def trim(p):
    p = list(p)
    while p and not p[-1]:
        p.pop()
    return p

def primitive(p):
    p = trim(p)
    if not p:
        return []
    den = lcm(*(Fraction(c).denominator for c in p))
    q = [int(c * den) for c in p]
    g = reduce(gcd, (abs(c) for c in q))
    return [c // g for c in q]  # strictly positive scaling only

def remainder(p, q):
    r = [Fraction(c) for c in p]
    while r and len(r) >= len(q):
        budget()
        c = r[-1] / q[-1]
        shift = len(r) - len(q)
        for k, x in enumerate(q):
            r[shift + k] -= c * x
        r = trim(r)
    return primitive(r)

def sign(x):
    return (x > 0) - (x < 0)

def variations(xs):
    xs = [x for x in xs if x]
    return sum(x != y for x, y in zip(xs, xs[1:]))

ROOT_CACHE = {}
def roots(coefficients):
    key = tuple(coefficients)
    if key in ROOT_CACHE:
        return ROOT_CACHE[key]
    f = trim(coefficients)
    zeros = 0
    while f and f[0] == 0:
        f = f[1:]
        zeros += 1
    if not f:
        result = {"status": "zero_slice", "pass": True}
    else:
        f = primitive(f)
        chain = [f]
        if len(f) > 1:
            chain.append(primitive([i*f[i] for i in range(1, len(f))]))
            while True:
                r = remainder(chain[-2], chain[-1])
                if not r:
                    break
                chain.append([-c for c in r])
        vm = variations([sign(p[-1]) * (-1)**(len(p)-1) for p in chain])
        v0 = variations([sign(p[0]) for p in chain])
        vp = variations([sign(p[-1]) for p in chain])
        gcd_degree = len(chain[-1])-1 if len(f)>1 else 0
        distinct_degree = len(f)-1-gcd_degree
        result = {"status": "nonzero_slice", "zero_multiplicity": zeros,
                  "degree_after_zero_removal": len(f)-1,
                  "gcd_degree": gcd_degree, "distinct_degree": distinct_degree,
                  "variations_minus_infinity_zero_plus_infinity": [vm,v0,vp],
                  "distinct_negative_roots": vm-v0,
                  "distinct_positive_roots": v0-vp,
                  "nonnegative_coefficients": all(c>=0 for c in coefficients),
                  "pass": all(c>=0 for c in coefficients) and vm-v0==distinct_degree,
                  "sturm_chain": chain}
    ROOT_CACHE[key] = result
    return result

def self_checks():
    cases = [([1],True), ([0,0,3],True), ([1,2,1],True),
             ([2,5,4,1],True), ([1,0,1],False), ([1,2,3],False),
             ([-1,1],False), ([0,1,2,1],True), ([1,0,2,0,1],False),
             ([0,0],True)]
    for p, expected in cases:
        assert roots(p)["pass"] == expected, (p,roots(p))
    assert roots([1,2,1])["distinct_negative_roots"] == 1
    assert roots([1,2,1])["gcd_degree"] == 1
    assert roots([-1,1])["distinct_positive_roots"] == 1
    return {"known_polynomial_cases": len(cases), "status": "passed"}

def mul(p,q):
    r = defaultdict(int)
    for (i,j),c in p.items():
        for (k,l),d in q.items():
            r[i+k,j+l] += c*d
    return {k:v for k,v in r.items() if v}

def next_label(x,y,z):
    # x: shared endpoint, y: old midpoint, z: opposite endpoint
    a,b,p = x
    c,d,q = y
    r = defaultdict(int, mul({(0,0):1,(1,0):1,(0,1):1},mul(p,q)))
    for (i,j),v in z[2].items():
        r[i+a,j+b] -= v
    return a+c,b+d,{k:v for k,v in r.items() if v}

INITIAL = ((0,1,{(0,0):1}),
           (1,2,{(2,0):1,(1,1):2,(0,2):1,(1,0):1}),
           (1,1,{(1,0):1,(0,1):1}))

def frame(path):
    lo,mid,hi = INITIAL
    for right in path:
        if right:
            lo,mid,hi = mid,next_label(hi,mid,lo),hi
        else:
            lo,mid,hi = lo,next_label(lo,mid,hi),mid
    return lo,mid,hi

def inside(a,b,i,j):
    return i>=0 and j>=0 and a*b <= b*i+a*j and i+j<=a+b-1

def checkpoint(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n")

def examine(name,label):
    budget()
    a,b,p = label
    points = {(i,j) for i in range(a+b) for j in range(a+b-i)
              if inside(a,b,i,j)}
    bad_support = [list(k) for k in p if k not in points]
    slices = []
    for direction in [(1,0),(0,1),(1,-1)]:
        di,dj = direction
        starts = sorted((i,j) for i,j in points if (i-di,j-dj) not in points)
        for i,j in starts:
            coords = []
            while (i,j) in points:
                coords.append([i,j]); i+=di; j+=dj
            coeffs = [p.get(tuple(k),0) for k in coords]
            violations = []
            for k in range(len(coeffs)-2):
                lhs,rhs = coeffs[k]*coeffs[k+2],coeffs[k+1]**2
                if lhs>rhs:
                    violations.append({"triple":coords[k:k+3],"outer_product":lhs,"middle_square":rhs})
            test = roots(coeffs)
            # Full chains retained for failures; successful chains reproducible from code.
            test = {k:v for k,v in test.items() if k!="sturm_chain" or not test["pass"]}
            slices.append({"direction":list(direction),"coordinates":coords,
                           "coefficients":coeffs,"raw_triples":max(0,len(coeffs)-2),
                           "raw_violations":violations,"root_test":test})
    result = {"name":name,"a":a,"b":b,"support":[[i,j,c] for (i,j),c in sorted(p.items())],
              "outside_polygon_support":bad_support,"polygon_point_count":len(points),
              "polygon_zero_count":sum(p.get(k,0)==0 for k in points),"slices":slices}
    checkpoint(Path(str(PREFIX)+"-"+name+".json"),result)
    return result

def main():
    checks = self_checks()
    completed = []
    status = {"provenance":"machine-authored researcher round-0000", "python":sys.version,
              "trial":{"hypothesis":"markov-slice-realroot-route-v0","invention":True},
              "commitment_ref":"b4f28ca309ddd3bef79f3327601ff47e32e43c7c723e2255acd5e3203409bed0",
              "budget_seconds":BUDGET,"self_checks":checks,"completed":[],"status":"running"}
    path = Path(str(PREFIX)+"-progress.json")
    checkpoint(path,status)
    try:
        labels = [("endpoint-0-1",INITIAL[0]),("endpoint-1-1",INITIAL[2])]
        for n in range(5):
            for bits in product([False,True],repeat=n):
                name = "path-"+("".join("1" if b else "0" for b in bits) or "empty")
                labels.append((name,frame(bits)[1]))
        for name,label in labels:
            result = examine(name,label)
            completed.append(result)
            status["completed"].append(name)
            status["elapsed_seconds"] = time.monotonic()-START
            checkpoint(path,status)
            failures = sum(not s["root_test"]["pass"] for s in result["slices"])
            print(name,str(label[0])+"/"+str(label[1]),"slices",len(result["slices"]),"root_failures",failures,flush=True)
        all_slices = [(r,s) for r in completed for s in r["slices"]]
        raw_failures = [{"name":r["name"],"direction":s["direction"],"violation":v}
                        for r,s in all_slices for v in s["raw_violations"]]
        root_failures = [{"name":r["name"],"a":r["a"],"b":r["b"],"direction":s["direction"],
                          "coordinates":s["coordinates"],"coefficients":s["coefficients"],"root_test":s["root_test"]}
                         for r,s in all_slices if not s["root_test"]["pass"]]
        status.update(status="complete", polynomial_count=len(completed),slice_count=len(all_slices),
                      raw_triple_count=sum(s["raw_triples"] for _,s in all_slices),raw_failures=raw_failures,
                      root_failure_count=len(root_failures),root_failures=root_failures,
                      outside_support_count=sum(len(r["outside_polygon_support"]) for r in completed),
                      polygon_zero_count=sum(r["polygon_zero_count"] for r in completed),
                      negative_coefficient_count=sum(c<0 for r in completed for _,_,c in r["support"]),
                      elapsed_seconds=time.monotonic()-START)
    except Exception as exc:
        status.update(status="incomplete",error=repr(exc),elapsed_seconds=time.monotonic()-START)
        checkpoint(path,status)
        raise
    checkpoint(path,status)
    print(json.dumps({k:v for k,v in status.items() if k not in ["root_failures","completed","python"]},indent=2),flush=True)

if __name__ == "__main__":
    main()
