# Committed trial execution checkpoint

Machine-authored researcher output, round-0000, 2026-10-18. Active contract: published-markov-6-3-clean-v2. Trial: {"hypothesis":"markov-slice-realroot-route-v0","invention":true}. Commitment reference: b4f28ca309ddd3bef79f3327601ff47e32e43c7c723e2255acd5e3203409bed0. Prospective binding: 82c0160efe95f793c1df59c34955de97dfc187a38c037380a514a055240e3c80. Immutable predictions are unchanged; this file records observations.

## Exact finite experiment

The complete committed family contains the two endpoints and 31 midpoint paths of lengths zero through four: 33 polynomials. All coefficients use arbitrary-size integers. Every maximal lattice segment of the pinned polygon in directions (1,0), (0,1), (1,-1) was enumerated before inspecting coefficient values. Zeros were retained in these arrays; none occurred in this bounded family. No negative coefficients or support outside the polygon occurred.

There were 976 segments and 4,047 consecutive triples. All raw inequalities passed. Of the segments, 438 failed the stronger nonnegative-real-nonpositive-root condition; the other 538 passed. The exact experiment took approximately 0.065 seconds as measured internally, well below its 600-second bound. Its ten known-polynomial arithmetic checks passed. These measurements do not include source retrieval, file preparation, or Lean proof work.

Sturm procedure: remove trailing zero coefficients to determine the actual degree, and separately strip any initial power of t for counting nonzero roots. Use f and f′ followed by negative rational Euclidean remainders; positive denominator/content scaling yields integer chain entries without changing signs. Compare variations at negative infinity and zero with degree(f) minus degree(gcd(f,f′)). The final nonzero remainder supplies that gcd degree. Thus repeated roots count once in both quantities. Nonnegative coefficients are checked separately. The removed zero root is allowed by the target condition. Constants and zero slices have explicit handling. Successful slice chain data are reproducible; all failed chain data are retained in the JSON checkpoints.

The independent replay enumerated triples directly rather than via maximal slices and reproduced all 4,047 comparisons. It also compared five integer evaluations of each midpoint with a scalar recurrence (155 checks), and checked finite label coprimality and neighbor determinants. This is corroboration of the implementation, not a formal representation law or universal proof.

## Obstruction to the sufficient strengthening

For path [false], the midpoint is labelled 1/3 and its polynomial is

u³+3u²v+3uv²+v³+2u²+2uv+u.

At i=1 the maximal vertical segment has coordinates (1,0),(1,1),(1,2) and coefficients 1,2,3. Its generating polynomial is f(t)=1+2t+3t². The raw inequality is 3≤4. Its discriminant is −8, and 3f(t)=(3t+1)²+2 proves strict positivity on the real line. The normalized Sturm chain is [1,2,3], [1,3], [−1] in ascending coefficient order. Its variations at negative infinity, zero and positive infinity are all 1, yielding no real roots for a degree-two polynomial. This obstruction belongs to the pinned family without any bounded extrapolation. Interpreting it as a source-family obstruction still requires the retained correspondence bridges.

The committed third outcome therefore occurs: raw inequalities pass in the complete bounded check, and the proposed sufficient strengthening fails. The universal real-rooted-slice route is rejected for the pinned family. No raw counterexample was found; no refutation of the published conjecture is claimed. Universal weak log-concavity, independent source correspondence and exact-root completion remain open.

## Local proof work and failed attempts

The direct installed Lean 4.32.2 compiled a fresh copy of the pinned root using explicit read-only dependency paths. The final MathGKM/MarkovSliceTrial0000.lean also compiled successfully, with axiom output restricted to propext, Classical.choice and Quot.sound. It proves the displayed midpoint label/polynomial identity, the three coefficients, polygon membership and raw arithmetic, and strict real positivity of f. These are local checked candidates submitted for independent checking, not an admission receipt.

Four failed witness-compilation attempts are retained in timestamped logs. The first coefficient proof used norm_num with coeff_mul and left antidiagonal sums unsolved. The second added reverse C_pow and finite-range expansion but reached recursion depth. The third used reverse C_pow with mul_coeff_one and also reached recursion depth. The fourth used pow_succ and mul_coeff_one and left two elementary coefficient simplifications. The successful fifth attempt explicitly simplifies coeff_one and coeff_X after that step. Failed logs include compiler-generated placeholder-axiom diagnostics for the unsolved theorem; none of those failed outputs is accepted or submitted. The final successful log has no such axiom. The initial Lake capability failure and shell temporary-file failure are separately retained in the capability note.

## Episode continuation

Round 0 does not end the two-round episode; its scheduled review is round 1. The observed obstruction already rules out the proposed universal sufficient strengthening. Next work should retain this witness, discharge a narrowly scoped source/recurrence bridge if possible, and pursue a weaker coefficient argument or explicitly restricted family such as 1/n. Delayed usefulness of these artifacts remains unassessed. No policy or executable change is installed or proposed here; the incumbent single-agenda policy is retained. No historical campaign or controller-certification obligation was pursued.
