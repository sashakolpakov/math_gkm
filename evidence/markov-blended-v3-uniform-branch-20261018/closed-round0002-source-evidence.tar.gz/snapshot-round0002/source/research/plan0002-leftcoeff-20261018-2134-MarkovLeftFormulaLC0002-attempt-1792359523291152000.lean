import MathGKM.MarkovLeftCoefficients0002

/-! Machine-authored round-0002 inequality attempt, bounded to 210 seconds. -/
namespace MathGKM.Markov.LeftBranch0001

theorem choose_ratio (n k : ℕ) (hk : k ≤ n) :
    (n.choose (k+1) : ℚ) / (n.choose k : ℚ) =
      ((n : ℚ)-k)/(k+1) := by
  have hp : (0 : ℚ) < n.choose k := by exact_mod_cast Nat.choose_pos hk
  apply (div_eq_div_iff (ne_of_gt hp) (by positivity : (k : ℚ)+1 ≠ 0)).2
  have he := congrArg (fun x : ℕ => (x : ℚ)) (Nat.choose_succ_right_eq n k)
  push_cast [Nat.cast_sub hk] at he
  exact he

theorem choose_upper_ratio (n k : ℕ) (hk : k ≤ n) :
    ((n+1).choose k : ℚ) / (n.choose k : ℚ) =
      ((n : ℚ)+1)/(n+1-k) := by
  have hp : (0 : ℚ) < n.choose k := by exact_mod_cast Nat.choose_pos hk
  apply (div_eq_div_iff (ne_of_gt hp) (by have : (k : ℚ) ≤ n := by exact_mod_cast hk; linarith)).2
  have he := congrArg (fun x : ℕ => (x : ℚ)) (Nat.choose_mul_succ_eq n k)
  push_cast [Nat.cast_sub (show k ≤ n+1 by omega)] at he
  nlinarith only [he]

theorem choose_lc (n k : ℕ) (hk : k+2 ≤ n) :
    (n.choose k : ℤ) * n.choose (k+2) ≤ (n.choose (k+1) : ℤ)^2 := by
  have ha : (0 : ℚ) < n.choose k := by exact_mod_cast Nat.choose_pos (by omega : k ≤ n)
  have hb : (0 : ℚ) < n.choose (k+1) := by exact_mod_cast Nat.choose_pos (by omega : k+1 ≤ n)
  have hr : (n.choose (k+2) : ℚ)/(n.choose (k+1) : ℚ) ≤
      (n.choose (k+1) : ℚ)/(n.choose k : ℚ) := by
    rw [show k+2 = (k+1)+1 by omega, choose_ratio n (k+1) (by omega), choose_ratio n k (by omega)]
    apply (div_le_div_iff₀ (by positivity) (by positivity)).2
    have hkn : (k : ℚ)+2 ≤ n := by exact_mod_cast hk
    push_cast
    nlinarith
  have he := (div_le_div_iff₀ hb ha).1 hr
  have : (n.choose k : ℚ) * n.choose (k+2) ≤ (n.choose (k+1) : ℚ)^2 := by nlinarith only [he]
  exact_mod_cast this

theorem choose_upper_lc (n k : ℕ) (hk : k ≤ n) :
    (n.choose k : ℤ) * (n+2).choose k ≤ ((n+1).choose k : ℤ)^2 := by
  have ha : (0 : ℚ) < n.choose k := by exact_mod_cast Nat.choose_pos hk
  have hb : (0 : ℚ) < (n+1).choose k := by exact_mod_cast Nat.choose_pos (by omega : k ≤ n+1)
  have hr : ((n+2).choose k : ℚ)/((n+1).choose k : ℚ) ≤
      ((n+1).choose k : ℚ)/(n.choose k : ℚ) := by
    rw [show n+2 = (n+1)+1 by omega, choose_upper_ratio (n+1) k (by omega), choose_upper_ratio n k hk]
    have hkn : (k : ℚ) ≤ n := by exact_mod_cast hk
    push_cast
    apply (div_le_div_iff₀ (by linarith) (by linarith)).2
    nlinarith
  have he := (div_le_div_iff₀ hb ha).1 hr
  have : (n.choose k : ℚ) * (n+2).choose k ≤ ((n+1).choose k : ℚ)^2 := by nlinarith only [he]
  exact_mod_cast this

#print axioms choose_lc
#print axioms choose_upper_lc
end MathGKM.Markov.LeftBranch0001
