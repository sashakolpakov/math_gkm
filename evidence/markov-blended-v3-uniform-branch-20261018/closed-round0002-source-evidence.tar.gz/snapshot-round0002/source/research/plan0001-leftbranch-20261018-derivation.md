# Restricted left-branch checkpoint

Machine-authored by the active researcher, round-0001, 2026-10-18.
Contract: published-markov-6-3-clean-v2, phase markov. Ordinary work;
committed_trial=null and selected_reference=null. No new hypothesis prediction.
Prospective binding: 4ac1e2c4901068cd3a2f382f2d9ca456a64231d28e65ad3b69d3f4e32ee06711.

## Recurrence and labels

Define Q_0=1, Q_1=U+V, Q_(n+2)=S Q_(n+1)-V Q_n using the pinned BiPoly.
The locally compiled frame_left invariant gives the entire frame after k false
steps: lo=(0,1,1), mid=(1,k+2,Q_(k+2)), hi=(1,k+1,Q_(k+1)).
The base polynomial equality is a ring calculation; the successor uses the
unchanged foldl and advance definitions. This identifies the restricted pinned
labels, without proving their correspondence to the published source family.

## Raw coefficient formula: derived, not yet a Lean theorem

In the formal power-series variable t, the recurrence suggests

F(t)=sum_(n>=0) Q_n t^n = (1-t)/(1-(U+V+1)t+Vt^2)
     = sum_(i>=0) U^i t^i (1-t)^(-i) (1-Vt)^(-i-1).

Expanding the two binomial series gives, for i>=1 and i+j<=n,

A(n,i,j) = binom(i+j,j) binom(n-j-1,i-1).

For i=0 the coefficient is 1 exactly at j=n; it is zero otherwise.
For i>=1 and i+j>n it is zero. These boundary clauses are essential: the
unguarded natural-number subtraction formula is wrong outside the support.
For n=0, Q_0=1 is also covered by these piecewise clauses.

The displayed generating-series derivation has not been formalized in Lean;
neither formal division nor infinite-sum rearrangement is silently assumed.
One possible finite proof obligation is the coefficient recurrence, with all
zero/boundary cases, followed by two Pascal identities. In the interior, the
two terms involving j-1 combine using
binom(N,r)-binom(N-1,r)=binom(N-1,r-1), and the remaining two terms use Pascal.
That route still requires the boundary cases and a coefficient extraction lemma.

## Three inequality attempts

For positive coefficients with i>=1, proposed adjacent ratios are

* horizontal: A(n,i+1,j)/A(n,i,j) = (i+j+1)(n-i-j)/(i(i+1));
* vertical: A(n,i,j+1)/A(n,i,j) = (i+j+1)(n-i-j)/((j+1)(n-j-1));
* diagonal: A(n,i+1,j-1)/A(n,i,j) = j(n-j)/(i(i+1)).

The three_ratio_inequalities theorem proves each next ratio is at most its
predecessor, over rational n,i,j under the exact domain conditions. Each ratio
is a product of two nonnegative decreasing factors. The proofs establish the
denominator signs and cross-multiplied inequalities directly; no preservation
of log-concavity by subtraction is used.

To turn this into WeakLC for every Q_n requires the universal coefficient
formula, positivity in its domain, the binomial ratio equalities, and the
transport of ratio monotonicity to raw integer inequalities. These are open
Lean obligations. The only triple involving i=0 is diagonal, starting at
(0,n),(1,n-1),(2,n-2), for n>=2. Its coefficients according to the formula
are 1,n,binom(n,2), so its inequality is binom(n,2)<=n^2. This boundary
calculation also remains part of the universal formal bridge.

The exact remaining propositions CoefficientBridge, FormulaWeakLC and
RestrictedWeakLC are defined in MarkovLeftCoefficientTargets0001.lean.
Its coefficient_targets_suffice is a local conditional transport lemma only;
neither antecedent is proved or added as an axiom. This auxiliary module is
not a fourth admission proposal. Its initial simplification attempt failed
because CoefficientBridge needed explicit unfolding; that attempt is preserved.

## Complete fallback

false_weakLC proves the original WeakLC predicate for (frame [false]).mid,
without replacing its quantifiers, polygon or coefficient convention. The
proof bounds i,j by 3, exhausts those natural indices and dismisses impossible
triples arithmetically. It computes the retained coefficients directly from
the pinned polynomial. There are exactly four valid triples, recorded by the
independent finite Python enumeration: coefficient triples [1,2,1], [1,2,3],
[1,3,3], [3,3,1]. The statement retains zeros through the unchanged predicate;
no coefficient-positivity premise filters triples.

## Exact finite experiment

The coefficients.py consumer loads the existing round-0000 exact recurrence
and runs only the restricted branch, not the earlier slice campaign. Through
n=80 it checks all coefficients in a containing square, every polygon triple
in the three directions, and every applicable adjacent ratio identity and
monotonicity. See coefficients.json for exact counts and runtime. Its success
does not prove the universal formula, restricted WeakLC, full root or source
membership. Sage and symbolic packages were already unavailable; this work
needs only installed Python standard-library arithmetic and pinned Lean.

## Episode review and source obligations

The previous [1,2,3] obstruction remains a reason to retire universal
real-nonpositive-root slices as a sufficient route for the pinned family.
It is not a refutation of coefficient log-concavity. This round makes actual
use of the pinned recurrence, and the earlier source-audit.md was read in
preparing this checkpoint. It supplies a comparison only. All seven independent
correspondence obligations remain open: coverage, source_family,
homogeneity_coefficients, polygon, directions_zeros_endpoints, assumptions,
proof_scope. No source-family or independent admission claim is inferred.

The episode horizon is now reached. There is a concrete restricted local proof
candidate and an explicitly incomplete universal route. Delayed usefulness and
continuation improvement are not certified. No policy/program change is
installed; the next-agenda suggestion is to prove the piecewise coefficient
formula before spending another round on universal left-branch inequalities.

## Preserved failures and capability boundary

The first compiler attempt lacked the root olean in the new build directory.
A direct sequential fresh build of the pinned root fixed that setup failure.
The first induction attempt left 1+(k+2)=k+3; omega closed it. Two fallback
attempts failed in tactic sequencing/coefficient simplification; the successful
version uses arithmetic elimination and explicit coefficient convolution.
Each attempted source and compiler output is retained under unique names.
Failed Lean elaborations may print sorryAx in their diagnostic axiom summaries;
they are rejected attempts, not admitted proofs. Successful candidates print
only propext, Classical.choice and Quot.sound.
The separate MarkovLeftSubmissionCheck0001 module locally elaborates the
exact three proposed statement/term pairs saved in submissions.json. It is an
interface check, not an independent admission or source audit.

The managed filesystem denies reads of workspace .scratch. No forbidden reads
or escalation were attempted. Compiler artifacts are retained, durable research
checkpoints rather than disposable temporary files. No Lake execution, network,
dependency updates, concurrent Lean compilers, other agents, Git or controllers
were used in this round.
