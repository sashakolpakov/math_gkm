"""Machine-authored sequential fresh compiler, round-0002. Durable research build.
.scratch is denied by managed policy; no temporary files, old oleans, Lake or network.
"""
from pathlib import Path
import os, subprocess, time, json, sys
root=Path.cwd()
prefix="plan0002-leftcoeff-20261018-2134"
build=root/"research"/(prefix+"-build")
(build/"MathGKM").mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
packages=json.loads(Path("lake-manifest.json").read_text())["packages"]
env["LEAN_PATH"]=":".join([str(build)]+[str(root/".lake/packages"/p["name"]/".lake/build/lib/lean") for p in packages])
for module in sys.argv[1:]:
 stamp=str(time.time_ns()); source=Path("MathGKM")/(module+".lean")
 (Path("research")/(prefix+"-"+module+"-attempt-"+stamp+".lean")).write_bytes(source.read_bytes())
 cmd=["/Users/sasha/.elan/bin/lean","-o",str(build/"MathGKM"/(module+".olean")),str(source)]
 start=time.monotonic()
 try:
  r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=65)
  output,code=r.stdout,r.returncode
 except subprocess.TimeoutExpired as ex: output,code=str(ex.stdout),124
 report="Command: "+repr(cmd)+"\nElapsed: "+str(time.monotonic()-start)+"\nReturn code: "+str(code)+"\n"+output
 (Path("research")/(prefix+"-"+module+"-compile-"+stamp+".txt")).write_text(report)
 print(report,flush=True)
 if code: sys.exit(code)
