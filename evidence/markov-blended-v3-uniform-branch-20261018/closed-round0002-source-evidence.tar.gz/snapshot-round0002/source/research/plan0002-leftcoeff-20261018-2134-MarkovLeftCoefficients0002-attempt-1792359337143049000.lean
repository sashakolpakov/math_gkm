import MathGKM.MarkovLeftCoefficientTargets0001

/-! Machine-authored round-0002 coefficient proof attempt. No new premises. -/
namespace MathGKM.Markov.LeftBranch0001
noncomputable section

theorem coeff_step_00 (n : ℕ) : coeff (Q (n+2)) 0 0 = coeff (Q (n+1)) 0 0 := by
  simp [Q, S, U, V, coeff, add_mul]

theorem coeff_step_0s (n j : ℕ) :
    coeff (Q (n+2)) 0 (j+1) = coeff (Q (n+1)) 0 j +
      coeff (Q (n+1)) 0 (j+1) - coeff (Q n) 0 j := by
  simp [Q, S, U, V, coeff, add_mul, Polynomial.coeff_X_mul]

theorem coeff_step_s0 (n i : ℕ) :
    coeff (Q (n+2)) (i+1) 0 = coeff (Q (n+1)) i 0 +
      coeff (Q (n+1)) (i+1) 0 := by
  simp [Q, S, U, V, coeff, add_mul, Polynomial.coeff_X_mul]

theorem coeff_step_ss (n i j : ℕ) :
    coeff (Q (n+2)) (i+1) (j+1) = coeff (Q (n+1)) i (j+1) +
      coeff (Q (n+1)) (i+1) j + coeff (Q (n+1)) (i+1) (j+1) -
      coeff (Q n) (i+1) j := by
  simp [Q, S, U, V, coeff, add_mul, Polynomial.coeff_X_mul]

theorem rawFormula_zero (n j : ℕ) : rawFormula n 0 j = if j = n then 1 else 0 := by
  simp [rawFormula]

theorem rawFormula_out (n i j : ℕ) (hi : 0 < i) (h : n < i+j) :
    rawFormula n i j = 0 := by
  simp [rawFormula, Nat.ne_of_gt hi, Nat.not_le.mpr h]

theorem rawFormula_in (n i j : ℕ) (hi : 0 < i) (h : i+j ≤ n) :
    rawFormula n i j = ((i+j).choose j : ℤ) * ((n-j-1).choose (i-1) : ℤ) := by
  simp [rawFormula, Nat.ne_of_gt hi, h]

theorem rawFormula_one (n j : ℕ) :
    rawFormula n 1 j = if j < n then (j+1 : ℕ) else 0 := by
  by_cases h : j < n
  · simp [rawFormula, show 1+j ≤ n by omega, h, Nat.add_comm,
      Nat.choose_succ_self_right]
  · simp [rawFormula, show ¬1+j ≤ n by omega, h]

#print axioms coeff_step_ss
end
end MathGKM.Markov.LeftBranch0001
