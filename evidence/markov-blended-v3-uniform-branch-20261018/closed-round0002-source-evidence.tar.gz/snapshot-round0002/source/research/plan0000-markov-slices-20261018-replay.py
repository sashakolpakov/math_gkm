"""Machine-authored independent finite experiment replay, round-0000.
Reads durable artifacts, enumerates triples directly (without slice traversal),
and compares support evaluations with scalar recurrence at five integer points.
No theorem certification is claimed.
"""
from pathlib import Path
from itertools import product
from math import gcd
import json
import time

prefix="research/plan0000-markov-slices-20261018"
start=time.monotonic()
points=[(0,0),(1,1),(2,3),(-2,1),(1,-3)]
def scalar_frame(bits,u,v):
    lo=(0,1,1); mid=(1,2,(u+v)**2+u); hi=(1,1,u+v)
    for bit in bits:
        shared,other=(hi,lo) if bit else (lo,hi)
        a,b,p=shared; c,d,q=mid
        new=(a+c,b+d,(u+v+1)*p*q-u**a*v**b*other[2])
        lo,mid,hi=(mid,new,hi) if bit else (lo,new,mid)
    return lo,mid,hi

triples=0; violations=[]; checked=0; scalar_checks=0
for f in sorted(Path("research").glob("plan0000-markov-slices-20261018-path-*.json")):
    r=json.loads(f.read_text()); a,b=r["a"],r["b"]
    assert gcd(a,b)==1 and 0<a<b
    bits=[] if r["name"]=="path-empty" else [c=="1" for c in r["name"][5:]]
    p={(i,j):c for i,j,c in r["support"]}
    def inside(i,j):
        return 0<=i and 0<=j and a*b<=b*i+a*j and i+j<=a+b-1
    count=0
    for i,j in product(range(a+b),repeat=2):
        for di,dj in [(1,0),(0,1),(1,-1)]:
            coords=[(i+k*di,j+k*dj) for k in range(3)]
            if all(inside(*c) for c in coords):
                count+=1
                x,y,z=[p.get(c,0) for c in coords]
                if x*z>y*y:
                    violations.append([r["name"],coords,x,y,z])
    assert count==sum(s["raw_triples"] for s in r["slices"])
    for u,v in points:
        lo,mid,hi=scalar_frame(bits,u,v)
        assert mid[:2]==(a,b)
        assert mid[2]==sum(c*u**i*v**j for (i,j),c in p.items())
        assert lo[1]*hi[0]-lo[0]*hi[1]==1
        scalar_checks+=1
    checked+=1; triples+=count

# Endpoints contribute no consecutive triples; verify directly from saved slices.
for name in ["endpoint-0-1","endpoint-1-1"]:
    r=json.loads(Path(prefix+"-"+name+".json").read_text())
    assert sum(s["raw_triples"] for s in r["slices"])==0

out={"provenance":"machine-authored independent finite replay round-0000",
     "midpoints_checked":checked,"endpoints_checked":2,"scalar_recurrence_checks":scalar_checks,
     "direct_raw_triples":triples,"raw_violations":violations,
     "witness":{"path":[False],"a":1,"b":3,"i":1,"j_values":[0,1,2],
                "coefficients":[1,2,3],"discriminant":2**2-4*3*1,
                "raw_outer_product":3,"raw_middle_square":4,
                "positive_identity":"3*(1+2*t+3*t^2)=(3*t+1)^2+2"},
     "elapsed_seconds":time.monotonic()-start,"status":"passed"}
assert checked==31 and triples==4047 and not violations
Path(prefix+"-replay.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
