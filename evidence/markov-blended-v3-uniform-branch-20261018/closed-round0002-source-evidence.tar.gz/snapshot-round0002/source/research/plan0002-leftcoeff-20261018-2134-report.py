"""Machine-authored report: hashes bind files, never certify mathematical truth."""
from pathlib import Path
import json,hashlib
p='research/plan0002-leftcoeff-20261018-2134'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
files=sorted(str(f) for f in Path('research').glob('plan0002-leftcoeff-20261018-2134-*') if f.is_file() and not f.name.endswith(('-manifest.json','-report.json')))
sources=['MathGKM/Markov.lean','MathGKM/MarkovLeftBranch0001.lean','MathGKM/Target29afbfe864de98b5d01fd5bf.lean','MathGKM/Accepted95a4e0482c798d7a5531cd05.lean','MathGKM/MarkovLeftCoefficientTargets0001.lean','MathGKM/MarkovLeftCoefficients0002.lean','MathGKM/MarkovLeftFormulaLC0002.lean','MathGKM/MarkovLeftWeakLC0002.lean','MathGKM/MarkovLeftSubmissionCheck0002.lean']
assert sha('MathGKM/Markov.lean')=='8b8408e5cae9822fe0969afd4a70b408d48e69f750dffb88c253dba8ef167dbe'
manifest={'request_id':'round-0002','provenance':'Machine-authored active researcher; fresh source build; no independent acceptance claimed','files':{f:sha(f) for f in sorted(files+sources)}}
Path(p+'-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
evidence=[]
for f in ['MISSION.md','docs/DESIGN.md','contract.json']+sources:
 evidence.append(dict(path=f,sha256=sha(f),kind='proof_candidate' if '0002' in f else 'source'))
for suffix,kind in [('-checkpoint.md','proof_candidate'),('-submissions.json','proof_candidate'),('-manifest.json','experiment')]:
 f=p+suffix; evidence.append(dict(path=f,sha256=sha(f),kind=kind))
for module in ['Markov','Accepted95a4e0482c798d7a5531cd05','MarkovLeftCoefficients0002','MarkovLeftFormulaLC0002','MarkovLeftWeakLC0002','MarkovLeftSubmissionCheck0002']:
 f=str(sorted(Path('research').glob('plan0002-leftcoeff-20261018-2134-'+module+'-compile-*.txt'))[-1])
 assert 'Return code: 0' in Path(f).read_text(),f
 assert 'sorryAx' not in Path(f).read_text(),f
 evidence.append(dict(path=f,sha256=sha(f),kind='proof_candidate'))
links=[
 ('MathGKM/MarkovLeftCoefficientTargets0001.lean','MathGKM/MarkovLeftCoefficients0002.lean','Uses the existing unchanged rawFormula and CoefficientBridge definitions; proves the bridge by coefficient recurrence and induction.'),
 ('MathGKM/MarkovLeftCoefficients0002.lean','MathGKM/MarkovLeftFormulaLC0002.lean','Uses the proved rawFormula_in and rawFormula_one boundary lemmas in all three formula inequality directions.'),
 ('MathGKM/MarkovLeftFormulaLC0002.lean','MathGKM/MarkovLeftWeakLC0002.lean','Consumes formula_weakLC with coefficient_bridge through coefficient_targets_suffice.'),
 ('MathGKM/Accepted95a4e0482c798d7a5531cd05.lean','MathGKM/MarkovLeftWeakLC0002.lean','Consumes the freshly rebuilt accepted obligation to transport restricted WeakLC to every all-false frame.'),
 (p+'-submissions.json','MathGKM/MarkovLeftSubmissionCheck0002.lean','The exact saved statement/term pairs generated this module and passed local elaboration.')]
payload=dict(agenda=['Continue published-markov-6-3-clean-v2, phase markov; retain full rational coverage and all seven source-correspondence obligations as open.','Retain the completed restricted coefficient and WeakLC candidates pending independent admission; no new invention episode or policy installation.'],
 summary='Completed the committed ordinary proof work; trial and selected reference are null. Freshly rebuilt the pinned root and accepted midpoint export source closure. Locally proved the exact CoefficientBridge for all n,i,j, FormulaWeakLC in all three directions including the i=0 diagonal boundary, and original WeakLC for every all-false path. RestrictedWeakLC follows as an intermediate theorem. All three exact submitted propositions passed local elaboration with only propext, Classical.choice and Quot.sound. Independent admission remains pending. The overall 900-second cap was respected; final checkpoint and submission preparation exceeded its 90-second suballocation. Preserved all failed attempts and source/log checkpoints. The managed temporary-storage limitation was handled with durable research artifacts. Full Conjecture63, universal rational coverage and all seven correspondence obligations remain open. No hypothesis finding, new episode, usefulness certification, policy change or completion claim.',
 hypotheses=[],evidence=evidence,trial=None,work_kind='ordinary',findings=[],commitment_ref=None,
 use_links=[dict(artifact=a,consumer=c,claim=s) for a,c,s in links],policy_proposal=None,executable_proposal=None,
 discovery_rechecks=[],discovery_completion=None,prospective_binding='f3afa95b8ad66694b2647d14327ba684bb5d68a7b7076c3d15478344d814c93b',
 mathematical_claims=json.loads(Path(p+'-submissions.json').read_text()),attachments=[],representations=[],reductions=[],fiber_gluings=[],completion=None)
Path(p+'-report.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(payload,ensure_ascii=False,separators=(',',':')))
