"""Machine-authored exact restricted-branch experiment, round-0001.
Reuses the active round-0000 scalar recurrence, not the root-test conjecture.
Finite evidence only; no universal certificate or source-family claim.
"""
from pathlib import Path
from math import comb
from fractions import Fraction
import runpy, json, time, sys

start = time.monotonic()
old = runpy.run_path("research/plan0000-markov-slices-20261018-exact.py")
initial, next_label, inside = old["INITIAL"], old["next_label"], old["inside"]

def candidate(n, i, j):
    if i == 0:
        return int(j == n)
    if i + j > n:
        return 0
    return comb(i+j, j) * comb(n-j-1, i-1)

def ratio(n, i, j, di, dj):
    if (di, dj) == (1, 0):
        return Fraction((i+j+1)*(n-i-j), i*(i+1))
    if (di, dj) == (0, 1):
        return Fraction((i+j+1)*(n-i-j), (j+1)*(n-j-1))
    return Fraction(j*(n-j), i*(i+1))

lo, mid, hi = initial
rows, witnesses = [], []
counts = {"coefficient_comparisons": 0, "raw_triples": 0,
          "ratio_identity_comparisons": 0, "ratio_monotonicity_comparisons": 0,
          "zero_entries_retained": 0}
for n in range(1, 81):
    if time.monotonic() - start > 120:
        raise TimeoutError("120-second finite coefficient experiment cap")
    if n == 1:
        label = hi
    elif n == 2:
        label = mid
    else:
        lo, mid, hi = lo, next_label(lo, mid, hi), mid
        label = mid
    a, b, p = label
    assert (a, b) == (1, n)
    for i in range(n+2):
        for j in range(n+2):
            c = p.get((i,j), 0)
            assert c == candidate(n,i,j), (n,i,j,c,candidate(n,i,j))
            counts["coefficient_comparisons"] += 1
            counts["zero_entries_retained"] += int(c == 0)
    for i in range(n+1):
        for j in range(n+1-i):
            for di, dj in [(1,0),(0,1),(1,-1)]:
                points = [(i+t*di,j+t*dj) for t in range(3)]
                if not all(inside(1,n,x,y) for x,y in points):
                    continue
                cs = [p.get(xy,0) for xy in points]
                assert cs[0]*cs[2] <= cs[1]**2, (n, points, cs)
                counts["raw_triples"] += 1
                if i >= 1:
                    r0 = ratio(n,i,j,di,dj)
                    r1 = ratio(n,i+di,j+dj,di,dj)
                    assert r0 == Fraction(cs[1],cs[0])
                    assert r1 == Fraction(cs[2],cs[1])
                    assert r1 <= r0
                    counts["ratio_identity_comparisons"] += 2
                    counts["ratio_monotonicity_comparisons"] += 1
                if n == 3:
                    witnesses.append({"points":points,"coefficients":cs,
                                      "outer_product":cs[0]*cs[2],"middle_square":cs[1]**2})
    rows.append({"n":n,"support_count":len(p)})
report = {"provenance":"machine-authored researcher round-0001",
          "scope":"1 <= n <= 80, all coefficients in a containing square, all valid triples",
          "status":"passed","counts":counts,"rows":rows,
          "path_false_all_triples":witnesses,
          "elapsed_seconds":time.monotonic()-start,"python":sys.version,
          "not_established":["universal Lean coefficient formula","source correspondence","full root"]}
out = Path("research/plan0001-leftbranch-20261018-coefficients.json")
if out.exists():
    raise FileExistsError(out)
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k != "rows"},ensure_ascii=False,indent=2))
