# Restricted coefficient proof checkpoint

Machine-authored by the active researcher, request round-0002, 2026-10-18.
Active contract: published-markov-6-3-clean-v2, phase markov.
Ordinary work: committed_trial=null; commitment.selected_reference=null.
Prospective binding: f3afa95b8ad66694b2647d14327ba684bb5d68a7b7076c3d15478344d814c93b.
There are no new or revised hypothesis predictions or hypothesis findings.

## Fresh inputs and resource boundaries

Read MISSION.md, docs/DESIGN.md and contract.json in full, followed by the
existing restricted-branch definitions, exact targets, accepted midpoint export,
target module, coefficient derivation and compiler runner. The historical
campaigns and real-rootedness experiment were not rerun. No other agents,
controllers, network, Lake, Git, package changes or background processes used.
All compiler invocations are sequential, using pinned Lean and dependencies.

Setup started at 21:33:57 UTC. By 21:35:34 the pinned root, LeftBranch0001,
Target29afbfe864de98b5d01fd5bf, accepted export, and coefficient targets had
been freshly rebuilt from source into this round's durable research build.
No earlier local project olean is on LEAN_PATH. Standard pinned dependency
oleans remain read-only. The source snapshots and individual command, return
code, elapsed time and diagnostic logs are preserved with unique timestamps.

The managed policy denies .scratch reads and temporary-directory access. The
first shell here-document failed because zsh could not create its temporary
file; the following compiler-runner invocation therefore found no runner.
The correction used direct file patches and durable research build artifacts,
without accessing the denied storage. This is a storage capability limitation,
not mathematical evidence. There are no disposable temporary artifacts.

## Coefficient bridge

MathGKM.MarkovLeftCoefficients0002 proves the exact existing CoefficientBridge,
unchanged: for every n,i,j, coeff(Q n) i j = rawFormula n i j.
It uses Nat.twoStepInduction, checking n=0 and n=1 separately. Coefficient
extraction gives the four recurrences at (0,0), (0,j+1), (i+1,0), and
(i+1,j+1). The piecewise formula satisfies each of these recurrences.
The i=0 row is a Kronecker delta. The i=1 row is j+1 when j<n and zero
otherwise. The positive-index interior follows two Pascal identities and ring
algebra. When j>=n, all terms in the i>=2 recurrence are outside support.
For j<n, removing the support guard is justified by choose_eq_zero_of_lt,
so truncated subtraction never silently supplies an outside-support value.

The exact bridge passed local compilation by 21:38:04, within 150 seconds
of completing setup, below its 480-second allocation. Initial elaborations
failed on coefficient-one simplification, equality orientation and a tactic
variable scope; every failed source snapshot and diagnostic remains preserved.
The successful theorem axiom closure is exactly propext, Classical.choice,
Quot.sound. No generating-series claim or experimental formula is assumed.

## Inequalities

MathGKM.MarkovLeftFormulaLC0002 proves the unchanged FormulaWeakLC.
First, exact binomial identities yield two rational adjacent ratios:
choose(n,k+1)/choose(n,k)=(n-k)/(k+1), and
choose(n+1,k)/choose(n,k)=(n+1)/(n+1-k).
Every denominator is proved positive or nonzero before comparison. Their
monotonicity proves log-concavity with fixed upper index and with fixed lower
index. The product of two nonnegative log-concave triples is log-concave.

For horizontal triples, apply these two binomial lemmas directly to the two
formula factors. For vertical triples use binomial symmetry on the first
factor and reverse the three upper indices in the second factor. For diagonal
triples with i>=1, symmetry makes the second factor's lower index constant,
n-i-j-2. All index equalities and natural subtraction bounds are proved.
The polygon excludes i=0 horizontal and vertical triples. At diagonal i=0,
the polygon forces n=j+2 and the coefficient triple is 1,n,choose(n,2).
The inequality follows choose(n,2)<=n^2. No zero is removed from WeakLC.

FormulaWeakLC passed locally by 21:40:33. Initial failed attempts concerned
arithmetic index congruences, binomial symmetry orientation and the argument
order of choose_le_pow; retained logs show these failures. The successful
axiom closure contains only the permitted three axioms. The earlier ratio
candidate and its invalid_comparison receipt were not consumed or admitted.

## Transport and scope

MathGKM.MarkovLeftWeakLC0002 applies coefficient_targets_suffice to the two
proved antecedents, obtaining RestrictedWeakLC for every n>=1. It then uses
Accepted95a4e0482c798d7a5531cd05.obligation, from this round's fresh rebuild,
to prove the original WeakLC statement for every frame(List.replicate k false).
The proposed submissions prioritize CoefficientBridge, FormulaWeakLC, and
this universal all-false-path consequence. RestrictedWeakLC is an intermediate
theorem rather than an extra fourth submission.

These are locally checked candidates for independent admission, not receipts
of independent acceptance. They do not establish the full Conjecture63 root.
All seven correspondence obligations remain open: coverage, source_family,
homogeneity_coefficients, polygon, directions_zeros_endpoints, assumptions,
proof_scope. Universal rational coverage beyond this branch remains open.
No completion request, new invention episode, policy proposal, executable
proposal, usefulness certification or persistent switch is made. The reviewed
episode is not extended; delayed benefit is not certified by this report.
