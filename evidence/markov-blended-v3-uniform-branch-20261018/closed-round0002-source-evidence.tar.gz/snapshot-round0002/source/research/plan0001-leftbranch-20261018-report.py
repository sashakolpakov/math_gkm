"""Machine-authored checkpoint manifest and researcher report, not certification."""
from pathlib import Path
import hashlib, json, time

prefix = "plan0001-leftbranch-20261018"
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
paths = sorted(set(
    [p for p in Path("research").glob(prefix+"*") if p.is_file()] +
    list(Path("MathGKM").glob("MarkovLeft*0001.lean")) +
    list(Path("research" , prefix+"-build").rglob("*.olean"))))
manifest = Path("research")/(prefix+"-manifest.json")
if manifest.exists():
    raise FileExistsError(manifest)
manifest.write_text(json.dumps({"provenance":"machine-authored researcher round-0001",
    "status":"local artifacts; independent checks pending",
    "files":[{"path":str(p),"sha256":digest(p)} for p in paths]},
    ensure_ascii=False,indent=2)+"\n")

evidence_specs = [
    ("MISSION.md","source"), ("docs/DESIGN.md","source"),
    ("contract.json","source"), ("MathGKM/Markov.lean","source"),
    ("MathGKM/MarkovLeftBranch0001.lean","proof_candidate"),
    ("MathGKM/MarkovLeftWeakLC0001.lean","proof_candidate"),
    ("MathGKM/MarkovLeftRatios0001.lean","proof_candidate"),
    ("MathGKM/MarkovLeftCoefficientTargets0001.lean","representation"),
    ("MathGKM/MarkovLeftSubmissionCheck0001.lean","proof_candidate"),
    ("research/"+prefix+"-coefficients.py","experiment"),
    ("research/"+prefix+"-coefficients.json","experiment"),
    ("research/"+prefix+"-derivation.md","proof_candidate"),
    ("research/"+prefix+"-submissions.json","proof_candidate"),
    (str(manifest),"experiment")]
payload = {
    "agenda":[
        "Continue the active Markov campaign with its unchanged full root and all seven correspondence obligations; retain the retired real-rooted-slice route and its obstruction.",
        "Next prove LeftBranch0001.CoefficientBridge, including all piecewise zero and boundary cases; then prove FormulaWeakLC and connect it to RestrictedWeakLC.",
        "Seek independent checking of the three submitted candidates; keep source-family membership and delayed usefulness separate from local compilation."
    ],
    "summary":"Executed the committed ordinary work with trial=null and selected_reference=null. The pinned root hash matches. Three closed candidates passed sequential local Lean compilation and exact statement/term elaboration: the universal left-branch midpoint recurrence bridge, complete original WeakLC for path [false], and three rational adjacent-ratio monotonicity inequalities. Successful axiom summaries contain only propext, Classical.choice and Quot.sound; independent admission remains pending. Derived a piecewise raw binomial coefficient formula and checked it through Q_80: 187160 coefficient comparisons, 246559 raw triples and 492960 ratio identities passed. These finite checks do not prove the universal coefficient bridge or restricted WeakLC. Exact remaining Lean targets, failed attempts and compiler outputs are preserved in uniquely named research checkpoints. At the episode horizon the prior real-rooted-slice obstruction retires that universal strengthening; coefficient log-concavity is not refuted. All seven source-correspondence obligations and the full root remain open. Delayed usefulness and continuation improvement are uncertified; no policy or program change was installed. The managed .scratch read denial required durable research build checkpoints.",
    "hypotheses":[],
    "evidence":[{"path":p,"sha256":digest(p),"kind":k} for p,k in evidence_specs],
    "trial":None,
    "work_kind":"ordinary",
    "findings":[],
    "commitment_ref":None,
    "use_links":[
        {"artifact":"MathGKM/Markov.lean","consumer":"MathGKM/MarkovLeftBranch0001.lean","claim":"Imports the pinned frame and polynomial definitions in the locally compiled universal left-branch frame invariant."},
        {"artifact":"MathGKM/MarkovLeftBranch0001.lean","consumer":"MathGKM/MarkovLeftCoefficientTargets0001.lean","claim":"Uses Q in the explicit remaining coefficient and restricted WeakLC targets and their conditional transport lemma."},
        {"artifact":"research/plan0000-markov-slices-20261018-exact.py","consumer":"research/"+prefix+"-coefficients.py","claim":"The executed consumer loads and uses next_label and inside for the restricted-branch exact replay."},
        {"artifact":"research/plan0000-markov-slices-20261018-source-audit.md","consumer":"research/"+prefix+"-derivation.md","claim":"The earlier source comparison was consulted and its seven unresolved correspondence obligations retained in the checkpoint."},
        {"artifact":"research/"+prefix+"-submissions.json","consumer":"MathGKM/MarkovLeftSubmissionCheck0001.lean","claim":"The same three saved statement/term pairs were generated into this module and elaborated locally."}
    ],
    "policy_proposal":None,
    "executable_proposal":None,
    "discovery_rechecks":[],
    "discovery_completion":None,
    "prospective_binding":"4ac1e2c4901068cd3a2f382f2d9ca456a64231d28e65ad3b69d3f4e32ee06711",
    "mathematical_claims":json.loads(Path("research/"+prefix+"-submissions.json").read_text()),
    "attachments":[],"representations":[],"reductions":[],"fiber_gluings":[],
    "completion":None
}
for e in payload["evidence"]:
    assert Path(e["path"]).is_file() and digest(e["path"]) == e["sha256"]
for link in payload["use_links"]:
    assert set(link) == {"artifact","consumer","claim"}
    assert all(Path(link[k]).is_file() for k in ["artifact","consumer"])
assert len(payload["mathematical_claims"]) == 3
report = Path("research")/(prefix+"-report.json")
if report.exists():
    raise FileExistsError(report)
report.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"request_id":"round-0001","payload_json":json.dumps(payload,ensure_ascii=False,separators=(",",":"))},ensure_ascii=False))
