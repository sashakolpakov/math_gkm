"""Machine-authored exact, closed checked-interface proposals.
This writes proposals and a local elaboration check, never an admission receipt.
"""
from pathlib import Path
import json

claims = [
    {
        "id": "markov-leftbranch0001-mid-recurrence",
        "module": "MathGKM.MarkovLeftBranch0001",
        "statement": "∀ k : ℕ, (MathGKM.Markov.frame (List.replicate k false)).mid.a = 1 ∧ (MathGKM.Markov.frame (List.replicate k false)).mid.b = k+2 ∧ (MathGKM.Markov.frame (List.replicate k false)).mid.p = MathGKM.Markov.LeftBranch0001.Q (k+2)",
        "term": "MathGKM.Markov.LeftBranch0001.mid_left"
    },
    {
        "id": "markov-leftbranch0001-false-weaklc",
        "module": "MathGKM.MarkovLeftWeakLC0001",
        "statement": "MathGKM.Markov.WeakLC (MathGKM.Markov.frame [false]).mid.a (MathGKM.Markov.frame [false]).mid.b (MathGKM.Markov.frame [false]).mid.p",
        "term": "MathGKM.Markov.LeftBranch0001.false_weakLC"
    },
    {
        "id": "markov-leftbranch0001-three-ratios",
        "module": "MathGKM.MarkovLeftRatios0001",
        "statement": "(∀ n i j : ℚ, 1 ≤ i → 0 ≤ j → i+j+2 ≤ n → ((i+j+2)/(i+2))*((n-i-j-1)/(i+1)) ≤ ((i+j+1)/(i+1))*((n-i-j)/i)) ∧ (∀ n i j : ℚ, 1 ≤ i → 0 ≤ j → i+j+2 ≤ n → ((i+j+2)/(j+2))*((n-i-j-1)/(n-j-2)) ≤ ((i+j+1)/(j+1))*((n-i-j)/(n-j-1))) ∧ (∀ n i j : ℚ, 1 ≤ i → 2 ≤ j → i+j ≤ n → ((j-1)/(i+2))*((n-j+1)/(i+1)) ≤ (j/(i+1))*((n-j)/i))",
        "term": "MathGKM.Markov.LeftBranch0001.three_ratio_inequalities"
    }
]
out = Path("research/plan0001-leftbranch-20261018-submissions.json")
if out.exists():
    raise FileExistsError(out)
out.write_text(json.dumps(claims, ensure_ascii=False, indent=2)+"\n")
lean = Path("MathGKM/MarkovLeftSubmissionCheck0001.lean")
if lean.exists():
    raise FileExistsError(lean)
lean.write_text("/- Machine-authored local exact proposal interface check. -/\n" +
    "\n".join("import " + c["module"] for c in claims) + "\n\n" +
    "\n\n".join("example : " + c["statement"] + " := " + c["term"] for c in claims) + "\n")
