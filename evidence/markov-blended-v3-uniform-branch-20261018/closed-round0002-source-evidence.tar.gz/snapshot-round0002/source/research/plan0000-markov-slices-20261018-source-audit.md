# Committed source audit, round 0

Machine-authored by the active researcher, 2026-10-18. Contract: published-markov-6-3-clean-v2. Trial: markov-slice-realroot-route-v0. Immutable reference: b4f28ca309ddd3bef79f3327601ff47e32e43c7c723e2255acd5e3203409bed0.

Primary source retrieved with the browsing tool (not shell networking): [Evans–Veselov–Winn, publisher HTML](https://armj.math.stonybrook.edu/Articles/250708-Winn/index.html). Inspected equations (5), (7)–(11), Definitions 6.1–6.2, Conjecture 6.3, and the adjacent rational-index discussion. Also opened the [arXiv HTML](https://arxiv.org/html/2501.14882v1); the comparison below uses the publisher version. Retrieval succeeded. This is a human-readable comparison, not independent source certification.

## Source comparison

Equation (5) matches the three initial labels after squaring variables and setting w=1. Equations (7) and (9) give total numerator degree a+b−1 and the raw coefficient convention. Equation (8) specializes to the subtraction recurrence. Both advances use the shared endpoint as its c/d. Equation (10) defines the convex-hull polygon; (11), for positive a,b, becomes ab≤bi+aj and i+j≤a+b−1. Definitions 6.1–6.2 match the three consecutive-triple inequalities and directions. Conjecture 6.3 supplies their universal target. The source separately sets P_0/1=1; the singleton convention is consistent. No discrepancy was found in these inspected formulas. This observation does not prove correspondence.

## Researcher-derived correspondence obligations, all retained

* **coverage:** Prove every reduced rational 0<a≤b appears among the midpoint paths or the 1/1 endpoint; prove path labels reduced and in range. Initial neighbor determinant is one, and each advance preserves that determinant algebraically; a complete terminating rational-search proof has not been supplied.
* **source_family:** Define an explicit source Laurent-polynomial interpretation and prove initial and advance compatibility, including the reflected neighbor ordering for the left advance. Substituting formal labels into a displayed formula is not a kernel bridge.
* **homogeneity_coefficients:** Reconstruct the homogeneous three-variable numerator and prove that setting w=1 preserves precisely its raw (i,j) coefficients. For the right advance, product total degree is (h.a+h.b−1)+(m.a+m.b−1)+1; the subtracted homogeneous monomial needs w^(h.a+h.b). These total degrees agree with the new label when m=lo+hi. The analogous left identity needs the low endpoint. These observations have not been formalized.
* **polygon:** Prove the convex hull of the reconstructed support equals the pinned inequality region; the source theorem has not been imported as an axiom. Saturation is neither assumed nor substituted for the polygon definition.
* **directions_zeros_endpoints:** Prove maximal-segment enumeration corresponds to every Lean triple, retaining internal zero coefficients. The third Lean conjunct traverses the same anti-diagonal in increasing i. Prove the degenerate endpoint cases separately.
* **assumptions:** No source statement, numerical library assertion, or observed positivity is added to Lean assumptions. Any future checked proof must satisfy the permitted axiom closure.
* **proof_scope:** A length≤4 scan cannot establish the full path quantifier, a universal slice theorem, or any source bridge. An exact slice obstruction only rejects the sufficient strengthening for the pinned family unless its source membership is independently established.

## Capability and execution notes

/opt/homebrew/bin/python3 is Python 3.14.6. Import discovery reports neither sympy nor sageall. Standard-library exact arithmetic is used instead; no packages are installed. The first environment probe used a shell here-document and failed before execution because zsh could not create its external temporary file. It was rerun successfully with python -c. This failed attempt is retained here. No mathematical inference follows from it. No Lean compiler has been launched at this checkpoint.
