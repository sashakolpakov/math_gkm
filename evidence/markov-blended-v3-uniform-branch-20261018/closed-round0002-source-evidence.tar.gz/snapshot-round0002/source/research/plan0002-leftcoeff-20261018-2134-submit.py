"""Machine-authored exact proposals, interface module and evidence manifest."""
from pathlib import Path
import json, hashlib
prefix='research/plan0002-leftcoeff-20261018-2134'
ns='MathGKM.Markov.LeftBranch0001.'
claims=[
 dict(id='markov-leftcoeff0002-coefficient-bridge',module='MathGKM.MarkovLeftCoefficients0002',
      statement='∀ n i j : ℕ, MathGKM.Markov.coeff (MathGKM.Markov.LeftBranch0001.Q n) i j = MathGKM.Markov.LeftBranch0001.rawFormula n i j',term=ns+'coefficient_bridge'),
 dict(id='markov-leftcoeff0002-formula-weakLC',module='MathGKM.MarkovLeftFormulaLC0002',
      statement=ns+'FormulaWeakLC',term=ns+'formula_weakLC'),
 dict(id='markov-leftcoeff0002-all-false-weakLC',module='MathGKM.MarkovLeftWeakLC0002',
      statement='∀ k : ℕ, let m := (MathGKM.Markov.frame (List.replicate k false)).mid; MathGKM.Markov.WeakLC m.a m.b m.p',term=ns+'all_false_weakLC')]
Path(prefix+'-submissions.json').write_text(json.dumps(claims,ensure_ascii=False,indent=2)+'\n')
check='import MathGKM.MarkovLeftWeakLC0002\n\n/-! Machine-authored exact submission elaboration, not independent admission. -/\n'
for i,c in enumerate(claims):
 check+=f'\ntheorem MathGKM.Markov.LeftBranch0001.submission0002_{i} :\n    {c["statement"]} :=\n  {c["term"]}\n#print axioms MathGKM.Markov.LeftBranch0001.submission0002_{i}\n'
Path('MathGKM/MarkovLeftSubmissionCheck0002.lean').write_text(check)
