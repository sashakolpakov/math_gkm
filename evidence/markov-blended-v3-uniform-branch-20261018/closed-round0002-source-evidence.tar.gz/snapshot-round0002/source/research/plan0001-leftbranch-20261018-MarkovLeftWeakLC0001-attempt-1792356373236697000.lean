import MathGKM.MarkovLeftBranch0001

/-! Machine-authored complete pinned WeakLC result for path [false].
All triples are retained by using the original predicate without alteration. -/
namespace MathGKM.Markov.LeftBranch0001

theorem false_polynomial :
    (frame [false]).mid.p =
      U^3 + 3*U^2*V + 3*U*V^2 + V^3 + 2*U^2 + 2*U*V + U := by
  norm_num [frame, advance, initial, S]
  ring

theorem false_weakLC :
    WeakLC (frame [false]).mid.a (frame [false]).mid.b
      (frame [false]).mid.p := by
  have ha : (frame [false]).mid.a = 1 := by rfl
  have hb : (frame [false]).mid.b = 3 := by rfl
  rw [ha, hb, false_polynomial]
  unfold WeakLC
  refine ⟨?_, ?_, ?_⟩
  all_goals
    intro i j h₀ h₁ h₂
    unfold InPolygon at h₀ h₁ h₂
    have hi : i ≤ 3 := by omega
    have hj : j ≤ 3 := by omega
    interval_cases i <;> interval_cases j <;>
      norm_num at h₀ h₁ h₂ ⊢
  all_goals
    norm_num [coeff, U, V, pow_succ, Polynomial.mul_coeff_one]
    simp [Polynomial.coeff_one, Polynomial.coeff_X]

#print axioms false_weakLC
end MathGKM.Markov.LeftBranch0001
