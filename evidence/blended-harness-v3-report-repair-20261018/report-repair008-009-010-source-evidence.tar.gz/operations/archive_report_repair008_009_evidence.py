#!/usr/bin/env python3
"""Bounded source-only008/009 engineering history. Root executes after009tests.
No research/builds/deletion/publication. Select only immutable checkpoints,
completed named tests/fixtures and final installation records. Never traverse
curation, suites, evaluations or active Markov studies.
"""
import argparse,codecs,gzip,hashlib,io,json,os,re,tarfile
from pathlib import Path
ROOT=Path('/Users/sasha/math_gkm')
OPS=ROOT/'.bootstrap/construction-v3-20261018'
CANDIDATE=ROOT/'.scratch/strategy-v3-blended-20261018'
F008=CANDIDATE/'evidence/construction-v3/source-audit-008'
F009=CANDIDATE/'evidence/construction-v3/source-audit-009'
INSTALLATION=ROOT/'evidence/harness-v3-install/20261018-009'
MANIFEST008='1bbee7531445753d1714e0e0f9641465977a938b554c492f41af90e826afd71f'
WATCH7B='5ede968f0d79a4fd192832822de6a3f266b2226dde2cd043b26f54ea8f3ff191'
MAX_FILES=12000
MAX_MEMBER=128*1024**2
MAX_TOTAL=512*1024**2
PRUNE={'.git','.lake','__pycache__','evaluation','curation-0001'}
BINARY_SUFFIXES={'.olean','.ilean','.o','.a','.so','.dylib','.dll','.exe','.bin','.zip','.pyc','.png','.jpg','.pdf','.c','.bc','.ll','.trace','.hash'}
REVIEWS=('math_gkm_resource_repro_frozen008_review_20261018.md',
 'math_gkm_v3_checkpoint008_admission_review.md',
 'math_gkm_resource_repro_frozen009_review_20261018.md',
 'math_gkm_v3_checkpoint009_admission_review.md')
MAPPINGS=((F008,'operations/round-0007-source-audit-008'),
 (F009,'operations/round-0008-source-audit-009'),(OPS,'operations'),
 (INSTALLATION,'installation009'),(CANDIDATE,'candidate'))

def fail(message): raise RuntimeError(message)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as source:
  for block in iter(lambda:source.read(1048576),b''):h.update(block)
 return h.hexdigest()
def stable(st): return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
def name_for(path):
 for base,prefix in MAPPINGS:
  if path.is_relative_to(base):return prefix+'/'+path.relative_to(base).as_posix()
 if path.parent==Path('/private/tmp') and (path.name in REVIEWS or path.name=='math_gkm_v3_hypothesis_evidence009_criteria.md'):
  return 'independent-review/'+path.name
 if path.is_relative_to(ROOT):return 'repository-prerequisites/'+path.relative_to(ROOT).as_posix()
 fail('unapproved source root: '+str(path))
def excluded_by_name(path):
 return (any(path.name.endswith(s) for s in ('.olean.private','.olean.server','.tar.gz','.tar'))
         or path.suffix in BINARY_SUFFIXES)

def text_or_json_gzip(path):
 # Gzip is allowed ONLY for complete premise JSON, never a generic binary archive.
 if path.name.endswith('.json.gz'):return True
 if excluded_by_name(path):return False
 decoder=codecs.getincrementaldecoder('utf-8')('strict')
 try:
  with path.open('rb') as source:
   for block in iter(lambda:source.read(1048576),b''):
    if b'\0' in block:return False
    decoder.decode(block)
  decoder.decode(b'',final=True)
 except UnicodeDecodeError:return False
 return True



def sources(manifest009):
 if not re.fullmatch('[0-9a-f]{64}',manifest009):fail('explicit frozen009 manifest hash required')
 selected={};skipped=[];scanned=0;outcomes={};fixtures={}
 def add(path,required=False):
  nonlocal scanned
  path=Path(os.path.abspath(path))
  if not path.exists():
   if required:fail('required finished engineering evidence missing: '+str(path))
   return
  if any(part in ('curation-0001','evaluation') or part.startswith('paired-v3-live-') for part in path.parts):
   fail('research/heldout path outside engineering archive scope')
  if path.is_symlink():
   if required:fail('required evidence is symlink')
   skipped.append({'path':name_for(path),'reason':'symlink; rebuild dependency from pins'});return
  if not path.is_file():fail('explicit member not regular')
  scanned+=1
  if scanned>MAX_FILES:fail('bounded file count')
  before=path.stat()
  if excluded_by_name(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'compiled or derived nonsource output'});return
  if before.st_size>MAX_MEMBER:fail('bounded member size')
  if not text_or_json_gzip(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'nonsource binary'});return
  value=digest(path)
  if stable(path.stat())!=stable(before):fail('source changed during inventory')
  selected[name_for(path)]={'source_path':str(path),'bytes':before.st_size,'sha256':value,'stat_identity':stable(before)}
 def tree(path):
  if not path.is_dir():fail('required finished bounded tree missing: '+str(path))
  for directory,dirs,files in os.walk(path,followlinks=False,onerror=lambda e:fail(str(e))):
   dirs[:]=sorted(d for d in dirs if d not in PRUNE and not (Path(directory)/d).is_symlink())
   for name in sorted(files):add(Path(directory)/name)
 for number,frozen,roundname,expected in (('008',F008,'round-0007',MANIFEST008),('009',F009,'round-0008',manifest009)):
  manifest=frozen/'SOURCE_MANIFEST.json'
  if digest(manifest)!=expected:fail('immutable checkpoint manifest mismatch: '+number)
  files=json.loads(manifest.read_text())['files_sha256']
  if number=='008' and len(files)!=320:fail('008 inventory changed')
  for name,value in files.items():
   p=frozen/'sources'/name
   if p.is_symlink() or not p.is_file() or digest(p)!=value:fail('frozen source missing/changed: '+number+'/'+name)
  tree(frozen)
  for name in files:
   if name_for(frozen/'sources'/name) not in selected:fail('required frozen source excluded')
  tree(OPS/(roundname+'-executed'))
  invocation=json.loads((OPS/(roundname+'-executed/receipt.json')).read_text())
  if invocation['exit_code']!=0:fail('constructor invocation did not finish normally')
  for name,value in invocation['artifacts'].items():
   if digest(OPS/(roundname+'-executed')/name)!=value:fail('constructor artifact hash mismatch')
  validation_path=OPS/('VALIDATION_'+number+'.json')
  validation=json.loads(validation_path.read_text());add(validation_path,True)
  if validation.get('source_mismatches'):fail('test source mismatch')
  if number=='008':
   if validation['tests']!=16 or validation['passed']!=15 or validation['failed']!=1:fail('008 failed outcome changed')
  else:
   if validation.get('outcome')!='PASS':fail('009 final validation not yet successful')
  for key in ('result','log','outer'):
   row=validation[key];p=Path(row['path'])
   if digest(p)!=row['sha256']:fail('named validation record changed')
  job=Path(validation['result']['path']).parent
  if job.parent!=CANDIDATE/'.scratch/v3-validation' or not re.fullmatch('cp00[89]-[A-Za-z0-9_-]+',job.name):fail('unexpected test job root')
  tree(job)
  outer=json.loads(Path(validation['outer']['path']).read_text())
  if outer.get('cleanup_errors'):fail('actual test cleanup unresolved')
  for suffix in ('.json','.jsonl','.stdout'):add(OPS/('testwatch-'+job.name+suffix),True)
  fs=validation.get('fixtures')
  if not isinstance(fs,list) or not fs:fail('explicit complete fixture list required')
  if number=='008' and len(fs)!=16:fail('008 explicit fixture inventory changed')
  fixtures[number]=fs
  for name in fs:
   p=Path(name)
   if p.parent not in (CANDIDATE/'.scratch',CANDIDATE/'local.scratch') or not re.fullmatch(r'(role-report-repair-|v3-|report00[89]-)[A-Za-z0-9_]{8}',p.name):fail('unexpected explicit fixture root')
   tree(p)
  outcomes[number]={'source_manifest_sha256':expected,'frozen_source_count':len(files),'validation':validation['outcome'],'tests':validation['tests'],'fixtures':len(fs),'constructor_exit_code':invocation['exit_code']}
 if digest(OPS/'bounded_test_watch_v7b.py')!=WATCH7B:fail('executed watcher source changed')
 add(OPS/'bounded_test_watch_v7b.py',True)
 # Shallow selected engineering records only, never a live candidate sweep.
 for p in sorted(OPS.iterdir()):
  if p.is_file() and (p.name.startswith(('round-0007-','round-0008-','testwatch-cp008-','testwatch-cp009-','CONSTRUCTION008_','CONSTRUCTION009_')) or p.name in ('FINAL_ACCEPTED_009_COMPOSITE.json','INSTALLED_SOURCE_REVIEW_009.json','ARCHIVE_REPORT_REPAIR_008_009_PLAN.md','archive_report_repair008_009_evidence.py')):add(p)
 for name in ('FINAL_ACCEPTED_009_COMPOSITE.json','INSTALLED_SOURCE_REVIEW_009.json'):add(OPS/name,True)
 tree(INSTALLATION)
 for name in REVIEWS:add(Path('/private/tmp')/name,True)
 add(Path('/private/tmp/math_gkm_v3_hypothesis_evidence009_criteria.md'))
 for name in ('repro/repro.py','repro/manifest-construction-v3.json','repro/README.md','lean-toolchain','lake-manifest.json','lakefile.toml','MathGKM.lean'):
  add(ROOT/name,True)
 if sum(row['bytes'] for row in selected.values())>MAX_TOTAL:fail('aggregate512MiB bound')
 return selected,skipped,outcomes,fixtures


def metadata(selected,skipped,outcomes,fixtures):
 return {'schema':'math-gkm.report-repair008-009-engineering-evidence.v1',
  'scope':'008 failed report-contract regression and009 reviewed/tested engineering correction only; no research campaign, mathematical action or admission is claimed',
  'checkpoints_and_outcomes':outcomes,'explicit_fixture_roots':fixtures,'outerwatch7b_sha256':WATCH7B,
  'path_mapping':{prefix:str(base) for base,prefix in MAPPINGS},
  'independent_review_mapping':'/private/tmp named008/009 memos only',
  'reproduction_note':'Frozen source bytes, commands, all validation-named fixtures, receipts and pins retained. Dependencies and compiled objects regenerate. Original absolute paths are provenance.008 failure remains failure;009 does not revise the two invalid model plans in failedstudy0003. No curator, heldout suite, current campaign or old large study history is selected.',
  'excluded_directory_names':sorted(PRUNE),'members':selected,'excluded':skipped}


class HashedReader:
 def __init__(self,source):self.source=source;self.hash=hashlib.sha256()
 def read(self,n=-1):
  data=self.source.read(n);self.hash.update(data);return data

def write_archive(path,record):
 if path.exists():fail('archive already exists; never overwrite evidence')
 path.parent.mkdir(parents=True,exist_ok=True)
 try:
  with path.open('xb') as raw:
   with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
    with tarfile.open(fileobj=compressed,mode='w|') as archive:
     for name,member in sorted(record['members'].items()):
      source=Path(member['source_path'])
      if source.is_symlink() or stable(source.stat())!=tuple(member['stat_identity']):fail('source changed before archiving: '+str(source))
      info=tarfile.TarInfo(name);info.size=member['bytes'];info.mode=0o644;info.mtime=0
      with source.open('rb') as stream:
       reader=HashedReader(stream);archive.addfile(info,reader)
       if reader.hash.hexdigest()!=member['sha256'] or stable(os.fstat(stream.fileno()))!=tuple(member['stat_identity']):fail('source changed during archiving: '+str(source))
     body=(json.dumps(record,sort_keys=True,indent=2)+'\n').encode()
     info=tarfile.TarInfo('ARCHIVE_MANIFEST.json');info.size=len(body);info.mode=0o644;info.mtime=0
     archive.addfile(info,io.BytesIO(body))
 except BaseException:
  # Preserve a partial artifact for debugging, clearly distinguishable by the
  # absence of a success sidecar; never delete or replace any source evidence.
  raise
 return digest(path)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--inventory',type=Path,required=True)
 parser.add_argument('--execute',action='store_true')
 parser.add_argument('--archive',type=Path)
 parser.add_argument('--manifest009-sha256',required=True)
 args=parser.parse_args()
 if args.inventory.exists():fail('inventory already exists; choose a new finalization label')
 if args.execute and not args.archive:fail('--execute requires a NEW --archive path')
 selected,skipped,outcomes,fixtures=sources(args.manifest009_sha256)
 record=metadata(selected,skipped,outcomes,fixtures)
 record['archiver_source_sha256']=digest(Path(__file__))
 if args.execute:record['archive_sha256']=write_archive(args.archive,record)
 args.inventory.parent.mkdir(parents=True,exist_ok=True)
 with args.inventory.open('x') as out:json.dump(record,out,indent=2,sort_keys=True);out.write('\n')
 print(json.dumps({'members':len(selected),'source_bytes':sum(m['bytes'] for m in selected.values()),'excluded':len(skipped),'checkpoints':len(outcomes),'inventory':str(args.inventory),'archive_sha256':record.get('archive_sha256')}))

if __name__=='__main__':main()
