# Engineering evidence008/009/010: source-only plan v2

The original008/009 archiver and plan remain unchanged and unexecuted. This separatev2 requires final010 readiness instead. Root owns source review and execution; no archive is run by its preparer.

Preserve all three immutable source checkpoints:008320files,009333files, and future010 with its explicitly reviewed manifest SHA256. Include successful raw constructor invocations round7/8/9, all actual test records, both independent reviews per checkpoint, and all16explicit fixture directories per run including seven local.scratch/report008-* paths. Never infer fixture inventory solely from printed logs.

Outcomes stay precise:008 ran16methods with15pass/1old hypothesis-evidence binding failure.009 repaired the original runtime rejection but failed two new positive subtest assertions within one method because the fixture selected the last hypothesis instead of the modified first hypothesis. These are failed runs. Future010 may be accepted only after its actual16tests pass and its runtime machinery hashes are byte-identical009. Its correction is test-only; it cannot change the mathematics or silently relabel earlier tests as passing.

Final010 composite, installed source review and installation20261018-010 records are required; no009installation or009PASS is required. Dependencies, caches and compiled objects are omitted. Checkpoints, paid source invocations, actual outcomes, exact source hashes and rebuild pins remain. No curation, suite, evaluation or active/new Markov study path is traversed. Prior failedstudy0003 remains separate with original twoinvalidplans/zero mathematical progress/no baseline.

Use the same bounded streaming writer and new archive/sidecar paths, with max12000files,128MiBmember and512MiBaggregate. No deletion, build, model, research or process signaling. Root should independently verify final member hashes, source/runtime equality, all48fixture roots and publication exclusions.

Proposed destination: evidence/blended-harness-v3-report-repair-20261018/.

Prepared command; fill the010manifest argument only after freeze/review:

```sh
/opt/homebrew/bin/python3 .bootstrap/construction-v3-20261018/archive_report_repair008_009_010_evidence_v2.py --manifest009-sha256 158adf3ffb5be5f5917c280f7de1b4bb5d07b80cef22b496f03595732e0a6ba6 --manifest010-sha256 EXACT_REVIEWED_010_SHA256 --inventory evidence/blended-harness-v3-report-repair-20261018/MANIFEST.json --archive evidence/blended-harness-v3-report-repair-20261018/report-repair008-009-010-source-evidence.tar.gz --execute
```
