# Report-contract engineering evidence008/009

Source-only preparation. Root reviews and executes only after immutable009 checkpoint, actual affected tests, independent reviews and final installation records exist. No source tree or fixture is deleted or rewritten.

Preserve complete immutable008 (320sources, manifest1bbee7531445753d1714e0e0f9641465977a938b554c492f41af90e826afd71f), successful constructorround7 raw invocation, the real16-test run (15pass/1preexisting hypothesis-evidence binding failure), and all16 explicitly recorded fixture directories. This includes seven report008-* fixtures in local.scratch which were absent from the printed test log. The008 result remains failed and must never be presented as accepted deployment evidence.

Preserve future immutable009 and require its exact independently reviewed SHA256 as a command argument. Include constructorround8 raw invocation, the actual final test results/logs/watch records, all explicitly named009 fixtures, both independent reviews, accepted009 composite and exact final installation records. No assumed test counts or pass is substituted before real outcomes exist. Hash-verify every frozen source and constructor artifact; fixtures come only from finished validation metadata and restricted neutral fixture path patterns.

Only these two checkpoints are archived; do not duplicate old broad construction history. Keep the prior failedstudy0003 debugging archive separate. Exclude curation/evaluation/suite contents, all Markov study directories, dependencies, package caches and compiled objects. Original receipts can contain dependency identities and host paths; they are bounded source provenance, not a cache copy or portable execution command.

The archiver uses reviewed streaming1MiB hashes and stable inode/size/timestamp checks, max12000 files,128MiB per member and512MiB aggregate. Archive/sidecar paths must be new; partial artifacts are preserved. No Lean build, model call, research, process signaling or cleanup is performed. Final archive remains subject to independent member/hash and publication-scope verification.

Proposed destination: evidence/blended-harness-v3-report-repair-20261018/.

Prepared command, replace the manifest argument only after009 freezes:

```sh
/opt/homebrew/bin/python3 .bootstrap/construction-v3-20261018/archive_report_repair008_009_evidence.py --manifest009-sha256 EXACT_REVIEWED_009_MANIFEST_SHA256 --inventory evidence/blended-harness-v3-report-repair-20261018/MANIFEST.json --archive evidence/blended-harness-v3-report-repair-20261018/report-repair008-009-source-evidence.tar.gz --execute
```
