# Frozen009 narrow source-safety review

Observed 2026-10-18T19:58:43.616282+00:00. Independent read-only source review, no tests/builds/LLM roles or mathematical advice.

Candidate `/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018`.
Manifest `evidence/construction-v3/source-audit-009/SOURCE_MANIFEST.json`.
SHA256 `158adf3ffb5be5f5917c280f7de1b4bb5d07b80cef22b496f03595732e0a6ba6`.

VERDICT: SAFE FOR PREPARED BOUNDED16-METHOD PURE TESTS. No test pass, installation, live model repair or mathematical campaign result is inferred.

All333 frozen entries and333 candidate live entries independently streamed and hash-matched. All008 listed entries remain present. All priorLean entries, exactgoal/root, sourcecontext, kernelreplay/premise inspection, mathematical admission, resources, toolchainpins, actualcallaccounting and controller paths except the previously approved008diagnostic remain unchanged.009runtime difference from008 is solely a five-line evidence-binding check in study_policy.py; the affected test adds assertions, and checkpoint/disposition/evidence records update.

Runtime condition exactly matches intended provenance: construct evidence_paths only after all current report.evidence safe-file/hash/kind checks pass. For every submitted hypothesis, evidence defaults[]; otherwise require a list whose every element is a string in evidence_paths. This check occurs before that hypothesis's version/findings storage. Existing-but-undeclared files are rejected, not promoted based on existence alone. No historical state rebinding or invented artifacts are introduced. The008immutable findings-reference registry and safe typed diagnostic are untouched.

The original existing negative test and expected 'hypothesis evidence not bound to actual artifacts' exception remain verbatim. Appended assertions cover bothmodes and prospective commit/execution: omitted/empty evidence, actual hash-bound artifact, existing-unbound/nonexistent references, malformed container/nonstrings, no report mutation and rejected-state preservation. Existing earlier assertions retain wrongreporthash, missingfile and theorem-self-certification negatives. No scenario is waived or relabeled.

Prepared VALIDATION_PLAN retains the same four selectors/16methods used in008, including new008contract/diagnostic tests and old Pureversion/repair regressions. Root will execute them with resource supervision; this reviewer executes none. The retained008result remains15/16 with a pre-existing provenance failure, not an accepted release. A new009pass must be earned by its actual run.

Scope clearance sent immediately to root and builder before durablememo. No redesign or extra heavy verification is requested for this local patch.

## Post-execution addendum 2026-10-18T20:00:35.705556+00:00

Root executed the prepared16methods. Existing missing-evidence negative now passes. Two new positive subtests fail at the same-method assertion (baseline/exploration, declared=True,present=True,value=['artifact.txt']);009is not allpass/installed. Independent read-only inspection of retained cp009-report-contract/run.log and neutral fixture source confirms fixture selection error: neutral.plan returns hypotheses a,b in that order; onlya.evidence is modified, while findings[-1] isb with its correctly empty evidence. The runtime storage/binding is correct for this case. Minimal010test-only fix must select the latest finding with the exact immutable reference of candidate.hypotheses[0], using the corresponding portfolio reference in both accepted and post-execution staged state. Latest is necessary because staged retains an earliera finding with empty evidence. Preserve exact expected list equality and all negatives; no runtime edits/waiver needed. No tests by reviewer.
