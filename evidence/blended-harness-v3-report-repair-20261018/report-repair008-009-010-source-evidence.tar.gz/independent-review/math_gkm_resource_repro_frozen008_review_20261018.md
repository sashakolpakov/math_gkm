# Independent resource/reproducibility scope review: frozen008

Reviewer: resource auditor (/root/disk_cleanup). Read-only source review; no tests, builds, models, research campaign, cleanup or process signals run by this reviewer.

Manifest: evidence/construction-v3/source-audit-008/SOURCE_MANIFEST.json

SHA256:1bbee7531445753d1714e0e0f9641465977a938b554c492f41af90e826afd71f.

All320 live entries and all320 immutable frozen copies were independently streamed and matched. Compared with007, the only implementation/test changes are machinery/study.py, machinery/study_policy.py and tests/test_report_contract008.py. All26 protected Lean/resource/profile/process/premise/deployment/completion/pin files in this candidate remain byte-identical. The prior007 checkpoint and original failedstudy0003 evidence remain separate, unchanged records.

The four prepared pure-report selectors may run sequentially with the supported source-bound validator under approved outerwatch7b SHA2565ede968f0d79a4fd192832822de6a3f266b2226dde2cd043b26f54ea8f3ff191. No concrete blocker to this finite bounded execution was found. This is source clearance, not a claim that the tests or an installed008 startup check have passed.

The actual delta explains the existing immutable hypothesis reference namespace to proposer/researcher reports. A typed FindingReferenceInvalid carries only the validated integer index; report_diagnostic emits fixed code/field/schema text solely for that exact class. Unknown failures retain the generic safe response. The controller records this fixed diagnostic in the original invalid-plan record and the next paid own-repair request. It does not repair model payloads, provide mathematical guidance, execute an invalid plan, raise budget or relax a finding reference.

The new tests use tiny neutral source files and retained local.scratch temporary fixtures. Their external-role boundary is mocked; no worker, hosted model, compiler or actual campaign is started. Tests inspect immutable receipt preservation, same-report and retained historical version references, malformed reference rejection, empty-findings validity, exact prompt namespaces, one newly charged repair id and withholding the researcher until plan validation. Prior report/version/repair regressions remain selected. Existing resource guards, Darwin required OS percentages30/25, native footprint4/5GiB, absolute RSS8GiB, disk8/5GiB, Linux8/5GiB byte floors, private-group ownership cleanup, premise/root checks and costs are unchanged.

No installed source authorization is inferred from the candidate manifest. Root owns affected test execution, exact accepted installation review, new implementation/publication identity and any fresh autonomous restart. Keep failedstudy0003 raw payloads and receipts; its round0/twoinvalidplans/zeroadmissions/baselineneverstarted outcome is not retroactively revised. Held-out suite and curator originals remain private; public debugging evidence stores only their hashes and provenance.
