# Independent resource/reproducibility review: frozen009

Reviewer: resource auditor (/root/disk_cleanup). Source-only; no tests, builds, hosted models, research, cleanup or process signals executed.

Manifest: evidence/construction-v3/source-audit-009/SOURCE_MANIFEST.json

SHA256:158adf3ffb5be5f5917c280f7de1b4bb5d07b80cef22b496f03595732e0a6ba6.

All333 live entries and all333 frozen copies were independently streamed and matched. The only code delta from frozen008 is machinery/study_policy.py and additional assertions within the existing tests/test_role_report_contract.py method. All27 protected Lean/resource/profile/process/study-controller/premise/deployment/completion/pin files remain byte-identical008.

The same four prepared selectors (16test methods) are cleared for finite sequential execution under approved outerwatch7b SHA2565ede968f0d79a4fd192832822de6a3f266b2226dde2cd043b26f54ea8f3ff191. They use tiny neutral fixtures and synthetic external-role boundaries, without worker, compiler, hosted model or campaign launches. No concrete resource/execution blocker was found. This is source clearance, not a claim that009 tests or installation have passed.

The actual fix builds evidence_paths only after ordinary evidence has passed existing safe-path, real-file, actual digest and allowed-kind checks. A hypothesis evidence entry must now be a list of strings present in that verified path set; missing/empty lists remain valid. Thus hypothetical or undeclared artifacts cannot be presented as supporting hypothesis evidence. This neither admits a theorem nor supplies mathematical strategy. The existing original negative test remains, with additional positive/negative cases in both modes and both plan/report paths, including caller-state/payload immutability checks.

Resource metrics and limits are unchanged: required Darwin OS percentage30/25, native footprint4/5GiB, absolute RSS8GiB, disk8/5GiB, Linux8/5GiB required MemAvailable floors; same ownership/cleanup/time/process/output limits. Existing report diagnostics, one charged own-repair allowance and exact mathematical admission/root checks remain unchanged. This amendment repairs the old unbound-hypothesis-evidence gap exposed by actual008 testing;008 remains15/16failed, and prior failedstudy0003 remains twoinvalidplans/zero mathematical actions/admissions/no baseline.

Root owns actual test execution, exact accepted installation review, new implementation/publication identity and any fresh autonomous restart. Preserve exact fixtures from VALIDATION_008 and VALIDATION_009, including local.scratch/report008-* paths omitted from printed logs. Archive only immutable checkpoints and completed named engineering fixtures/receipts; keep curator/evaluation/new-study paths private and separate.
