# Frozen008 narrow source-safety review

Observed 2026-10-18T19:51:46.751459+00:00. Independent read-only review. No tests, compilers, workers, campaigns or mathematical research by reviewer.

Candidate `/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018`.
Manifest `evidence/construction-v3/source-audit-008/SOURCE_MANIFEST.json`.
SHA256 `1bbee7531445753d1714e0e0f9641465977a938b554c492f41af90e826afd71f`.

VERDICT: SAFE FOR PREPARED BOUNDED PURE TEST EXECUTION. This is a source-safety disposition, not a test pass, installed release, real-model repair demonstration or mathematical campaign success.

All320 frozen sources under checkpoint008/sources and all320 corresponding candidate live entries independently streamed and hash-matched. All007 listed entries remain present. All69 prior Lean entries (including retained evidence) are byte-identical. Goal/root, context, premise inspectors, mathematical admission, resources, toolchain pins and actual Arm.call accounting are unchanged. Substantive changes are only machinery/study_policy.py, machinery/study.py and tests/test_report_contract008.py; two checkpoint/disposition tracking files and newly retained evidence accompany them.

Strict mathematical/report boundary is preserved: findings.reference must be a string exactly matching a content reference in the staged immutable hypothesis registry, including retained historic versions and valid same-report new versions. Paths, ordinary IDs, arbitrary hashes and unknown changed/stale hashes remain rejected. Added list/object checks safely reject malformed findings rather than treating them as evidence. Core version/hash computation is unchanged.

Both proposer/researcher prompts now distinguish findings hypothesis-reference namespace from artifact evidence paths, expose optional version fields and describe the existing canonical hash correctly (sorted compact UTF8 JSON with ensure_ascii=false, core plus parent/revision). They explicitly allow omitted/empty findings and ordinary source observations without artificial hypotheses. A new proposer need not calculate a future controller commitment hash. Reviewer findings schema is unchanged.

The new FindingReferenceInvalid carries only a trusted bounded integer index. report_diagnostic uses exact type equality and returns fixed code, generated findings[index].reference field and static expectation. Unknown exceptions retain generic feedback. No submitted value, arbitrary exception string, evaluator output or held-out answer is forwarded. The only consumer added is own proposer plan_with_repair, which still retains original receipts, requires a new charged request and executes no research before valid commitment. There is no automatic payload mutation, forced exploration downgrade, path-to-hypothesis alias, budget increase or approval bypass.

Prepared008 tests cover the actual two failed shapes, typed field diagnostics, transactional state/report preservation, bad path/ID/hash/malformed rejection, accepted historic/same-report child references, invalid declared content hash, ordinary and exploratory empty findings, actual rendered role prompts, own two-request repair identity/retention flow and generic-safe fallback. Existing role-contract and Pure version/repair regressions are included by VALIDATION_PLAN.json.

Evidence limit: the new synthetic external-role test calls actual plan_with_repair but stubs Arm.call and manually records a charge list. It tests that control flow/identity binding, not actual provider charges or realLLM repair ability. Prior actual007 two charged proposer calls remain separate evidence; unchanged Arm.call's real accounting is not newly demonstrated by this fixture. A subsequent real008 study must earn its own outcome. No new theorem or Markov result is inferred.

Scope approval was sent immediately to root and builder, before this durable memo. No broad architecture changes are requested; ordinary functional failures may be retained from bounded tests.

## Post-execution addendum 2026-10-18T19:53:39.715401+00:00

Root reports prepared008 selectors executed16tests:15passed,1existing RoleReportContract negative failed; all7new008tests passed. This is not allpass or release acceptance. Independent source comparison confirms the missing hypothesis-evidence binding was already present007; see /private/tmp/math_gkm_v3_hypothesis_evidence009_criteria.md for narrow strict repair criteria. No tests run by this reviewer.
