"""Source-only repair007 freeze, adapted from freeze006; no candidate imports or execution."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

root=Path.cwd()
out=root/'evidence/construction-v3/source-audit-007'
assert not out.exists(), '007 already exists; immutable, never retry'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''): h.update(block)
    return h.hexdigest()
def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
prior_path=root/'evidence/construction-v3/source-audit-006/SOURCE_MANIFEST.json'
prior=json.loads(prior_path.read_text()); prior_hash=sha(prior_path)
assert (prior_path.parent/'SOURCE_MANIFEST.sha256').read_text().split()[0]==prior_hash
progress=json.loads((root/'local.scratch/REPAIR007_PROGRESS.json').read_text())
assert prior_hash==progress['prior_manifest_sha256']
old_snapshot=progress['snapshot006']
for name,expected in old_snapshot.items(): assert sha(root/name)==expected,name
substantive=['machinery/resources.py','config/darwin-memory-profile-007.json',
    'tests/test_darwin_pressure007.py','tests/test_construction_v3_repair004.py','tests/test_capacity_repair005.py']
allowed=set(substantive)|{'CONSTRUCTION_V3_AUDIT.json','INSTALLATION_SOURCE_DISPOSITION.json'}
delta={n:sha(root/n) for n,h in prior['files_sha256'].items() if sha(root/n)!=h}
assert set(delta)<=allowed,set(delta)-allowed
inputs=root/'.bootstrap/darwin-pressure-007-inputs'
input_map=json.loads((inputs/'INPUT_MANIFEST.json').read_text())
for name,expected in input_map.items(): assert sha(inputs/name)==expected,name
profile_path=root/'config/darwin-memory-profile-007.json'
profile=json.loads(profile_path.read_text())
runtime=ast.parse((root/'machinery/resources.py').read_text())
assignments={node.targets[0].id:ast.literal_eval(node.value) for node in runtime.body
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name)
    and node.targets[0].id in ('PROFILE_SHA256','PROFILE_PATH')}
assert assignments['PROFILE_SHA256']==sha(profile_path)
assert assignments['PROFILE_PATH']=='config/darwin-memory-profile-007.json'
assert profile['approval_provenance']['sha256']==input_map['DARWIN_PRESSURE_METRIC_DECISION_007.json']
out.mkdir(parents=True)
for name in ['INPUT_MANIFEST.json',*input_map]:
    dest=out/'inputs'/name; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(inputs/name,dest)
shutil.copyfile(__file__,out/'freeze_sources.py')
protected={n:dict(before=r['after'],after=sha(root/n),unchanged=r['after']==sha(root/n)) for n,r in prior['protected'].items()}
assert all(r['unchanged'] for r in protected.values())
# Every unchanged prior file is checked as well, including all mathematical sources/policies.
unchanged_prior={n:h for n,h in prior['files_sha256'].items() if n not in allowed}
assert all(sha(root/n)==h for n,h in unchanged_prior.items())
selectors=['tests.test_darwin_pressure007.Pressure007',
 'tests.test_construction_v3_repair004.Resources004.test_narrow_helper_count_and_arbitrary_eperm_fail_closed',
 'tests.test_construction_v3_repair004.Resources004.test_tree_only_admission_floor_without_heavy_lease',
 'tests.test_construction_v3_repair004.Resources004.test_limit_numeric_validation_and_valid_controls006',
 'tests.test_construction_v3_repair004.Resources004.test_distinct_memory_disk_admission_floors006',
 'tests.test_capacity_repair005.Resource005.test_darwin_charge_rss_absolute_footprint_hard_sustain_and_unavailable',
 'tests.test_capacity_repair005.Resource005.test_native_return_and_birth_rechecks',
 'tests.test_capacity_repair005.Resource005.test_no_worker_cap_increase',
 'tests.test_construction_v3_resources.Resources.test_simulated_disk_rss_process_and_monitor_failure',
 'tests.test_construction_v3_repair.ResourcesRepair.test_simulated_birth_and_unknown_monitor_failure']
# Verify exact legacy selector class/name from source instead of test collection.
legacy_tree=ast.parse((root/'tests/test_construction_v3_repair.py').read_text())
legacy=[('tests.test_construction_v3_repair.'+c.name+'.'+m.name) for c in legacy_tree.body
 if isinstance(c,ast.ClassDef) for m in c.body if isinstance(m,ast.FunctionDef)
 and ('simulated' in m.name or 'unknown' in m.name)]
selectors=selectors[:-1]+legacy
prefix=('env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin '
 'GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null PYTHONDONTWRITEBYTECODE=1 '
 'TMPDIR='+str(root/'local.scratch')+' /opt/homebrew/bin/python3 -m machinery.v3_validate '
 '--manifest evidence/construction-v3/source-audit-007/SOURCE_MANIFEST.json '
 '--review local.scratch/source-review-007.json --seconds 180 --label 007-pressure ')
commands=[dict(command=prefix+' '.join(selectors),status='PREPARED ONLY; independent changed-file source audit first; supervisor owns tests/install/activation')]
save(out/'VALIDATION_PLAN.json',dict(tests_run=False,selectors=selectors,commands=commands,sequential_only=True,
 gate='STOP for independent changed-file source audit; supervisor owns execution, installation and activation'))
save(out/'PRIOR_EVIDENCE.json',dict(checkpoint006_manifest_sha256=prior_hash,
 snapshot_files_sha256=old_snapshot,unchanged_prior_files_sha256=unchanged_prior,tests_run=False,
 disposition='All006 snapshots, old profiles, prior raw failures and failed installed freeze preserved; no retry, overwrite, relabel or acceptance.',
 failed_installed_freeze='paired-v3-live-20261018/study/deployment-preflight/result.json: root decision provenance only, never modified or retried',
 supplied_root_decision_sha256=input_map['DARWIN_PRESSURE_METRIC_DECISION_007.json']))
paths=set(prior['files_sha256'])|set(substantive)
paths.update(str(p.relative_to(root)) for p in prior_path.parent.iterdir() if p.is_file())
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file())
save(out/'STATIC_REVIEW.json',dict(method='Source inspection, AST/JSON parsing and streaming hashes only; no runtime imports or test collection',
 tests_run=False,compilers_run=False,probes_run=False,campaigns_run=False,substantive_changes=substantive,
 changed_existing_files=delta,protected=protected,prior_manifest_sha256=prior_hash,
 scope='Only Darwin global capacity metric: required bounded memory_pressure -Q unique integer0..100, admission>=30%, dynamic>=25%; harden-only finite numeric percentage floors. VM bytes audit-only value/failure. Linux MemAvailable8/5GiB. Disk8/5GiB BOTH platforms.',
 preserved='Native footprint4GiB sustained3s/5GiB hard, absoluteRSS8GiB, observer timeout/output safeguards, single-heavy/onecompiler, birth/cleanup/privileged observer bounds, growth/output/time/poll caps; all mathematical sources/contracts/contexts/premise/English/completion/strategy semantics byte-identical.',
 fixture_migration='Two legacy resource fixture files stub required percentage independently; native/RSS/process/disk/unknown-monitor assertions retained; Linux byte-floor assertions remain.',
 prior_snapshots='All006 copies byte-identical; failed installed freeze never overwritten or retried; prior results never relabeled007'))
paths.add(str((out/'STATIC_REVIEW.json').relative_to(root)))
for name in sorted(paths):
    p=root/name
    if p.suffix=='.py': ast.parse(p.read_text(),filename=name)
    elif p.suffix=='.json': json.loads(p.read_text())
disposition=json.loads((root/'INSTALLATION_SOURCE_DISPOSITION.json').read_text())
for name in sorted(paths-{'INSTALLATION_SOURCE_DISPOSITION.json','CONSTRUCTION_V3_AUDIT.json'}):
    old=disposition['artifacts'].get(name,{})
    disposition['artifacts'][name]=dict(sha256=sha(root/name),disposition=old.get('disposition',
        'archive exact007 source/review/root decision/manual/primary-note provenance; not acceptance' if name.startswith('evidence/') else 'ship source/runtime/acceptance/reproduction artifact'))
disposition['metadata_bound_by']='source-audit-007/SOURCE_MANIFEST.json binds exact install map and current audit'
disposition['runtime_and_acceptance_overlay']=sorted(set(disposition['runtime_and_acceptance_overlay'])|set(substantive))
disposition['meaning']='Source disposition only; installation/activation/tests owned by supervisor after independent changed-file audit. Failed installed freeze preserved, never retried.'
save(root/'INSTALLATION_SOURCE_DISPOSITION.json',disposition)
old_audit=json.loads((root/'CONSTRUCTION_V3_AUDIT.json').read_text())
remaining=['Independent changed-file source audit of007 required; STOP',
 'Prepared selectors only; tests_run=false; supervisor owns tests, installation and activation',
 'Failed installed freeze preserved and never retried; no007 runtime acceptance claimed']
changed={n:sha(root/n) for n in paths if n!='CONSTRUCTION_V3_AUDIT.json' and prior['files_sha256'].get(n)!=sha(root/n)}
audit={**old_audit,'invocation':'darwin-pressure-metric-repair007','status':'FROZEN source only; STOP for independent changed-file source audit',
 'checkpoint':'evidence/construction-v3/source-audit-007/SOURCE_MANIFEST.json',
 'prior_checkpoint':dict(manifest=str(prior_path.relative_to(root)),sha256=prior_hash,disposition='001-006 snapshots/results and failed installed freeze preserved unchanged'),
 'changed_files_sha256':changed,'protected':protected,'tests_run':False,'compilers_run':False,'preflights_run':False,'probes_run':False,'campaigns_launched':False,
 'actual_prior_evidence':dict(checkpoint006_manifest_sha256=prior_hash,disposition='006 remains006; failed freeze preserved; no007 execution',details='evidence/construction-v3/source-audit-007/PRIOR_EVIDENCE.json'),
 'limits':{**old_audit['limits'],'darwin_profile_sha256':sha(profile_path),'darwin_memory_admission_bytes':None,'darwin_capacity_rule':'required OS free percent >=30 admission, >=25 dynamic; raw VM bytes AUDIT-ONLY; no guaranteed allocatable bytes','os_pressure_admission_percent':30,'os_pressure_dynamic_percent':25,'linux_memory_admission_bytes':8*1024**3,'linux_memory_dynamic_bytes':5*1024**3,'disk_admission_bytes':8*1024**3,'disk_dynamic_bytes':5*1024**3},
 'approved_inputs_sha256':input_map,'planned_commands':commands,'remaining':remaining,'substantive_changes':substantive}
save(root/'CONSTRUCTION_V3_AUDIT.json',audit)
# Final metadata syntax parsing after edits.
for n in ('CONSTRUCTION_V3_AUDIT.json','INSTALLATION_SOURCE_DISPOSITION.json'): json.loads((root/n).read_text())
hashes={n:sha(root/n) for n in sorted(paths)}
changed={n:h for n,h in hashes.items() if prior['files_sha256'].get(n)!=h}
assert set(n for n in changed if n in prior['files_sha256'])<=allowed
for name,expected in old_snapshot.items(): assert sha(root/name)==expected,name
for name,expected in hashes.items():
    dest=out/'sources'/name; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,dest); assert sha(dest)==expected; dest.chmod(0o444)
manifest=dict(schema='math-gkm.frozen-source-audit.v7',invocation='darwin-pressure-metric-repair007',
 created_utc=datetime.now(timezone.utc).isoformat(),tests_run=False,compilers_run=False,probes_run=False,
 files_sha256=hashes,changed_files_sha256=changed,substantive_changes=substantive,protected=protected,
 prior_checkpoint=dict(path=str(prior_path.relative_to(root)),sha256=prior_hash),
 source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',validation_plan='evidence/construction-v3/source-audit-007/VALIDATION_PLAN.json',
 source_copies='sources/<workspace-relative-path>',unshipped_bootstrap_sources_required=False,
 execution_gate='FROZEN: STOP for independent changed-file source audit; supervisor owns tests, installation and activation')
save(out/'SOURCE_MANIFEST.json',manifest)
(out/'SOURCE_MANIFEST.sha256').write_text(sha(out/'SOURCE_MANIFEST.json')+'  SOURCE_MANIFEST.json\n')
for p in out.rglob('*'):
    if p.is_file(): p.chmod(0o444)
result=dict(checkpoint=str(out.relative_to(root)),sha256=sha(out/'SOURCE_MANIFEST.json'),files=len(hashes),
 substantive_changes=substantive,protected_unchanged=True,prior_snapshots_unchanged=True,tests_run=False,status='STOP: independent changed-file source audit')
save(root/'local.scratch/REPAIR007_PROGRESS.json',result)
print(json.dumps(result))
