import MathGKM.Accepted0c0c62cb492ed4920bdd7e6d
import MathGKM.ResearchSemantics
import MathGKM.NeutralV3Root
def MathGKM.Target58077597aee59dcd3a56d4bc.Interface := MathGKM.ResearchSemantics.ConservativeExtension (Nat × Nat) ((Nat × Nat) × Unit)
def MathGKM.Target58077597aee59dcd3a56d4bc.Transport (StudyInterface : MathGKM.Target58077597aee59dcd3a56d4bc.Interface) : Prop := ∀ b : (Nat × Nat), StudyInterface.forget (StudyInterface.extend b) = b
def MathGKM.Target58077597aee59dcd3a56d4bc.Goal (StudyInterface : MathGKM.Target58077597aee59dcd3a56d4bc.Interface) : Prop := ∀ e : ((Nat × Nat) × Unit), (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) (StudyInterface.forget e)
