# Read-only integration finding: trial research → main research

Observed during constructor round 2; no source edits or tests by this audit.

`Arm.policy_trial` admits researcher submissions into each branch's local state and retains that state/snapshot. A later branch round can consume those exports, and the policy review sees the compared research source snapshots. `Arm.review` installs only a selected policy/program. `policy.request` projects the main state's knowledge/components/DAG, without branch discoveries. Branch completion claims do not call `study_completion.check` (only main research_round does).

Consequently genuine branch mathematics is durably retained and can benefit that finite branch continuation, but is not automatically returned to the continuing machine's own mathematical library or exact-root completion path. Ordinary main-round exploration retains its own mathematics; this finding is specifically the branch-to-main handoff. Adapter/evaluation answers are different artifacts and must remain hidden.

Readiness: neutral safety testing may proceed after review, but a full self-reinforcing blend must not silently strand genuine researcher-origin general theorems or root candidates. A prospective bounded handoff may retain source/context/receipts from branch admission records as pending discoveries and expose those exact sources to the main researcher, with paid ordinary source/premise rechecking before main admission or completion. It must exclude hidden adapters/evaluation answers, preserve the immutable root/context/premise gate, record provenance and costs, reject collisions/changed sources, and retain candidates honestly if the promotion allowance is unavailable. Mathematical truth is not conditional on which strategy wins empirical selection.

This is artifact plumbing and reporting, not a supplied Markov proof or strategy. It has not been silently added to the running constructor's immutable prompt. Tests must distinguish within-branch checked reuse from demonstrated trial-to-main reuse.
