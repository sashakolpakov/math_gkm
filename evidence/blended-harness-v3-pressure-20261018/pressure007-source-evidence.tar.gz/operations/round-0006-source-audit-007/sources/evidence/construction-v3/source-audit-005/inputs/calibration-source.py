#!/usr/bin/env python3
"""Supervisor-only prospective observation; NO execution until reviewed --execute.

One pinned Lean -j1 `import Mathlib` compile under the unchanged checkpoint004
process.run/Guard limits. Only an additive observer subclass is substituted;
no limit, mathematical source, proof gate, or candidate file is changed.
Run under the independently reviewed outer watcher as a second operational bound.
"""
import argparse
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT=Path('/Users/sasha/math_gkm')
CANDIDATE=ROOT/'.scratch/strategy-v3-blended-20261018'
MANIFEST=CANDIDATE/'evidence/construction-v3/source-audit-004/SOURCE_MANIFEST.json'
MANIFEST_SHA='bb1c09cdc706569ffdcd3814fbc9b3248dce901c832db18cedc222786a28bc64'
FAILED=CANDIDATE/'.scratch/v3-deployment-004-measured/result.json'
LEAN=Path('/Users/sasha/.elan/toolchains/leanprover--lean4---v4.32.2/bin/lean')
LEAN_SHA='1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
V4_FIELDS=('user_time system_time pkg_idle_wkups interrupt_wkups pageins wired_size '
 'resident_size phys_footprint proc_start_abstime proc_exit_abstime child_user_time '
 'child_system_time child_pkg_idle_wkups child_interrupt_wkups child_pageins '
 'child_elapsed_abstime diskio_bytesread diskio_byteswritten cpu_time_qos_default '
 'cpu_time_qos_maintenance cpu_time_qos_background cpu_time_qos_utility '
 'cpu_time_qos_legacy cpu_time_qos_user_initiated cpu_time_qos_user_interactive '
 'billed_system_time serviced_system_time logical_writes lifetime_max_phys_footprint '
 'instructions cycles billed_energy serviced_energy interval_max_phys_footprint runnable_time').split()
class UsageV4(c.Structure):
    _fields_=[('ri_uuid',c.c_uint8*16)]+[('ri_'+n,c.c_uint64) for n in V4_FIELDS]

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda:source.read(1048576),b''):h.update(block)
    return h.hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true',help='Only after independent source review')
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--seconds',type=int,default=120)
    args=parser.parse_args()
    if not args.execute:raise SystemExit('Source-only proposal: independent review required before --execute')
    if not 10<=args.seconds<=180:raise SystemExit('10..180 second prospective observation only')
    out=args.out.absolute()
    if (out.exists() or not out.resolve().is_relative_to(ROOT/'.scratch')
            or out.resolve().is_relative_to(CANDIDATE)):
        raise SystemExit('Fresh output under repo/.scratch, outside candidate, required')
    if sha(MANIFEST)!=MANIFEST_SHA or sha(LEAN)!=LEAN_SHA:raise SystemExit('Pinned manifest/binary changed')
    frozen=json.loads(MANIFEST.read_text())
    def changed():return [n for n,h in frozen['files_sha256'].items() if sha(CANDIDATE/n)!=h]
    if changed():raise SystemExit('Frozen candidate sources changed')
    if c.sizeof(UsageV4)!=296 or UsageV4.ri_phys_footprint.offset!=72 or UsageV4.ri_lifetime_max_phys_footprint.offset!=240:
        raise SystemExit('Unexpected public rusage V4 ABI')
    lib=c.CDLL('/usr/lib/libproc.dylib',use_errno=True)
    lib.proc_pid_rusage.argtypes=[c.c_int,c.c_int,c.c_void_p]
    lib.proc_pid_rusage.restype=c.c_int
    # Verify observer availability on self before launching any Lean child.
    own=UsageV4();c.set_errno(0)
    if lib.proc_pid_rusage(os.getpid(),4,c.byref(own))!=0:
        raise SystemExit('Public self-rusage unavailable: '+str(c.get_errno()))
    sys.path.insert(0,str(CANDIDATE))
    from machinery import process,resources
    from machinery.study_common import write
    original=process.Guard
    limits=dict(resources.LIMITS)
    if (limits['rss_sustained']!=4*1024**3 or limits['rss_hard']!=5*1024**3
            or limits['poll_seconds']!=1 or limits['admit_free']!=8*1024**3):
        raise SystemExit('Original resource profile changed; new independent review required')
    out.mkdir(parents=True,exist_ok=False)
    source=out/'ImportMathlib.lean';source.write_text('import Mathlib\n')
    failed=json.loads(FAILED.read_text())
    positive=failed['positive']
    env=dict(positive['launch_environment'])
    deps=[str(Path(p).resolve()) for p in positive['dependency_paths'] if Path(p).is_dir()]
    if not any(Path(p).name=='lean' and 'mathlib' in p for p in deps):
        raise SystemExit('Pinned Mathlib library path absent')
    env.update(LEAN_PATH=os.pathsep.join(deps),TMPDIR=str(out),OMP_NUM_THREADS='1',
               OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    argv=[str(LEAN),'-j','1','-o',str(out/'ImportMathlib.olean'),source.name]
    write(out/'intent.json',dict(scope='One import-only calibration, no proof admission or policy selection',
        argv=argv,manifest_sha256=MANIFEST_SHA,lean_sha256=LEAN_SHA,unchanged_limits=limits,
        environment=env,failed_result_sha256=sha(FAILED),source_sha256=sha(source),
        allocated_seconds=args.seconds,observer_sha256=sha(__file__)))
    started=time.monotonic()
    with (out/'footprints.jsonl').open('x') as log:
        class ObservedGuard(original):
            def _check(self,force=False):
                previous=self.last
                try:return super()._check(force)
                finally:
                    # No return here: original guard exceptions always propagate.
                    if self.last!=previous:self.observe_snapshot()
            def observe_snapshot(self):
                rows=[]
                for pid,birth in list(self.owned.items()):
                    before=resources.current_process(pid)
                    if not before or before['identity']!=birth:continue
                    data=UsageV4();c.set_errno(0)
                    rc=lib.proc_pid_rusage(pid,4,c.byref(data));error=c.get_errno()
                    if rc:
                        if error==3:continue
                        raise resources.ResourceFailure('monitor_unavailable: public footprint '+str(error))
                    after=resources.current_process(pid)
                    if not after or after['identity']!=birth:continue
                    rows.append(dict(pid=pid,birth=birth,resident_bytes=int(data.ri_resident_size),
                        phys_footprint_bytes=int(data.ri_phys_footprint),
                        lifetime_max_phys_footprint_bytes=int(data.ri_lifetime_max_phys_footprint),
                        wired_bytes=int(data.ri_wired_size),start_abstime=int(data.ri_proc_start_abstime)))
                vm=resources.observation(['/usr/bin/vm_stat'])
                sample=dict(elapsed_seconds=time.monotonic()-started,
                    guard_last_sample=self.samples[-1] if self.samples else None,
                    native_birth_owned_processes=rows,
                    native_scope='Footprints of birth-bound processes; bounded privileged helper RSS stays in guard totals',
                    vm_stat_raw=vm,meaning='RSS minus footprint is NOT an exact file-backed-page measurement')
                log.write(json.dumps(sample)+'\n');log.flush();os.fsync(log.fileno())
        process.Guard=ObservedGuard
        try:
            result=process.run(argv,cwd=out,env=env,timeout=args.seconds,
                output_bytes=1048576,scope=out,log_path=out/'lean.log')
        finally:process.Guard=original
    write(out/'result.json',dict(result=result,elapsed_seconds=time.monotonic()-started,
        source_mismatches_after=changed(),limits_unchanged=resources.LIMITS==limits,
        classification='Measured calibration only; no replay, premise inspection, theorem admission or cap increase'))
    print(out/'result.json',flush=True)
    return 0 if not result.get('termination') and result.get('returncode')==0 and not changed() else 1

if __name__=='__main__':raise SystemExit(main())
