import MathGKM.Target1f9c269a652db5c37b89c715
import MathGKM.ResearchSemantics
import Lean
def Accepted6671fb7b70e9dda1d3f14764.interface : MathGKM.Target1f9c269a652db5c37b89c715.Interface := MathGKM.ResearchSemantics.pushLift (f := (fun n : Nat => n)) (F := (fun _ : Nat => Nat)) (G := (fun _ : Nat => Nat)) (fun n m : Nat => n + m)
theorem Accepted6671fb7b70e9dda1d3f14764.transport : MathGKM.Target1f9c269a652db5c37b89c715.Transport Accepted6671fb7b70e9dda1d3f14764.interface := MathGKM.ResearchSemantics.push_beta (f := (fun n : Nat => n)) (F := (fun _ : Nat => Nat)) (G := (fun _ : Nat => Nat)) (fun n m : Nat => n + m)
theorem Accepted6671fb7b70e9dda1d3f14764.obligation : MathGKM.Target1f9c269a652db5c37b89c715.Goal Accepted6671fb7b70e9dda1d3f14764.interface := MathGKM.ResearchSemantics.push_unique (f := (fun n : Nat => n)) (F := (fun _ : Nat => Nat)) (G := (fun _ : Nat => Nat)) (fun n m : Nat => n + m)
