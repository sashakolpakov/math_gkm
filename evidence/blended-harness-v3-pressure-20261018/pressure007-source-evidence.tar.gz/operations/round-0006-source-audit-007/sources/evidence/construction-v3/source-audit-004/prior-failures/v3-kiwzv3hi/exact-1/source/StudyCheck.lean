import MathGKM.Target072593636cece637fa5dacbf
import MathGKM.Construction
import Lean
def StudyInterface : MathGKM.Target072593636cece637fa5dacbf.Interface := True.intro
theorem StudyTransport : MathGKM.Target072593636cece637fa5dacbf.Transport StudyInterface := True.intro
theorem StudyObligation : MathGKM.Target072593636cece637fa5dacbf.Goal StudyInterface := MathGKM.Continuation.verified_change
