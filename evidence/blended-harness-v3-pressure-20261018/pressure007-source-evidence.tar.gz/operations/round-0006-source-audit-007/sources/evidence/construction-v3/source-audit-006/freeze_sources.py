"""Source-only hygiene006: AST/JSON parsing and streaming hashes; no runtime imports."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

root=Path.cwd()
out=root/'evidence/construction-v3/source-audit-006'
assert not out.exists(), '006 already exists; immutable'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''): h.update(block)
    return h.hexdigest()
def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
prior_path=root/'evidence/construction-v3/source-audit-005/SOURCE_MANIFEST.json'
prior=json.loads(prior_path.read_text()); prior_hash=sha(prior_path)
assert (prior_path.parent/'SOURCE_MANIFEST.sha256').read_text().split()[0]==prior_hash
allowed={'machinery/resources.py','tests/test_construction_v3_repair004.py',
         'CONSTRUCTION_V3_AUDIT.json','INSTALLATION_SOURCE_DISPOSITION.json'}
before_delta={n:sha(root/n) for n,h in prior['files_sha256'].items() if sha(root/n)!=h}
assert set(before_delta)<=allowed, set(before_delta)-allowed
old_snapshot={str(p.relative_to(root)):sha(p) for p in prior_path.parent.rglob('*') if p.is_file()}
inputs=root/'.bootstrap/final-hygiene-006-inputs'
input_map=json.loads((inputs/'INPUT_MANIFEST.json').read_text())
for name,expected in input_map.items(): assert sha(inputs/name)==expected,name
approval=json.loads((inputs/'DARWIN_ADMISSION_DECISION_006.json').read_text())
profile=json.loads((root/'config/darwin-memory-profile-005.json').read_text())
profile['approved_utc']=approval['approved_utc']
profile['authority']='Root prospective approval DARWIN_ADMISSION_DECISION_006.json; measured cp005 full-Mathlib compiles and kernel replays; independent resource review before source change.'
profile['darwin']['host_memory_admission_bytes']=7*1024**3
profile['linux_memory_admission_bytes']=8*1024**3
profile['disk_admission_bytes']=8*1024**3
profile['disk_dynamic_bytes']=5*1024**3
profile['os_pressure_admission_percent']=30
profile['os_pressure_dynamic_percent']=25
profile['available_memory_estimator']='Unchanged: free + inactive + speculative VM pages; no extra cache.'
profile['approval_provenance']={'path':'evidence/construction-v3/source-audit-006/inputs/DARWIN_ADMISSION_DECISION_006.json',
    'sha256':input_map['DARWIN_ADMISSION_DECISION_006.json']}
profile['prior_profile']={'path':'config/darwin-memory-profile-005.json','sha256':sha(root/'config/darwin-memory-profile-005.json'),'disposition':'immutable005 provenance;005 results remain005'}
profile_path=root/'config/darwin-memory-profile-006.json'
save(profile_path,profile)
runtime=root/'machinery/resources.py'
text=runtime.read_text(); assert text.count('PENDING_006_HASH')==1
runtime.write_text(text.replace('PENDING_006_HASH',sha(profile_path)))
save(root/'local.scratch/HYGIENE006_PROGRESS.json',dict(status='tiny changes prepared; freezing source only',tests_run=False,prior_manifest_sha256=prior_hash,profile_sha256=sha(profile_path)))
out.mkdir(parents=True)
for name in ['INPUT_MANIFEST.json',*input_map]:
    dest=out/'inputs'/name; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(inputs/name,dest)
shutil.copyfile(__file__,out/'freeze_sources.py')
protected={n:dict(before=r['after'],after=sha(root/n),unchanged=r['after']==sha(root/n)) for n,r in prior['protected'].items()}
assert all(r['unchanged'] for r in protected.values())
substantive=['machinery/resources.py','tests/test_construction_v3_repair004.py','config/darwin-memory-profile-006.json']
selectors=['tests.test_construction_v3_repair004.Resources004.test_limit_numeric_validation_and_valid_controls006',
 'tests.test_construction_v3_repair004.Resources004.test_distinct_memory_disk_admission_floors006',
 'tests.test_construction_v3_repair004.Resources004.test_tree_only_admission_floor_without_heavy_lease',
 'tests.test_construction_v3_resources.Resources.test_simulated_disk_rss_process_and_monitor_failure',
 'tests.test_capacity_repair005.Resource005.test_no_worker_cap_increase']
prefix=('env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin '
 'GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null PYTHONDONTWRITEBYTECODE=1 '
 'TMPDIR='+str(root/'local.scratch')+' /opt/homebrew/bin/python3 -m machinery.v3_validate '
 '--manifest evidence/construction-v3/source-audit-006/SOURCE_MANIFEST.json '
 '--review local.scratch/source-review-006.json --seconds 180 --label 006-hygiene ')
commands=[dict(command=prefix+' '.join(selectors),status='PREPARED ONLY; independent changed-file source audit first; supervisor owns tests and final installed preflight')]
save(out/'VALIDATION_PLAN.json',dict(tests_run=False,selectors=selectors,commands=commands,sequential_only=True,
 gate='STOP for independent changed-file source audit; supervisor owns execution and final installed preflight'))
evidence={}
for directory in sorted((root/'.scratch/v3-validation').glob('cp005-*')):
    for name in ('intent.json','result.json','run.log'):
        p=directory/name
        if p.is_file(): evidence[str(p.relative_to(root))]=dict(bytes=p.stat().st_size,sha256=sha(p))
save(out/'PRIOR_EVIDENCE.json',dict(checkpoint005_manifest_sha256=prior_hash,raw_evidence=evidence,
 snapshot_files_sha256=old_snapshot,tests_run=False,
 disposition='All prior snapshots/results preserved.005 passes stay bound005; no006 execution or acceptance.',
 supplied_approval_evidence=approval['evidence']))
paths=set(prior['files_sha256'])|set(substantive)
paths.update(str(p.relative_to(root)) for p in prior_path.parent.iterdir() if p.is_file())
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file())
delta={n:sha(root/n) for n,h in prior['files_sha256'].items() if sha(root/n)!=h}
assert set(delta)<=allowed, set(delta)-allowed
save(out/'STATIC_REVIEW.json',dict(method='Source inspection, AST/JSON parsing and streaming hashes only; no machinery imports',
 tests_run=False,compilers_run=False,probes_run=False,campaigns_run=False,substantive_changes=substantive,
 changed_existing_files=delta,protected=protected,prior_manifest_sha256=prior_hash,
 scope='Bool/nonfinite override rejection; separate root-approved Darwin memory7GiB admission and disk8GiB floors; narrow controls and legacy threshold correction.',
 preserved='VM estimate formula; dynamic memory/disk5GiB; native footprint4/5GiB; absolute RSS8GiB; Linux admission8GiB; pressure/process/output/time/single-heavy bounds; all proofs, roots, contexts and premise policies.',
 prior_snapshots='Preserved byte-for-byte;005 results never relabeled006'))
paths.add(str((out/'STATIC_REVIEW.json').relative_to(root)))
for name in sorted(paths):
    p=root/name
    if p.suffix=='.py': ast.parse(p.read_text(),filename=name)
    elif p.suffix=='.json': json.loads(p.read_text())
disposition=json.loads((root/'INSTALLATION_SOURCE_DISPOSITION.json').read_text())
for name in sorted(paths-{'INSTALLATION_SOURCE_DISPOSITION.json','CONSTRUCTION_V3_AUDIT.json'}):
    old=disposition['artifacts'].get(name,{})
    disposition['artifacts'][name]=dict(sha256=sha(root/name),disposition=old.get('disposition',
        'archive exact006 source/review/approval provenance; not acceptance' if name.startswith('evidence/') else 'ship source/runtime/acceptance/reproduction artifact'))
disposition['metadata_bound_by']='source-audit-006/SOURCE_MANIFEST.json binds exact install map and current audit'
disposition['runtime_and_acceptance_overlay']=sorted(set(disposition['runtime_and_acceptance_overlay'])|set(substantive))
save(root/'INSTALLATION_SOURCE_DISPOSITION.json',disposition)
old_audit=json.loads((root/'CONSTRUCTION_V3_AUDIT.json').read_text())
remaining=['Independent changed-file source audit of006 required; STOP',
 'Affected selectors prepared only; tests_run=false; supervisor owns tests and final installed preflight',
 'Prior005 passes remain005; no006 acceptance claimed']
changed={n:sha(root/n) for n in paths if n!='CONSTRUCTION_V3_AUDIT.json' and prior['files_sha256'].get(n)!=sha(root/n)}
audit={**old_audit,'invocation':'final-hygiene-006','status':'FROZEN source only; STOP for independent changed-file source audit',
 'checkpoint':'evidence/construction-v3/source-audit-006/SOURCE_MANIFEST.json',
 'prior_checkpoint':dict(manifest=str(prior_path.relative_to(root)),sha256=prior_hash,disposition='001-005 snapshots/results preserved unchanged'),
 'changed_files_sha256':changed,'protected':protected,'tests_run':False,'compilers_run':False,'preflights_run':False,'probes_run':False,'campaigns_launched':False,
 'actual_prior_evidence':dict(checkpoint005_manifest_sha256=prior_hash,disposition='005 passes remain bound005; no006 execution',details='evidence/construction-v3/source-audit-006/PRIOR_EVIDENCE.json'),
 'limits':{**old_audit['limits'],'darwin_profile_sha256':sha(profile_path),'darwin_memory_admission_bytes':7*1024**3,'disk_admission_bytes':8*1024**3,'linux_memory_admission_bytes':8*1024**3},
 'planned_commands':commands,'remaining':remaining,'substantive_changes':substantive}
save(root/'CONSTRUCTION_V3_AUDIT.json',audit)
hashes={n:sha(root/n) for n in sorted(paths)}
changed={n:h for n,h in hashes.items() if prior['files_sha256'].get(n)!=h}
assert set(n for n in changed if n in prior['files_sha256'])<=allowed
for name,expected in old_snapshot.items(): assert sha(root/name)==expected,name
for name,expected in hashes.items():
    dest=out/'sources'/name; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,dest); assert sha(dest)==expected; dest.chmod(0o444)
manifest=dict(schema='math-gkm.frozen-source-audit.v6',invocation='final-hygiene-006',
 created_utc=datetime.now(timezone.utc).isoformat(),tests_run=False,compilers_run=False,probes_run=False,
 files_sha256=hashes,changed_files_sha256=changed,substantive_changes=substantive,protected=protected,
 prior_checkpoint=dict(path=str(prior_path.relative_to(root)),sha256=prior_hash),
 source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',validation_plan='evidence/construction-v3/source-audit-006/VALIDATION_PLAN.json',
 source_copies='sources/<workspace-relative-path>',unshipped_bootstrap_sources_required=False,
 execution_gate='FROZEN: STOP for independent changed-file source audit; supervisor owns tests and final installed preflight')
save(out/'SOURCE_MANIFEST.json',manifest)
(out/'SOURCE_MANIFEST.sha256').write_text(sha(out/'SOURCE_MANIFEST.json')+'  SOURCE_MANIFEST.json\n')
for p in out.rglob('*'):
    if p.is_file(): p.chmod(0o444)
result=dict(checkpoint=str(out.relative_to(root)),sha256=sha(out/'SOURCE_MANIFEST.json'),files=len(hashes),
 substantive_changes=substantive,protected_unchanged=True,prior_snapshots_unchanged=True,tests_run=False,status='STOP: independent changed-file source audit')
save(root/'local.scratch/HYGIENE006_PROGRESS.json',result)
print(json.dumps(result))
