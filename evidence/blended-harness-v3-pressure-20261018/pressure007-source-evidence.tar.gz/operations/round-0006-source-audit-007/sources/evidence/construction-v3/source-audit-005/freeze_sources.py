"""Source-only checkpoint005 constructor: AST/JSON parsing and streaming hashes."""
import ast
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shutil

root=Path.cwd(); out=root/'evidence/construction-v3/source-audit-005'
if (out/'SOURCE_MANIFEST.json').exists(): raise RuntimeError('already frozen')
out.mkdir(parents=True,exist_ok=True)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''): h.update(block)
    return h.hexdigest()
def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
prior_path=root/'evidence/construction-v3/source-audit-004/SOURCE_MANIFEST.json'
prior=json.loads(prior_path.read_text()); prior_hash=sha(prior_path)
assert prior_hash=='bb1c09cdc706569ffdcd3814fbc9b3248dce901c832db18cedc222786a28bc64'
old_audit=json.loads((root/'CONSTRUCTION_V3_AUDIT.json').read_text())
inputs=root/'.bootstrap/capacity-repair-005-inputs'
input_map=json.loads((inputs/'INPUT_MANIFEST.json').read_text())
for name,expected in input_map.items():
    assert sha(inputs/name)==expected, name
for name in ['INPUT_MANIFEST.json',*input_map]:
    dest=out/'inputs'/name; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(inputs/name,dest)
shutil.copyfile(__file__,out/'freeze_sources.py')
protected={n:dict(before=r['after'],after=sha(root/n),unchanged=r['after']==sha(root/n))
           for n,r in prior['protected'].items()}
assert all(r['unchanged'] for r in protected.values())
# Preserve exact source-bound historical evidence, without copying large stdout.
evidence={}
for directory in sorted((root/'.scratch/v3-validation').glob('cp004-*')):
    for name in ('intent.json','result.json','run.log'):
        p=directory/name
        if p.is_file(): evidence[str(p.relative_to(root))]=dict(bytes=p.stat().st_size,sha256=sha(p))
save(out/'PRIOR_EVIDENCE.json',dict(checkpoint004_manifest_sha256=prior_hash,
    reported_neutral_passes=49,reported_by='root task inputs; no005 execution',
    raw_evidence=evidence,construction='compile/replay succeeded; inspector rejected 24,807,578 bytes at16MiB',
    full_mathlib='old RSS guard stop; calibration RSS about5.2GB/footprint about0.676GB; success/final peak UNKNOWN',
    classification='capacity failures, never mathematical refutations',tests_run=False))
prefix=('env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin '
        'GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null PYTHONDONTWRITEBYTECODE=1 '
        'TMPDIR='+str(root/'.scratch')+' /opt/homebrew/bin/python3 -m machinery.v3_validate '
        '--manifest evidence/construction-v3/source-audit-005/SOURCE_MANIFEST.json '
        '--review .scratch/source-review-005.json --seconds 1800 --label ')
groups=[('005-small','tests.test_capacity_repair005.Parser005 tests.test_capacity_repair005.Resource005'),
        ('005-two-regressions','tests.test_round4.Round4.test_complete_episode_pools_protect_seconds_and_calls tests.test_round4.Round4.test_requests_disclose_exact_aggregate_and_validation_limits tests.test_round4.Round4.test_seven_valid_proposals_route_only_six_failed_checks'),
        ('005-resources','tests.test_construction_v3_resources.Resources tests.test_construction_v3_repair.ResourceRepair tests.test_construction_v3_repair004.Resources004')]
commands=[dict(command=prefix+label+' '+selectors,status='PREPARED ONLY; independent source audit and supervisor outerwatch6 first') for label,selectors in groups]
old_plan=json.loads((root/'evidence/construction-v3/source-audit-004/VALIDATION_PLAN.json').read_text())
for row in old_plan['commands']:
    row=dict(row); row['command']=row['command'].replace('source-audit-004','source-audit-005').replace('source-review-004','source-review-005').replace('--label 004-','--label 005-')
    row['status']='PREPARED ONLY; independent source audit and outerwatch6 first'
    commands.append(row)
save(out/'VALIDATION_PLAN.json',dict(tests_run=False,sequential_only=True,
    gate='STOP: independent source audit of005 before tests; supervisor separately supplies outerwatch6; no wrapper edited here',
    commands=commands,remaining=['Actual native ABI/return/identity and cleanup acceptance UNKNOWN',
    'Parser regressions and retained actual hidden-premise tests NOT RUN on005',
    'Full Construction inspector acceptance, replay and full Mathlib import final peak UNKNOWN',
    'All changed-source tests unrun;004 passes remain004 evidence only','D1-D3 OPEN; no mathematical work']))
paths=set(prior['files_sha256'])
paths.update(['config/darwin-memory-profile-005.json','tests/test_capacity_repair005.py','docs/CAPACITY_REPAIR_005.md'])
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file())
allowed={'machinery/proof_audit.py','machinery/resources.py','machinery/study_common.py',
 'machinery/validation_receipts.py','machinery/study_transfer.py','tests/test_round4.py',
 'tests/test_construction_v3_resources.py','tests/test_construction_v3_repair.py',
 'tests/test_construction_v3_repair004.py','CONSTRUCTION_V3_AUDIT.json','INSTALLATION_SOURCE_DISPOSITION.json'}
delta={n:sha(root/n) for n,h in prior['files_sha256'].items() if sha(root/n)!=h}
assert set(delta)<=allowed, set(delta)-allowed
save(out/'STATIC_REVIEW.json',dict(method='AST/JSON parsing, source inspection, streaming hashes only',
 tests_run=False,compilers_run=False,probes_run=False,prior_files=266,
 unchanged_prior_files=266-len(delta),changed_existing_files=delta,protected=protected,
 operational_wrappers='unchanged; supervisor outerwatch6 external',all_mathematical_sources='unchanged'))
paths.add(str((out/'STATIC_REVIEW.json').relative_to(root)))
for name in sorted(paths):
    p=root/name
    if p.suffix=='.py': ast.parse(p.read_text(),filename=name)
    elif p.suffix=='.json': json.loads(p.read_text())
disposition=json.loads((root/'INSTALLATION_SOURCE_DISPOSITION.json').read_text())
for name in sorted(paths-{'INSTALLATION_SOURCE_DISPOSITION.json','CONSTRUCTION_V3_AUDIT.json'}):
    old=disposition['artifacts'].get(name,{})
    disposition['artifacts'][name]=dict(sha256=sha(root/name),disposition=old.get('disposition',
        'archive exact005 source/review/input provenance; not acceptance' if name.startswith('evidence/') else 'ship source/runtime/acceptance/reproduction artifact'))
disposition['metadata_bound_by']='source-audit-005/SOURCE_MANIFEST.json binds map and current audit'
disposition['runtime_and_acceptance_overlay']=sorted(n for n in paths if not n.startswith('evidence/') and n not in ('MathGKM.lean','CONSTRUCTION_V3_AUDIT.json','INSTALLATION_SOURCE_DISPOSITION.json'))
save(root/'INSTALLATION_SOURCE_DISPOSITION.json',disposition)
changed={n:sha(root/n) for n in paths if n!='CONSTRUCTION_V3_AUDIT.json' and prior['files_sha256'].get(n)!=sha(root/n)}
audit={**old_audit,'invocation':'capacity-repair-005','checkpoint':'evidence/construction-v3/source-audit-005/SOURCE_MANIFEST.json',
 'prior_checkpoint':dict(manifest=str(prior_path.relative_to(root)),sha256=prior_hash,disposition='001-004 and raw failures preserved unchanged'),
 'changed_files_sha256':changed,'protected':protected,'tests_run':False,'compilers_run':False,'probes_run':False,
 'actual_prior_evidence':dict(checkpoint004_manifest_sha256=prior_hash,neutral_passes=49,
    disposition='untouched004 evidence; no fresh005 passes',details='evidence/construction-v3/source-audit-005/PRIOR_EVIDENCE.json'),
 'limits':{**old_audit['limits'],'inspector_artifact_bytes':32*1024**2,'validator_result_bytes':64*1024**2,
    'darwin_profile_sha256':sha(root/'config/darwin-memory-profile-005.json')},
 'planned_commands':commands,'remaining':json.loads((out/'VALIDATION_PLAN.json').read_text())['remaining']}
save(root/'CONSTRUCTION_V3_AUDIT.json',audit)
hashes={n:sha(root/n) for n in sorted(paths)}
changed={n:h for n,h in hashes.items() if prior['files_sha256'].get(n)!=h}
for name,expected in hashes.items():
    dest=out/'sources'/name; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,dest); assert sha(dest)==expected; dest.chmod(0o444)
manifest=dict(schema='math-gkm.frozen-source-audit.v5',invocation='capacity-repair-005',
 created_utc=datetime.now(timezone.utc).isoformat(),tests_run=False,compilers_run=False,probes_run=False,
 files_sha256=hashes,changed_files_sha256=changed,protected=protected,
 prior_checkpoint=dict(path=str(prior_path.relative_to(root)),sha256=prior_hash),
 source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',validation_plan='evidence/construction-v3/source-audit-005/VALIDATION_PLAN.json',
 source_copies='sources/<workspace-relative-path>',unshipped_bootstrap_sources_required=False,
 execution_gate='FROZEN: independent source audit before tests; supervisor outerwatch6 separately prepared')
save(out/'SOURCE_MANIFEST.json',manifest)
(out/'SOURCE_MANIFEST.sha256').write_text(sha(out/'SOURCE_MANIFEST.json')+'  SOURCE_MANIFEST.json\n')
for p in out.rglob('*'):
    if p.is_file(): p.chmod(0o444)
print(json.dumps(dict(checkpoint=str(out.relative_to(root)),sha256=sha(out/'SOURCE_MANIFEST.json'),
 files=len(hashes),changed=len(changed),protected_unchanged=True,tests_run=False)))
