"""Source-only freeze for repair004: stdlib parsing/hashing/copying, no imports of candidate code."""
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
from datetime import datetime,timezone

root=Path.cwd()
out=root/'evidence/construction-v3/source-audit-004'
if (out/'SOURCE_MANIFEST.json').exists(): raise RuntimeError('checkpoint already frozen')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v): Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
prior=json.loads((root/'evidence/construction-v3/source-audit-003/SOURCE_MANIFEST.json').read_text())
old_audit=json.loads((root/'evidence/construction-v3/source-audit-003/sources/CONSTRUCTION_V3_AUDIT.json').read_text())
# Inventory every regular file in intended source/reproduction directories,
# recursively, excluding only cache directories. No selected overlay globs.
paths=set()
for folder in ('machinery','tests','MathGKM','docs','contracts','studies','config','repro'):
 for directory,dirs,files in os.walk(root/folder,followlinks=False):
  dirs[:]=[d for d in dirs if d not in ('__pycache__','.git','.lake')]
  for name in files:
   p=Path(directory)/name
   if p.is_symlink(): raise RuntimeError('unclassified source symlink '+str(p))
   paths.add(str(p.relative_to(root)))
paths.update(p.name for p in root.iterdir() if p.is_file() and p.name not in ('CONSTRUCTION_V3_AUDIT.json','INSTALLATION_SOURCE_DISPOSITION.json'))
# Include exact shipped reference/review/failure source+receipt+recipe bundles.
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file() and 'sources' not in p.relative_to(out).parts)
errors=[]
for name in sorted(paths):
 p=root/name
 if p.suffix=='.py':
  try: ast.parse(p.read_text(),filename=name)
  except SyntaxError as e: errors.append(dict(path=name,error=str(e)))
 elif p.suffix=='.json':
  try: json.loads(p.read_text())
  except ValueError as e: errors.append(dict(path=name,error=str(e)))
if errors: raise RuntimeError(json.dumps(errors))
protected={name:dict(before=row['after'],after=sha(root/name),unchanged=row['after']==sha(root/name))
           for name,row in old_audit['protected'].items()}
if not all(r['unchanged'] for r in protected.values()): raise RuntimeError('protected input changed')
dispositions={}
for name in sorted(paths):
 action=('EXCLUDE candidate-only aggregate; preserve installed API/historical imports byte-for-byte' if name=='MathGKM.lean' else
    'ship acceptance fixture only; not a research result' if name=='MathGKM/NeutralV3Root.lean' else
    'verify unchanged protected input; preserve installed version' if name in protected else
    'archive exact source/review/failure/receipt/recipe provenance; not an approval or rerun' if name.startswith('evidence/') else
    'ship source/runtime/acceptance/reproduction artifact')
 dispositions[name]=dict(sha256=sha(root/name),disposition=action)
save(root/'INSTALLATION_SOURCE_DISPOSITION.json',dict(
 schema='math-gkm.installation-source-disposition.v2',installation_performed=False,
 artifacts=dispositions,metadata_bound_by='source-audit-004/SOURCE_MANIFEST.json also binds this map and current audit',
 candidate_only_exclusions={'MathGKM.lean':dict(sha256=sha(root/'MathGKM.lean'),action='EXCLUDE; preserve installed aggregate including historical Agoh imports')},
 acceptance_inputs={'MathGKM/NeutralV3Root.lean':'ship as fixture; never count as discovered result'},
 runtime_and_acceptance_overlay=[n for n in paths if not n.startswith('evidence/') and n!='MathGKM.lean'],
 historical_agoh='Preserve installed historical modules/imports unchanged; absent candidate historical recompilation remains OPEN at installation.',
 protected_sources={n:r['after'] for n,r in protected.items()},
 runtime_inputs='Independent review and live activation are operator-created after auditing/testing; config templates are never approval. No unshipped bootstrap source input is needed for the new reproduction route.',
 meaning='Complete source disposition only; no installation/publication/activation performed.'))
paths.add('INSTALLATION_SOURCE_DISPOSITION.json')
changed={n:sha(root/n) for n in paths if prior['files_sha256'].get(n)!=sha(root/n)}
plan=json.loads((out/'VALIDATION_PLAN.json').read_text())
audit=dict(phase='construction',schema='math-gkm.construction-v3.source-audit',
 model='gpt-6.1-sol',reasoning='high',invocation='source-repair-004',
 status='FROZEN FOR INDEPENDENT SOURCE AUDIT; STOP BEFORE TESTS',
 tests_run=False,compilers_run=False,preflights_run=False,probes_run=False,campaigns_launched=False,
 syntax_check='AST and JSON parsing only; no candidate imports, compilation, test collection or behavioral probes',
 checkpoint=str((out/'SOURCE_MANIFEST.json').relative_to(root)),
 prior_checkpoint=dict(manifest='evidence/construction-v3/source-audit-003/SOURCE_MANIFEST.json',sha256=sha(root/'evidence/construction-v3/source-audit-003/SOURCE_MANIFEST.json'),disposition='001/002/003 unchanged; actual failures/receipts retained'),
 changed_files_sha256=changed,protected=protected,
 actual_prior_evidence=dict(pure=dict(executions=7,pass_count=6,history_view_errors=1),
  fresh_consumer='three actual component admissions; representation syntax rejection; full test failed',
  construction='failed ORIGINAL context compilation; no model theorem refutation',
  resource_runner='privileged OS observer compatibility defect; source repair untested',
  no_markov_results_or_campaign=True),
 open_obligations=old_audit['open_obligations'],limits=old_audit['limits'],
 source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',planned_commands=plan['commands'],
 remaining=['Independent source audit and all actual changed-source tests/compile/replay/premise outcomes UNKNOWN.',
  'Actual Darwin observer/resource/normal-exit cleanup paths and full-Mathlib sandbox capacity need observed acceptance.',
  'Real branch-to-main checked handoff, completion-source plumbing and crash recovery require the prepared actual tests; fixture truth is not live discovery/usefulness.',
  'Polling/public observer identity is not atomic containment; detached hostile sessions require OS isolation.',
  'Historical installed aggregate/Agoh recompilation remains an installation-side gap; preserve installed API.',
  'D1/D2/D3 OPEN; no abstract-model-to-live-host certification.'],
 trial_authorization='Root already authorized for fresh matched trials after meaningful audit/actual acceptance; constructor launches none.',
 manifest_rule='All listed current sources, maps, plans, review inputs, pins, provenance and source/receipt recipes are copied independently; manifest excludes its own hash.')
save(root/'CONSTRUCTION_V3_AUDIT.json',audit)
paths.add('CONSTRUCTION_V3_AUDIT.json')
save(out/'STATIC_REVIEW.json',dict(method='stdlib AST/JSON parsing, source inspection and hashes only',
 findings=[],tests_run=False,compilers_run=False,probes_run=False,protected=protected,
 created_utc=datetime.now(timezone.utc).isoformat()))
paths.add(str((out/'STATIC_REVIEW.json').relative_to(root)))
hashes={n:sha(root/n) for n in sorted(paths)}
# Independent frozen copies; never hardlink a live writer or mutate a prior checkpoint.
for name in hashes:
 dest=out/'sources'/name
 dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(root/name,dest)
 if sha(dest)!=hashes[name]: raise RuntimeError('copy changed '+name)
 dest.chmod(0o444)
manifest=dict(schema='math-gkm.frozen-source-audit.v4',invocation='source-repair-004',
 created_utc=datetime.now(timezone.utc).isoformat(),tests_run=False,compilers_run=False,probes_run=False,
 files_sha256=hashes,protected=protected,changed_files_sha256=changed,
 source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',
 validation_plan='evidence/construction-v3/source-audit-004/VALIDATION_PLAN.json',
 source_copies='sources/<workspace-relative-path>',unshipped_bootstrap_sources_required=False,
 execution_gate='Independent supervisor review binds this exact manifest; all planned commands run sequentially afterward.')
save(out/'SOURCE_MANIFEST.json',manifest)
(out/'SOURCE_MANIFEST.sha256').write_text(sha(out/'SOURCE_MANIFEST.json')+'  SOURCE_MANIFEST.json\n')
print(json.dumps(dict(checkpoint=str(out.relative_to(root)),manifest_sha256=sha(out/'SOURCE_MANIFEST.json'),
 source_files=len(hashes),changed_files=len(changed),static_parse_findings=errors,
 protected_unchanged=True,tests_run=False,compilers_run=False,probes_run=False)))
