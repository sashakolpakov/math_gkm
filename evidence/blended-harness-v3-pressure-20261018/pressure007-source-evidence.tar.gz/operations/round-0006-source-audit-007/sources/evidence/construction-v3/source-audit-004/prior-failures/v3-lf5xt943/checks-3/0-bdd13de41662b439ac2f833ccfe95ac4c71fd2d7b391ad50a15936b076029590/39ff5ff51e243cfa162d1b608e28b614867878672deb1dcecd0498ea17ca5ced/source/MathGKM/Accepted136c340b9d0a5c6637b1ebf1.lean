import MathGKM.Target58077597aee59dcd3a56d4bc
import MathGKM.Accepted0c0c62cb492ed4920bdd7e6d
import Lean
def Accepted136c340b9d0a5c6637b1ebf1.interface : MathGKM.Target58077597aee59dcd3a56d4bc.Interface := { forget := Prod.fst, extend := fun b => (b, ()), forget_extend := fun _ => rfl }
theorem Accepted136c340b9d0a5c6637b1ebf1.transport : MathGKM.Target58077597aee59dcd3a56d4bc.Transport Accepted136c340b9d0a5c6637b1ebf1.interface := Accepted136c340b9d0a5c6637b1ebf1.interface.forget_extend
theorem Accepted136c340b9d0a5c6637b1ebf1.obligation : MathGKM.Target58077597aee59dcd3a56d4bc.Goal Accepted136c340b9d0a5c6637b1ebf1.interface := MathGKM.ResearchSemantics.ConservativeExtension.preserves Accepted136c340b9d0a5c6637b1ebf1.interface (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) (fun b => Accepted0c0c62cb492ed4920bdd7e6d.obligation b.1 b.2)
