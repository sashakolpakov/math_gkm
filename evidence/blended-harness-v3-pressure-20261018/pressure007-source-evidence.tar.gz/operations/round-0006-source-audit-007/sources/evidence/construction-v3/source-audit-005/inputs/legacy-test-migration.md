# Narrow legacy regression migration (read-only review)

Retained failing log: candidate `.scratch/v3-validation/cp004-observer-and-budget-regressions/run.log`.
No tests/builds or candidate edits by reviewer. Preserve these as historical failures until revised assertions actually pass.

1. `tests.test_round4.Round4.test_complete_episode_pools_protect_seconds_and_calls`: the former rounds=2,max_calls=6,meta_calls=4 boundary assumed no proposer repair. New default proposal_repairs=1 reserves 8 total calls and 6 meta calls: two rounds each reserve proposer+possible repair+researcher, plus reviewer+selector. Test exact funded 8/6 and retain review pool=2/2, unavailable outside reserved pools, cannot steal reviewer seconds, and idempotent repeated funding assertions. Keep the old 6/4 boundary with explicit proposal_repairs=0, or assert 6/4 with repairs=1 fails before any role. Do not change actual executed-call counts from six to eight when no repair actually occurred: reservations and execution are separate.

2. `test_requests_disclose_exact_aggregate_and_validation_limits`: preserve disclosed limits and malformed report `[{}]*7`; V3 now journals independent rejection instead of globally raising. Assert no checker call, no admitted facts/components/closed residuals, no budget change, six malformed rejections and a seventh explicit cap-exhausted/not-checked receipt. Add a small routing test with seven distinct syntactically valid claims and a mocked checker returning checked=False, never fake acceptance: exactly six checker invocations/reservations, seventh not checked, no admitted mathematics. This preserves the aggregate cost scenario without forcing all-or-nothing admission or changing the mathematical gate.

Keep actual Lean false-conclusion, missing-premise, exact-context, required-export, hidden-generated-premise and interrupted replay checks unchanged. This is an assertion/config migration, not permission to delete scenarios or reduce proof validation.
