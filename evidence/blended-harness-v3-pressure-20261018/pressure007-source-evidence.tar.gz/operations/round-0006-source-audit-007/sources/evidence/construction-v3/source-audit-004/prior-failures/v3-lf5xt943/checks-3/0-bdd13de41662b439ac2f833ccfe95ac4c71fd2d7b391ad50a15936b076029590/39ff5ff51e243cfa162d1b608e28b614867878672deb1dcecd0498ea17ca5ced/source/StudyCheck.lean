import MathGKM.Target680cd9996d00335cef493b5f
import MathGKM.Accepted136c340b9d0a5c6637b1ebf1
import Lean
def StudyInterface : MathGKM.Target680cd9996d00335cef493b5f.Interface := { forward := Accepted136c340b9d0a5c6637b1ebf1.interface.extend, law := fun b => by
  change ((fun x : Nat × Nat => x.1 + x.2 = x.2 + x.1) (Accepted136c340b9d0a5c6637b1ebf1.interface.forget (Accepted136c340b9d0a5c6637b1ebf1.interface.extend b))) ↔ _
  rw [Accepted136c340b9d0a5c6637b1ebf1.transport b] }
theorem StudyTransport : MathGKM.Target680cd9996d00335cef493b5f.Transport StudyInterface := StudyInterface.law
theorem StudyObligation : MathGKM.Target680cd9996d00335cef493b5f.Goal StudyInterface := MathGKM.ResearchSemantics.Representation.consume StudyInterface
