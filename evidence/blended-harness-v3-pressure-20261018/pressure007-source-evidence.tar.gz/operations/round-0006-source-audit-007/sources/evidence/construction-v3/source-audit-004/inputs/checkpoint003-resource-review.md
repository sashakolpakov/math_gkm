# Frozen003 — scoped safety clearance for neutral tests

Independent resource auditor. Manifest `evidence/construction-v3/source-audit-003/SOURCE_MANIFEST.json`, SHA-256 `7e3f856bc4f77eb33575a1bc17a91a0e6f5cd99436ffe37529e044f9df454c9c`. All124 listed file hashes match. Free space observed~200GiB. Static inspection only: no candidate code imported, no tests/builds executed.

**Approved: small sequential neutral tests under supervisor bounded_test_watch_v3.py SHA `752794beab59c2a5720e0416107c6a6ac864cf2385ecf5daa27a42f20b9756e9`.** This clearance intentionally permits safe tests to expose functional defects; it is not a claim of deployment readiness or complete process containment.

Recommended allowed order:

1. `tests.test_construction_v3.Pure` (no live model/Lean jobs).
2. `tests.test_construction_v3_resources.Resources` (simulated thresholds,32MiB hash fixture,100KiB output fixture; ordinary test sleepers have10/20s finite lifetimes; unrelated fixture process has finally cleanup).
3. `tests.test_construction_v3.CheckedMath.test_successive_admission_fresh_consumer_exact_root` alone, exercising real neutral universal theorem admission and successive interface consumers. Execute other CheckedMath cases individually after the initial actual compile/replay/premise path has been observed.

Use unique labels, frozen source checks, protected supervisor review binding, single outer watcher and one active test job. Preserve every failure/log/generated theorem source. Neither successful fixture policies nor a root commutativity example establishes a new research theorem or Markov progress.

Keep MatchedContinuation, full deployment, fresh comparative campaign and all live model invocations held until the simple actual validator path works and the remaining campaign-critical process defect is repaired. The fixture can then be run under the same bounded outer watcher, sequentially. No broad49-test suite or parallel Mathlib builds.

## Improvements verified since002

Native current PPID/microsecond birth ownership is now pinned once and not rebound from stale ps. Monitor failure leaves a persistent launch hold. OS observer output is capped/streamed. Wrapper `lake` is no longer counted as a second compiler. Post-spawn setup is inside finally cleanup. Zombie processes are excluded from the live check, avoiding the prior false unresolved-cleanup hold. Admission receipts record release/failure/elapsed distinctly from caps.

Source inventory is now explicit UTF-8 text with8MiB/file,128MiB total and10k-file caps; compiled variants/archive payloads are excluded and retained at origin. Source snapshots are bounded independent copies outside live-writer aliasing; aggregate retained history bound1GiB. Validation inputs/pins are flushed and exact pin hashes checked before derived-object retirement. New test runner delegates to the bounded common process helper with no nested heavy lease and a capped streamed log.

## Remaining precise functional blockers / follow-ups

- `process._run` still polls/reaps its leader and kills only that child plus descendants already observed by Guard. An ordinary child spawned then orphaned before the first sample can survive timeout. Current approved fault fixture sleeps only10s, so it is safe to observe this class of behavior under the outer watcher; it does not fix or fully test immediate-parent-exit cleanup. Before unattended use, fix original-private-group cleanup while direct child remains unreaped, and add a tiny immediate-parent-exit fixture with explicit descendant PID/finally cleanup and assert that it is gone.
- `tree_only=True` skips admission headroom checks. The independently approved outer watcher supplies headroom for these tests. Before unattended use, provide a headroom-only check without a conflicting heavy lease.
- A cached REBUILD.json is still accepted without equality to freshly computed recipe; derived directory deletion remains unrestricted recursive deletion. Recovery should compare the exact recipe and reject symlink/unclassified unique files before retirement. These tests use fresh attempt directories and known compiler outputs, so this does not block scoped positive testing. Demonstrate rebuilding after retirement and publish exact sources/pins/recipes/receipts.
- General observer `study_audit.measure/collect` now needs actual bounded/streaming inspection; do not run it on arbitrary large payloads. Retain source-only and fixed-input semantics. Runtime birth-query ctypes declarations should be explicit/cached eventually; the current call uses fixed zero argument and136-byte structure matching the reviewed SDK, but avoid proliferating dynamic ctypes classes per process poll.
- Source retention bounds protect storage but do not prove useful strategy transfer. Matched arms must be sequential, share only read-only pinned packages, and use identical global caps. Confirm with actual evidence after basic validator tests succeed.

A failure within time/resource limits is operationally incomplete, not a mathematical refutation. If any unresolved-cleanup hold appears, inspect the exact owned PIDs/births and finite fixture lifetimes before clearing it; never kill unrelated application/Codex processes.
