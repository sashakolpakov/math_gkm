import MathGKM.NeutralV3Root
def MathGKM.Target033bbb9bdf1b12c0f946c8aa.Interface := True
def MathGKM.Target033bbb9bdf1b12c0f946c8aa.Transport (StudyInterface : MathGKM.Target033bbb9bdf1b12c0f946c8aa.Interface) : Prop := True
def MathGKM.Target033bbb9bdf1b12c0f946c8aa.Goal (StudyInterface : MathGKM.Target033bbb9bdf1b12c0f946c8aa.Interface) : Prop := ∀ n m : Nat, n + m = m + n
