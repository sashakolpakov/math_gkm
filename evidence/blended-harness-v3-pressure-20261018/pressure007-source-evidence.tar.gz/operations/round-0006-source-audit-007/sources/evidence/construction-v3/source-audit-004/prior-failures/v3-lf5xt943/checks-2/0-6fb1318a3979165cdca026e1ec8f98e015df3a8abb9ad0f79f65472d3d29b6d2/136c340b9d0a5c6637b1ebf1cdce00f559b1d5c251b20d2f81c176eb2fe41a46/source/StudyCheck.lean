import MathGKM.Target58077597aee59dcd3a56d4bc
import MathGKM.Accepted0c0c62cb492ed4920bdd7e6d
import Lean
def StudyInterface : MathGKM.Target58077597aee59dcd3a56d4bc.Interface := { forget := Prod.fst, extend := fun b => (b, ()), forget_extend := fun _ => rfl }
theorem StudyTransport : MathGKM.Target58077597aee59dcd3a56d4bc.Transport StudyInterface := StudyInterface.forget_extend
theorem StudyObligation : MathGKM.Target58077597aee59dcd3a56d4bc.Goal StudyInterface := MathGKM.ResearchSemantics.ConservativeExtension.preserves StudyInterface (fun b : Nat × Nat => b.1 + b.2 = b.2 + b.1) (fun b => Accepted0c0c62cb492ed4920bdd7e6d.obligation b.1 b.2)
