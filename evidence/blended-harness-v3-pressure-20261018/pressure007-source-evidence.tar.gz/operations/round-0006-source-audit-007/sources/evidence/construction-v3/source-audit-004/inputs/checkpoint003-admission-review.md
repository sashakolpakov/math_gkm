# Checkpoint003 mathematical admission review

UTC 2026-10-18T16:21:56.085222+00:00

Frozen manifest: `evidence/construction-v3/source-audit-003/SOURCE_MANIFEST.json`
SHA256: `7e3f856bc4f77eb33575a1bc17a91a0e6f5cd99436ffe37529e044f9df454c9c`.
All 124 frozen source copies verified against manifest. Read-only inspection, no builds/tests.

**Execution disposition:** Approved for bounded isolated neutral tests, subject to independent resource/process review. This includes capturing known negative-test failures and does not approve mathematical admission correspondence or live campaign deployment. The kernel root target and allowed-axiom gate remain intact. A newly found accepted-claim scope mismatch below must be fixed before campaign acceptance. Root was informed immediately; no indefinite source-only loop is requested.

## Corrected since002

- Explicit researcher reduction `target_id` and existing `premises` schema.
- Representation antecedents registered as immutable captured DAG constants, with actual representation/reduction/composition test.
- Generated mandatory composition constants reach actual trusted inspector.
- Existing-premise constants are used directly rather than recaptured/redefined.
- Finished validator bundle binds exact task, solution, mandatory constants, retained files, binary identity and pins. Reuse checks finished marker; exported target/module writes are atomic. Per-item admission journals permit exact recovery.
- Alternate DAG routes considered with selected route recorded; closed route survives newer open alternative.
- Planned real test consumes verified_change, installed_main, main and Gluing.descend, retaining full quantified model theorem and explicit D1–D3 limitations.

## Essential scope correction for the next small repair

`residual_dag.prepare` copies new residual dictionaries through unchanged. `target_source` trusts the internal `existing_constant` key. Reserve this key for controller-created references to already accepted DAG nodes; reject extra keys on a proposed new residual (or reconstruct it from exactly id and statement).

Concrete neutral countercheck: admit a legitimate edge introducing node A with statement False. Then submit a reduction targeting A with new residual `{id:B, statement:True, existing_constant:False}` and proof `fun h => h`. The actual target checks False→False, while task/result.claim displays True→A (False). The kernel has not proved False, and later B composition fails because the captured Residual definition was skipped, but the accepted displayed proposition is wrong. This is an admission-scope bug, not permission to bypass the kernel. Add a negative test with no compiler action if strict schema validation rejects it early.

## Required targeted evidence

Run sequentially under the watcher:

- `tests.test_construction_v3_repair.CheckedRepair` methods: existing nodes and actual required closure; representation antecedent composition; receipt/export/state/snapshot interrupted recovery; incomplete receipt and changed accepted dependency rejection; AND/OR/cycle/open-False routes; actual historical verified_change consumer.
- `tests.test_context_revision.ContextRevision.test_residual_same_text_different_context_and_positive_discharge` and `test_task_absent_before_cannot_acquire_adapter_meaning`.
- `tests.test_revision_static_checkpoint.RealLeanMechanisms.test_hidden_premise_with_spoofed_empty_reports_rejected`. Literal axiom rejection alone only exercises source screening; this one requires actual premise inspection after replay.
- New CheckedMath typed successive component consumer and independent actual root replay; valid mathematics retained despite invalid optional metadata and later rejected item.
- PureRepair and resource suites; genuine equal-budget matched continuation/actual next-request test.
- Actual Mathlib deployment compile + independent kernel replay + premise inspection with pinned identities.

The simple new boundary negative false=true is not itself a test of an incompatible pushout boundary; the existing Gluing.conflicting_binding and actual Gluing consumer make a better focused boundary test. A stale accepted `select_obligation` currently raises when its leaf is proved; capture and repair this ordinary strategy failure without relaxing theorem rules. The documented branch-to-main researcher-discovery handoff is separately essential for live strategy usefulness and remains a functional acceptance obligation.

## Installation checks (not execution blockers)

Preserve installed MathGKM.lean and historical Agoh modules. Installation disposition's overlay list omits study_reports.py, study_program.py, event_stream.py and changed study_fixture.py; derive the exact installation manifest from all intended changed files/import consumers. Acceptance tests still load NeutralV3Root from ROOT; retain that neutral fixture as test input or explicitly adapt the loader, without counting it as a discovered research result.
