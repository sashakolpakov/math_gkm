# math_gkm: mathematical research with explicit proof boundaries

`math_gkm` is a machine-authored mathematical research experiment in the
**Gödel–Kolmogorov Machine (GKM)** lineage. A general LLM researcher chooses
representations, reads literature, runs experiments and develops Lean proofs;
retained records and independent review distinguish what was proposed, executed,
compiled, replayed and actually proved. The fixed [mission](MISSION.md) and
[design](docs/DESIGN.md) govern the project.

## Blended V3 — validation incomplete

Repair 004 is a source-only checkpoint awaiting independent source audit and
actual sequential acceptance. No tests, compilers or behavioral probes ran on
these changed sources. Read [the current checkpoint](docs/STUDY_V3.md) and
[the exact audit record](CONSTRUCTION_V3_AUDIT.json).

Checkpoint003 actually ran seven Pure/PureRepair tests: six passed and one
history_view error. Direct neutral diagnostics admitted three components before
a multiline representation syntax failure; the independent Construction test
failed original-context compilation. Those failures and the resource observer
issue are retained. These are incomplete harness evidence, not mathematical
refutations. D1/D2/D3 remain OPEN. No Markov results/campaign have run here.

The historical V2 49-test evidence remains historical; it is not V3 validation.
Root will rerun affected cases, the supported neutral legacy selectors (or
record explicit justified dispositions), and deployed full-Mathlib checks.
The user already authorizes fresh matched trials after meaningful acceptance;
root activates them. No inherited proofs or mathematical strategy are supplied.

**Research status, through closed worker 188 (17 October 2026):** the Agoh
exercise is complete. For Markov polynomials, every numerator-two source has
all three raw-coefficient log-concavity directions at all natural indices.
Every numerator-three source has horizontal log-concavity throughout the
lower half-plane and in upper rows satisfying the explicit linear bound,
including zeros. Earlier rows and additional strict column regions are also
proved, including the single upper-row triple at columns 4, 5 and 6 under
its stated depth conditions. **Full Conjecture 6.3 remains open.** See the
dated [research status and exact remaining scope](RESEARCH_STATUS.md) for the
precise domains, residual obligations and validation limits.

## The three ideas behind the name and architecture

| Idea | What is present here | Boundary |
| --- | --- | --- |
| **Gödel machine** | A checked Lean model compares a guarded engine change with the entire incumbent continuation, including later searches and installations. | This does not certify arbitrary Python, LLM or operating-system edits. The live research controller is experimental. |
| **Kolmogorov perspective** | Description, dependency and reuse evidence can be audited separately from mathematical success. | True Kolmogorov complexity is uncomputable. Complexity is audit-only: no curiosity reward, action-selection score or theorem-count objective. |
| **Gluing / cofibrant construction** | Lean proves a pushout universal property for types, a concrete glued-state equivalence, and conditional conservative attachment/transport theorems. | No model category, cofibration structure or automatic conservative linker for dependent Lean modules is implemented. |

Read [Gödel machines, complexity and the actual research loop](docs/GKM.md) and
[gluing: mathematics, witnesses and implementation limits](docs/GLUING.md).
These pages separate proved interfaces from the broader design vocabulary.

```mermaid
flowchart LR
    C[Fixed problem contract] --> P[LLM researcher]
    H[Retained observations and failures] --> P
    P --> T[Literature, experiments, representations, Lean]
    T --> H
    T --> V[Proof checks and scope review]
    V --> H
    V --> R[Exact root check and independent source audit]
    R --> D[Resolution only if both pass]
```

The proposer has general research actions within its granted tools and resource
limits. The supervisor supplies the problem and reviews evidence, rather than
supplying a proof recipe. Ordinary exploration does not require a proof that each
next action is optimal. A theorem about a mathematical claim, a proof of a model
switch, and permission to edit the host controller are three different things.

## Reading the repository

- [Current research scope](RESEARCH_STATUS.md), with exact source links and
  evidence limits; [Agoh account](docs/round2/AGOH.md) for the completed exercise.
- [Construction mathematics](docs/CONSTRUCTION_MATHEMATICS.md) for the precise
  continuation theorem and counterexamples to missing assumptions.
- [Controller](docs/CONTROLLER.md) for live transport, durable recovery, resource
  accounting and the independent completion boundary.
- [Original construction checkpoint](docs/CONSTRUCTION.md),
  [initial Markov account](docs/round2/MARKOV.md) and
  [attempt log](docs/ATTEMPTS.md) for historical stages. Their dated status
  statements are not the current frontier.
- [Checkpoint](RESUME.json), `research/` sources, `evidence/` receipts and
  controller-retained worker records for provenance. A file's existence or a
  worker's successful exit does not alone establish mathematical acceptance.

Use the [portable reproduction and recovery tools](repro/README.md) to create a
separate workspace with exact source and dependency pins. Fresh construction,
Agoh and initial Markov compilation and kernel replay have passed using the
existing pinned dependencies. A cold dependency bootstrap and the whole later
campaign have not been rebuilt by that check. The historical wrappers and their
environment-specific paths remain preserved.

Sources, scripts, inputs, dependency pins and recovery manifests stay in Git.
Large optional compilation caches are archived as checksum-verified
[GitHub Release assets](https://github.com/sashakolpakov/math_gkm/releases/tag/recovery-cache-2026-10-17);
`git clone` does not download those assets. The recovery tool downloads them
explicitly. Local cache cleanup must never remove necessary public source/data
history or turn into a Git deletion commit. Ordinary `.olean` and `.lake` build
caches remain untracked; explicitly sealed binary evidence keeps its recorded
historical status.

## Public evidence provenance

The [public repository](https://github.com/sashakolpakov/math_gkm) exports a
filtered history: one expired publisher-PDF URL query was removed from a
historical worker58 trace. The original local history is retained. Historical
audit hashes identify those original local records; the redacted trace is a
derivative record, not hash-identical evidence. No Lean source was changed by
this filtering, and it adds no mathematical or verification claim.
