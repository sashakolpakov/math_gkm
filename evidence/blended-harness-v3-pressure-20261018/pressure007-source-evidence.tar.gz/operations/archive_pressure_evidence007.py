#!/usr/bin/env python3
"""Bounded source-only007 publication archive. Never build/delete/publish.
Root executes after review. Only frozen007, completed15-test evidence,
installation receipts and the first failed freeze are selected. The active
freeze-0002, curation, suites and research-arm paths are never traversed.
"""
import argparse,codecs,gzip,hashlib,io,json,os,re,tarfile
from pathlib import Path
ROOT=Path('/Users/sasha/math_gkm')
OPS=ROOT/'.bootstrap/construction-v3-20261018'
CANDIDATE=ROOT/'.scratch/strategy-v3-blended-20261018'
FROZEN=CANDIDATE/'evidence/construction-v3/source-audit-007'
JOB=CANDIDATE/'.scratch/v3-validation/cp007-pressure'
FAILED=ROOT/'.bootstrap/paired-v3-live-20261018/study/deployment-preflight'
INSTALLATION=ROOT/'evidence/harness-v3-install/20261018-007'
MANIFEST007='3e39e2efd9a0f3fa092bfe4b0305cd836156adb7de37d11bf19bfc45f5374310'
PROFILE007='fa7318100cea3a6bd4f06f96a2dd87249bb18339a9d259333ac3f40ac5c9411a'
WATCH7='60563d05ab5116a12534e3d79bf7607f758adaa55829e88d6c8f3b61c20f57a9'
WATCH7B='5ede968f0d79a4fd192832822de6a3f266b2226dde2cd043b26f54ea8f3ff191'
MAX_FILES=6000
MAX_MEMBER=128*1024**2
MAX_TOTAL=512*1024**2
PRUNE={'.git','.lake','__pycache__'}
BINARY_SUFFIXES={'.olean','.ilean','.o','.a','.so','.dylib','.dll','.exe','.bin','.zip','.pyc','.png','.jpg','.pdf','.c','.bc','.ll','.trace','.hash'}
MAPPINGS=((FROZEN,'operations/round-0006-source-audit-007'),(OPS,'operations'),
 (INSTALLATION,'installation007'),(JOB,'candidate-tests/cp007-pressure'),
 (FAILED,'failed-first-freeze/deployment-preflight'),(CANDIDATE,'candidate'))

def fail(message): raise RuntimeError(message)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as source:
  for block in iter(lambda:source.read(1048576),b''):h.update(block)
 return h.hexdigest()
def stable(st): return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
def name_for(path):
 for base,prefix in MAPPINGS:
  if path.is_relative_to(base):return prefix+'/'+path.relative_to(base).as_posix()
 if path.is_relative_to(ROOT):return 'repository-prerequisites/'+path.relative_to(ROOT).as_posix()
 fail('unapproved source root: '+str(path))
def excluded_by_name(path):
 return (any(path.name.endswith(s) for s in ('.olean.private','.olean.server','.tar.gz','.tar'))
         or path.suffix in BINARY_SUFFIXES)

def text_or_json_gzip(path):
 # Gzip is allowed ONLY for complete premise JSON, never a generic binary archive.
 if path.name.endswith('.json.gz'):return True
 if excluded_by_name(path):return False
 decoder=codecs.getincrementaldecoder('utf-8')('strict')
 try:
  with path.open('rb') as source:
   for block in iter(lambda:source.read(1048576),b''):
    if b'\0' in block:return False
    decoder.decode(block)
  decoder.decode(b'',final=True)
 except UnicodeDecodeError:return False
 return True



def sources():
 selected={};skipped=[];scanned=0
 def add(path,required=False):
  nonlocal scanned
  path=Path(os.path.abspath(path))
  if not path.exists():
   if required:fail('required evidence missing: '+str(path))
   return
  if path.is_symlink():
   if required:fail('required evidence is symlink: '+str(path))
   skipped.append({'path':name_for(path),'reason':'symlink; dependency restored from pins'});return
  if not path.is_file():fail('explicit evidence not regular: '+str(path))
  scanned+=1
  if scanned>MAX_FILES:fail('bounded file count')
  before=path.stat()
  if excluded_by_name(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'compiled or derived nonsource output'});return
  if before.st_size>MAX_MEMBER:fail('bounded member size: '+str(path))
  if not text_or_json_gzip(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'nonsource binary'});return
  sha=digest(path)
  if stable(path.stat())!=stable(before):fail('evidence changed while reading: '+str(path))
  selected[name_for(path)]={'source_path':str(path),'bytes':before.st_size,'sha256':sha,'stat_identity':stable(before)}
 def tree(path):
  if not path.is_dir():fail('required bounded evidence tree missing: '+str(path))
  for directory,dirs,files in os.walk(path,followlinks=False,onerror=lambda e:fail(str(e))):
   dirs[:]=sorted(d for d in dirs if d not in PRUNE and not (Path(directory)/d).is_symlink())
   for name in sorted(files):add(Path(directory)/name)
 manifest=FROZEN/'SOURCE_MANIFEST.json'
 if digest(manifest)!=MANIFEST007:fail('frozen007 manifest changed')
 files=json.loads(manifest.read_text())['files_sha256']
 if len(files)!=307:fail('frozen007 source count changed')
 for name,expected in files.items():
  source=FROZEN/'sources'/name
  if source.is_symlink() or not source.is_file() or digest(source)!=expected:
   fail('frozen007 source missing/changed: '+name)
 tree(FROZEN)
 for name in files:
  if name_for(FROZEN/'sources'/name) not in selected:fail('required frozen source excluded: '+name)
 if digest(OPS/'bounded_test_watch_v7.py')!=WATCH7:fail('executed watcher7 changed')
 if digest(OPS/'bounded_test_watch_v7b.py')!=WATCH7B:fail('executed watcher7b changed')
 tree(OPS/'round-0006-executed')
 tree(OPS/'final007-independent-reviews')
 for name in ('round-0006-CONSTRUCTION_V3_AUDIT.json','round-0006-prompt-007.txt',
              'bounded_test_watch_v7.py','bounded_test_watch_v7b.py',
              'FINAL_ACCEPTED_007_COMPOSITE.json','VALIDATION_007.json',
              'INSTALLED_SOURCE_REVIEW_007.json','LIVE_AUTHORIZATION006_BEFORE007.json',
              'DARWIN_PRESSURE_METRIC_DECISION_007.json','PRESSURE_METRIC_007_PRIMARY_NOTE.md',
              'archive_pressure_evidence007.py'):
  add(OPS/name,True)
 for label in ('cp007-pressure','cp007-construction'):
  for suffix in ('.json','.jsonl','.stdout'):add(OPS/('testwatch-'+label+suffix),True)
 # Read only completed cp007, not all validation jobs or active workspaces.
 validation=json.loads((OPS/'VALIDATION_007.json').read_text())
 if validation['outcome']!='PASS' or validation['tests']!=15:fail('007 test evidence incomplete')
 result=json.loads((JOB/'result.json').read_text())
 if result['returncode']!=0 or result.get('termination') or result['source_mismatches_after']:
  fail('actual007 tests did not finish cleanly')
 tree(JOB)
 log=JOB/'run.log'
 if log.stat().st_size>8*1024**2:fail('test log size bound')
 fixtures=sorted(set(re.findall(r'(?<![A-Za-z0-9_-])v3-(?:resources-)?[A-Za-z0-9_]{8}(?![A-Za-z0-9_-])',log.read_text())))
 for name in fixtures:tree(CANDIDATE/'.scratch'/name)
 # Failure is retained as FAILURE; no new ready/pass claim, no live study tree.
 failed=json.loads((FAILED/'receipt.json').read_text())
 if failed['ready'] is not False:fail('selected first-freeze outcome changed')
 if digest(FAILED/'result.json')!=failed['result_sha256']:fail('first-freeze result changed')
 for name,expected in failed['files'].items():
  if digest(FAILED/name)!=expected:fail('first-freeze receipt source changed: '+name)
 tree(FAILED)
 # Small installation records only; no source or cache sweep of current repo.
 tree(INSTALLATION)
 for name in ('repro/repro.py','repro/manifest-construction-v3.json','repro/README.md',
              'lean-toolchain','lake-manifest.json','lakefile.toml','MathGKM.lean'):
  add(ROOT/name,True)
 if sum(row['bytes'] for row in selected.values())>MAX_TOTAL:fail('aggregate512MiB bound')
 return selected,skipped,[str(JOB),str(FAILED)],fixtures


def metadata(selected,skipped,jobs,fixtures):
 return {'schema':'math-gkm.pressure007-source-evidence.v1',
  'scope':'Frozen007 operational metric source, exact completed15 tests, installation records and failed first freeze only; active fresh freeze0002 and research excluded',
  'checkpoint007_manifest_sha256':MANIFEST007,'approved_profile007_sha256':PROFILE007,
  'outerwatch7_sha256':WATCH7,'outerwatch7b_sha256':WATCH7B,
  'prior_archives':{
   'candidate_validation_sha256':'3ab351726d1b625831817043412a8e13d878436b5bac8d85b08fa86d5fb8e110',
   'installed006_validation_sha256':'bf9c11b0aba4351804febddf530839e5fe58f789b2e9beea3223ca7da319fd7e'},
  'path_mapping':{prefix:str(base) for base,prefix in MAPPINGS},
  'frozen_mapping_note':'OPS round0006-source-audit007 copy was absent. Archive portable operations/round0006-source-audit007 names map directly to the immutable candidate frozen subtree, with every307 source verified. No source copy or live source scan was required.',
  'reproduction_note':'Sources and exact pins/commands are retained; package caches and compiled outputs are regenerated. Original absolute host paths are provenance. Apply the separately published installed007 five-file overlay to installed006 preserved sources/public tree; preserve original top MathGKM.lean. This archive does not include an actual full verification of007: fresh freeze0002 owns that later result. No Markov theorem or formal Python-to-Lean equivalence is claimed.',
  'job_roots':jobs,'fixture_roots':fixtures,'excluded_directory_names':sorted(PRUNE),
  'members':selected,'excluded':skipped}


class HashedReader:
 def __init__(self,source):self.source=source;self.hash=hashlib.sha256()
 def read(self,n=-1):
  data=self.source.read(n);self.hash.update(data);return data

def write_archive(path,record):
 if path.exists():fail('archive already exists; never overwrite evidence')
 path.parent.mkdir(parents=True,exist_ok=True)
 try:
  with path.open('xb') as raw:
   with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
    with tarfile.open(fileobj=compressed,mode='w|') as archive:
     for name,member in sorted(record['members'].items()):
      source=Path(member['source_path'])
      if source.is_symlink() or stable(source.stat())!=tuple(member['stat_identity']):fail('source changed before archiving: '+str(source))
      info=tarfile.TarInfo(name);info.size=member['bytes'];info.mode=0o644;info.mtime=0
      with source.open('rb') as stream:
       reader=HashedReader(stream);archive.addfile(info,reader)
       if reader.hash.hexdigest()!=member['sha256'] or stable(os.fstat(stream.fileno()))!=tuple(member['stat_identity']):fail('source changed during archiving: '+str(source))
     body=(json.dumps(record,sort_keys=True,indent=2)+'\n').encode()
     info=tarfile.TarInfo('ARCHIVE_MANIFEST.json');info.size=len(body);info.mode=0o644;info.mtime=0
     archive.addfile(info,io.BytesIO(body))
 except BaseException:
  # Preserve a partial artifact for debugging, clearly distinguishable by the
  # absence of a success sidecar; never delete or replace any source evidence.
  raise
 return digest(path)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--inventory',type=Path,required=True)
 parser.add_argument('--execute',action='store_true')
 parser.add_argument('--archive',type=Path)
 args=parser.parse_args()
 if args.inventory.exists():fail('inventory already exists; choose a new finalization label')
 if args.execute and not args.archive:fail('--execute requires a NEW --archive path')
 selected,skipped,jobs,fixtures=sources()
 record=metadata(selected,skipped,jobs,fixtures)
 record['archiver_source_sha256']=digest(Path(__file__))
 if args.execute:record['archive_sha256']=write_archive(args.archive,record)
 args.inventory.parent.mkdir(parents=True,exist_ok=True)
 with args.inventory.open('x') as out:json.dump(record,out,indent=2,sort_keys=True);out.write('\n')
 print(json.dumps({'members':len(selected),'source_bytes':sum(m['bytes'] for m in selected.values()),'excluded':len(skipped),'jobs':len(jobs),'inventory':str(args.inventory),'archive_sha256':record.get('archive_sha256')}))

if __name__=='__main__':main()
