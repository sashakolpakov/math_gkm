# Independent resource review: frozen checkpoint 007

Reviewer: resource auditor (/root/disk_cleanup). Source-only review; no tests, Lean builds, cleanup, cache pressure or process signals executed by this reviewer.

## Identity and scoped verdict

Frozen manifest: evidence/construction-v3/source-audit-007/SOURCE_MANIFEST.json

SHA256: 3e39e2efd9a0f3fa092bfe4b0305cd836156adb7de37d11bf19bfc45f5374310

All 307 live manifest entries independently streamed and matched. The preceding 006 changed-file comparison, resources.py consumers, new profile and focused tests were inspected. The prepared nine selectors may run sequentially under approved outer watcher 7b, SHA256 5ede968f0d79a4fd192832822de6a3f266b2226dde2cd043b26f54ea8f3ff191. No concrete blocker to these finite bounded tests was found. This verdict is source clearance, not a claim that tests or a new installed preflight have passed.

## Actual operational changes

Darwin admission requires the unique whole-line integer 0..100 returned by /usr/bin/memory_pressure -Q, with a 30-percent admission floor and 25-percent dynamic floor. Missing, duplicate, malformed and failed required observations fail closed. The raw free+inactive+speculative VM-page estimate is recorded as an audit value or audit failure and cannot substitute for or veto the required Darwin percentage. No percentage-to-allocatable-byte conversion is made.

Native birth-bound charged phys_footprint remains 4 GiB sustained / 5 GiB hard, with an independent 8 GiB aggregate RSS ceiling. Disk admission/dynamic floors remain 8/5 GiB. Linux retains required MemAvailable admission/dynamic floors of 8/5 GiB and historical RSS4/5. Existing process ownership, direct-child cleanup, native failure behavior, timeout, concurrency and output/growth limits are unchanged. Caller percentage overrides must be finite non-boolean numbers in (0,100] and may only raise the default floors.

The profile is config/darwin-memory-profile-007.json, SHA256 fa7318100cea3a6bd4f06f96a2dd87249bb18339a9d259333ac3f40ac5c9411a. Its provenance identifies the root-approved prospective change and preserves the prior 006 profile and failed freeze. Resources.profile_identity verifies this exact profile hash.

## Focused coverage inspected

The seven Pressure007 tests cover admission30/29, dynamic25/24, malformed/duplicate/out-of-range/noninteger/failed observer output, low and failed raw VM audit observations, unchanged Linux missing/low byte rules, unchanged disk floors on both platforms, and harden-only percentage overrides plus bool/nonfinite rejection. The two migrated fixture modules stub the newly required observation while retaining prior actual resource semantics. The prepared nine selectors also retain native-metric, arbitrary-EPERM, process-limit, no-cap-increase and monitor-failure regressions. These are inspected test intentions, not executed results.

## Meaning and limitations of the Darwin observation

The official Apple memory_pressure implementation obtains the reported free percentage through memorystatus_get_level; XNU returns its kernel memorystatus_level counter. XNU VM accounting computes that level from kernel available pages, distinct from its pressure-state enum. The OS percentage is an engineering capacity observation; it is neither a literal count of untouched RAM nor a guarantee that a proposed allocation cannot trigger pressure. The independent per-tree native/RSS bounds, process and disk bounds remain required. Exact byte thresholds are not silently lowered further, and raw VM bytes remain visible for audit.

Primary sources:

- https://raw.githubusercontent.com/apple-oss-distributions/system_cmds/main/memory_pressure/memory_pressure.c
- https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/kern/kern_memorystatus.c
- https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/osfmk/vm/vm_pageout.c

No unconditional OOM safety, arbitrary detached-process containment, mathematical theorem admission, formal equivalence of Python to the Lean construction, cold portable rebuild, or Markov result is asserted by this operational source review. Root and builder own actual tests, installation, the fresh study freeze and publication.
