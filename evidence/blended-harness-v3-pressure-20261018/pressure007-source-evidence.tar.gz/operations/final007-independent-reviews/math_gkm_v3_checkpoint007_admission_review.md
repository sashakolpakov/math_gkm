# Checkpoint007 narrow mathematical/source scope review

UTC 2026-10-18T19:11:08.709907+00:00

Manifest `evidence/construction-v3/source-audit-007/SOURCE_MANIFEST.json`.
SHA256 `3e39e2efd9a0f3fa092bfe4b0305cd836156adb7de37d11bf19bfc45f5374310`.
Independently verified all307 frozen copies AND current listed files; no removals versus006. Prior006 manifest remains exactly `47757e16d92b964d58af75538e83c40d7956f6d3a94832a6feb37075dd983c8f`. Its addition as an entry in007 is provenance, not a rewrite.

**Verdict: approved for bounded focused tests**, subject to separate resource review. No mathematical-scope blocker. No build, test, installation or research invocation by reviewer.

Only substantive changes are resources.py, config/darwin-memory-profile-007.json, new tests/test_darwin_pressure007.py, and affected resource fixtures in test_capacity_repair005.py/test_construction_v3_repair004.py. Other new entries are audit, profile-decision, source-freeze and prior-evidence metadata. Every Lean, root proposition, premise/closure inspector, context binder, declaration consumer, residual DAG, discovery-handoff and completion file is byte-identical to006.

Darwin's required operational signal is the actual unique integer System-wide memory free percentage from memory_pressure -Q. Admission/dynamic thresholds are30/25percent. Missing/ambiguous/out-of-range observation fails closed. Raw VM estimate or its failure is recorded for audit only; it does not decide admission/dynamic limits and is never converted to guaranteed allocatable bytes. Linux keeps MemAvailable byte floors. Native charged-footprint4/5GiB, absolute RSS8GiB, disks8/5GiB and other bounds remain unchanged. This is a resource observation change, not a new mathematical implication or assumption.

The prior successful006 installed preflight and subsequent failed006 freeze retain their exact actual scope. They are not replayed or relabeled007 acceptance. No study arm initialized in that failed freeze, per retained evidence; the fresh study remains a separate operation with the same independently chosen tasks.

The operator installer is regeneratable against this final accepted manifest and its review, adding007 config and tests while preserving all already installed/history Lean, top aggregate and dependency pins. No installer change or execution is required from this reviewer. Regenerate the final plan rather than applying an earlier006 inventory hash.
