"""Supervisor-only operational bounds around one independent constructor invocation.
No mathematical research or harness implementation. Prospective supervisor-owned
Darwin profile: OS-reported percentage30/25, native footprint4/5GiB and RSS8GiB.
RSS and native charged footprint are distinct accounting measures. This profile
was authorized after a bounded native-memory calibration; completion is unproved.
No worker-facing argument or environment variable can select or increase limits.
"""
from pathlib import Path
import argparse, ctypes, json, os, re, shutil, signal, stat, subprocess, sys, time

# Darwin identity layout from Apple XNU bsd/sys/proc_info.h (PROC_PIDTBSDINFO).
# https://github.com/apple-oss-distributions/xnu/blob/main/bsd/sys/proc_info.h
class BSDInfo(ctypes.Structure):
 _fields_=[(name,ctypes.c_uint32) for name in ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','reserved')]+[('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[(name,ctypes.c_uint32) for name in ('nfiles','pgid','pjobc','e_tdev','e_tpgid')]+[('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]
LIBPROC=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
LIBPROC.proc_pidinfo.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int]
LIBPROC.proc_pidinfo.restype=ctypes.c_int

# Public macOS26.5 SDK sys/resource.h, rusage_info_v4: 296B, footprint offset72,
# lifetime peak offset240. Same ABI was checked on self and the pinned Lean
# process in the retained calibration, not inferred from ps RSS.
V4_FIELDS=('user_time system_time pkg_idle_wkups interrupt_wkups pageins wired_size '
 'resident_size phys_footprint proc_start_abstime proc_exit_abstime child_user_time '
 'child_system_time child_pkg_idle_wkups child_interrupt_wkups child_pageins '
 'child_elapsed_abstime diskio_bytesread diskio_byteswritten cpu_time_qos_default '
 'cpu_time_qos_maintenance cpu_time_qos_background cpu_time_qos_utility '
 'cpu_time_qos_legacy cpu_time_qos_user_initiated cpu_time_qos_user_interactive '
 'billed_system_time serviced_system_time logical_writes lifetime_max_phys_footprint '
 'instructions cycles billed_energy serviced_energy interval_max_phys_footprint runnable_time').split()
class UsageV4(ctypes.Structure):
 _fields_=[('ri_uuid',ctypes.c_uint8*16)]+[('ri_'+name,ctypes.c_uint64) for name in V4_FIELDS]
if (ctypes.sizeof(BSDInfo)!=136 or ctypes.sizeof(UsageV4)!=296
    or UsageV4.ri_phys_footprint.offset!=72
    or UsageV4.ri_lifetime_max_phys_footprint.offset!=240):
 raise RuntimeError('unreviewed native process/footprint ABI')
LIBPROC.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p]
LIBPROC.proc_pid_rusage.restype=ctypes.c_int

def process_info(pid):
 info=BSDInfo()
 ctypes.set_errno(0)
 n=LIBPROC.proc_pidinfo(pid,3,1,ctypes.byref(info),ctypes.sizeof(info))
 if n!=ctypes.sizeof(info):
  if ctypes.get_errno() in (3,):return None
  raise OSError(ctypes.get_errno(),'native process birth monitor unavailable for PID '+str(pid))
 if info.pid!=pid:raise RuntimeError('invalid native process PID returned for '+str(pid))
 return {'birth':(int(info.start_sec),int(info.start_usec)),'ppid':int(info.ppid),'pgid':int(info.pgid),'status':int(info.status)}

def identity(pid):
 info=process_info(pid)
 return info['birth'] if info else None

def native_usage(pid,expected_birth):
 # A counter is accepted only between two native birth confirmations. ESRCH
 # with an independent native absence is a completed process, not a zero
 # estimate for an unobserved live process. Other counter failures stop work.
 before=process_info(pid)
 if before is None:return None
 if before['birth']!=expected_birth:
  raise RuntimeError('footprint process birth changed for PID '+str(pid))
 if before['status']==5:return None  # independently verified exited zombie
 data=UsageV4();ctypes.set_errno(0)
 rc=LIBPROC.proc_pid_rusage(pid,4,ctypes.byref(data));error=ctypes.get_errno()
 if rc:
  if error==3:
   exited=process_info(pid)
   if exited is None or (exited['birth']==expected_birth and exited['status']==5):return None
  raise OSError(error,'native footprint monitor unavailable for PID '+str(pid))
 after=process_info(pid)
 if after is None:return None
 if after['birth']!=expected_birth:
  raise RuntimeError('footprint process birth changed during sample for PID '+str(pid))
 if not data.ri_proc_start_abstime:
  raise RuntimeError('invalid native footprint start time for PID '+str(pid))
 return {'pid':pid,'birth':list(expected_birth),
         'resident_bytes':int(data.ri_resident_size),
         'phys_footprint_bytes':int(data.ri_phys_footprint),
         'lifetime_max_phys_footprint_bytes':int(data.ri_lifetime_max_phys_footprint),
         'wired_bytes':int(data.ri_wired_size),
         'start_abstime':int(data.ri_proc_start_abstime)}

# PUBLIC PROC_PIDT_SHORTBSDINFO has no same-effective-user restriction.
class ShortBSDInfo(ctypes.Structure):
 _fields_=[(n,ctypes.c_uint32) for n in ('pid','ppid','pgid','status')]+[('comm',ctypes.c_char*16)]+[(n,ctypes.c_uint32) for n in ('flags','uid','gid','ruid','rgid','svuid','svgid','reserved')]
LIBPROC.proc_pidpath.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32]
LIBPROC.proc_pidpath.restype=ctypes.c_int

def privileged_ps_observer(pid,parent,expected_parent_birth):
 # Narrow exception established by the retained Darwin host probe: only the
 # immutable setuid system /bin/ps observer, never arbitrary EPERM children.
 info=ShortBSDInfo();ctypes.set_errno(0)
 n=LIBPROC.proc_pidinfo(pid,13,1,ctypes.byref(info),ctypes.sizeof(info))
 if n!=ctypes.sizeof(info):
  if ctypes.get_errno()==3:return None  # already gone, never adopted
  raise RuntimeError('short observer identity unavailable for PID '+str(pid))
 if info.status==5:return None  # exited observer uses no resources
 path=ctypes.create_string_buffer(4096)
 length=LIBPROC.proc_pidpath(pid,path,len(path))
 if length<=0:
  if ctypes.get_errno()==3:return None
  raise RuntimeError('observer executable path unavailable for PID '+str(pid))
 exe=path.value.decode('utf-8','strict');mode=os.stat('/bin/ps')
 if not (info.pid==pid and info.ppid==parent and info.uid==0 and info.ruid==os.getuid()
         and exe=='/bin/ps' and mode.st_uid==0 and mode.st_mode&stat.S_ISUID):
  raise RuntimeError('unapproved privileged descendant PID '+str(pid)+' executable '+exe)
 pinfo=process_info(parent)
 if not pinfo or pinfo['birth']!=expected_parent_birth:
  raise RuntimeError('observer parent identity changed for PID '+str(pid))
 return {'pid':pid,'ppid':parent,'pgid':int(info.pgid),'euid':int(info.uid),'ruid':int(info.ruid),'executable':exe}

GIB=1024**3
ROOT=Path('/Users/sasha/math_gkm')
CANDIDATE=ROOT/'.scratch/strategy-v3-blended-20261018'
OPS=ROOT/'.bootstrap/construction-v3-20261018'
PROFILE_ID='darwin-ospercent30-25-footprint4-5GiB-rss8GiB-supervisor-20261018'
PROFILE={'identity':PROFILE_ID,'platform':'Darwin','footprint_sustained_bytes':4*GIB,
 'footprint_hard_bytes':5*GIB,'footprint_sustained_seconds':3,
 'rss_absolute_hard_bytes':8*GIB,'os_reported_percentage_admission':30,
 'os_reported_percentage_dynamic':25,'raw_vm_estimate_policy':'audit-only; never an admission or abort gate',
 'sample_seconds':1,
 'authority':'prospective root approval; no autonomous worker cap increase',
 'calibration_source_sha256':'47204d350e74afdda79a317daad88a67d91579965419105f99f0d2e340e3e574'}

def processes():
 r=subprocess.run(['/bin/ps','-axo','pid=,ppid=,rss='],capture_output=True,text=True,timeout=3)
 if r.returncode: raise RuntimeError('process monitor unavailable: '+r.stderr[:200])
 table={}
 for line in r.stdout.splitlines():
  x=line.split()
  if len(x)==3: table[int(x[0])]=(int(x[1]),int(x[2])*1024)
 if not table or os.getpid() not in table:raise RuntimeError('empty/incomplete process observation')
 return table

def discover(table, seen, known_groups, helper_started):
 # ps provides candidate PIDs/RSS only. Ancestry is admitted using a CURRENT
 # native PPID plus birth-confirmed parent; never overwrite a prior birth.
 owned={};helpers={}
 for old in list(helper_started):
  if old not in table:del helper_started[old]
 for pid,birth in seen.items():
  info=process_info(pid)
  if info and info['birth']==birth:owned[pid]=info
 for _ in range(len(table)+1):
  added=False
  for pid in table:
   if pid in owned or pid in seen or table[pid][0] not in owned:continue
   try:info=process_info(pid)
   except PermissionError:
    parent=table[pid][0]
    helper=privileged_ps_observer(pid,parent,seen[parent])
    if helper is not None:
     since=helper_started.setdefault(pid,time.monotonic())
     helper.update(rss=table[pid][1],observed_seconds=time.monotonic()-since)
     if helper['rss']>64*1024**2 or helper['observed_seconds']>3:raise RuntimeError('privileged OS observer exceeded narrow bound')
     helpers[pid]=helper
    continue
   if not info or info['ppid'] not in owned:continue
   parent=process_info(info['ppid'])
   if not parent or parent['birth']!=seen[info['ppid']]:continue
   seen[pid]=info['birth'];owned[pid]=info;known_groups.add(info['pgid']);added=True
  if not added:break
 if len(helpers)>4:raise RuntimeError('privileged observer concurrency bound')
 return owned,helpers

def bytes_used():
 size=0
 def scan_error(error):raise error
 for directory, dirs, files in os.walk(CANDIDATE,followlinks=False,onerror=scan_error):
  dirs[:]=[d for d in dirs if not (Path(directory)/d).is_symlink()]
  for name in files:
   p=Path(directory)/name
   if not p.is_symlink():
    try:size+=p.stat().st_size
    except FileNotFoundError:pass
 return size

def memory_free_percent():
 r=subprocess.run(['/usr/bin/memory_pressure','-Q'],capture_output=True,text=True,timeout=3)
 if r.returncode:raise RuntimeError('system memory-pressure monitor unavailable')
 observations=[line for line in r.stdout.splitlines() if 'System-wide memory free percentage' in line]
 if len(observations)!=1:raise RuntimeError('missing or duplicate OS-reported memory percentage')
 m=re.fullmatch(r'System-wide memory free percentage:\s*([0-9]+)%',observations[0])
 if not m:raise RuntimeError('malformed OS-reported memory percentage')
 value=int(m.group(1))
 if not 0<=value<=100:raise RuntimeError('invalid OS-reported memory percentage')
 return value

def available_memory_observation():
 # Raw free/inactive/speculative counts remain audit data. This homemade byte
 # estimate is NOT Apple's kernel pressure percentage or an allocation promise.
 r=subprocess.run(['/usr/bin/vm_stat'],capture_output=True,text=True,timeout=3)
 if r.returncode:raise RuntimeError('raw VM audit observer unavailable')
 page=re.search(r'page size of (\d+) bytes',r.stdout)
 counts={k:int(v) for k,v in re.findall(r'^([^:\n]+):\s+(\d+)\.',r.stdout,re.M)}
 names=('Pages free','Pages inactive','Pages speculative')
 if not page or not all(k in counts for k in names):
  raise RuntimeError('unrecognized raw VM audit output')
 page_size=int(page[1])
 return {'available_memory_estimate':sum(counts[k] for k in names)*page_size,
         'raw_vm_counts':counts,'raw_vm_page_size':page_size,'raw_vm_audit_error':None}

def available_memory_estimate():
 # Backward-compatible read-only observer; main never gates on this value.
 return available_memory_observation()['available_memory_estimate']

def available_memory_audit():
 try:return available_memory_observation()
 except Exception as exc:
  return {'available_memory_estimate':None,'raw_vm_counts':None,
          'raw_vm_page_size':None,'raw_vm_audit_error':type(exc).__name__+': '+str(exc)}

def live_group_members(pgid):
 # Darwin may return EPERM for a group containing only zombies. Never infer
 # that from the signal error alone: require an independent full ps sample.
 r=subprocess.run(['/bin/ps','-axo','pid=,pgid=,stat='],capture_output=True,text=True,timeout=3)
 if r.returncode or not r.stdout.strip():raise RuntimeError('live group observation unavailable')
 rows=[]; observed_self=False
 for line in r.stdout.splitlines():
  fields=line.split()
  if len(fields)!=3:raise RuntimeError('live group observation malformed')
  pid,group=map(int,fields[:2]);state=fields[2]
  if pid==os.getpid():observed_self=True
  if group==pgid and not state.startswith('Z'):rows.append({'pid':pid,'state':state})
 if not observed_self:raise RuntimeError('live group observation incomplete')
 return rows

def signal_owned_group(pgid,sig,cleanup_errors,empty_groups):
 try:os.killpg(pgid,sig)
 except ProcessLookupError:pass
 except PermissionError as exc:
  try:
   members=live_group_members(pgid)
   if members:cleanup_errors.append('permission denied for live owned group: '+str(pgid)+' '+repr(members))
   else:empty_groups.append({'pgid':pgid,'signal':int(sig),'reason':'EPERM with independently observed no live group members'})
  except BaseException as obs:cleanup_errors.append('cannot reconcile group permission failure: '+str(obs))
 except BaseException as exc:cleanup_errors.append('owned group cleanup failed: '+str(exc))

def main():
 a=argparse.ArgumentParser(); a.add_argument('--label',required=True); a.add_argument('--seconds',type=int,default=1800); a.add_argument('command',nargs=argparse.REMAINDER); args=a.parse_args()
 if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',args.label):raise ValueError('simple unique label required')
 if not 1<=args.seconds<=3600:raise ValueError('bounded wall allowance1..3600s required')
 if args.command[:1]==['--']:args.command=args.command[1:]
 if not args.command:raise ValueError('explicit bounded test command required')
 signal.signal(signal.SIGCHLD,signal.SIG_DFL)  # keep our direct child waitable/unreaped
 log=OPS/f'testwatch-{args.label}.jsonl'; summary=OPS/f'testwatch-{args.label}.json'
 if log.exists() or summary.exists(): raise RuntimeError('operational receipt exists; choose new round')
 if (OPS/'RESOURCE_CLEANUP_HOLD.json').exists():raise RuntimeError('unresolved prior cleanup hold; independent inspection required')
 if shutil.disk_usage(ROOT).free<8*GIB:raise RuntimeError('constructor refused: less than8GiB free')
 if memory_free_percent()<30:raise RuntimeError('constructor refused: less than30% system memory free')
 if sys.platform!='darwin':raise RuntimeError('this prospective supervisor profile is Darwin-only')
 own_birth=identity(os.getpid())
 if own_birth is None or native_usage(os.getpid(),own_birth) is None:raise RuntimeError('constructor refused: own native birth/footprint unavailable')
 initial=bytes_used(); started=time.monotonic(); seen={}; helper_started={}; root_birth=None; known_groups=set(); p=None; error=None; cleanup_errors=[]; empty_groups=[]; peak=0; peak_footprint=0; peak_count=0; low_samples=0; footprint_over_since=None; max_growth=0
 try:
  command=args.command
  with (OPS/f'testwatch-{args.label}.stdout').open('xb') as out:
   env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
   p=subprocess.Popen(command,cwd=CANDIDATE,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
   known_groups.add(p.pid)
   root_birth=identity(p.pid)
   if root_birth is None:raise RuntimeError('constructor root vanished before birth identity capture')
   seen[p.pid]=root_birth
   os.set_blocking(p.stdout.fileno(),False)
   written=0
   with log.open('x') as stream:
    while True:
     # Stream with pipe backpressure and a fixed retained-output cap.
     while True:
      try:data=os.read(p.stdout.fileno(),65536)
      except BlockingIOError:break
      if not data:break
      if written+len(data)>8*1024*1024:raise RuntimeError('outer retained-output8MiB limit')
      out.write(data);out.flush();written+=len(data)
     # Do not reap the direct child before group cleanup: its reserved PID
     # then keeps the original private PGID valid even if its parent exits
     # before the first sample, leaving an ordinary orphan in that group.
     leader=process_info(p.pid)
     if leader is None:raise RuntimeError('unreaped child identity unexpectedly unavailable')
     if leader['birth']!=root_birth:raise RuntimeError('unreaped child identity changed')
     if leader['status']==5:break  # Darwin SZOMB; p.wait only after cleanup.
     table=processes()
     owned,helpers=discover(table,seen,known_groups,helper_started)
     helper_rss=sum(x['rss'] for x in helpers.values())
     rss=sum(table[x][1] for x in owned if x in table)+helper_rss
     native_samples=[]
     for pid,info in owned.items():
      usage=native_usage(pid,info['birth'])
      if usage is not None:native_samples.append(usage)
     native_footprint=sum(x['phys_footprint_bytes'] for x in native_samples)
     footprint=native_footprint+helper_rss  # inaccessible strict ps observers charged conservatively by RSS
     count=len(owned)+len(helpers);peak=max(peak,rss);peak_footprint=max(peak_footprint,footprint);peak_count=max(peak_count,count)
     free=shutil.disk_usage(ROOT).free; growth=bytes_used()-initial;max_growth=max(max_growth,growth); memfree=memory_free_percent();vm_audit=available_memory_audit();now=time.monotonic()
     sample={'profile_identity':PROFILE_ID,'elapsed':round(now-started,2),'owned':len(owned),'bounded_privileged_observers':list(helpers.values()),'tree_rss':rss,'native_phys_footprint':native_footprint,'helper_rss_footprint_charge':helper_rss,'charged_footprint':footprint,'native_usage_samples':native_samples,'free_disk':free,'candidate_growth':growth,'system_memory_free_percent':memfree,'available_memory_estimate':vm_audit['available_memory_estimate'],'raw_vm_counts':vm_audit['raw_vm_counts'],'raw_vm_page_size':vm_audit['raw_vm_page_size'],'raw_vm_audit_error':vm_audit['raw_vm_audit_error']}
     stream.write(json.dumps(sample)+'\n');stream.flush()
     if footprint>4*GIB:
      if footprint_over_since is None:footprint_over_since=now
     else:footprint_over_since=None
     low_samples=low_samples+1 if memfree<25 else 0
     if rss>8*GIB:raise RuntimeError('owned constructor absolute RSS8GiB limit')
     if footprint>5*GIB:raise RuntimeError('owned constructor native footprint5GiB hard limit')
     if footprint_over_since is not None and now-footprint_over_since>=3:raise RuntimeError('owned constructor native footprint4GiB sustained3s limit')
     if count>24:raise RuntimeError('owned constructor process-count limit')
     if free<5*GIB:raise RuntimeError('minimum-free-disk limit')
     if growth>GIB:raise RuntimeError('candidate1GiB growth limit')
     if low_samples>=3:raise RuntimeError('OS-reported memory percentage below25% for3 samples')
     if time.monotonic()-started>args.seconds+15:raise TimeoutError('constructor outer wall limit')
     time.sleep(1)
 except BaseException as exc:error=type(exc).__name__+': '+str(exc)
 finally:
  if p:
   # A failed broad ps observation does not bypass birth-checked cleanup.
   # libproc provides an independent per-process birth identity for fallback.
   try:
    table=processes()
    discover(table,seen,known_groups,helper_started)
   except BaseException as exc:cleanup_errors.append('process-table cleanup fallback: '+str(exc))
   for sig in (signal.SIGTERM,signal.SIGKILL):
    live_groups=set()
    for pid,birth in list(seen.items()):
     try:
      info=process_info(pid)
      if not info or info['birth']!=birth:continue
      pgid=info['pgid']
      if pgid in known_groups and pgid!=os.getpgrp():live_groups.add(pgid)
     except ProcessLookupError:pass
     except BaseException as exc:cleanup_errors.append('identity confirmation failed: '+str(exc))
    # Signal a process group only while a birth-confirmed owned member still
    # belongs to its previously recorded private group. This also reaps unseen
    # descendants in that group; no unrelated repository process is selected.
    for pgid in live_groups:signal_owned_group(pgid,sig,cleanup_errors,empty_groups)
    for pid,birth in reversed(list(seen.items())):
     try:
      info=process_info(pid)
      if info and info['birth']==birth and info['status']!=5:os.kill(pid,sig)
     except ProcessLookupError:pass
     except BaseException as exc:cleanup_errors.append('owned process cleanup failed: '+str(exc))
    if sig==signal.SIGTERM:time.sleep(1)
   # Our direct child has not been polled or waited above, so its PID is
   # still reserved even as a zombie. Its private initial group therefore
   # remains ours; clean ordinary unseen orphans before releasing that PID.
   signal_owned_group(p.pid,signal.SIGKILL,cleanup_errors,empty_groups)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:
    # p is our unreaped child: its PID cannot have been reused.
    p.kill();p.wait()
   if cleanup_errors:
    error=error or 'cleanup observation incomplete; refuse next launch pending review'
    (OPS/'RESOURCE_CLEANUP_HOLD.json').write_text(json.dumps({'label':args.label,'errors':cleanup_errors,'seen_births':seen,'action':'Independent owned-process inspection required before removing this hold'},indent=2)+'\n')
  result={'error':error,'exit_code':p.returncode if p else None,'elapsed':round(time.monotonic()-started,3),'resource_profile':PROFILE,'peak_owned_rss':peak,'peak_owned_charged_footprint':peak_footprint,'peak_owned_processes':peak_count,'max_candidate_growth':max_growth,'free_disk_final':shutil.disk_usage(ROOT).free,'cleanup_errors':cleanup_errors,'empty_group_signal_observations':empty_groups,'ownership':'observed descendants bound to native birth seconds+microseconds; verified private groups; observation and signal are not atomic','rss_scope':'sum of native-owned RSS plus strictly verified bounded privileged /bin/ps observers; shared pages may count twice','footprint_scope':'sum of current birth-bound native phys_footprint plus conservative RSS charge for strict privileged ps helpers; native failures for live owned processes fail closed','privileged_observer_policy':'public short BSDINFO current parent/UIDs + exact kernel executable /bin/ps + immutable root setuid file;64MiB/3seconds/max4; never general EPERM suppression','command':command,'scope':str(CANDIDATE),'label':args.label,'monitor_failures':'fail closed; no hard OOM guarantee if OS monitoring unavailable'}
  summary.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 return 0 if not error and p and p.returncode==0 else 1
if __name__=='__main__':sys.exit(main())
