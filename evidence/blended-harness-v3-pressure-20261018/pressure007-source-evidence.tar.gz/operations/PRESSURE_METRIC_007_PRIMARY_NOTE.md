# Darwin percentage observation: operational interpretation007

Apple memory_pressure -Q obtains the reported free percentage through memorystatus_get_level. XNU returns its kernel memorystatus_level counter; VM accounting computes that level from kernel available pages, independently of the pressure-state enum. The percentage therefore serves as a system capacity observation, not literal untouched RAM or a guarantee of allocatable bytes. The raw free+inactive+speculative estimate is separately visible as audit data or audit failure.

Primary sources inspected before007:

- https://raw.githubusercontent.com/apple-oss-distributions/system_cmds/main/memory_pressure/memory_pressure.c
- https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/kern/kern_memorystatus.c
- https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/osfmk/vm/vm_pageout.c
- Installed macOS memory_pressure(1) manual (read-only; no memory pressure generation performed).

The preceding first freeze was safely refused by a raw7GiB memory-admission estimate after4 compile and2 kernel-replay operations. No research arm was initialized. A contemporaneous independent read-only observation recorded raw7,780,696,064 bytes, memory_pressure61 percent, kern.memorystatus_level61, pressure enum1 and zero swap. Different accounting explains the signals' divergence; it does not establish that all file-backed bytes are immediately reclaimable.

Root prospectively approved required Darwin OS percentage floors30 admission/25 running, raw VM audit-only, preserving independent native footprint4/5GiB, absolute RSS8GiB, disk8/5GiB, process/output/time/ownership bounds and Linux required MemAvailable8/5GiB. Required missing/malformed/duplicate percentage data fails closed. Limits may be hardened, not weakened by workers. No OOM guarantee is asserted. The exact007 profile and both independent reviews retain the source binding and limitations. Fresh freeze0002's own actual validation is separate future evidence; this archive preserves the earlier failed freeze without changing its outcome.
