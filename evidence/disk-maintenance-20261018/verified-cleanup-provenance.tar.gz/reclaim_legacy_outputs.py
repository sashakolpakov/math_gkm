#!/usr/bin/env python3
"""Reclaim only reproducible, source-published Lean outputs and inactive duplicate copies."""
from pathlib import Path
import hashlib,json,os,subprocess,time,sys,collections
ROOT=Path('/Users/sasha/math_gkm');os.chdir(ROOT)
OUT=ROOT/'.bootstrap/disk-maintenance-20261018'
PUBLIC=ROOT/'.git/publication/export-2170.git'
DIRS=sorted(str(p) for p in Path('evidence').glob('markov-*') if p.is_dir())
def sh(args): return subprocess.check_output(args)
def digest(p,algorithm='sha256',git=False):
 h=hashlib.new(algorithm)
 if git: h.update(('blob '+str(p.stat().st_size)+'\0').encode())
 with p.open('rb') as f:
  while chunk:=f.read(1024*1024): h.update(chunk)
 return h.hexdigest()
def tree(public=False):
 cmd=['git']+(['--git-dir='+str(PUBLIC)] if public else [])
 process=subprocess.Popen(cmd+['ls-tree','-r','-z','main' if public else 'HEAD','--','evidence','research','lean-toolchain','lake-manifest.json','lakefile.toml'],stdout=subprocess.PIPE)
 result={}; tail=b''
 while chunk:=process.stdout.read(1024*1024):
  data=tail+chunk;parts=data.split(b'\0');tail=parts.pop()
  for entry in parts:
   metadata,name=entry.split(b'\t',1);result[os.fsdecode(name)]=metadata.decode().split()[2]
 if process.wait()!=0: raise RuntimeError('git tree failed')
 return result
local,public=tree(),tree(True);pin_cache={}
def pinned(path):
 if path not in pin_cache:
  p=ROOT/path
  pin_cache[path]=p.is_file() and not p.is_symlink() and local.get(path)==public.get(path)==digest(p,'sha1',True)
 return pin_cache[path]
pins=['lean-toolchain','lake-manifest.json','lakefile.toml']
for pin in pins:
 if not pinned(pin): raise SystemExit('Pin not published: '+pin)
proven={};skipped=collections.Counter();source_hashes={}
for d in DIRS:
 for receipt in (ROOT/d).glob('*.json'):
  try:
   if receipt.stat().st_size>16*1024*1024: skipped['large_json_unexamined']+=1;continue
   r=json.loads(receipt.read_text())
   if not isinstance(r,dict):continue
   command=r.get('command',[])
   if r.get('returncode')!=0 or not isinstance(command,list) or '-o' not in command:continue
   target=Path(command[command.index('-o')+1]);target=target if target.is_absolute() else ROOT/target
   rel=str(target.relative_to(ROOT))
   if target.parent!=ROOT/d or target.suffix!='.olean' or rel in local:continue
   receipt_rel=str(receipt.relative_to(ROOT))
   if not pinned(receipt_rel):skipped['receipt_not_exactly_published']+=1;continue
   sources=[receipt.with_name(receipt.name.removeprefix('run-')).with_suffix('.lean')]
   if command and isinstance(command[-1],str) and command[-1].endswith('.lean'):
    p=Path(command[-1]);sources.append(p if p.is_absolute() else ROOT/p)
   valid=None
   for source in sources:
    try:source_rel=str(source.relative_to(ROOT))
    except ValueError:continue
    if not pinned(source_rel):continue
    if source_rel not in source_hashes:source_hashes[source_rel]=digest(source)
    sha=source_hashes[source_rel];mh=r.get('modules',{})
    if sha!=r.get('sha256') and not(isinstance(mh,dict) and sha in mh.values()):continue
    valid=(source_rel,sha);break
   if valid is None:skipped['published_source_hash_match_absent']+=1;continue
   proven[rel]={'source':valid[0],'source_sha256':valid[1],'source_git_blob':local[valid[0]],'receipt':receipt_rel,'receipt_sha256':digest(receipt),'receipt_git_blob':local[receipt_rel],'command':command}
  except (OSError,ValueError,KeyError,json.JSONDecodeError):skipped['malformed_or_other_json']+=1
plan={'schema':'math-gkm-verified-legacy-output-cleanup/v2','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'local_head':sh(['git','rev-parse','HEAD']).decode().strip(),'public_head':sh(['git','--git-dir='+str(PUBLIC),'rev-parse','main']).decode().strip(),'dependency_pins':{p:local[p] for p in pins},'free_bytes_before':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,'proven_output_count':len(proven),'skipped_counts':dict(skipped),'proven_outputs':proven,'preserved':'All .lean, metadata, research logs, failed launches, Git objects and active construction. Old untracked compiled .olean alone selected; source and recipe exact in both local and public Git.'}
(OUT/'legacy-provenance.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'proven_output_count':len(proven),'skipped_counts':dict(skipped),'free_bytes_before':plan['free_bytes_before']}),flush=True)
if '--apply' not in sys.argv:raise SystemExit(0)
counts=collections.Counter();logical=collections.Counter();allocated=collections.Counter();objects={};failures=[]
log=(OUT/'legacy-removed.jsonl').open('a')
def remove(p,category,provenance,expected_hash=None):
 if not p.is_file() or p.is_symlink():return
 rel=str(p.relative_to(ROOT))
 if rel in local:failures.append({'path':rel,'reason':'tracked'});return
 st=p.stat()
 if expected_hash and digest(p)!=expected_hash:
  failures.append({'path':rel,'reason':'content hash mismatch'});return
 st2=p.stat()
 if (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)!=(st2.st_dev,st2.st_ino,st2.st_size,st2.st_mtime_ns):
  failures.append({'path':rel,'reason':'changed during verification'});return
 record={'path':rel,'bytes':st.st_size,'allocated_bytes':st.st_blocks*512,'hardlinks':st.st_nlink,'category':category,'provenance':provenance,'sha256':expected_hash,'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 log.write(json.dumps(record)+'\n');log.flush();os.fsync(log.fileno());p.unlink()
 counts[category]+=1;logical[category]+=st.st_size;allocated[category]+=st.st_blocks*512
for rel in proven:remove(ROOT/rel,'evidence_compiled',{'published_build':proven[rel]['receipt']})
for worker in sorted((ROOT/'.control/markov/workers').iterdir()):
 receipt=worker/'receipt.json'
 if not receipt.is_file() or receipt.stat().st_size>16*1024*1024:continue
 try:r=json.loads(receipt.read_text())
 except (ValueError,OSError):continue
 changes=r.get('changes',{})
 if not isinstance(changes,dict):continue
 for rel,change in changes.items():
  if rel not in proven or not isinstance(change,dict):continue
  sha=change.get('after')
  if not isinstance(sha,str) or len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha):continue
  p=worker/'artifacts'/rel
  if not p.is_file():continue
  provenance={'published_build':proven[rel]['receipt'],'worker_receipt':str(receipt.relative_to(ROOT)),'worker_receipt_sha256':digest(receipt),'logical_output':rel}
  remove(p,'inactive_worker_compiled',provenance,sha)
  objects[sha]=provenance
 print(json.dumps({'worker':worker.name,'removed_count':sum(counts.values()),'removed_logical_bytes':sum(logical.values())}),flush=True)
for sha,provenance in objects.items():remove(ROOT/'.control/markov/objects'/sha,'inactive_object_compiled',provenance,sha)
log.close()
result={k:v for k,v in plan.items() if k!='proven_outputs'}
result.update({'removed_counts':dict(counts),'removed_logical_bytes':dict(logical),'removed_allocated_accounting_bytes':dict(allocated),'total_removed_count':sum(counts.values()),'total_removed_logical_bytes':sum(logical.values()),'free_bytes_after':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,'failures':failures,'completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'measurement_note':'st_blocks accounting can double-count APFS clone extents. df/statvfs free-space difference measures actual observed system availability and may include unrelated concurrent activity.'})
(OUT/'legacy-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['removed_counts','total_removed_logical_bytes','free_bytes_after','failures']}),flush=True)
