#!/usr/bin/env python3
"""Delete only untracked old Lean outputs with source/build receipts in local and public Git."""
from pathlib import Path
import hashlib,json,os,subprocess,time,sys
ROOT=Path('/Users/sasha/math_gkm')
os.chdir(ROOT)
OUT=ROOT/'.bootstrap/disk-maintenance-20261018'
PUBLIC=ROOT/'.git/publication/export-2170.git'
DIRS=['evidence/markov-ae257c53','evidence/markov-8b851864','evidence/markov-00a02b28']
def run(args):
 return subprocess.check_output(args)
def tree(public=False):
 args=['git']+(['--git-dir='+str(PUBLIC)] if public else [])
 data=run(args+['ls-tree','-r','-z','main' if public else 'HEAD','--',*DIRS,'lean-toolchain','lake-manifest.json','lakefile.toml'])
 result={}
 for entry in data.split(b'\0'):
  if not entry: continue
  metadata,name=entry.split(b'\t',1)
  result[os.fsdecode(name)]=metadata.decode().split()[2]
 return result
local,public=tree(),tree(True)
def digest(p,algorithm='sha256',git=False):
 h=hashlib.new(algorithm)
 if git: h.update(('blob '+str(p.stat().st_size)+'\0').encode())
 with p.open('rb') as f:
  while chunk:=f.read(1024*1024): h.update(chunk)
 return h.hexdigest()
def pinned(path):
 p=ROOT/path
 return p.is_file() and local.get(path)==public.get(path)==digest(p,'sha1',True)
for pin in ['lean-toolchain','lake-manifest.json','lakefile.toml']:
 if not pinned(pin): raise SystemExit('Unpublished dependency pin: '+pin)
tracked=set(os.fsdecode(p) for p in run(['git','ls-files','-z','--',*DIRS]).split(b'\0') if p)
items=[]; skipped=[]; seen=set()
for d in DIRS:
 for receipt in sorted((ROOT/d).glob('*.json')):
  try:
   r=json.loads(receipt.read_text())
   if not isinstance(r,dict): continue
   command=r.get('command',[])
   if r.get('returncode')!=0 or '-o' not in command: continue
   target=Path(command[command.index('-o')+1])
   if not target.is_absolute(): target=ROOT/target
   target_rel=str(target.relative_to(ROOT))
   if target_rel in seen or target.parent!=ROOT/d or target.suffix!='.olean': continue
   if not target.is_file() or target.is_symlink(): continue
   if target_rel in tracked: continue
   source=receipt.with_name(receipt.name.removeprefix('run-')).with_suffix('.lean'); source_rel=str(source.relative_to(ROOT))
   receipt_rel=str(receipt.relative_to(ROOT))
   if not source.is_file() or source.is_symlink():
    skipped.append({'target':target_rel,'reason':'archived source absent'});continue
   source_hash=digest(source)
   module_hashes=r.get('modules',{})
   if not ((isinstance(module_hashes,dict) and source_hash in module_hashes.values()) or source_hash==r.get('sha256')):
    skipped.append({'target':target_rel,'reason':'source hash not bound by successful receipt'});continue
   if not pinned(source_rel) or not pinned(receipt_rel):
    skipped.append({'target':target_rel,'reason':'source or receipt differs from published and local Git'});continue
   st=target.stat()
   items.append({'path':target_rel,'bytes':st.st_size,'device':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'hardlinks':st.st_nlink,'source':source_rel,'source_sha256':source_hash,'source_git_blob':local[source_rel],'receipt':receipt_rel,'receipt_sha256':digest(receipt),'receipt_git_blob':local[receipt_rel],'original_command':command})
   seen.add(target_rel)
  except (ValueError,KeyError,OSError,json.JSONDecodeError) as e:
   skipped.append({'receipt':str(receipt.relative_to(ROOT)),'reason':str(e)})
plan={'schema':'math-gkm-verified-compiled-cleanup/v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'local_head':run(['git','rev-parse','HEAD']).decode().strip(),'published_head':run(['git','--git-dir='+str(PUBLIC),'rev-parse','main']).decode().strip(),'public_export':str(PUBLIC.relative_to(ROOT)),'free_bytes_before':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,'dependency_pins':{p:local[p] for p in ['lean-toolchain','lake-manifest.json','lakefile.toml']},'scope':DIRS,'plan_bytes':sum(i['bytes'] for i in items),'plan_count':len(items),'preserved':'Every source, successful build receipt, research record and Git object. Only untracked .olean named by matched receipts selected.','items':items,'skipped':skipped}
(OUT/'verified-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({k:plan[k] for k in ['local_head','published_head','free_bytes_before','plan_count','plan_bytes']},indent=2))
if '--apply' not in sys.argv: raise SystemExit(0)
removed=[]
with (OUT/'removed.jsonl').open('a') as log:
 for item in items:
  target=ROOT/item['path']; st=target.stat()
  if any(stval!=item[key] for stval,key in [(st.st_size,'bytes'),(st.st_dev,'device'),(st.st_ino,'inode'),(st.st_mtime_ns,'mtime_ns')]):
   raise SystemExit('Changed output; stopped before unlink: '+item['path'])
  record={**item,'removed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
  log.write(json.dumps(record)+'\n');log.flush();os.fsync(log.fileno())
  target.unlink();removed.append(item)
result={k:v for k,v in plan.items() if k not in ['items']}
result.update({'removed_count':len(removed),'removed_logical_bytes':sum(i['bytes'] for i in removed),'removed_single_link_bytes':sum(i['bytes'] for i in removed if i['hardlinks']==1),'free_bytes_after':os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,'completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['removed_count','removed_logical_bytes','removed_single_link_bytes','free_bytes_after']},indent=2))
