# Sequential operator source — HOLD, NOT AUTHORIZED TO RUN

The source `sequential_operator.py` was prepared and parsed only. Its SHA256 is `d6dce60f902ef71510a4024b2ba81e1d9b344c7854319c466b20fb42f614c4e0`. It has not been executed. Root reports the study freeze failed at a resource-admission check before both initial arm states existed. Preserve the failed `study` directory and receipts. Do not overwrite, retry, or run this source against it.

This version is intentionally bound to the original `study` child, contract, suite, protocol and implementation. A subsequently authorized fresh study or changed implementation needs a new reviewed launcher version and new immutable bindings. Do not edit this executed-history candidate silently. No official controllers, mathematical roles or additional validation jobs were started by the builder.

The source waits at most 1800 seconds for freeze's final `setup-cost.json` marker plus both initial states and seal; verifies the exact clean seed, equal budget identities and official implementation/dependency checks; then calls official foreground exploration followed by baseline, each once. It uses a separate sole-operator lock and exclusive BEGIN marker, retains PID/log/result and 15-minute heartbeat records, respects STOP/cleanup holds, stops on nonzero or blocked arm status, and sets a 72-hour overall limit with a reserved graceful-stop window. It contains no research policy or mathematical agenda and does not modify the runtime implementation or arm state. Its official STOP handling is operational only.

No launch command is supplied while this HOLD applies. Root owns subsequent source review, activation, retention and any new launch.
