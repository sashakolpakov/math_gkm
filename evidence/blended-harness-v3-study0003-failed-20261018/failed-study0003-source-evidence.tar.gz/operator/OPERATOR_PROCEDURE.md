# Prospective operator procedure — paired blended-harness comparison

This records commands only. This document does not authorize or launch a live call. The root operator owns activation after the installed actual preflight passes, source review is complete, and public source/evidence retention is ready. No mathematical agenda is supplied here.

## Fixed common inputs

Use `/Users/sasha/math_gkm/.bootstrap/paired-v3-live-20261018` as `OPS`, its existing `contract.json` and `config.json`, and fresh children `curation-0001` and `study`. Both arms receive the same clean seed, pinned dependencies, model `gpt-6.1-sol`, fixed reasoning `high`, proof gates, resource profile and upper allowances. The prior record fixes order **exploration, then baseline**, sequentially. The baseline uses the corrected common admission/resource machinery with the exploitation strategy; it is not the obsolete implementation.

The contract is exactly `clean_contract()` plus this operational field:

```json
{"evaluation_setup":{"max_tasks":2,"reason":"matched-budget-cap","curator_instruction":"Select at most two tasks; an empty suite is allowed. This is an operational count limit, not a mathematical selection criterion.","over_cap":"retain original suite and receipts; stop before freeze; never trim tasks"}}
```

Canonical contract digest: `95f8e281bd881c80b48287f2f0f8bb8424ddac8fe4b7af7c0312aa9a5b68c7f4`. Config digest: `d77c21dd28a2575f50c0bdfd64880037cd3a06b4a641f13f607b9ad93802616c`; fully merged protocol digest: `c482aeb8175ad625bfc4cbd90cfa3bd029d753971b0dbe91aacf90d8988f9448`. These are canonical-object digests, distinct from raw file SHA256.

Root remains the exact original `MathGKM.Markov.Conjecture63`, source SHA256 `8b8408e5cae9822fe0969afd4a70b408d48e69f750dffb88c253dba8ef167dbe`. No inherited facts, old exercises, campaign hints or additional `seed_sources` are permitted. The copied seed is the original root, Protocol, mission/design and pinned Lake files, plus ResearchSemantics and ContinuationObligations. Installed historical results are implementation-identity hashed but are not copied into either read-isolated research input. Curation reads its own fresh seed, before either arm, with no old trial artifacts. Read-only dependency caches are common infrastructure.

## Authorization and curator

The root operator must first bind protected `.bootstrap/study-authorization.json` to `digest(exact contract)`, `digest(implementation())`, and `user_explicit_ok: true`, retaining the completed installed-preflight/source-review provenance. Do not use an old contract or implementation digest. `implementation()` covers machinery Python, installed MathGKM Lean sources and base permissions. This authorization is required **before curation**, again at freeze and live calls. No new user permission is needed; this is the previously authorized post-readiness activation. Only the root operator writes it.

All command blocks below are prospective; run from the repo after that activation:

```sh
cd /Users/sasha/math_gkm
OPS=/Users/sasha/math_gkm/.bootstrap/paired-v3-live-20261018
/opt/homebrew/bin/python3 -m machinery.study_curate \
  --out "$OPS/curation-0001" --transport live --seconds 600 \
  --model gpt-6.1-sol --contract "$OPS/contract.json"
```

600 seconds is a prospective common setup cap, separate from arm budgets. The curator fixes `high` in source; there is no effort flag. Both CLIs support `--contract`. There is no CLI task-count switch: the field informs the independent curator, and the following gate enforces its numeric limit without selecting mathematical content.

Preserve the entire curation directory on success or failure. In particular retain job prompt/spec/events/receipt, suite and provenance. An empty suite is allowed and authorizes no heldout-transfer claim. An over-cap suite must remain intact and stop the workflow; do not trim, replace or silently retry it after seeing its tasks.

## Count and full-horizon gate before freeze

Execute this read-only validation and write a gate receipt; the gate neither selects tasks nor activates a study:

```sh
/opt/homebrew/bin/python3 - <<'PY_GATE'
from pathlib import Path
from machinery.study import DEFAULT,validate_protocol,validate_suite,validate_commitment
from machinery.study_common import read,write,digest,implementation,authorize_live,clean_contract
ops=Path('/Users/sasha/math_gkm/.bootstrap/paired-v3-live-20261018')
c=read(ops/'contract.json'); p={**DEFAULT,**read(ops/'config.json')}
assert {k:v for k,v in c.items() if k!='evaluation_setup'}==clean_contract()
assert c['evaluation_setup']['max_tasks']==2 and not c.get('seed_sources')
authorize_live(c);validate_protocol(p)
s=read(ops/'curation-0001/suite.json');validate_suite(s,c)
n=len(s['tasks']); planned=(62400+7200*n) if n else 53400
ok=n<=2 and planned<=p['arm_seconds'] and 36<=p['max_calls'] and 20<=p['meta_calls']
write(ops/'COUNT_GATE.json',{'accepted':ok,'tasks':n,'max_tasks':2,
 'contract_sha256':digest(c),'suite_sha256':digest(s),
 'implementation_sha256':digest(implementation()),'planned_seconds':planned,
 'action':'freeze may proceed' if ok else 'retain outputs and stop; never trim'})
assert ok, 'Count/horizon gate rejected; preserve curation outputs and do not freeze'
validate_commitment(p,n)
PY_GATE
```

At two tasks, each paired evaluation has cap `E=6600s`; two main episodes, optional matched trial and final evaluation total at most `76800s`, leaving `9600s` of the `86400s` arm allowance. The planned role envelope is 36 calls/20 meta calls, within 64/32. It includes one repair opportunity per plan and reserves the review once. The formula is `50400+4E(m)=62400+7200m` for a nonempty suite; the empty-suite path is `53400s` if the optional trial runs, but supplies no transfer evidence. These are reservation opportunities, not actual billed usage or a universal reward. Additional optional discovery promotion/stitching/recovery remains paid and may stay pending. `validate_commitment` checks one episode, so it alone is not a full-horizon guarantee. See `ENVELOPE_AUDIT.json`.

## Freeze and sequential arms

```sh
/opt/homebrew/bin/python3 -m machinery.study freeze \
  --study "$OPS/study" --config "$OPS/config.json" \
  --suite "$OPS/curation-0001/suite.json" --contract "$OPS/contract.json"
```

The study child must not already exist. Keep `suite.json` beside its `provenance.json`; freeze validates the exact independent completed curator receipt, model, high reasoning and suite digest. Freeze performs another actual deployment preflight and source/dependency identity hashing, then creates equally empty arm states. Inspect the seal, initial states, copied seed inventories and `setup-cost.json` before starting.

Launch **only exploration first**:

```sh
/opt/homebrew/bin/python3 -m machinery.study run --study "$OPS/study" --arm exploration --detach
/opt/homebrew/bin/python3 -m machinery.study status --study "$OPS/study"
```

Only after that controller is finished, no owned live call remains, and the controller lock is released, launch the comparator:

```sh
/opt/homebrew/bin/python3 -m machinery.study run --study "$OPS/study" --arm baseline --detach
```

Do not use `--arm both`: current CLI deliberately iterates baseline then exploration and would violate the precommitted operator order. Do not launch both detached commands together. If a run is interrupted, retain every receipt and follow the supported recovery path; `run --resume` alone is not permission to repeat finished work. Record the session/recovery setup cost and any deviation from the original order. Do not send proof hints or research strategy from this monitoring session.

## Observation and honest reporting

Monitor about every 15 minutes using status, states and finished source-bound receipts. Report separate statuses for (1) fresh Lean/kernel/premise-admitted facts, with exact quantifiers and conditions; (2) independently reviewed English/source correspondence; (3) actual checked reuse/path toward the exact root. A conditional or disconnected exploratory lemma does not close the unconditional root. Give a short mathematical description alongside operational status. Record exploration actions and later checked reuse, strategy reassessment, and actual costs; the complexity/sawtooth observer is one-way audit only.

Every fresh arm controller session performs another actual deployment preflight before its first hosted role; freeze also performs one. Together with the root's manual installed check, an uninterrupted two-arm comparison ordinarily incurs four preflights, each default 1200-second cap. These are separately recorded infrastructure setup, outside arm research opportunity caps. Independent curation and streamed dependency/source verification are further common setup. Repeated sessions add setup; do not bypass it, count it as theorem progress, or sum overlapping controller/worker elapsed times. Provider usage remains raw/unverified, without token/currency normalization.

An empty or unsuitable heldout suite, no optional exploration, no strategy selection, or no checked reuse is a legitimate observed limitation. Equal upper allowances do not imply equal actual cost. Order/provider/time drift remain uncontrolled; one sequential pair cannot establish causal superiority. No novelty or Markov theorem claim follows from harness tests alone.
