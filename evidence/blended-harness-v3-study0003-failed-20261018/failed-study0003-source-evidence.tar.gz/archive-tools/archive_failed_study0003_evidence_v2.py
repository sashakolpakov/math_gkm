#!/usr/bin/env python3
"""Source-only debugging archive for completed study0003. Never run research.
Root reviews and executes separately. Private curator/evaluation contents stay
local; only hashes, sizes and source provenance are recorded. No deletions.
"""
import argparse,codecs,gzip,hashlib,io,json,os,re,tarfile
from pathlib import Path
ROOT=Path('/Users/sasha/math_gkm')
OPS=ROOT/'.bootstrap/construction-v3-20261018'
OPERATOR=ROOT/'.bootstrap/paired-v3-live-20261018'
STUDY=ROOT/'.scratch/paired-v3-live-20261018-study-0003'
CURATOR=OPERATOR/'curation-0001'
SUITE_SHA='63b2ce6c7f223eac414137a90be674ccdeebaebb325a912e78fb1b29e161617d'
IMPLEMENTATION_SHA='cd9eed60f505f955250fb0f73803baf0cb64f9c746d0af4b485ee528089340f2'
PUBLIC_COMMIT='0a19d25710a497cf3fd171fa40225bd82e236822'
MAX_FILES=6000
MAX_MEMBER=128*1024**2
MAX_TOTAL=512*1024**2
PRUNE={'.git','.lake','__pycache__','evaluation'}
BINARY_SUFFIXES={'.olean','.ilean','.o','.a','.so','.dylib','.dll','.exe','.bin','.zip','.pyc','.png','.jpg','.pdf','.c','.bc','.ll','.trace','.hash'}
MAPPINGS=((STUDY,'study0003'),(OPERATOR,'operator'),(OPS,'archive-tools'))

def fail(message): raise RuntimeError(message)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as source:
  for block in iter(lambda:source.read(1048576),b''):h.update(block)
 return h.hexdigest()
def stable(st): return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
def name_for(path):
 for base,prefix in MAPPINGS:
  if path.is_relative_to(base):return prefix+'/'+path.relative_to(base).as_posix()
 if path.is_relative_to(ROOT):return 'tested-implementation/'+path.relative_to(ROOT).as_posix()
 fail('unapproved source root: '+str(path))
def excluded_by_name(path):
 return (any(path.name.endswith(s) for s in ('.olean.private','.olean.server','.tar.gz','.tar'))
         or path.suffix in BINARY_SUFFIXES)

def text_or_json_gzip(path):
 # Gzip is allowed ONLY for complete premise JSON, never a generic binary archive.
 if path.name.endswith('.json.gz'):return True
 if excluded_by_name(path):return False
 decoder=codecs.getincrementaldecoder('utf-8')('strict')
 try:
  with path.open('rb') as source:
   for block in iter(lambda:source.read(1048576),b''):
    if b'\0' in block:return False
    decoder.decode(block)
  decoder.decode(b'',final=True)
 except UnicodeDecodeError:return False
 return True



def sources():
 selected={};skipped=[];private=[];scanned=0
 # Only private-content matching, never publication or model exposure.
 suite=STUDY/'evaluation/suite.json'
 secret=json.loads(suite.read_text())
 canonical_suite=hashlib.sha256(json.dumps(secret,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
 if canonical_suite!=SUITE_SHA:fail('retained private canonical suite identity changed')
 if len(secret['tasks'])!=2:fail('private suite count changed')
 fragments=[]
 for value in [secret.get('selection_basis','')]+[t.get(k,'') for t in secret['tasks'] for k in ('id','statement','interface_type','transport_type')]:
  if isinstance(value,str) and len(value)>=8:
   fragments.extend([value.encode(),json.dumps(value,ensure_ascii=True)[1:-1].encode()])
 overlap=max(map(len,fragments),default=1)-1
 if overlap>1024**2:fail('private comparison field exceeds bound')
 def add(path,required=False):
  nonlocal scanned
  path=Path(os.path.abspath(path))
  if not path.exists():
   if required:fail('required evidence missing: '+str(path))
   return
  if path.is_relative_to(CURATOR) or path.is_relative_to(STUDY/'evaluation'):
   fail('attempt to publish heldout/curator contents')
  if path.is_symlink():
   if required:fail('required evidence is symlink')
   skipped.append({'path':name_for(path),'reason':'symlink; dependency restored from pins'});return
  if not path.is_file():fail('explicit evidence not regular')
  scanned+=1
  if scanned>MAX_FILES:fail('bounded file count')
  before=path.stat()
  if excluded_by_name(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'compiled or derived nonsource output'});return
  if before.st_size>MAX_MEMBER:fail('bounded member size')
  if not text_or_json_gzip(path):
   skipped.append({'path':name_for(path),'bytes':before.st_size,'reason':'nonsource binary'});return
  # Fail closed if a selected original record accidentally repeats a heldout
  # task/selection field. Do not redact, silently drop, or print private text.
  if path.name.endswith('.json.gz'):fail('unexpected compressed record; separately review private-content scan')
  tail=b''
  with path.open('rb') as f:
   for block in iter(lambda:f.read(1048576),b''):
    joined=tail+block
    if any(fragment in joined for fragment in fragments):fail('heldout content detected in selected member: '+name_for(path))
    tail=joined[-overlap:] if overlap else b''
  sha=digest(path)
  if stable(path.stat())!=stable(before):fail('source changed during inventory')
  selected[name_for(path)]={'source_path':str(path),'bytes':before.st_size,'sha256':sha,'stat_identity':stable(before)}
 def tree(path):
  if not path.is_dir():fail('required bounded tree missing: '+str(path))
  for directory,dirs,files in os.walk(path,followlinks=False,onerror=lambda e:fail(str(e))):
   dirs[:]=sorted(d for d in dirs if d not in PRUNE and not (Path(directory)/d).is_symlink())
   for name in sorted(files):add(Path(directory)/name)
 def private_hash(path):
  nonlocal scanned
  if path.is_symlink() or not path.is_file():fail('private provenance file not regular')
  scanned+=1
  if scanned>MAX_FILES or path.stat().st_size>MAX_MEMBER:fail('private provenance bound')
  before=path.stat();value=digest(path)
  if stable(path.stat())!=stable(before):fail('private artifact changed during hashing')
  private.append({'source_path':str(path),'bytes':before.st_size,'sha256':value,'disposition':'PRIVATE retained locally, contents excluded for same pretrial-suite reuse'})
 seal=json.loads((STUDY/'seal.json').read_text())
 if seal['suite']!=SUITE_SHA:fail('seal suite identity changed')
 exp=json.loads((STUDY/'arms/exploration/state.json').read_text())['state']
 baseline=json.loads((STUDY/'arms/baseline/state.json').read_text())['state']
 if not (exp['round']==0 and exp['calls']==2 and exp['meta_calls']==2 and exp['status']=='bounded_or_blocked' and not exp['evaluations']):fail('completed failedstudy state changed')
 if not (baseline['round']==0 and baseline['calls']==0 and baseline['meta_calls']==0 and baseline['status']=='ready' and not baseline['receipts']):fail('baseline no longer pristine')
 if exp['research']['knowledge'] or exp['research']['components']:fail('unexpected admitted knowledge; re-scope evidence')
 jobs=STUDY/'arms/exploration/jobs'
 if sorted(p.name for p in jobs.iterdir() if p.is_dir())!=['plan-0000','plan-0000-repair-1']:fail('proposer job inventory changed')
 for name in ('plan-0000','plan-0000-repair-1'):
  if json.loads((jobs/name/'invalid-plan.json').read_text())['status']!='invalid_proposer_payload':fail('expected invalid proposer outcome changed')
 # Both setup preflights and original payloads/history/workspaces are selected;
 # evaluation is private. Dependency caches/objects are excluded by filters.
 tree(STUDY)
 for path in [suite,CURATOR/'suite.json',CURATOR/'provenance.json']:
  if path.is_file():private_hash(path)
 # All curator invocation sources/events/prompts may disclose the private
 # selection. Preserve them locally, publish only complete per-file hashes.
 if CURATOR.exists():
  for directory,dirs,files in os.walk(CURATOR,followlinks=False,onerror=lambda e:fail(str(e))):
   dirs[:]=sorted(d for d in dirs if d not in PRUNE and not (Path(directory)/d).is_symlink())
   for name in sorted(files):
    path=Path(directory)/name
    if path not in (CURATOR/'suite.json',CURATOR/'provenance.json'):private_hash(path)
 # Only shallow named operational records, never other studies or curation.
 prefixes=('sequential_operator','SEQUENTIAL','sequential007v3-')
 explicit={'ACTIVATION_007.json','ARM_ORDER.json','COUNT_GATE_007.json','ENVELOPE_AUDIT.json',
  'IMPLEMENTATION_AT_ACTIVATION_007.json','OPERATOR_PROCEDURE.md','SETUP.json',
  'SOURCE_PUBLICATION007.json','config.json','contract.json'}
 for p in sorted(OPERATOR.iterdir()):
  if p.is_file() and (p.name.startswith(prefixes) or p.name in explicit):add(p,True)
 outcome=json.loads((OPERATOR/'SEQUENTIAL007V3_RESULT.json').read_text())
 if outcome['status']!='stopped; no retry or next arm':fail('operator completion changed')
 publication=json.loads((OPERATOR/'SOURCE_PUBLICATION007.json').read_text())
 if publication['public_commit']!=PUBLIC_COMMIT or publication['implementation_sha256']!=IMPLEMENTATION_SHA:fail('published source identity changed')
 # Exact source bytes bound by seal, not a broad current-source copy. If a
 # later008 install has replaced any byte, STOP and recover from recorded Git.
 impl=seal['implementation']
 if len(impl)!=70:fail('sealed implementation inventory changed')
 for name,value in impl.items():
  p=ROOT/name
  if p.is_symlink() or digest(p)!=value:fail('sealed007 source changed; recover original from publiccommit: '+name)
  add(p,True)
 for name in ('MathGKM.lean','lean-toolchain','lake-manifest.json','lakefile.toml',
              'repro/repro.py','repro/manifest-construction-v3.json','repro/README.md',
              'config/darwin-memory-profile-007.json','.bootstrap/study-authorization.json'):
  add(ROOT/name,True)
 add(OPS/'archive_failed_study0003_evidence.py',True)
 add(Path(__file__).resolve(),True)
 if sum(row['bytes'] for row in selected.values())>MAX_TOTAL:fail('aggregate512MiB bound')
 return selected,skipped,private,{'exploration':{'round':0,'calls':2,'meta_calls':2,'admissions':0,'mathematical_actions':0,'status':exp['status']},'baseline':{'calls':0,'started':False},'setup_preflight_ready':seal['deployment_preflight']['ready']}


def metadata(selected,skipped,private,outcome):
 return {'schema':'math-gkm.failed-study0003-debugging-source-evidence.v1',
  'scope':'Failed schema-only proposer experiment; two invalid plans, no executed mathematical action/admission, no baseline or comparative result',
  'public_source_commit':PUBLIC_COMMIT,'implementation_sha256':IMPLEMENTATION_SHA,
  'private_suite_sha256':SUITE_SHA,'private_suite_task_count':2,'private_artifacts':private,
  'private_contents_policy':'Retain every original locally; archive only hashes/sizes/provenance of curator and heldout suite. No answers, statements or task identities are published.',
  'path_mapping':{prefix:str(base) for base,prefix in MAPPINGS},
  'reproduction_note':'Original absolute paths are host provenance. Restore exact published007 source/pins and retained proposer payloads for parser debugging. Dependencies/objects regenerated; heldout evaluation cannot be reproduced publicly until its private original is deliberately released. Do not count setup neutral proofs as new Markov progress or assume a completed comparison.',
  'outcome':outcome,'excluded_directory_names':sorted(PRUNE),'members':selected,'excluded':skipped}


class HashedReader:
 def __init__(self,source):self.source=source;self.hash=hashlib.sha256()
 def read(self,n=-1):
  data=self.source.read(n);self.hash.update(data);return data

def write_archive(path,record):
 if path.exists():fail('archive already exists; never overwrite evidence')
 path.parent.mkdir(parents=True,exist_ok=True)
 try:
  with path.open('xb') as raw:
   with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
    with tarfile.open(fileobj=compressed,mode='w|') as archive:
     for name,member in sorted(record['members'].items()):
      source=Path(member['source_path'])
      if source.is_symlink() or stable(source.stat())!=tuple(member['stat_identity']):fail('source changed before archiving: '+str(source))
      info=tarfile.TarInfo(name);info.size=member['bytes'];info.mode=0o644;info.mtime=0
      with source.open('rb') as stream:
       reader=HashedReader(stream);archive.addfile(info,reader)
       if reader.hash.hexdigest()!=member['sha256'] or stable(os.fstat(stream.fileno()))!=tuple(member['stat_identity']):fail('source changed during archiving: '+str(source))
     body=(json.dumps(record,sort_keys=True,indent=2)+'\n').encode()
     info=tarfile.TarInfo('ARCHIVE_MANIFEST.json');info.size=len(body);info.mode=0o644;info.mtime=0
     archive.addfile(info,io.BytesIO(body))
 except BaseException:
  # Preserve a partial artifact for debugging, clearly distinguishable by the
  # absence of a success sidecar; never delete or replace any source evidence.
  raise
 return digest(path)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--inventory',type=Path,required=True)
 parser.add_argument('--execute',action='store_true')
 parser.add_argument('--archive',type=Path)
 args=parser.parse_args()
 if args.inventory.exists():fail('inventory already exists; choose a new finalization label')
 if args.execute and not args.archive:fail('--execute requires a NEW --archive path')
 selected,skipped,private,outcome=sources()
 record=metadata(selected,skipped,private,outcome)
 record['archiver_source_sha256']=digest(Path(__file__))
 if args.execute:record['archive_sha256']=write_archive(args.archive,record)
 args.inventory.parent.mkdir(parents=True,exist_ok=True)
 with args.inventory.open('x') as out:json.dump(record,out,indent=2,sort_keys=True);out.write('\n')
 print(json.dumps({'members':len(selected),'source_bytes':sum(m['bytes'] for m in selected.values()),'excluded':len(skipped),'private_artifacts_hashed':len(private),'inventory':str(args.inventory),'archive_sha256':record.get('archive_sha256')}))

if __name__=='__main__':main()
