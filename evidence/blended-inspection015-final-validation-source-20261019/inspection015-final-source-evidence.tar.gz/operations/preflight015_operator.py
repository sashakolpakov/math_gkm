"""Root-authorized source-bound actual neutral deployed preflight; no model calls."""
import hashlib,json,os,sys,time
from pathlib import Path
BASE=Path('/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018')
sys.path.insert(0,str(BASE))
MANIFEST=BASE/'evidence/construction-v3/source-audit-015/SOURCE_MANIFEST.json'
EXPECTED='bfec46aa82823a1424ee4ae1ea3c8facb8c06f9926db8adb3bb4cd16262780a2'
REVIEW=BASE/'.bootstrap/construction-v3-review-015.json'
OUT=BASE/'.scratch/v3-validation/cp015-deployment'
DEPLOY=BASE/'.scratch/cp015-deployment'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
    return h.hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def changed():
    assert sha(MANIFEST)==EXPECTED
    return [r for r,h in read(MANIFEST)['files_sha256'].items() if sha(BASE/r)!=h]
def main():
    from machinery.process import run
    review=read(REVIEW)
    assert review['accepted'] is True and review['manifest_sha256']==EXPECTED
    assert review['approved_actual_deployment'] is True
    assert changed()==[] and not DEPLOY.exists()
    OUT.mkdir(parents=True,exist_ok=False)
    command=[sys.executable,'-m','machinery.study_deployment','--out',str(DEPLOY),'--seconds','1200']
    write(OUT/'intent.json',dict(argv=command,manifest_sha256=EXPECTED,review_sha256=sha(REVIEW),
        operator_sha256=sha(Path(__file__)),preflight_seconds=1200,guard_seconds=1260))
    result={};reason=None;start=time.monotonic();receipt_verified=False
    try:
        result=run(command,cwd=BASE,env={**os.environ,'PATH':'/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin',
            'TMPDIR':str(BASE/'.scratch'),'PYTHONDONTWRITEBYTECODE':'1'},timeout=1260,output_bytes=8*1024**2,
            scope=BASE/'.scratch',tree_only=True,log_path=OUT/'run.log')
        reason=result.get('termination')
        if result.get('returncode')==0 and reason is None:
            from machinery.study_deployment import verify_receipt
            assert read(DEPLOY/'result.json')['ready'] is True
            binding=dict(ready=True,receipt=str(DEPLOY/'receipt.json'),receipt_sha256=sha(DEPLOY/'receipt.json'))
            verify_receipt(binding)
            receipt_verified=True
            write(OUT/'READY_BINDING.json',binding)
    except (OSError,ValueError,AssertionError,KeyboardInterrupt) as exc:reason=type(exc).__name__+': '+str(exc)
    finally:
        write(OUT/'result.json',dict(returncode=result.get('returncode'),termination=reason,
            resources=result.get('resources'),wall_seconds=time.monotonic()-start,source_mismatches_after=changed(),
            deployment_result_sha256=sha(DEPLOY/'result.json') if (DEPLOY/'result.json').exists() else None,
            ready_receipt_verified=receipt_verified,manifest_sha256=EXPECTED,
            log_sha256=sha(OUT/'run.log') if (OUT/'run.log').exists() else None,
            scope='Actual neutral sandbox/Lean/kernel/premise/completion preflight; no research campaign or mathematical root resolution'))
    return 0 if result.get('returncode')==0 and reason is None and not changed() and receipt_verified else 1
if __name__=='__main__':raise SystemExit(main())
