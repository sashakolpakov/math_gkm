"""Prepared ops-only old010 inspector comparison on exact fresh replayed neutral objects."""
import hashlib,importlib.util,json,os,sys,time,unittest
from pathlib import Path
BASE=Path('/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018')
OPS=Path('/Users/sasha/math_gkm/.bootstrap/construction-v3-20261018')
sys.path.insert(0,str(BASE))
MANIFEST=BASE/'evidence/construction-v3/source-audit-014/SOURCE_MANIFEST.json'
EXPECTED='86b321c9628ce7493c89e06ab0000050375974fd7fe10c1c28181e5467e8ee3f'
FIXTURE='26438fcf09ee851c40abd70727007e75d859357e185d5d2626208efb92b493c1'
assert '--tag' in sys.argv
TAG=sys.argv[sys.argv.index('--tag')+1]
assert TAG in {'identity_base','identity_repeat','identity_changed_unused','aggregate'}
OUT=BASE/'.scratch/v3-validation'/('cp014-fixture-'+TAG+'-old')
UNUSED='MathGKM.InspectionIdentityControl013.unused'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def changed():
    assert sha(MANIFEST)==EXPECTED
    return [r for r,h in read(MANIFEST)['files_sha256'].items() if sha(BASE/r)!=h]
class ExactOldInspector(unittest.TestCase):
    def test_same_fresh_replayed_objects(self):
        from machinery import study_transfer
        from machinery.validation_receipts import reuse
        from machinery.study_transfer import bind_task
        from tests.test_inspection011_fixture import Supervisor011
        helper=Supervisor011('runTest');case=next(c for c in helper.inputs()['differential_cases'] if c['tag']==TAG)
        self.assertEqual(case['seconds'],1200)
        newout=BASE/'.scratch/v3-validation'/('cp014-fixture-'+TAG+'-new')
        assertion=read(newout/'ASSERTIONS.json');self.assertIs(assertion['checked'],True)
        check=Path(assertion['check_directory']);new=read(check/'result.json')
        task=case['task'] if 'target_module' in case['task'] else bind_task(check.parent/'workspace',case['task'])
        self.assertEqual(reuse(check,task,case['solution'],case['required']),new)
        self.assertEqual(sha(check/'FINISHED.json'),assertion['FINISHED_sha256'])
        objects={n:sha(check/'build'/(n.replace('.','/')+'.olean')) for n in new['object_hashes']}
        self.assertEqual(objects,new['object_hashes'])
        prior=BASE/'evidence/construction-v3/source-audit-010'
        self.assertEqual(sha(prior/'SOURCE_MANIFEST.json'),'91849c3534793fc2c9b0c77303816bc3d7c322b310eb09d5a9745734953cbd7b')
        source=prior/'sources/machinery/proof_audit.py'
        self.assertEqual(sha(source),read(prior/'SOURCE_MANIFEST.json')['files_sha256']['machinery/proof_audit.py'])
        spec=importlib.util.spec_from_file_location('machinery._inspection014_old_audit',source)
        old_audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(old_audit)
        directory=check.parent/'old-inspector-only';directory.mkdir(exist_ok=False)
        roots=tuple(r['name'] for r in new['declarations'])
        modules=sorted({c['origin'] for c in new['declarations'][0]['catalog']})
        (directory/'OldInspect.lean').write_text(old_audit.inspector('StudyCheck',roots,case['required'],modules,artifact='declarations.json'))
        deps=[Path(v) for v in new['launch_environment']['LEAN_PATH'].split(':')]
        prefix=study_transfer.sandbox_prefix(directory,deps)
        record=None;old=None
        try:
            record=study_transfer.run(prefix+[str(study_transfer.LEAN),'-j','1','OldInspect.lean'],
                cwd=directory,env={**new['launch_environment'],'TMPDIR':str(directory)},timeout=case['seconds'],output_bytes=1048576)
            write(directory/'RAW_PROCESS_RECORD.json',record)
            self.assertEqual(record['returncode'],0,record)
            self.assertIsNone(record.get('termination'),record)
            self.assertFalse(record.get('operationally_incomplete'),record)
            old=old_audit.parse_artifact(record,roots,directory/'declarations.json')
            self.assertEqual(len(old),len(new['declarations']))
            for a,b in zip(old,new['declarations']):
                self.assertEqual(a['name'],b['name'])
                self.assertEqual(set(a['axioms']),set(b['axioms']))
                self.assertLessEqual(set(a['axioms']),{'propext','Classical.choice','Quot.sound'})
                for field in ('constants','catalog'):
                    self.assertEqual({(c['name'],c['origin']) for c in a[field]},
                                     {(c['name'],c['origin']) for c in b[field]})
            for rows in (old,new['declarations']):
                for row in rows:
                    self.assertLessEqual(set(case['required']),{c['name'] for c in row['constants']})
                    self.assertIn(UNUSED,{c['name'] for c in row['catalog']})
                    self.assertNotIn(UNUSED,{c['name'] for c in row['constants']})
            self.assertEqual({n:sha(check/'build'/(n.replace('.','/')+'.olean')) for n in objects},objects)
            for name,h in case['files_sha256'].items():self.assertEqual(sha(check.parent/'workspace'/name),h)
            write(OUT/'IDENTITIES.json',dict(tag=TAG,fixture_sha256=FIXTURE,source_manifest_sha256=EXPECTED,
                versions=[{c['name']:c['semantic_sha256'] for c in rows[0]['catalog']} for rows in (old,new['declarations'])],
                encoding_order=['old010','new014'],check_directory=str(check),old_directory=str(directory),
                same_replayed_object_hashes=objects,old_artifact_sha256=sha(directory/'declarations.json'),
                new_result_sha256=sha(check/'result.json'),all_catalog_and_closure_name_origin_sets_equal=True,
                standard_axioms_equal=True,unused_present_in_catalog_absent_from_root_closure=True,
                scope='INSPECTOR ONLY; no old010 controller/check_task/receipt admission claim'))
        finally:
            write(OUT/'ENGINEERING_MEASUREMENTS.json',dict(tag=TAG,source_manifest_sha256=EXPECTED,
                fixture_sha256=FIXTURE,old_source_sha256=sha(source),record=record,
                old_artifact_bytes=(directory/'declarations.json').stat().st_size if (directory/'declarations.json').exists() else None,
                old_rows_parsed=old is not None,same_replayed_objects_before=objects,
                same_replayed_objects_after={n:sha(check/'build'/(n.replace('.','/')+'.olean')) for n in objects},
                original_old_inspector_seconds=case['seconds']))
def aggregate():
    fixture=read(BASE/'local.scratch/inspection011-fixture.json');records={}
    for tag in ['identity_base','identity_repeat','identity_changed_unused']:
        path=BASE/'.scratch/v3-validation'/('cp014-fixture-'+tag+'-old')/'IDENTITIES.json'
        value=read(path);assert value['fixture_sha256']==FIXTURE and value['source_manifest_sha256']==EXPECTED
        records[tag]=value
    results=[]
    for pair in fixture['differential_identity_pairs']:
        for version in [0,1]:
            left=records[pair['left']]['versions'][version][pair['constant']]
            right=records[pair['right']]['versions'][version][pair['constant']]
            assert (left==right)==pair['equal'],(pair,version)
            results.append(dict(pair=pair,encoding=['old010','new014'][version],observed_equal=left==right))
    OUT.mkdir(parents=True,exist_ok=False);write(OUT/'AGGREGATE.json',dict(passed=True,comparisons=results,
        source_manifest_sha256=EXPECTED,fixture_sha256=FIXTURE,scope='Within-encoding identities only; no cross-encoding digest equality claim'))
    return 0
def main():
    assert sha(BASE/'local.scratch/inspection011-fixture.json')==FIXTURE
    assert changed()==[]
    if TAG=='aggregate':return aggregate()
    if '--child' in sys.argv:
        os.environ['GKM_INSPECTION011_FIXTURE_SHA256']=FIXTURE
        return 0 if unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ExactOldInspector)).wasSuccessful() else 1
    from machinery.process import run
    OUT.mkdir(parents=True,exist_ok=False)
    write(OUT/'intent.json',dict(source_manifest_sha256=EXPECTED,fixture_sha256=FIXTURE,tag=TAG,
        old_inspector_seconds=1200,runner_seconds=1260,own_operator_sha256=sha(Path(__file__))))
    record={};reason=None;start=time.monotonic()
    try:
        record=run([sys.executable,str(Path(__file__).resolve()),'--tag',TAG,'--child'],cwd=BASE,
            env={**os.environ,'TMPDIR':str(BASE/'.scratch'),'PYTHONDONTWRITEBYTECODE':'1'},timeout=1260,
            output_bytes=8*1024**2,scope=BASE/'.scratch',tree_only=True,log_path=OUT/'run.log')
        reason=record.get('termination')
    except (OSError,ValueError,KeyboardInterrupt) as exc:reason=type(exc).__name__+': '+str(exc)
    finally:write(OUT/'result.json',dict(returncode=record.get('returncode'),termination=reason,
        resources=record.get('resources'),wall_seconds=time.monotonic()-start,source_mismatches_after=changed(),
        source_manifest_sha256=EXPECTED,fixture_sha256=FIXTURE,log_sha256=sha(OUT/'run.log') if (OUT/'run.log').exists() else None))
    return 1 if reason or changed() else record.get('returncode',1)
if __name__=='__main__':raise SystemExit(main())
