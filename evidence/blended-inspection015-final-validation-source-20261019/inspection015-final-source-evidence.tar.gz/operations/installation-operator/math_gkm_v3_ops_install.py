#!/usr/bin/env python3
"""Operator-only reviewed-source installation; never launches research or Lean.

prepare writes a reviewable JSON plan. apply requires its exact SHA256 and an
accepted source review, preserves all existing Lean/pin inputs, and makes backups.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile

EXPECTED_ROOT = Path('/Users/sasha/math_gkm')
LEAN_ADDITIONS = {'MathGKM/Construction.lean', 'MathGKM/NeutralV3Root.lean'}
PINNED = ('MathGKM.lean', 'MISSION.md', 'docs/DESIGN.md', 'lakefile.toml',
          'lake-manifest.json', 'lean-toolchain', 'contracts/markov-goal.json')

def fail(message):
    raise RuntimeError(message)

def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def read(path):
    path = Path(path)
    if path.is_symlink() or path.stat().st_size > 16 * 1024 * 1024:
        fail('invalid or oversized metadata: ' + str(path))
    return json.loads(path.read_text())

def safe(base, name):
    relative = Path(name)
    if relative.is_absolute() or '..' in relative.parts:
        fail('invalid relative source name: ' + name)
    path = base / relative
    if path.is_symlink() or not path.resolve().is_relative_to(base.resolve()):
        fail('source/destination alias: ' + name)
    return path

def allowed(name):
    return (name in LEAN_ADDITIONS or
            re.fullmatch(r'machinery/[A-Za-z0-9_]+\.py', name) is not None or
            re.fullmatch(r'tests/[A-Za-z0-9_]+\.py', name) is not None or
            re.fullmatch(r'config/[A-Za-z0-9_\-]+\.json', name) is not None or
            (name.startswith('docs/') and name.endswith('.md') and name != 'docs/DESIGN.md'))

def atomic_copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    mode = stat.S_IMODE(target.stat().st_mode) if target.exists() else 0o644
    with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.math-gkm-install-', delete=False) as output:
        temporary = Path(output.name)
        with Path(source).open('rb') as input_file:
            shutil.copyfileobj(input_file, output, 1024 * 1024)
        output.flush()
        os.fsync(output.fileno())
    temporary.chmod(mode)
    os.replace(temporary, target)

def atomic_json(target, value):
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', dir=target.parent, prefix='.math-gkm-install-', delete=False) as output:
        temporary = Path(output.name)
        json.dump(value, output, sort_keys=True, indent=2)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, target)

def root_path(path):
    root = Path(path).resolve()
    if root != EXPECTED_ROOT:
        fail('this plan is scoped only to /Users/sasha/math_gkm')
    return root

def source_inputs(candidate, manifest_path, review_path):
    manifest = read(manifest_path)
    review = read(review_path)
    manifest_hash = sha(manifest_path)
    if review.get('accepted') is not True or review.get('manifest_sha256') != manifest_hash:
        fail('source review does not accept this exact manifest')
    for name, expected in manifest['files_sha256'].items():
        if sha(safe(candidate, name)) != expected:
            fail('candidate differs from reviewed source: ' + name)
    return manifest, manifest_hash

def prepare(args):
    root = root_path(args.installed)
    candidate = Path(args.candidate).resolve()
    if not candidate.is_relative_to(root / '.scratch'):
        fail('candidate must be the separately reviewed local construction checkout')
    manifest_path = Path(args.source_manifest).resolve()
    review_path = Path(args.review).resolve()
    manifest, manifest_hash = source_inputs(candidate, manifest_path, review_path)
    protected = {str(p.relative_to(root)): sha(p) for p in sorted((root / 'MathGKM').glob('*.lean'))}
    protected.update({name: sha(root / name) for name in PINNED})
    for name in PINNED:
        if name != 'MathGKM.lean' and manifest['files_sha256'].get(name) != protected[name]:
            fail('protected source/pin differs: ' + name)
    for name, expected in manifest['files_sha256'].items():
        if name.startswith('MathGKM/') and name.endswith('.lean') and name not in LEAN_ADDITIONS:
            target = safe(root, name)
            if not target.is_file() or sha(target) != expected:
                fail('required reviewed Lean context is absent/different: ' + name)
    overlay, unchanged = [], {}
    for name, expected in sorted(manifest['files_sha256'].items()):
        if not allowed(name):
            continue
        destination = safe(root, name)
        current = sha(destination) if destination.is_file() else None
        if current == expected:
            unchanged[name] = expected
            continue
        if name in protected:
            fail('refusing to replace an existing Lean/protected source: ' + name)
        source = safe(candidate, name)
        if source.stat().st_size > 32 * 1024 * 1024:
            fail('source installation size bound: ' + name)
        overlay.append(dict(path=name, before_sha256=current, after_sha256=expected,
                            bytes=source.stat().st_size, action='replace' if current else 'add'))
    if sum(row['bytes'] for row in overlay) > 64 * 1024 * 1024:
        fail('source installation total bound')
    metadata = root / 'INSTALLATION_SOURCE_DISPOSITION.json'
    plan = dict(schema='math-gkm.ops.install-plan.v1', installed_root=str(root),
                candidate_root=str(candidate), source_manifest=str(manifest_path),
                source_manifest_sha256=manifest_hash, source_review=str(review_path),
                source_review_sha256=sha(review_path), overlay=overlay,
                unchanged_required=unchanged, protected_before=protected,
                metadata_before_sha256=sha(metadata) if metadata.exists() else None,
                exclusions=['MathGKM.lean candidate copy', 'README.md (root maintains current status)',
                            '.git', '.lake', '.bootstrap', '.scratch', 'compiled objects'],
                installation_performed=False,
                scope='Source/config/tests/docs installation only; no research activation or test-success claim')
    out = Path(args.out)
    if out.exists():
        fail('choose an unused plan path')
    atomic_json(out, plan)
    print(json.dumps(dict(plan=str(out), plan_sha256=sha(out), overlay_files=len(overlay),
                          overlay_bytes=sum(row['bytes'] for row in overlay))))

def apply(args):
    plan_path = Path(args.plan).resolve()
    if sha(plan_path) != args.plan_sha256:
        fail('exact installation plan hash differs')
    plan = read(plan_path)
    if plan.get('schema') != 'math-gkm.ops.install-plan.v1':
        fail('unknown installation plan')
    root = root_path(plan['installed_root'])
    candidate = Path(plan['candidate_root']).resolve()
    if not candidate.is_relative_to(root / '.scratch'):
        fail('candidate path changed')
    if sha(plan['source_review']) != plan['source_review_sha256']:
        fail('source review changed')
    manifest, manifest_hash = source_inputs(candidate, Path(plan['source_manifest']), Path(plan['source_review']))
    if manifest_hash != plan['source_manifest_sha256']:
        fail('accepted source manifest changed')
    for name, expected in {**plan['protected_before'], **plan['unchanged_required']}.items():
        if sha(safe(root, name)) != expected:
            fail('installed protected/prior source changed: ' + name)
    for row in plan['overlay']:
        name = row['path']
        if not allowed(name) or name in plan['protected_before']:
            fail('plan contains a disallowed replacement: ' + name)
        if manifest['files_sha256'].get(name) != row['after_sha256']:
            fail('overlay is not an accepted source: ' + name)
        destination = safe(root, name)
        if (sha(destination) if destination.exists() else None) != row['before_sha256']:
            fail('installed before-hash changed: ' + name)
    metadata = root / 'INSTALLATION_SOURCE_DISPOSITION.json'
    if (sha(metadata) if metadata.exists() else None) != plan['metadata_before_sha256']:
        fail('installed disposition metadata changed')
    required_free = max(512 * 1024 * 1024, 3 * sum(row['bytes'] for row in plan['overlay']))
    if shutil.disk_usage(root).free < required_free:
        fail('insufficient free space for source backups and installation record')
    record = Path(args.record_dir).resolve()
    if not record.is_relative_to(root / 'evidence') or record.exists():
        fail('record directory must be fresh and inside math_gkm/evidence')
    record.mkdir(parents=True)
    atomic_copy(plan_path, record / 'PLAN.json')
    atomic_copy(plan['source_manifest'], record / 'ACCEPTED_SOURCE_MANIFEST.json')
    atomic_copy(plan['source_review'], record / 'ACCEPTED_SOURCE_REVIEW.json')
    atomic_json(record / 'INTENT.json', dict(plan_sha256=args.plan_sha256,
                phase='prepared; source installation only', created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    changes = []
    try:
        for row in plan['overlay']:
            name = row['path']; destination = safe(root, name)
            if destination.exists():
                atomic_copy(destination, record / 'before' / name)
            atomic_copy(safe(candidate, name), destination)
            if sha(destination) != row['after_sha256']:
                fail('copy verification failed: ' + name)
            changes.append(dict(path=name, before_sha256=row['before_sha256'], after_sha256=sha(destination)))
            atomic_json(record / 'PROGRESS.json', changes)
        for name, expected in plan['protected_before'].items():
            if sha(safe(root, name)) != expected:
                fail('protected source changed during install: ' + name)
        names = sorted(set(plan['protected_before']) | set(plan['unchanged_required']) |
                       {row['path'] for row in plan['overlay']} | {'README.md'})
        actual = {name: sha(safe(root, name)) for name in names}
        if metadata.exists():
            atomic_copy(metadata, record / 'before' / metadata.name)
        source_disposition = candidate / metadata.name
        if source_disposition.exists():
            atomic_copy(source_disposition, record / 'CANDIDATE_SOURCE_DISPOSITION.json')
        installed_map = dict(schema='math-gkm.installation-source-disposition.v3',
            installation_performed=True, approved_source_manifest_sha256=manifest_hash,
            artifacts={name: dict(sha256=value, disposition='installed source/preserved input; current pin, not test evidence')
                       for name, value in actual.items()},
            protected_sources=plan['protected_before'],
            candidate_only_exclusions={'MathGKM.lean': 'preserve installed historical aggregate byte-for-byte'},
            acceptance_inputs={'MathGKM/NeutralV3Root.lean': 'neutral fixture, not discovered mathematics'},
            meaning='Operator source installation record; no activation, proof resolution, or test outcome inferred')
        atomic_json(metadata, installed_map)
        actual[metadata.name] = sha(metadata)
        installed_manifest = record / 'INSTALLED_SOURCE_MANIFEST.json'
        atomic_json(installed_manifest, dict(schema='math-gkm.installed-source.v1',
                    files_sha256=actual, accepted_candidate_manifest_sha256=manifest_hash,
                    installation_plan_sha256=args.plan_sha256,
                    preserved_aggregate_sha256=actual['MathGKM.lean']))
        atomic_json(record / 'INSTALLED_REVIEW_TEMPLATE.json', dict(accepted=False,
                    manifest_sha256=sha(installed_manifest),
                    scope='Requires independent installed-byte/source review; no test or live-activation approval'))
        atomic_json(record / 'RESULT.json', dict(installed=True, changes=changes,
                    protected_after={name: sha(root / name) for name in plan['protected_before']},
                    installed_manifest_sha256=sha(installed_manifest),
                    compiled_or_research_launched=False))
    except BaseException as exc:
        atomic_json(record / 'FAILURE.json', dict(error_type=type(exc).__name__, error=str(exc),
                    changed=changes, action='Sources/backups retained; inspect partial installation before creating a new exact plan'))
        raise
    print(json.dumps(dict(record_dir=str(record), installed_files=len(changes),
                          installed_manifest=str(installed_manifest),
                          installed_manifest_sha256=sha(installed_manifest),
                          aggregate_preserved=sha(root / 'MathGKM.lean'))))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    create = commands.add_parser('prepare')
    create.add_argument('--installed', default=str(EXPECTED_ROOT))
    create.add_argument('--candidate', required=True)
    create.add_argument('--source-manifest', required=True)
    create.add_argument('--review', required=True)
    create.add_argument('--out', required=True)
    create.set_defaults(function=prepare)
    install = commands.add_parser('apply')
    install.add_argument('--plan', required=True)
    install.add_argument('--plan-sha256', required=True)
    install.add_argument('--record-dir', required=True)
    install.set_defaults(function=apply)
    args = parser.parse_args()
    args.function(args)

if __name__ == '__main__':
    main()
