import MathGKM.Target449cffc38d986722fd99a26f
import MathGKM.Original
import Lean
def Acceptedda787402541b3db51fb80ca6.interface : MathGKM.Target449cffc38d986722fd99a26f.Interface :=
  (
    True.intro
  )
theorem Acceptedda787402541b3db51fb80ca6.transport : MathGKM.Target449cffc38d986722fd99a26f.Transport Acceptedda787402541b3db51fb80ca6.interface :=
  (
    True.intro
  )
theorem Acceptedda787402541b3db51fb80ca6.obligation : MathGKM.Target449cffc38d986722fd99a26f.Goal Acceptedda787402541b3db51fb80ca6.interface :=
  (
    ⟨(
      show (
        Neutral.Q
      ) from (
        True.intro
      )
    ), (
      show (
        Neutral.Q
      ) from (
        True.intro
      )
    )⟩
  )
