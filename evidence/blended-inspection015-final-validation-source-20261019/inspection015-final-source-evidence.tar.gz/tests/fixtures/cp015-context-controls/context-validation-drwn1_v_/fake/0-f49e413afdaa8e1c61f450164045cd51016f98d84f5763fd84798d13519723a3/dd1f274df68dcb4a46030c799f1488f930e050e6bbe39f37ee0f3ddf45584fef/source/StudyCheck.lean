import MathGKM.Targete4471caa7e0251963c386b80
import MathGKM.Counterfeit
import Lean
def StudyInterface : MathGKM.Targete4471caa7e0251963c386b80.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Targete4471caa7e0251963c386b80.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Targete4471caa7e0251963c386b80.Goal StudyInterface :=
  (
    ⟨(
      show (
        Neutral.P
      ) from (
        True.intro
      )
    ), (
      show (
        Neutral.P
      ) from (
        True.intro
      )
    )⟩
  )
