import MathGKM.Target47114a92ed4e4dce1538da62
import MathGKM.Original
import Lean
def StudyInterface : MathGKM.Target47114a92ed4e4dce1538da62.Interface :=
  (
    True.intro
  )
theorem StudyTransport : MathGKM.Target47114a92ed4e4dce1538da62.Transport StudyInterface :=
  (
    True.intro
  )
theorem StudyObligation : MathGKM.Target47114a92ed4e4dce1538da62.Goal StudyInterface :=
  (
    ⟨(
      show (
        True
      ) from (
        True.intro
      )
    ), (
      show (
        True
      ) from (
        True.intro
      )
    )⟩
  )
