# Closed014 integration: independent resource/reproducibility audit

The six NEW validator cases and all three OLD-v3 inspector comparisons are closed and pass their recorded engineering checks. The no-Lean identity aggregate passes all six expected comparisons. This is a read-only reconciliation of existing receipts and source bytes; I ran no tests, compiler, production behavioral import, researcher call or process intervention.

Detailed audit: `/private/tmp/math_gkm_closed014_integration_resource_repro_audit_20261019.json`, SHA256 `06e8c97db70b9119c30ac8100c5fe18fb47d4972f69b5f85370cbb48854f8e93`.

| NEW case | Compiles | Kernel replays | Premise inspections | FINISHED file bindings |
|---|---:|---:|---:|---:|
| PUBLIC restricted-branch pilot | 10 | 10 | 1 | 19 |
| Neutral addition identity | 4 | 4 | 1 | 13 |
| Full-Mathlib identity | 4 | 4 | 1 | 13 |
| Unused-definition base | 5 | 5 | 1 | 9 |
| Exact repeat | 5 | 5 | 1 | 9 |
| Changed unused definition | 5 | 5 | 1 | 9 |
| Total | 33 | 33 | 6 | 72 |

All72 NEW operations have exit0, no termination and no operational incompleteness. Every one of the72 FINISHED file hashes, exact task/solution/required binding, producer nonce/content completion, original context source, pin and executable hash was independently reconciled. The recorded exact full persisted-receipt reuse checks passed. The resulting premise lists contain only the permitted standard axioms; these neutral NEW cases report no axioms, and the restricted branch fixture remains scoped by its own independent mathematical audit.

All three OLD-v3 comparisons use the same fresh, replayed object bytes as their corresponding NEW cases. I independently read each bounded335,200-byte old catalog, compared every root's complete declaration/closure name-origin sets and axiom sets with its NEW result, recomputed the old type/body semantic digests, checked NEW identities against their recorded result catalogs, and rehashed the retained replayed objects. The unused definition is present in the complete root catalog and absent from the root's transitive proof closure. Across both encodings separately, exact repeats preserve its identity, changing its unused body changes its identity, and the unchanged proof root retains its identity. All six aggregate comparisons match the immutable engineering fixture specification. This is an OLD010 inspector-only comparison, not execution or admission by an old010 controller and not equality between different hash encodings.

The014 source audit remained exact at final reconciliation: all368 frozen copies and live source hashes matched manifest `86b321c9628ce7493c89e06ab0000050375974fd7fe10c1c28181e5467e8ee3f`; all49 externally protected inputs matched. A later authorized015 constructor may change its narrow source paths and must receive its own frozen review. The current014 plan remains provisional and does not authorize installation.

All outer watchers exited0 with cleanup[] and unchanged007 limits. The largest NEW/OLD observed native charge was1,006,588,168B; the largest aggregate RSS was5,847,498,752B. The longest outer run was187.574s (PUBLIC pilot); the full-Mathlib run was130.993s. No limit change or OOM is inferred or needed from these observations. Raw outcomes, sources, FINISHED, REBUILD, pins, profiles and compact catalogs remain locally retained for the later integration evidence package.

At00:08:13UTC all76 recorded native process births belonging to these CLOSED checks were absent, with no cleanup holds. The separate approved source015 constructor tree was active and small; it is not an orphan. Sole caffeinate3452 remained running, OS memory free58%, disk204,278,112,256B and swap used0.19MiB. Snapshot `/private/tmp/math_gkm_closed014_final_quiescence_20261019.json`, SHA256 `2ab0ac93338e949bd0df36d8504c3879d8732752df89f398f170e03a54052055`.

These outcomes establish the bounded fixture engineering paths. They do not install the candidate, resolve the general Markov conjecture or full manuscript root, retroactively admit original pilot submissions to the main registry, certify an arbitrary host edit, prove cold dependency bootstrap or authorize a new research campaign. Root-controlled015 source review, affected tests and actual final deployment verification remain separate obligations.
