# Frozen014 narrow independent source review

Final source-only review, 2026-10-19. Reviewer /root/blend_source_review.
Candidate /Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018.
Exact manifest evidence/construction-v3/source-audit-014/SOURCE_MANIFEST.json SHA25686b321c9628ce7493c89e06ab0000050375974fd7fe10c1c28181e5467e8ee3f.

Disposition: SOURCE-SAFETY CLEAR for root-authorized bounded sequential execution of the same two individual Producer012 methods and existing pure controls. No installation, deployed-preflight, capacity/differential or campaign success/activation is established. Reviewer ran no tests, compilers, behavioral imports, models or mathematical work and edited no repo source.

Independently streamed and rehashed all368 listed live/frozen source files: zero mismatches; no013 manifest source entry removed. All listed metadata hashes match. Protected before/after maps contain4509 entries, are equal, and their actual listed bytes match. Prior-source, Lean math/aggregate, contracts/pins/root, context/closure/admission/receipt/feedback/controller/resource and seed/study inputs remain protected. Changed existing bytes are only inspection_stream.py, test_inspection012.py and final disposition; new doc is inspection014.md.

Mechanical runtime fixes: expr now constructs a local key with explicit type Lean.Meta.Sym.ExprPtr, uses exactly that key for both lookup and insertion, and therefore retains the reviewed same-live-Expr pointer identity semantics. declaration's optional-body match binds an explicit Json monadic result; the present branch uses local do/let-id/pure Json rather than an escaping return in the enclosing M Unit action. Body absence remains Json.null and opaque bodies remain included. No encoding field/order, traversal/catalog/axiom/required-use rule, trusted nonce/hash/output/receipt binding, cap, target or mathematical statement changed.

The tests now expose rather than mask the prior observed false-positive mechanism. Both producer methods first require the complete utility prelude, without a later command, to elaborate successfully with actual exit0, no termination/incompleteness and exactly empty stdout/stderr. Capacity setup uses exactly the same128-byte-record/512-byte-total test-only prelude as its intentional negatives; raw clean-setup source and process hashes are retained. Production1MiB/32MiB limits are unchanged.

The intended-capacity predicate independently requires clean setup, actual exit1, no termination/incompleteness, authenticated expected failure category and exactly one remaining deliberate IO-error diagnostic after removing the validated fixed token. Additional warnings, utility errors, arbitrary output or resource signals cannot satisfy it. A small actual generated negative inserts an ill-typed unrelated utility immediately before the same subsequent run_cmd, explicitly requires its real authenticated capacity token and then asserts the strict predicate rejects this case. Thus valid failure evidence alone is not enough to relabel unrelated elaboration failure as successful intended rejection. Whether the pinned compiler emits exactly the expected diagnostic remains an ordinary test question, not assumed source success.

Existing eight SHA256/chunk vectors, actual completed producer-consumer binding and both bounds in both modes/next-role projections remain. Producer subprocesses still use Lean-j1,60seconds,1MiB output, sequential watched execution and raw record retention. SHA/completion tests now explicitly require no resource incompleteness/stderr and exact completion-marker output before parsing. The extra clean-prelude and unrelated-error runs remain inside the two named selectors and do not authorize the inherited full Producer class or increased budgets.

Exact affected selectors:
- tests.test_inspection012.Producer012.test_sha256_vectors_chunking_and_completed_producer_consumer
- tests.test_inspection012.Producer012.test_producer_actual_record_and_total_bounds_ingest_requests

The source-only independent014 constructor is reported ended normally at198.656seconds with rc0 and clean cleanup; that fact does not mean generated Lean ran. Original013 constructor timeout360.198seconds/outerrc1 remains a failed invocation. Prior012 evidence stays28purePASS plus producer1FAIL/1ERROR. Actual013 stays32purePASS plus raw producer1PASS/1FAIL; its capacity PASS is expressly inconclusive because unrelated utility elaboration errors preceded the authentic token. Empty digest output was never a full-vector pass. None of these observations is rewritten by this review.

No additional source-safety blocker found in the narrow delta. Functional verification remains pending the finite actual tests, followed only upon separate root decision by original deployed/full-Mathlib/strict-negative/immutable-capacity/differential controls. No mathematical help or research-seed change is authorized. This memo is closed; subsequent results require separate receipts.
