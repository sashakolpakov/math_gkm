import MathGKM.Control
import Root
theorem ControllerRootCheck : Root := @Control
#print axioms ControllerRootCheck
