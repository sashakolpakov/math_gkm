import MathGKM.Control
import Root
theorem ControllerRootCheck : Root := @Changed
#print axioms ControllerRootCheck
