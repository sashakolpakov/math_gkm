namespace MathGKM.InspectionIdentityControl013

def unused : Nat := 1

end MathGKM.InspectionIdentityControl013
