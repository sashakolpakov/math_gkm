namespace MathGKM.InspectionIdentityControl013

def unused : Nat := 2

end MathGKM.InspectionIdentityControl013
