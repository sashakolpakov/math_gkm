# Trusted inspection capacity audit — read-only, fixed study unchanged

The observed failures expose representation and traversal limits in the inspection path. They do not refute the submitted propositions. The current comparison remains frozen: no cap changes, proof suggestions, code patches, new model calls or Lean runs were performed for this audit. Engineering options below concern a separately versioned future harness after this comparison.

## Observed evidence

| Main submission | Inspector artifact bytes | Outcome |
| --- | ---: | --- |
| round0/first | 54,509,041 | Inspector exited0;32MiB artifact gate rejected. |
| round0/second | 74,720,053 | Inspector exited0;32MiB artifact gate rejected. |
| round0/third | No artifact | Inspector exited1: dependency traversal exhausted. |
| round1/structural bridge | 12,610,114 | Actual compile, kernel replay and trusted inspection admitted the exact obligation/interfaces. |
| round1/finite WeakLC submission | 350,812,587 | Inspector exited0; artifact rejected; no reusable FINISHED bundle. |
| round1/third | 74,943,870 | Inspector exited0; artifact rejected. |

The first two and last oversized attempts retained finished failure bundles. The350.8MB attempt additionally exceeds the256MiB total retained-validator-bundle limit; its result.json is marked finished but FINISHED.json is absent. A finished result file is not a reusable acceptance receipt. The third round0 failure is specifically StudyInspect.lean: dependency traversal exhausted, not a kernel rejection or a detected forbidden axiom. No theorem admission should be inferred from inspector exit0 without the parser, premise/context and finished-bundle gates.

## Why the output grows

The trusted generator in proof_audit.inspector first enumerates the imported environment and catalogs EVERY declaration whose origin is a selected frozen module, including declarations unused by the submitted proof. For each it materializes the complete type and optional opaque-inclusive body as `(repr ...).pretty 100000000` strings. It then independently traverses each of the three checked roots and emits complete type/body strings AGAIN for qualifying used declarations. The first row includes the complete catalog, and individual rows also include their used constants. The final Json array is constructed and compressed as one complete value before writing the file.

This is a verbose expression-tree representation, not a small source/proof-script encoding. Derived Expr representation records recursive syntax rather than an explicit shared-expression dictionary; runtime subexpression sharing is not expressed as reusable node references. Large elaborated proof bodies, including generated auxiliary declarations, can therefore dominate while source text and the number of declarations remain small. Exact sharing statistics and field distributions of the rejected350.8MB artifact were not measured; it was not loaded for this audit.

The admitted12.61MB example gives direct bounded evidence. It has67 catalog declarations and48 used-declaration records across the three roots:115 emitted records but only73 distinct declaration names. Catalog type strings total94,094 characters; catalog bodies total6,357,982. Used type/body strings contribute another6,145,829. All emitted type/body strings total12,597,905 characters, versus6,456,551 when each declaration is retained once. One frame_left body accounts for5,621,489 characters in the catalog. Thus whole-declaration duplication alone nearly doubles this example; it is not sufficient to conclude that deduplication alone would bring the350.8MB case under32MiB.

There is a separate dependency-walk issue. Each root initializes a List-based todo and seen list, and decrements200000fuel BEFORE asking whether the popped name was already seen. Dependencies are appended for every newly visited declaration's type/body and for inductive constructors. Lean's pinned Expr.getUsedConstants already deduplicates constants within one expression using a visited-expression set and NameHashSet (Lean/Util/FoldConsts.lean); the remaining repeats arise across declarations and paths through the dependency graph. A repeated pop still consumes fuel, and seen.contains is linear. Therefore exhaustion does not establish that200000 distinct declarations were required. There is also a boundary case: fuel==0 rejects even if the final pop emptied the todo list. No claim about the number of unique dependencies or likely speedup is justified without new-version instrumentation.

## What must remain trustworthy

The proof-soundness path must still freshly compile and independently kernel-replay exact original-context targets and all generated typed laws, then inspect the actual checked environment. Each root must exist with a body. Transitive traversal must retain type dependencies, opaque-inclusive bodies and the currently required constructor handling; every nonpermitted axiom remains a rejection, with only propext/Classical.choice/Quot.sound allowed. Explicit required constants must be in the actual closure. Candidate-printed axiom reports or claimed dependencies do not substitute for this check.

Exact frozen source/context/target ordering, pinned binaries, sandbox identity, object hashes before/after inspection and original source bindings remain mandatory. Conservative-extension section laws, exact representation equivalences, dependent pushforward laws and composed residual antecedents are actual Lean obligations. Smaller inspection records must not erase any such premise or typed law. Finished task/solution/required-list/source receipt bindings must remain exact.

Complete declaration version coverage has a different purpose from dumping raw expressions: transfer/regression tests need identities of ALL frozen declarations in the inspected modules, including unused ones, and identities of the declarations actually used by the consumer. Current consumers reduce each type/body pair to SHA256 anyway. catalog_snapshot uses those digests for full retention, and evaluation intersects actual used-version digests with before/after catalogs to attribute changed-component use. Source-module hashes, names, comments, theorem counts or a candidate-supplied digest cannot replace those exact type/body identities. The current field named semantic_sha256 is an encoding identity, not a proof of semantic equivalence or mathematical novelty.

## Conservative options for a future separately reviewed version

1. **Fix dependency bookkeeping rather than raise fuel.** Use exact Name membership sets and enqueue/visit each dependency once, preserving the same checked-environment closure and axiom/required-constant conditions. Keep independent bounded limits for unique nodes, edges/work, wall time and memory; exhaustions remain explicit failures. Track unique visits, total edges, duplicate skips and the reason for stopping. A completed queue should be distinguished from an exhausted nonempty queue. This changes capacity accounting, not the logical predicate checked; differential tests must establish the same closures on runs both versions finish.

2. **Emit each declaration once and reference it.** One trusted declaration table can serve all root closures and the complete module catalog. Root rows carry exact declaration references, allowed axioms and required-use results. This preserves all existing data and removes obvious duplication, as the12.61MB example demonstrates. It is only a partial remedy: a single enormous unshared body can still exceed the fixed output bound.

3. **Replace verbose exported bodies with complete trusted fingerprints.** Compute versioned, deterministic cryptographic identities over the ENTIRE type and optional body from the trusted post-replay environment, with explicit tags/lengths and full expression/name/universe information. Hashing/serialization can stream or use a lossless shared-expression representation; keep complete per-declaration catalog coverage and actual used-closure identities. If a new canonical encoding is chosen, version it and validate its exact structural distinctions; do not silently normalize/drop proof bodies or change the comparison semantics. Lean's internal noncryptographic Expr.hash or pointer identity may assist an exact-equality cache but cannot be the external certificate. Raw source and target text stay retained for independent English/type audits, and detailed expressions can be retained as bounded side artifacts where useful. No proposer's fingerprint is trusted.

4. **Bound every stage, not only the file reader.** Keep current child memory/process/time/disk limits and the small control channel. Avoid constructing the full pretty-printed Json array, then parsing/copying it repeatedly. A redesigned producer/parser must remain bounded, authenticate ordered roots/complete counts/end markers, reject duplicate/conflicting identifiers, truncation, trailing data and mutated files, and bind the exact manifest in FINISHED receipts. Compression is only an encoding technique and needs a decompressed-size/work bound. The current32MiB artifact cap,64MiB result-read cap,256MiB finished-bundle cap and1MiB subprocess-output cap are distinct; simply raising the first cap would encounter other limits and could create much larger Python allocations. No change is proposed to any current cap.

The first two options can preserve full current string evidence with a new representation. Complete trusted fingerprints preserve the actual requirements consumed for version retention and used-component attribution but require a new schema and independent producer/consumer audit. Neither a small digest nor a compact encoding establishes new mathematical correctness by itself: compilation/replay/premise/context gates remain. Fixed resource limits necessarily leave some legitimate proofs outside operational capacity; no representation change promises universal admission.

## Comparison/review path

review() calls evaluate_pair before invoking the reviewer. Each side first gets catalog_snapshot, before any heldout adapter. A failed catalog prevents valid frozen-context/transfer measurement; it is not evidence of mathematical regression, no component transfer or an unsuccessful curiosity hypothesis. A returned invalid_frozen_context result can still be reported to the reviewer, while a thrown operational/retention exception may stop the arm. These cases should be classified separately from a valid paired non-solution.

The scope is narrower than “all unadmitted files are inspected.” catalog_snapshot copies the whole source snapshot but imports manifest.admitted_modules and their import closures. The generator only catalogs declarations actually loaded from selected frozen modules. Therefore an unrelated standalone unadmitted candidate file is not automatically imported; an unused/unadmitted declaration INSIDE an imported accepted module can still enlarge the catalog. Current round1 admitted roots include the structural-bridge source/accepted/target modules, while separate WeakLC/Ratios candidate modules are not import roots. Snapshot copying alone does not prove the350.8MB rejected proof enters the after-catalog.

At the final21:06:53UTC observation, BOTH frozen-context catalogs had passed:2,485,848bytes before and8,797,641bytes after. The first heldout adapter call had begun (calls5). The catalog-capacity risk therefore did not block this first episode evaluation; its later outcome is not yet observed here.

At the initial public status read, the arm was round2/review with4calls, before-catalog had passed at2,485,848bytes and after-catalog had no finished marker. That was ongoing validation, not a demonstrated catalog failure. Latest catalog-only statuses are recorded below; no suite statements, adapter tasks or answers were read. A capacity problem on either side can censor the comparison before adaptation even when the two sides have equal caps, so no superiority, mathematical regression or absence of transfer should be inferred from such a censored comparison.

## Necessary regression evidence before any future deployment

Preserve hidden forbidden-premise examples even when candidate reports falsely print no axioms; missing actual required constants; same proposition text in different original contexts; altered accepted dependencies; exact typed boundary/section/representation failures; conditional roots that retain open premises; and unfinished/mutated receipt rejection. Add neutral repeated-diamond dependency graphs with identical complete closures, a forbidden axiom behind many shared paths, exact fuel-boundary completion/exhaustion, unused declaration body changes, same-name/different-body/type variants, and module-copy/comment-only nontransfer. New compact records must reject duplicate/conflicting roots or declarations, missing coverage, malformed/truncated/oversized/corrupt streams and forged digests. A real kernel/premise/context positive and these intended negative reasons must pass under unchanged resource limits; infrastructure failures are not successful negative tests. No such new tests were run here.

## Bound observation metadata

```json
{
  "observed_utc": "2026-10-18T21:06:53.092877+00:00",
  "scope": "Read-only installed010 source audit plus finished main researcher validation metadata; no suite/tasks/adapter answers, no new models/Lean runs or source/cap edits",
  "sources": {
    "machinery/proof_audit.py": "9c8f8de8c2512f78c7409668bc118ebfb554cb287b010c09c486bd217becf296",
    "machinery/study_transfer.py": "c6dfdd392a2dace548328ca6ddb27935d80715b6d2482efd46a8cf32ee0f330e",
    "machinery/validation_receipts.py": "d7f46f84d7290a94e7b0f44f042893263364170eaf0117eca2693a0d71966701",
    "machinery/study_common.py": "1fddc7d61c8240fd1452c0a0dc38582db31742c1bd674813bb1cddebd02bf196"
  },
  "main_validation_results": [
    {
      "round": "0000",
      "path": "rounds/0000/checks/math/0-33615bc3f425f5c5b1e81773d7acc4d8a425e3cfc9fef3853d06a0a0541d81ea/a2294bc47a840ea474c60673c310e0953cf85ddfcefe014694ff11fc14c4c198/result.json",
      "result_sha256": "9a45da1051e0a4eb8a8245c91743dbb887bc25982dc602069c8078127c150426",
      "artifact_bytes": 54509041,
      "checked": false,
      "failure": "malformed or oversized inspector artifact",
      "finished_bundle": true
    },
    {
      "round": "0000",
      "path": "rounds/0000/checks/math/1-19c69ff450cac0efc59721dff03809ae23c0af091b11aed842d0f21966840f31/4c9c930cd7825601dea6f91bac83154400b811ed5a8e125faa1980ff5254cd91/result.json",
      "result_sha256": "4ad30ab3757d24b3be478a5712e16fe86f0a486937bf7c0b2de97a2fee32c5d5",
      "artifact_bytes": 74720053,
      "checked": false,
      "failure": "malformed or oversized inspector artifact",
      "finished_bundle": true
    },
    {
      "round": "0000",
      "path": "rounds/0000/checks/math/2-a88e830a316e2cc0e613341859211ec36a73e2d268a6c6bf58307191732f584a/96cc03b421276a5ee4201125198582e118fcc43fb5915cc668dea4195145d244/result.json",
      "result_sha256": "85a18219c7f2bad42856b6d54110c87de2199caeb4b1f09d3cfb2cb6db3f2c4e",
      "artifact_bytes": null,
      "checked": false,
      "failure": "trusted premise inspector failed",
      "finished_bundle": true
    },
    {
      "round": "0001",
      "path": "rounds/0001/checks/math/0-255ae72e4b91e839ca05e44e1163f7341cfb4071df7cb7fceedc133bee7bcd3b/95a4e0482c798d7a5531cd05e8f236270f1f8416f7a11916f92d4584ada3c847/result.json",
      "result_sha256": "13b7693f4e0c339efffea5926a1b4bea364bfad6619d6021c7a069ef519c0d51",
      "artifact_bytes": 12610114,
      "checked": true,
      "failure": null,
      "finished_bundle": true
    },
    {
      "round": "0001",
      "path": "rounds/0001/checks/math/1-4c91b51659dea93ba576bdce36ae8154db6efc17d4dc1b9718fefba69d0e4d70/394039a64ce011615b50f01ebf75a9a909a33b6660546ff3ec93bf0699862dfe/result.json",
      "result_sha256": "4fb5d8615df0cf4a65a91f8b18a38bbf9bed174ce75700ec77bf61f29d262830",
      "artifact_bytes": 350812587,
      "checked": false,
      "failure": "malformed or oversized inspector artifact",
      "finished_bundle": false
    },
    {
      "round": "0001",
      "path": "rounds/0001/checks/math/2-60794da96d8d69591371900fcb5dcd85b4932b069ad0fe9296c0fadc5c0d4927/9a89cbe71451f84cac88998f850ccd8d5e5db7165b3b45f2eb375ff7dd5357fd/result.json",
      "result_sha256": "e0da041eb8a87f6afce774642f1a2fce3b72b0d81938b1d7942c41dc5a12d8ae",
      "artifact_bytes": 74943870,
      "checked": false,
      "failure": "malformed or oversized inspector artifact",
      "finished_bundle": true
    }
  ],
  "public_controller": {
    "status": "running",
    "round": 2,
    "phase": "review",
    "calls": 5,
    "active": "/Users/sasha/math_gkm/.scratch/paired-v3-live-20261018-study-0004/arms/exploration/jobs/eval-episode-2-before"
  },
  "catalog_only_status": [
    {
      "side": "before",
      "finished": 1792357407.419136,
      "checked": true,
      "failure": null,
      "artifact_bytes": 2485848
    },
    {
      "side": "after",
      "finished": 1792357572.722156,
      "checked": true,
      "failure": null,
      "artifact_bytes": 8797641
    }
  ],
  "large_artifact_handling": "Only stat for54.5/74.7/350.8/74.9MB artifacts. No parsing or rescanning giant files. Existing12.61MB admitted result was read to measure its field lengths; no new proof run."
}
```
