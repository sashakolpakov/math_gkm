"""Adapted from freeze007: source-only report008 freeze; never imports candidate code."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

root = Path.cwd()
out = root / 'evidence/construction-v3/source-audit-008'
assert not out.exists(), '008 is immutable; never overwrite or retry'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024**2), b''): h.update(block)
    return h.hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

prior_path = root / 'evidence/construction-v3/source-audit-007/SOURCE_MANIFEST.json'
prior = json.loads(prior_path.read_text()); prior_hash = sha(prior_path)
assert (prior_path.parent / 'SOURCE_MANIFEST.sha256').read_text().split()[0] == prior_hash
progress_path = root / 'local.scratch/REPAIR008_PROGRESS.json'
progress = json.loads(progress_path.read_text())
assert progress['prior_manifest_sha256'] == prior_hash
for name, expected in progress['snapshot007'].items(): assert sha(root / name) == expected, name
substantive = ['machinery/study_policy.py', 'machinery/study.py', 'tests/test_report_contract008.py']
metadata = {'CONSTRUCTION_V3_AUDIT.json', 'INSTALLATION_SOURCE_DISPOSITION.json'}
allowed = set(substantive) | metadata
delta = {n: sha(root / n) for n, h in prior['files_sha256'].items() if sha(root / n) != h}
assert set(delta) <= set(substantive), set(delta) - set(substantive)
inputs = root / '.bootstrap/report-contract-008-inputs'
input_map = json.loads((inputs / 'INPUT_MANIFEST.json').read_text())
for name, expected in input_map.items(): assert sha(inputs / name) == expected, name
# Hash every prior snapshot without opening any historical campaign payloads.
snapshot = {str(p.relative_to(root)): sha(p)
            for p in (root / 'evidence/construction-v3').glob('source-audit-00[1-7]/**/*') if p.is_file()}
protected = {n: dict(before=h, after=sha(root / n), unchanged=h == sha(root / n))
             for n, h in prior['files_sha256'].items() if n not in allowed}
assert all(r['unchanged'] for r in protected.values())
# Independently constrain study.py edits to diagnostic forwarding within plan_with_repair.
old_study = (prior_path.parent / 'sources/machinery/study.py').read_text()
new_study = (root / 'machinery/study.py').read_text()
restored = new_study.replace("                diagnostic=policy.report_diagnostic(exc)\n                if diagnostic is not None: record['diagnostic']=diagnostic\n", '', 1)
restored = restored.replace("                if diagnostic is not None: repair['diagnostic']=diagnostic\n", '', 1)
assert restored == old_study, 'study.py exceeded diagnostic-only forwarding scope'
# All policy functions apart from report validation and rendered prompt stay exact.
old_policy = ast.parse((prior_path.parent / 'sources/machinery/study_policy.py').read_text())
new_policy = ast.parse((root / 'machinery/study_policy.py').read_text())
old_functions = {n.name: ast.dump(n) for n in old_policy.body if isinstance(n, ast.FunctionDef)}
new_functions = {n.name: ast.dump(n) for n in new_policy.body if isinstance(n, ast.FunctionDef)}
assert all(new_functions[n] == body for n, body in old_functions.items() if n not in ('record', 'prompt'))
selectors = ['tests.test_report_contract008.ReportContract008',
             'tests.test_role_report_contract.RoleReportContract',
             'tests.test_construction_v3.Pure.test_versions_findings_and_ordinary_default',
             'tests.test_construction_v3.Pure.test_charged_repair_new_request_and_next_researcher']
prefix = ('env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin '
          'GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null PYTHONDONTWRITEBYTECODE=1 '
          'TMPDIR=' + str(root / 'local.scratch') + ' /opt/homebrew/bin/python3 -m machinery.v3_validate '
          '--manifest evidence/construction-v3/source-audit-008/SOURCE_MANIFEST.json '
          '--review local.scratch/source-review-008.json --seconds 180 --label 008-report-contract ')
commands = [dict(command=prefix + ' '.join(selectors), status='PREPARED ONLY; independent frozen source audit first')]
out.mkdir(parents=True)
for name in ['INPUT_MANIFEST.json', *input_map]:
    dest = out / 'inputs' / name; dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(inputs / name, dest)
shutil.copyfile(__file__, out / 'freeze_sources.py')
save(out / 'VALIDATION_PLAN.json', dict(tests_run=False, selectors=selectors, commands=commands,
    sequential_only=True, gate='STOP: independent frozen source audit before tests; root owns tests, installation and fresh restart',
    unchanged_controls='Every existing mathematical/resource negative control remains byte-identical007; selectors do not expand scope; no hosted calls or real campaigns.'))
save(out / 'PRIOR_EVIDENCE.json', dict(prior_manifest_sha256=prior_hash,
    prior_snapshots_sha256=snapshot, tests_run=False,
    disposition='Prior snapshots and failed runs preserved unchanged; no old payloads edited, normalized, retried or relabeled.'))
save(out / 'PROMPT_INPUT_PROVENANCE.json', dict(inputs_sha256=input_map,
    input_manifest_sha256=sha(inputs / 'INPUT_MANIFEST.json'), prompt_source='machinery/study_policy.py:prompt',
    prompt_source_sha256=sha(root / 'machinery/study_policy.py'),
    rendered_prompt_regression='tests.test_report_contract008.ReportContract008.test_actual_rendered_prompts_define_hypothesis_namespace',
    rendered_prompts_executed=False, root_prelaunch_review='Caller-owned prerequisite stated in supplied ROOT_REQUIREMENTS_008.json; no constructor attestation of a separate review artifact',
    independent_frozen_source_audit='Required after freeze and before any tests; root owns it', tests_run=False))
save(out / 'STATIC_REVIEW.json', dict(method='Source inspection, AST/JSON parsing and streaming hashes only; no candidate imports',
    tests_run=False, compilers_run=False, probes_run=False, campaigns_run=False,
    substantive_changes=substantive, changed_existing_files=delta,
    protected=protected, prior_manifest_sha256=prior_hash,
    scope='Actual proposer/researcher report contract; allowlisted typed findings[index].reference diagnostic; diagnostic-only forwarding in plan_with_repair; neutral pure regressions.',
    preserved='Exact staged reference membership including retained historic versions; unchanged version hashing, strict rejection, work kinds, charged IDs/counts/budgets, prospective commitment, SEED, all mathematical/resource/model/arm/curation scopes.',
    source_checks=['All prior manifest paths outside allowed scope byte-identical007',
                   'All study.py text outside two diagnostic-forwarding insertions exact007',
                   'All existing policy functions except record/prompt AST-identical007',
                   'All prior001-007 snapshot bytes streamed and retained']))
paths = set(prior['files_sha256']) | set(substantive)
paths.update(str(p.relative_to(root)) for p in prior_path.parent.iterdir() if p.is_file())
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file())
for name in sorted(paths):
    p = root / name
    if p.suffix == '.py': ast.parse(p.read_text(), filename=name)
    elif p.suffix == '.json': json.loads(p.read_text())
disposition = json.loads((root / 'INSTALLATION_SOURCE_DISPOSITION.json').read_text())
for name in sorted(paths - metadata):
    old = disposition['artifacts'].get(name, {})
    disposition['artifacts'][name] = dict(sha256=sha(root / name), disposition=old.get('disposition',
        'archive exact008 source/provenance; no acceptance' if name.startswith('evidence/') else 'ship source/acceptance artifact after root audit'))
disposition['metadata_bound_by'] = 'source-audit-008/SOURCE_MANIFEST.json binds exact install map and current audit'
disposition['runtime_and_acceptance_overlay'] = sorted(set(disposition['runtime_and_acceptance_overlay']) | set(substantive))
disposition['meaning'] = 'Source disposition only; no installation or activation; root owns tests/install/restart after independent frozen source audit. All failed runs preserved.'
save(root / 'INSTALLATION_SOURCE_DISPOSITION.json', disposition)
old_audit = json.loads((root / 'CONSTRUCTION_V3_AUDIT.json').read_text())
remaining = ['Independent frozen source audit008 required before tests; STOP',
             'Tests prepared, tests_run=false; root owns tests, installation and fresh restart',
             'All failed runs and prior evidence preserved; no runtime acceptance claimed']
audit = {**old_audit, 'invocation': 'report-contract-repair008',
    'status': 'FROZEN source only; STOP for independent frozen source audit',
    'checkpoint': 'evidence/construction-v3/source-audit-008/SOURCE_MANIFEST.json',
    'prior_checkpoint': dict(manifest=str(prior_path.relative_to(root)), sha256=prior_hash),
    'changed_files_sha256': {n: sha(root / n) for n in paths if n not in metadata and prior['files_sha256'].get(n) != sha(root / n)},
    'protected': protected, 'tests_run': False, 'compilers_run': False, 'preflights_run': False,
    'probes_run': False, 'campaigns_launched': False, 'approved_inputs_sha256': input_map,
    'actual_prior_evidence': dict(checkpoint007_manifest_sha256=prior_hash, disposition='007 stays007; all failed runs preserved; no008 execution'),
    'planned_commands': commands, 'remaining': remaining, 'substantive_changes': substantive}
save(root / 'CONSTRUCTION_V3_AUDIT.json', audit)
hashes = {n: sha(root / n) for n in sorted(paths)}
changed = {n: h for n, h in hashes.items() if prior['files_sha256'].get(n) != h}
assert set(n for n in changed if n in prior['files_sha256']) <= allowed
for name, expected in snapshot.items(): assert sha(root / name) == expected, name
for name, expected in hashes.items():
    dest = out / 'sources' / name; dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, dest); assert sha(dest) == expected; dest.chmod(0o444)
manifest = dict(schema='math-gkm.frozen-source-audit.v8', invocation='report-contract-repair008',
    created_utc=datetime.now(timezone.utc).isoformat(), tests_run=False, compilers_run=False,
    probes_run=False, campaigns_run=False, files_sha256=hashes, changed_files_sha256=changed,
    substantive_changes=substantive, protected=protected,
    prior_checkpoint=dict(path=str(prior_path.relative_to(root)), sha256=prior_hash),
    source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',
    validation_plan='evidence/construction-v3/source-audit-008/VALIDATION_PLAN.json',
    prompt_input_provenance='evidence/construction-v3/source-audit-008/PROMPT_INPUT_PROVENANCE.json',
    source_copies='sources/<workspace-relative-path>', unshipped_bootstrap_sources_required=False,
    execution_gate='STOP: independent frozen source audit before tests; root owns tests, installation and fresh restart')
save(out / 'SOURCE_MANIFEST.json', manifest)
(out / 'SOURCE_MANIFEST.sha256').write_text(sha(out / 'SOURCE_MANIFEST.json') + '  SOURCE_MANIFEST.json\n')
for p in out.rglob('*'):
    if p.is_file(): p.chmod(0o444)
result = dict(checkpoint=str(out.relative_to(root)), sha256=sha(out / 'SOURCE_MANIFEST.json'),
    substantive_changes=substantive, files=len(hashes), protected_unchanged=True,
    prior_snapshots_unchanged=True, tests_run=False, prepared_selectors=selectors,
    status='STOP: independent frozen source audit; root owns tests/install/restart')
save(progress_path, result)
print(json.dumps(result))
