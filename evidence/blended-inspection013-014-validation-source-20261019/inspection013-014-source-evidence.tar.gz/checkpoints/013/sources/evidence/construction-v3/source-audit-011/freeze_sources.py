"""Source-only freeze: stdlib AST/JSON/hashes/copies, no candidate imports."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

root=Path.cwd(); out=root/'evidence/construction-v3/source-audit-011'
assert not out.exists(),'011 immutable; never overwrite'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''): h.update(b)
    return h.hexdigest()
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
inputs=root/'.bootstrap/inspection011-inputs'
im=json.loads((inputs/'INPUT_MANIFEST.json').read_text())
req=json.loads((inputs/'ROOT_REQUIREMENTS_011.json').read_text())
for name,info in im['files'].items(): assert sha(inputs/name)==info['sha256'],name
prior_path=root/req['prior_checkpoint']['path']
assert sha(prior_path)==req['prior_checkpoint']['sha256']
prior=json.loads(prior_path.read_text())
protected={n:dict(before=h,after=sha(root/n)) for n,h in req['protected_before_sha256'].items()}
assert all(v['before']==v['after'] for v in protected.values())
old_evidence={str(p.relative_to(root)):sha(p) for d in (root/'evidence/construction-v3').glob('source-audit-*')
    for p in d.rglob('*') if p.is_file()}
substantive=['machinery/proof_audit.py','machinery/inspection_stream.py','machinery/own_feedback.py',
    'machinery/completion.py','machinery/study_completion.py','machinery/study_transfer.py',
    'machinery/study_policy.py','machinery/study_knowledge.py','machinery/validation_receipts.py',
    'tests/test_inspection011.py','tests/test_inspection011_fixture.py','tests/test_capacity_repair005.py',
    'docs/inspection011.md']
# Update only reproduction disposition; installation stays held.
disposition_path=root/'INSTALLATION_SOURCE_DISPOSITION.json'
disposition=json.loads(disposition_path.read_text())
for n in substantive:
    disposition['artifacts'][n]=dict(sha256=sha(root/n),
        disposition='ship exact011 source for independent review/reproduction; no installation authorized')
disposition['inspection011']=dict(source_only=True,installation_performed=False,
    new_modules=['machinery/inspection_stream.py','machinery/own_feedback.py'],
    schema='math-gkm.inspection-dag.v2',prior_receipts='require charged fresh schema2 check',
    gate='Independent source review, mandatory regressions and supervisor large fixture before any installation')
save(disposition_path,disposition)
allowed=set(substantive+['INSTALLATION_SOURCE_DISPOSITION.json'])
delta={n:sha(root/n) for n,h in prior['files_sha256'].items() if sha(root/n)!=h}
assert set(delta)<=allowed,delta
for n in substantive:
    if n.endswith('.py'): ast.parse((root/n).read_text(),filename=n)
out.mkdir(parents=True)
for name in ['INPUT_MANIFEST.json',*im['files']]:
    dest=out/'inputs'/name; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(inputs/name,dest)
shutil.copyfile(__file__,out/'freeze_sources.py')
selectors=['tests.test_inspection011','tests.test_capacity_repair005.Parser005',
    'tests.test_construction_v3.CheckedMath','tests.test_construction_v3_repair.CheckedRepair',
    'tests.test_context_revision.ContextRevision','tests.test_report_contract008','tests.test_role_report_contract',
    'tests.test_inspection011_fixture.Supervisor011']
prefix=('env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin '
    'PYTHONDONTWRITEBYTECODE=1 TMPDIR='+str(root/'local.scratch')+' /opt/homebrew/bin/python3 -m unittest ')
save(out/'VALIDATION_PLAN.json',dict(tests_run=False,compilers_run=False,selectors=selectors,
    commands=[prefix+' '.join(selectors)],sequential_only=True,
    gate='STOP: independent frozen source review before ANY execution',
    fixture_schema='docs/inspection011.md',
    mandatory_remaining=['Supervisor exact immutable large pilot closure and external SHA256',
        'Repeated diamond/hidden forbidden sharing exact closure and exact real traversal-boundary fixtures',
        'All existing intended mathematical negatives must reject mathematically, not by infrastructure failure',
        'Deterministic actual ingestion to next role request for every diagnostic class and private canary',
        'Independent audit of generated Lean syntax, structural fields/cache, failure artifact provenance and caps',
        'Corrupt but syntactically valid stream mutation needs independent producer/parser integrity review'],
    measurements=['artifact bytes','distinct nodes/edges/duplicates','wall time','native/RSS receipts','actual admission status']))
save(out/'PROMPT_INPUT_PROVENANCE.json',dict(input_manifest_sha256=sha(inputs/'INPUT_MANIFEST.json'),
    prompt_sha256=im['approved_exact_prompt_sha256'],inputs=im['files'],
    source_only=True,tests_run=False,compilers_run=False,prior_checkpoint=req['prior_checkpoint']))
save(out/'PRIOR_EVIDENCE.json',dict(prior_checkpoint=req['prior_checkpoint'],
    all_prior_source_checkpoint_files_sha256=old_evidence,
    disposition='All prior source checkpoints/failed runs/pilot evidence retained unchanged; no011 execution'))
save(out/'STATIC_REVIEW.json',dict(method='Source reads, AST/JSON parsing, streaming hashes only',
    tests_run=False,compilers_run=False,behavioral_imports_run=False,probes_run=False,
    protected=protected,changed_existing=delta,new_source_paths=[n for n in substantive if n not in prior['files_sha256']],
    remaining='Uncompiled/unexecuted engineering candidate; mandatory plan evidence not yet established. No mathematical result.',
    schema_description='docs/inspection011.md',installation_performed=False))
paths=set(prior['files_sha256'])|set(substantive)|{'INSTALLATION_SOURCE_DISPOSITION.json'}
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file())
hashes={}
for n in sorted(paths):
    p=root/n
    if p.suffix=='.py': ast.parse(p.read_text(),filename=n)
    if p.suffix=='.json': json.loads(p.read_text())
    hashes[n]=sha(p)
for n,h in old_evidence.items(): assert sha(root/n)==h,n
for n,h in hashes.items():
    dest=out/'sources'/n; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/n,dest); assert sha(dest)==h; dest.chmod(0o444)
manifest=dict(schema='math-gkm.frozen-source-audit.v11',invocation='engineering-only-inspection011',
    created_utc=datetime.now(timezone.utc).isoformat(),tests_run=False,compilers_run=False,probes_run=False,
    behavioral_imports_run=False,campaigns_run=False,files_sha256=hashes,
    changed_files_sha256={n:h for n,h in hashes.items() if prior['files_sha256'].get(n)!=h},
    substantive_changes=substantive,protected=protected,prior_checkpoint=req['prior_checkpoint'],
    validation_plan=str((out/'VALIDATION_PLAN.json').relative_to(root)),
    source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',source_copies='sources/<workspace-relative-path>',
    execution_gate='STOP for independent source review BEFORE tests/compilers/preflight/installation/relaunch')
save(out/'SOURCE_MANIFEST.json',manifest)
checkpoint=sha(out/'SOURCE_MANIFEST.json')
(out/'SOURCE_MANIFEST.sha256').write_text(checkpoint+'  SOURCE_MANIFEST.json\n')
for p in out.rglob('*'):
    if p.is_file(): p.chmod(0o444)
result=dict(checkpoint=str(out.relative_to(root)),sha256=checkpoint,tests_run=False,compilers_run=False,
    changed_paths=sorted(allowed),protected_unchanged=True,prior_evidence_unchanged=True,status='STOP: independent source review')
save(root/'local.scratch/CONSTRUCTION011_PROGRESS.json',result)
print(json.dumps(result))
