"""Adapted from freeze009.py: test-target-only010 freeze; source/AST/JSON/hashes only."""
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import shutil

root = Path.cwd()
out = root / 'evidence/construction-v3/source-audit-010'
assert not out.exists(), '010 is immutable; never overwrite or retry'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

progress = root / 'local.scratch/REPAIR010_PROGRESS.json'
prior_path = root / 'evidence/construction-v3/source-audit-009/SOURCE_MANIFEST.json'
prior = json.loads(prior_path.read_text())
prior_hash = sha(prior_path)
assert (prior_path.parent / 'SOURCE_MANIFEST.sha256').read_text().split()[0] == prior_hash
save(progress, dict(status='Source checks in progress; no execution', prior_manifest_sha256=prior_hash,
                    tests_run=False, resume_script='local.scratch/freeze010.py'))
inputs = root / '.bootstrap/test-finding-010-inputs'
input_map = json.loads((inputs / 'INPUT_MANIFEST.json').read_text())
for name, expected in input_map.items():
    assert sha(inputs / name) == expected, name
observed = json.loads((inputs / 'observed009-intent.json').read_text())
result009 = json.loads((inputs / 'observed009-result.json').read_text())
assert observed['manifest_sha256'] == prior_hash
assert result009['returncode'] == 1
assert result009['log_sha256'] == sha(inputs / 'observed009-run.log')
assert result009['source_mismatches_after'] == []
test_name = 'tests/test_role_report_contract.py'
substantive = [test_name]
delta = {n: sha(root / n) for n, h in prior['files_sha256'].items() if sha(root / n) != h}
assert set(delta) == {test_name}, delta
protected = {n: dict(before=h, after=sha(root / n), unchanged=h == sha(root / n))
             for n, h in prior['files_sha256'].items() if n != test_name}
assert all(r['unchanged'] for r in protected.values())
old_test = (prior_path.parent / 'sources' / test_name).read_text()
new_test = (root / test_name).read_text()
expected = old_test
for state in ('accepted', 'staged'):
    old_line = f"                            self.assertEqual({state}['findings'][-1]['evidence'], value if present else [])\n"
    new_lines = (
        f"                            reference = {state}['portfolio'][candidate['hypotheses'][0]['id']]['reference']\n"
        f"                            finding = next(f for f in reversed({state}['findings']) if f['reference'] == reference)\n"
        "                            self.assertEqual(finding['evidence'], value if present else [])\n")
    assert expected.count(old_line) == 1
    expected = expected.replace(old_line, new_lines, 1)
assert new_test == expected, 'Only the two latest-reference target selections may change'
old_plan = json.loads((prior_path.parent / 'VALIDATION_PLAN.json').read_text())
selectors = old_plan['selectors']
assert observed['argv'][4:] == selectors
trees = {n: ast.parse((root / n).read_text()) for n in
         ('tests/test_report_contract008.py', test_name)}
assert sum(sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_')
               for n in ast.walk(t)) for t in trees.values()) + 2 == 16
assert (root / 'tests/test_revision_static_checkpoint.py').read_bytes() == (
    prior_path.parent / 'sources/tests/test_revision_static_checkpoint.py').read_bytes()
snapshot = {str(p.relative_to(root)): sha(p)
            for directory in (root / 'evidence/construction-v3').glob('source-audit-*')
            if directory.is_dir()
            for p in directory.rglob('*') if p.is_file()}
prefix = ('env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin '
          'GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null PYTHONDONTWRITEBYTECODE=1 '
          'TMPDIR=' + str(root / 'local.scratch') + ' /opt/homebrew/bin/python3 -m machinery.v3_validate '
          '--manifest evidence/construction-v3/source-audit-010/SOURCE_MANIFEST.json '
          '--review local.scratch/source-review-010.json --seconds 180 --label 010-test-finding ')
commands = [dict(command=prefix + ' '.join(selectors),
                 status='PREPARED ONLY; root/source review before tests')]
save(progress, dict(status='Checks complete; writing immutable010 snapshot',
    prior_manifest_sha256=prior_hash, tests_run=False, protected_unchanged=True,
    substantive_changes=substantive, resume_script='local.scratch/freeze010.py'))
out.mkdir(parents=True)
for name in ['INPUT_MANIFEST.json', *input_map]:
    dest = out / 'inputs' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(inputs / name, dest)
shutil.copyfile(__file__, out / 'freeze_sources.py')
(out / 'TEST_ONLY.diff').write_text(''.join(difflib.unified_diff(
    old_test.splitlines(keepends=True), new_test.splitlines(keepends=True),
    fromfile='009/' + test_name, tofile='010/' + test_name)))
save(out / 'VALIDATION_PLAN.json', dict(tests_run=False, selectors=selectors,
    selected_test_methods=16, commands=commands, sequential_only=True,
    gate='STOP: root/source review before tests; root owns any later execution',
    unchanged_controls='Same two-hypothesis fixture, all cases, negatives, state/payload identity and exact equality.'))
save(out / 'PRIOR_EVIDENCE.json', dict(prior_manifest_sha256=prior_hash,
    prior_snapshots_sha256=snapshot, tests_run=False, observed009_returncode=1,
    observed009_log_sha256=sha(inputs / 'observed009-run.log'),
    observed009_intent_sha256=sha(inputs / 'observed009-intent.json'),
    observed009_result_sha256=sha(inputs / 'observed009-result.json'),
    disposition='008 and009 remain failed; all old manifests, snapshots and raw runs unchanged; no010 run or acceptance.'))
save(out / 'PROMPT_INPUT_PROVENANCE.json', dict(inputs_sha256=input_map,
    input_manifest_sha256=sha(inputs / 'INPUT_MANIFEST.json'),
    prompt_source='machinery/study_policy.py:prompt',
    prompt_source_sha256=sha(root / 'machinery/study_policy.py'),
    prompt_function_unchanged009=True, rendered_prompts_executed=False, tests_run=False,
    root_prelaunch_review='Caller-owned prerequisite supplied by ROOT_REQUIREMENTS_010.json',
    independent_frozen_source_audit='Required after freeze and before tests; root owns it'))
save(out / 'STATIC_REVIEW.json', dict(
    method='Source inspection, AST/JSON parsing and streaming hashes only; no candidate imports',
    tests_run=False, compilers_run=False, probes_run=False, campaigns_run=False,
    substantive_changes=substantive, changed_existing_files=delta, protected=protected,
    prior_manifest_sha256=prior_hash,
    scope='Only two positive targets select latest finding matching the corresponding portfolio reference.',
    preserved='ALL prior sources except the two test targets exact009, including machinery/diagnostics, Lean/proof/premise/context/root, resources/caps/model/budgets/seed/curation and installation metadata.',
    installation='009 plan remains held; no apply; no Markov',
    source_checks=['Exact two-line replacement reconstruction of009 test source',
                   'Fixture and all other test code exact009',
                   'Same four selectors and16 methods by AST; not executed',
                   'All other009 manifest files protected byte-identical',
                   'All old snapshot files and manifests hashed before and after']))
paths = set(prior['files_sha256'])
paths.update(str(p.relative_to(root)) for p in prior_path.parent.iterdir() if p.is_file())
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file())
for name in sorted(paths):
    p = root / name
    if p.suffix == '.py':
        ast.parse(p.read_text(), filename=name)
    elif p.suffix == '.json':
        json.loads(p.read_text())
hashes = {n: sha(root / n) for n in sorted(paths)}
changed = {n: h for n, h in hashes.items() if prior['files_sha256'].get(n) != h}
assert {n for n in changed if n in prior['files_sha256']} == {test_name}
for name, expected_hash in snapshot.items():
    assert sha(root / name) == expected_hash, name
for name, expected_hash in hashes.items():
    dest = out / 'sources' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, dest)
    assert sha(dest) == expected_hash
    dest.chmod(0o444)
manifest = dict(schema='math-gkm.frozen-source-audit.v10', invocation='test-finding-correction010',
    created_utc=datetime.now(timezone.utc).isoformat(), tests_run=False, compilers_run=False,
    probes_run=False, campaigns_run=False, files_sha256=hashes, changed_files_sha256=changed,
    substantive_changes=substantive, protected=protected,
    prior_checkpoint=dict(path=str(prior_path.relative_to(root)), sha256=prior_hash),
    source_disposition='INSTALLATION_SOURCE_DISPOSITION.json', installation_plan009='held; no apply; no Markov',
    validation_plan='evidence/construction-v3/source-audit-010/VALIDATION_PLAN.json',
    prompt_input_provenance='evidence/construction-v3/source-audit-010/PROMPT_INPUT_PROVENANCE.json',
    source_copies='sources/<workspace-relative-path>', unshipped_bootstrap_sources_required=False,
    execution_gate='STOP: root/source review before tests; root owns tests/install/restart')
save(out / 'SOURCE_MANIFEST.json', manifest)
(out / 'SOURCE_MANIFEST.sha256').write_text(sha(out / 'SOURCE_MANIFEST.json') + '  SOURCE_MANIFEST.json\n')
for p in out.rglob('*'):
    if p.is_file():
        p.chmod(0o444)
result = dict(checkpoint=str(out.relative_to(root)), sha256=sha(out / 'SOURCE_MANIFEST.json'),
    substantive_changes=substantive, files=len(hashes), protected_unchanged=True,
    prior_snapshots_unchanged=True, tests_run=False, prepared_selectors=selectors,
    selected_test_methods=16, test_only_diff=str((out / 'TEST_ONLY.diff').relative_to(root)),
    installation_plan009='held; no apply; no Markov',
    status='STOP: root/source review before tests')
save(progress, result)
print(json.dumps(result))
