"""Adapted from freeze008: narrow009 source freeze; no candidate imports/execution."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

root = Path.cwd()
out = root / 'evidence/construction-v3/source-audit-009'
assert not out.exists(), '009 is immutable; never overwrite or retry'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

prior_path = root / 'evidence/construction-v3/source-audit-008/SOURCE_MANIFEST.json'
prior = json.loads(prior_path.read_text())
prior_hash = sha(prior_path)
assert (prior_path.parent / 'SOURCE_MANIFEST.sha256').read_text().split()[0] == prior_hash
progress_path = root / 'local.scratch/REPAIR009_PROGRESS.json'
assert json.loads(progress_path.read_text())['prior_manifest_sha256'] == prior_hash
substantive = ['machinery/study_policy.py', 'tests/test_role_report_contract.py']
metadata = {'CONSTRUCTION_V3_AUDIT.json', 'INSTALLATION_SOURCE_DISPOSITION.json'}
allowed = set(substantive) | metadata
delta = {n: sha(root / n) for n, h in prior['files_sha256'].items() if sha(root / n) != h}
assert set(delta) <= set(substantive), set(delta) - set(substantive)
inputs = root / '.bootstrap/hypothesis-evidence-009-inputs'
input_map = json.loads((inputs / 'INPUT_MANIFEST.json').read_text())
for name, expected in input_map.items():
    assert sha(inputs / name) == expected, name
observed = json.loads((inputs / 'observed008-intent.json').read_text())
assert observed['manifest_sha256'] == prior_hash
result008 = json.loads((inputs / 'observed008-result.json').read_text())
assert result008['log_sha256'] == sha(inputs / 'observed008-run.log')
assert result008['returncode'] == 1
snapshot = {str(p.relative_to(root)): sha(p)
            for p in (root / 'evidence/construction-v3').glob('source-audit-00[1-8]/**/*') if p.is_file()}
protected = {n: dict(before=h, after=sha(root / n), unchanged=h == sha(root / n))
             for n, h in prior['files_sha256'].items() if n not in allowed}
assert all(r['unchanged'] for r in protected.values())
# Exact-text reversal confines the sole runtime delta to the missing binding.
old_policy = (prior_path.parent / 'sources/machinery/study_policy.py').read_text()
new_policy = (root / 'machinery/study_policy.py').read_text()
set_insert = "    evidence_paths = {item['path'] for item in evidence}\n"
binding_insert = """        hypothesis_evidence = h.get('evidence', [])
        if not isinstance(hypothesis_evidence, list) or not all(
                isinstance(path, str) and path in evidence_paths for path in hypothesis_evidence):
            raise Invalid('hypothesis evidence not bound to actual artifacts')
"""
assert new_policy.count(set_insert) == new_policy.count(binding_insert) == 1
assert new_policy.replace(set_insert, '', 1).replace(binding_insert, '', 1) == old_policy
assert new_policy.index(set_insert) > new_policy.index('        evidence.append(item)')
assert new_policy.index(binding_insert) < new_policy.index("        original=state['portfolio'].get(h['id'])")
# The original negative and every other test method remain exact; only append locally.
test_name = 'tests/test_role_report_contract.py'
old_test = (prior_path.parent / 'sources' / test_name).read_text()
new_test = (root / test_name).read_text()
start = '    def test_intentions_cannot_become_evidence_or_checked_facts(self):\n'
end = '    def test_cached_invalid_plan_is_not_repaired_replayed_or_recharged(self):\n'
old_before, old_tail = old_test.split(start, 1)
new_before, new_tail = new_test.split(start, 1)
old_method, old_after = old_tail.split(end, 1)
new_method, new_after = new_tail.split(end, 1)
assert old_before == new_before and old_after == new_after
assert new_method.startswith(old_method.rstrip('\n') + '\n')
old_plan = json.loads((prior_path.parent / 'VALIDATION_PLAN.json').read_text())
selectors = old_plan['selectors']
# Same four selectors expand to the same16 methods; count AST definitions without imports.
trees = {n: ast.parse((root / n).read_text()) for n in
         ('tests/test_report_contract008.py', 'tests/test_role_report_contract.py')}
assert sum(sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_')
               for n in ast.walk(t)) for t in trees.values()) + 2 == 16
prefix = ('env PATH=/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin '
          'GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null PYTHONDONTWRITEBYTECODE=1 '
          'TMPDIR=' + str(root / 'local.scratch') + ' /opt/homebrew/bin/python3 -m machinery.v3_validate '
          '--manifest evidence/construction-v3/source-audit-009/SOURCE_MANIFEST.json '
          '--review local.scratch/source-review-009.json --seconds 180 --label 009-hypothesis-evidence ')
commands = [dict(command=prefix + ' '.join(selectors), status='PREPARED ONLY; independent frozen source audit first')]
out.mkdir(parents=True)
for name in ['INPUT_MANIFEST.json', *input_map]:
    dest = out / 'inputs' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(inputs / name, dest)
shutil.copyfile(__file__, out / 'freeze_sources.py')
save(out / 'VALIDATION_PLAN.json', dict(tests_run=False, selectors=selectors, selected_test_methods=16,
    commands=commands, sequential_only=True,
    gate='STOP: independent frozen source audit before tests; root owns tests, installation and fresh restart',
    unchanged_controls='Original negative retained verbatim; no model or real campaign; same16 selected methods.'))
save(out / 'PRIOR_EVIDENCE.json', dict(prior_manifest_sha256=prior_hash,
    prior_snapshots_sha256=snapshot, tests_run=False, observed008_returncode=1,
    observed008_log_sha256=sha(inputs / 'observed008-run.log'),
    disposition='008 observed15pass/1fail remains failed; all001-008 snapshots/raw failures unchanged; no rerun or acceptance.'))
save(out / 'PROMPT_INPUT_PROVENANCE.json', dict(inputs_sha256=input_map,
    input_manifest_sha256=sha(inputs / 'INPUT_MANIFEST.json'),
    prompt_source='machinery/study_policy.py:prompt', prompt_source_sha256=sha(root / 'machinery/study_policy.py'),
    prompt_function_unchanged008=True, rendered_prompts_executed=False, tests_run=False,
    root_prelaunch_review='Caller-owned prerequisite supplied by ROOT_REQUIREMENTS_009.json; no separate constructor attestation',
    independent_frozen_source_audit='Required after freeze and before tests; root owns it'))
save(out / 'STATIC_REVIEW.json', dict(method='Source inspection, AST/JSON parsing and streaming hashes only; no candidate imports',
    tests_run=False, compilers_run=False, probes_run=False, campaigns_run=False,
    substantive_changes=substantive, changed_existing_files=delta, protected=protected,
    prior_manifest_sha256=prior_hash,
    scope='Only short hypothesis evidence list/string/current validated evidence-path binding before hypothesis storage; same-method assertions appended.',
    preserved='All008 namespace/typed diagnostics, immutable current/historic/staged versions, other runtime, proofs, roots, resources, model/budget/curation/seed/comparison sources exact008.',
    source_checks=['Runtime exact008 after reversing only the two binding insertions',
                   'Original failing assertion and all other test methods exact008',
                   'Same four selectors and16 methods by AST; not executed',
                   'All protected prior manifest sources exact008; all001-008 snapshots streamed and preserved']))
paths = set(prior['files_sha256']) | set(substantive)
paths.update(str(p.relative_to(root)) for p in prior_path.parent.iterdir() if p.is_file())
paths.update(str(p.relative_to(root)) for p in out.rglob('*') if p.is_file())
for name in sorted(paths):
    p = root / name
    if p.suffix == '.py':
        ast.parse(p.read_text(), filename=name)
    elif p.suffix == '.json':
        json.loads(p.read_text())
disposition = json.loads((root / 'INSTALLATION_SOURCE_DISPOSITION.json').read_text())
for name in sorted(paths - metadata):
    old = disposition['artifacts'].get(name, {})
    disposition['artifacts'][name] = dict(sha256=sha(root / name), disposition=old.get('disposition',
        'archive exact009 source/provenance; no acceptance' if name.startswith('evidence/') else 'ship source after root audit'))
disposition['metadata_bound_by'] = 'source-audit-009/SOURCE_MANIFEST.json binds exact install map and current audit'
disposition['runtime_and_acceptance_overlay'] = sorted(set(disposition['runtime_and_acceptance_overlay']) | set(substantive))
disposition['meaning'] = 'Source disposition only; no installation/activation; root owns tests/install/restart after independent frozen source audit. All failed runs preserved.'
save(root / 'INSTALLATION_SOURCE_DISPOSITION.json', disposition)
old_audit = json.loads((root / 'CONSTRUCTION_V3_AUDIT.json').read_text())
remaining = ['Independent frozen source audit009 before tests; STOP',
             'tests_run=false; root owns tests, installation and any clean restart',
             'Observed008 failure and all prior evidence preserved; no runtime acceptance claimed']
audit = {**old_audit, 'invocation': 'hypothesis-evidence-repair009',
    'status': 'FROZEN source only; STOP for independent frozen source audit',
    'checkpoint': 'evidence/construction-v3/source-audit-009/SOURCE_MANIFEST.json',
    'prior_checkpoint': dict(manifest=str(prior_path.relative_to(root)), sha256=prior_hash),
    'changed_files_sha256': {n: sha(root / n) for n in paths if n not in metadata and prior['files_sha256'].get(n) != sha(root / n)},
    'protected': protected, 'tests_run': False, 'compilers_run': False, 'preflights_run': False,
    'probes_run': False, 'campaigns_launched': False, 'approved_inputs_sha256': input_map,
    'actual_prior_evidence': dict(checkpoint008_manifest_sha256=prior_hash, observed008_returncode=1,
        disposition='008 retains15pass/1fail; raw log unchanged; no009 execution'),
    'planned_commands': commands, 'remaining': remaining, 'substantive_changes': substantive}
save(root / 'CONSTRUCTION_V3_AUDIT.json', audit)
hashes = {n: sha(root / n) for n in sorted(paths)}
changed = {n: h for n, h in hashes.items() if prior['files_sha256'].get(n) != h}
assert set(n for n in changed if n in prior['files_sha256']) <= allowed
for name, expected in snapshot.items():
    assert sha(root / name) == expected, name
for name, expected in hashes.items():
    dest = out / 'sources' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, dest)
    assert sha(dest) == expected
    dest.chmod(0o444)
manifest = dict(schema='math-gkm.frozen-source-audit.v9', invocation='hypothesis-evidence-repair009',
    created_utc=datetime.now(timezone.utc).isoformat(), tests_run=False, compilers_run=False,
    probes_run=False, campaigns_run=False, files_sha256=hashes, changed_files_sha256=changed,
    substantive_changes=substantive, protected=protected,
    prior_checkpoint=dict(path=str(prior_path.relative_to(root)), sha256=prior_hash),
    source_disposition='INSTALLATION_SOURCE_DISPOSITION.json',
    validation_plan='evidence/construction-v3/source-audit-009/VALIDATION_PLAN.json',
    prompt_input_provenance='evidence/construction-v3/source-audit-009/PROMPT_INPUT_PROVENANCE.json',
    source_copies='sources/<workspace-relative-path>', unshipped_bootstrap_sources_required=False,
    execution_gate='STOP: independent frozen source audit before tests; root owns tests, installation and any clean restart')
save(out / 'SOURCE_MANIFEST.json', manifest)
(out / 'SOURCE_MANIFEST.sha256').write_text(sha(out / 'SOURCE_MANIFEST.json') + '  SOURCE_MANIFEST.json\n')
for p in out.rglob('*'):
    if p.is_file():
        p.chmod(0o444)
result = dict(checkpoint=str(out.relative_to(root)), sha256=sha(out / 'SOURCE_MANIFEST.json'),
    substantive_changes=substantive, files=len(hashes), protected_unchanged=True,
    prior_snapshots_unchanged=True, tests_run=False, prepared_selectors=selectors,
    status='STOP: independent frozen source audit; root owns tests/install/restart')
save(progress_path, result)
print(json.dumps(result))
