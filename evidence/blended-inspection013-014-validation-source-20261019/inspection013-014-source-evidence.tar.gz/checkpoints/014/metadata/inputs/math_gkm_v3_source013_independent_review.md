# Preserved checkpoint013 independent source review

Final source-only review, 2026-10-19. Reviewer /root/blend_source_review.
Exact candidate /Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018.
Manifest evidence/construction-v3/source-audit-013/SOURCE_MANIFEST.json SHA256 b7f0e1f0d76ed9233b61321ce39f123c80a954ac436e66d7a885cbc12700558c.

## Source-only disposition and invocation boundary

Cleared on SOURCE-SAFETY grounds for root-authorized bounded sequential pure/parser, two individual producer and focused neutral deployment-fixture tests. No tests, compilers, behavioral imports, hosted model calls, implementation edits or mathematical research were performed by reviewer. Not functional acceptance, installation/campaign activation or a successful constructor-run receipt.

The source checkpoint was preserved before the independent constructor invocation ended with TimeoutError at360.198seconds under its360-second construction bound (outer allowance420). Child process exit0 does not change outer/launcher exit1, and this review does not relabel that invocation successful. Review is of the exact immutable source bytes and their finite testability. Actual013 tests remain unexecuted at this review cutoff. Preserve012's28PASS and producer1FAIL/1ERROR exactly, including primary Stream collision and downstream absent failure metadata.

Independently streamed/rehashed all367 frozen copies and live files: zero mismatches, no012 manifest entries removed. Manifest metadata hashes match. Protected before/after dictionaries are equal:38 base entries plus15 recursively inventoried mathematical Lean files,49 distinct protected paths after overlap, all checked against current bytes. All original mathematical Lean, root/contract/pin/resource/study/model inputs are unchanged.

Seven intended substantive paths: six changed existing paths (INSTALLATION_SOURCE_DISPOSITION.json; machinery/inspection_stream.py; machinery/study_deployment.py; tests/test_inspection011_fixture.py; tests/test_inspection012.py; tests/test_sol_deployment.py) and new docs/inspection013.md. No other runtime consumer was changed from012.

## Generated Lean helper namespace

The entire PRELUDE opens MathGKMTrustedInspection013 before defining helpers, including Stream and M, so the private structure no longer occupies the conflicting root Stream namespace. program() closes the same namespace after its generated command. Both producer-test source constructions that append commands to PRELUDE now close that namespace after their command bodies. No Expr tags/fields, pointer-cache semantics, full catalog/type/opaque/inductive/axiom/use traversal, byte/node/work guard, fresh nonce, digest, completion marker, parser or receipt semantics were altered. Actual compilation and SHA/vector completion remain tests to run, not source-review conclusions.

Producer test subprocess records are now retained before assertions. Guard tests retain nullable failure diagnostics and the raw-record hash, then explicitly require non-null authenticated failure evidence, actual exit1 and no termination before checking category and measured bound. A compilation failure can no longer be mistaken for a successful capacity boundary observation, though it will still correctly fail the test.

## Exact missing-required neutral control

The negative fixture's task metadata and effective required argument now BOTH equal exactly ['MathGKM.DeploymentRoot.Root'], while the proof still uses DeploymentRoot.identity for the original neutral proposition. This preserves the intended actual-use failure instead of substituting a different theorem or accepting an unused catalog entry.

accepted_controls delegates this negative to missing_required_control with the own attempt's directory/workspace/task/solution binding. That verifier requires finished-validator.v3 reuse with exact task/solution/required and all file/pin/binary checks; exact returned result equality; checked:false/deployed_sandbox/stage trusted_premise_inspection/no infrastructure flag; exact effective required list and task hash; original root source hash; regenerated trusted inspector with the one nonce extracted from its generated source, required list and actual MathGKM inventory; exact StudyCheck wrapper and frozen target source; context source bytes; expected binary/pin sets; actual successful preceding compile and kernel replay records for every staged module; final genuine inspector exit1 with no timeout/termination/operationally-incomplete flag; sandbox-prefixed argv and profile identity; regular nonlink artifact; and agreement of both nonce-bound typed failure control and bounded regular failure artifact with category missing_required, plus matching stored diagnostic evidence.

Failure prose and mere checked:false do not authorize a successful negative control. Missing/malformed artifact, missing FINISHED, mismatching list or nonce/token, unsupported category, signal, timeout/output/resource failure, earlier compile failure and incomplete process reject. This is a stricter neutral deployment-readiness check, not an expansion of production mathematical admission. It consumes a failure receipt and does not claim that the missing-required theorem has been disproved. Source/premise/required-use production gates stay unchanged012.

The ordinary positive still imports full Mathlib, proves the exact neutral identity and requests actual identity use. Wrong-target still requires actual StudyCheck type-mismatch elaboration exit1. Completion still requires lean_exact_root_checked:true, resolved:false, and the exact independent source/English correspondence-audit rejection for the bundle. No synthetic negative replaces the original real integration controls.

## Neutral completion arm and tests

NeutralArm supplies an ordinary baseline research state, study/root/workspace/round/status, durable fsync-backed save, durable reservation list and original stop callback. Actual unresolved study_completion.check can now retain own feedback and save the arm without KeyError/AttributeError from the former stand-in. The fixture is deliberately neutral_unresolved; it cannot supply an independent English audit.

The focused orchestration regression now calls real study_completion.check and stubs only expensive completion.verify. It asserts one reservation, no audit, durable unresolved state, immutable feedback file/hash and both future proposer/researcher request projections even with keep_observations=0. The missing-control helper uses synthetic process records with real generated sources/failure-file/finished-receipt authentication, explicitly labeled synthetic. Such tests establish interface/control behavior, not actual kernel/sandbox success. Actual deployed preflight is still required later. Other existing negative scenarios remain present.

## Metrics, historical inspector and disposition

Supervisor fixture measurement runs in finally. It records returned raw result or exception, nullable result/FINISHED hashes, FINISHED presence, existing artifact size/traversal/process metrics and raw path without altering original raw result bytes. Checker/finalization failure is retained as failure, then propagates. Mathematical acceptance tests separately require an actual reusable finished receipt. These engineering exception messages are not exported as own research feedback.

Old010 differential remains inspector-only on the same freshly rebuilt/replayed objects; it does not run an old check_task with current receipt code. In addition to checking extracted old inspector bytes against its manifest, the test now directly requires the exact externally anchored old manifest SHA91849c3534793fc2c9b0c77303816bc3d7c322b310eb09d5a9745734953cbd7b. Separate immutable supervisor fixtures/identity pairs and extracted published010 inputs remain prerequisites, never research seed material.

The final disposition now enumerates inspection_stream.py, own_feedback.py, inspection011/012/013 docs and focused test sources in the explicit runtime/acceptance overlay. All existing listed artifact hashes agree with the exact013 manifest entries. Current inspection013 metadata identifies wire schema3, Expr identity2, source-only state and no installation; manifest binds final disposition without a self/circular hash. Historical inspection011 fields/wording remain historical and are not current installation authority. Candidate-only MathGKM.lean is explicitly excluded to preserve installed historical imports/API. Any eventual installation still needs its own reviewed exact overlay and must preserve root-maintained docs/history, not blindly overwrite them from this candidate.

## Exact bounded next selectors

Pure focused fixtures:
- tests.test_sol_deployment.SolDeployment.test_control_criteria_reject_infrastructure_negatives_and_unwrapped_evidence
- tests.test_sol_deployment.SolDeployment.test_missing_root_rejects_mismatch_spoof_and_infrastructure
- tests.test_sol_deployment.SolDeployment.test_neutral_arm_reservation_and_stop_are_durable
- tests.test_sol_deployment.SolDeployment.test_preflight_control_flow_keeps_all_validation_on_live_path

Retain the existing prepared tests.test_inspection012.Entrypoints012, Parser005, Compact011/Feedback011 and008/009 report controls. After pure results, run the same two individual Producer012 methods sequentially under operational/resource monitoring: test_sha256_vectors_chunking_and_completed_producer_consumer; test_producer_actual_record_and_total_bounds_ingest_requests. Their60-second per-subprocess limits, no model calls and unchanged caps remain binding. Do not invoke the whole derived Producer class and count inherited duplicate pure tests as new independent evidence.

Only after these results and a separate root decision should actual deployed full-Mathlib preflight, original mathematical negatives, immutable original public ten-module capacity closure and exact old010 inspector differential run. Preserve actual source/nonce/receipt bindings and operational-versus-mathematical distinctions. No fixture trimming, changed goal, larger caps, hinted mathematics, installation or research campaign follows from this source clearance.

No new source-safety blocker identified. Ordinary Lean/Python/fixture failures may still be found by these finite tests and must be retained. This closed memo must not be relabeled functional success; subsequent execution requires its own receipts.
