"""Root-authorized engineering validation of ONE unchanged public proof closure."""
import hashlib,json,os,sys,time,unittest
from pathlib import Path
BASE=Path('/Users/sasha/math_gkm/.scratch/strategy-v3-blended-20261018')
OPS=Path('/Users/sasha/math_gkm/.bootstrap/construction-v3-20261018')
sys.path.insert(0,str(BASE))
MANIFEST=BASE/'evidence/construction-v3/source-audit-014/SOURCE_MANIFEST.json'
EXPECTED='86b321c9628ce7493c89e06ab0000050375974fd7fe10c1c28181e5467e8ee3f'
FIXTURE='26438fcf09ee851c40abd70727007e75d859357e185d5d2626208efb92b493c1'
OUT=BASE/'.scratch/v3-validation/cp014-largepilot-v2'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def changed():
    assert sha(MANIFEST)==EXPECTED
    return [r for r,h in json.loads(MANIFEST.read_text())['files_sha256'].items() if sha(BASE/r)!=h]
class ExactLargePilot(unittest.TestCase):
    def test_original_large_pilot(self):
        from tests.test_inspection011_fixture import Supervisor011
        from machinery import proof_audit
        from machinery.validation_receipts import reuse
        from machinery.study_transfer import bind_task
        helper=Supervisor011('runTest')
        cases=helper.inputs()['cases']
        case=next(c for c in cases if c['tag']=='large_pilot')
        self.assertEqual(case['seconds'],900)
        self.assertEqual(case['provenance']['historical_checked'],False)
        origin=BASE/case['source_directory']
        before={r:sha(origin/r) for r in case['files_sha256']}
        self.assertEqual(before,case['files_sha256'])
        result=None
        try:
            # Match the ordinary deployed workspace dependency layout exactly.
            # The fixture helper's whole-directory link adds a lexical link chain
            # outside the approved sandbox metadata paths.
            def ordinary_layout_checker(workspace,*args,**kwargs):
                from machinery.study_common import dependencies
                from machinery.study_transfer import check_task
                packages=workspace/'.lake/packages'
                self.assertTrue(packages.is_symlink())
                self.assertEqual(packages.resolve(),(BASE/'.lake/packages').resolve())
                packages.unlink()
                dependencies(workspace)
                self.assertFalse(packages.is_symlink())
                return check_task(workspace,*args,**kwargs)
            result=helper.run_case(case,checker=ordinary_layout_checker)
            check=helper.last_check_directory
            self.assertTrue((check/'FINISHED.json').is_file(),result)
            task=case['task'] if 'target_module' in case['task'] else bind_task(check.parent/'workspace',case['task'])
            self.assertEqual(reuse(check,task,case['solution'],case['required']),json.loads(json.dumps(result)))
            self.assertIs(result['checked'],True,result)
            self.assertEqual({c['operation'] for c in result['checks']},{'compile','kernel_replay','trusted_premise_inspection'})
            self.assertEqual(result['inspection_schema'],proof_audit.SCHEMA)
            self.assertTrue(result['declarations'])
            for declaration in result['declarations']:
                self.assertLessEqual(set(declaration['axioms']),{'propext','Classical.choice','Quot.sound'})
            for record in result['checks']:
                self.assertEqual(record['returncode'],0,record)
                self.assertIsNone(record.get('termination'),record)
                self.assertFalse(record.get('operationally_incomplete'),record)
            self.assertEqual({r:sha(check.parent/'workspace'/r) for r in before},before)
            write(OUT/'ASSERTIONS.json',dict(checked=True,check_directory=str(check),
                FINISHED_sha256=sha(check/'FINISHED.json'),result_sha256=sha(check/'result.json'),
                actual_operations=[c['operation'] for c in result['checks']],
                axioms=[d['axioms'] for d in result['declarations']],
                original_math_context_hashes=before,task_hash=case['task_hash'],
                solution_hash=case['solution_hash'],required=case['required'],
                original_900second_budget_preserved=True,fresh_receipt_reuse_exact=True,
                scope='Public unchanged machine-authored restricted-branch theorem, not general conjecture'))
        finally:
            after={r:sha(origin/r) for r in before}
            write(OUT/'FIXTURE_SOURCE_AFTER.json',dict(before=before,after=after,unchanged=before==after))
            self.assertEqual(after,before)
def main():
    if '--child' in sys.argv:
        os.environ['GKM_INSPECTION011_FIXTURE_SHA256']=FIXTURE
        suite=unittest.defaultTestLoader.loadTestsFromTestCase(ExactLargePilot)
        return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1
    from machinery.process import run
    assert changed()==[]
    assert sha(BASE/'local.scratch/inspection011-fixture.json')==FIXTURE
    OUT.mkdir(parents=True,exist_ok=False)
    write(OUT/'intent.json',dict(source_manifest_sha256=EXPECTED,fixture_sha256=FIXTURE,
        selected_tag='large_pilot',validator_seconds=900,runner_seconds=960,
        own_operator_sha256=sha(Path(__file__)),authorized_scope='root approved ONE unchanged public proof closure only'))
    start=time.monotonic();record={};reason=None
    try:
        env={**os.environ,'PATH':'/opt/homebrew/bin:/Users/sasha/.elan/bin:/usr/bin:/bin',
             'TMPDIR':str(BASE/'.scratch'),'PYTHONDONTWRITEBYTECODE':'1',
             'GKM_INSPECTION011_FIXTURE_SHA256':FIXTURE}
        record=run([sys.executable,str(Path(__file__).resolve()),'--child'],cwd=BASE,env=env,
            timeout=960,output_bytes=8*1024**2,scope=BASE/'.scratch',tree_only=True,log_path=OUT/'run.log')
        reason=record.get('termination')
    except (OSError,ValueError,KeyboardInterrupt) as exc:reason=type(exc).__name__+': '+str(exc)
    finally:
        write(OUT/'result.json',dict(returncode=record.get('returncode'),termination=reason,
            resources=record.get('resources'),wall_seconds=time.monotonic()-start,
            source_mismatches_after=changed(),log_sha256=sha(OUT/'run.log') if (OUT/'run.log').exists() else None,
            source_manifest_sha256=EXPECTED,fixture_sha256=FIXTURE,
            scope='Engineering validation only; no installed admission, root resolution or fresh research seed'))
    return 1 if reason or changed() else record.get('returncode',1)
if __name__=='__main__':raise SystemExit(main())
