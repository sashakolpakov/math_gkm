# Exact prompt-context source reproduction

This packet preserves implementation d7c3f043e81417605553e9e034415bff90fa2736f9e91d6ce41538a715891957 and the exact two pure test files (17 existing plus 10 new). The repository root at the pinned public parent retains an earlier published implementation; overlaying only study_context.py there would mix versions. This packet supplies all 76 implementation files instead.

Use a NEW disposable copy/worktree of a normally prepared public checkout at commit 1b71692b08f4f61157240d710bb6bd4e582023d9. Do not overlay a running campaign or a checkout containing private work. Preparation of external pinned dependencies/toolchain is outside this packet; pins/configuration are retained, binaries and dependency caches are not. The pure fixtures use Python standard-library mocks and do not launch compilers, models or native research workers. This is not a claim of a standalone installed proof environment.

Extract this archive into a separate empty directory. Before copying anything, verify that every regular member except MANIFEST.json occurs in its files map with its exact raw-file SHA256. Reject duplicate paths, links and parent-directory traversal. Verify SHA256 of sorted compact UTF-8 JSON for the manifest implementation object equals its implementation_sha256. Copy source/. onto the disposable prepared public checkout (including tests and pinned config). The pinned public parent's implementation-scanned filename set is exactly the packet's 76 entries, so no deletion is required. Verify every implementation and source input hash again after copying. There are intentionally no machinery/__init__.py or tests/__init__.py inputs: both are namespace directories in this version.

In that disposable checkout, the following explicit local-module recipe avoids accidentally importing an unrelated installed tests or machinery package. It runs the exact included 27 tests, rather than a broad repository suite:

```sh
python3 -B - <<'PYTEST'
from pathlib import Path
import importlib.machinery, importlib.util, os, signal, subprocess, sys, types, unittest
from unittest.mock import patch
root = Path.cwd().resolve()
pkg = types.ModuleType('machinery')
pkg.__package__ = 'machinery'
pkg.__path__ = [str(root / 'machinery')]
pkg.__spec__ = importlib.machinery.ModuleSpec('machinery', loader=None, is_package=True)
sys.modules['machinery'] = pkg
suite = unittest.TestSuite()
def blocked(*args, **kwargs):
    raise AssertionError('external process, shell or signal prohibited in pure fixtures')
with patch.object(subprocess, 'Popen', side_effect=blocked), patch.object(subprocess, 'run', side_effect=blocked), patch.object(os, 'system', side_effect=blocked), patch.object(os, 'kill', side_effect=blocked), patch.object(signal, 'signal', side_effect=blocked):
    for i, name in enumerate(('test_study_context_transport.py', 'test_study_context_compaction.py')):
        spec = importlib.util.spec_from_file_location('pure_context_fixture_' + str(i), root / 'tests' / name)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
PYTEST
```

Recorded evidence/CHECKS.json reports the earlier 27 author and 7 independent synthetic controls on these bound source bytes. This extracted recipe was NOT rerun during preservation; current packaging checks were static imports, member hashes and Git mechanics only. Those checks do not prove a theorem or certify machine self-change. No complete campaign replay is asserted.

The existing accepted64 proof artifact is preserved separately and unchanged: evidence/accepted-checkpoint-20261020.tar.gz SHA256 1ef1cde454c2b868a8f8914f4ffdbd0e34ae2dabeaba1efc5ac6fb143f027f79 at the pinned public parent. Its original proof/controller identities remain historical. No accepted proof, runtime state, authority, request, hidden comparison or active draft is included here.
